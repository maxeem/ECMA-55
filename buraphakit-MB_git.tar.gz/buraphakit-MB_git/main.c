//
// main.c - This is the file containing main() and options processing
//          for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
static const char *const license_msg = "\
Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021,2023  John Gatewood Ham\n\
\n\
This file is part of ecma55.\n\
\n\
ecma55 is free software; you can redistribute it and/or modify\n\
it under the terms of the GNU General Public License version 2\n\
as published by the Free Software Foundation.\n\
\n\
ecma55 is distributed in the hope that it will be useful,\n\
but WITHOUT ANY WARRANTY; without even the implied warranty of\n\
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n\
GNU General Public License for more details.\n\
\n\
You should have received a copy of the GNU General Public License\n\
along with ecma55.  If not, see <http://www.gnu.org/licenses/>.\n\
\n\
The assembly code used to implement ACOS, ANGLE, ASIN, ATAN, COS,\n\
COSH, EXP, LOG, LOG10, LOG2, SIN, SINH, TAN, and TANH is from Naoki\n\
Shibata's SLEEF-3.5.1 under the Boost Software License Version 1.0.\n\
You should have received a copy of the Boost Software License along\n\
with ecma55.  If not, see\n\
<http://www.boost.org/LICENSE_1_0.txt>.\n\
\n\
The floating point conversion code from David M. Gay is free to use\n\
but it is under Copyright (c) 1991, 1996 by Lucent Technologies.\n\
\n\
The code implementing RND and RANDOMIZE is derived from Bob Jenkins'\n\
ISAAC64, and is in the public domain.\n\
\n\
The code for accessing the timezone database and converting date and\n\
time to localtime is derived from David Olson's Time Zone Database,\n\
and is in the public domain.\n\
\n\
The code for accessing the Linux vDSO come from the Linux kernel\n\
and was written by Andrew Lutomirski.  That code uses the Createive\n\
Commons Zero license for the reference vDSO parser and the GNU GPL\n\
v2.0 only for the stack walking and pointer setup code run at program\n\
startup that uses that reference parser.  You should have received a\n\
copy of the Creative Commons Zero license along with ecma55.  If not,\n\
see\n\
<http://creativecommons.org/publicdomain/zero/1.0/legalcode>.\n\
\n\
The code for the zlib decompression code was written by Mark Adler\n\
and is from the zlib contrib directory from zlib-1.2.11.  I added some\n\
type casts to silence some warnings.\n\
";

#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
#include <math.h>
#include <fenv.h>
#include <fcntl.h>
#if defined(__linux__)
#include <sys/utsname.h>
#endif
//
// The FOSS compilers refuse to implement this standard feature
//
// #if defined(__STDC_IEC_559__) && ( __STDC_IEC_559__ == 1 )
#ifdef __GLIBC__
#include <malloc.h>
#endif
#include "globals.h"
#include "error_messages.h"
#include "scanner3.h"
#include "parser2.h"
#include "symbol_table.h"
#include "codegen.h"
#include "peephole.h"
#include "load_textdata.h"
#include "textdata.h"

static char errbuffer[4096] = { 0 };    // error message buffer
static bool use_peephole = true;        // use peephole scanner

static void show_version(const char *progname);
static void show_long_licenses(void);
static void ecma55_usage(const char *progname);
static char *load_file_into_buffer(const char *filename, uint64_t *bytecount);
static int process_command_line_arguments(int *argc, char **argv, char **outname);

//
// This procedure will print the version of the program.  The program
// parameter is the program name obtained from main's first magic argument.
//
static void show_version(
    const char *progname) {
  size_t rez;
  char buf[120] = {0};
  bool ok2run=false;           // true if the platform where ecma55 runs
                               // is AMD64/EM64T/INTEL-64/x86-64 Linux
#if defined(__linux__)
  struct utsname superbuf;
#endif

  printf("ecma55 version %s\n"
         "Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021,2023  John Gatewood Ham\n"
         "Compiler License is GNU GPL version 2 ONLY\n"
         "Executable was invoked with name '%s'\n", version, progname);
  rez = confstr(_CS_GNU_LIBC_VERSION, buf, 120);
  if (rez < 1) strcpy(buf, "unknown libc");
  printf("Using %s\n", buf);
#if defined(__clang__)
  printf("Built with what claims to be LLVM/clang version %u.%u.%u\n",
         __clang_major__, __clang_minor__, __clang_patchlevel__);
  fputs("Program was built using ", stdout);
#if defined(__code_model_large__)
  fputs("the large", stdout);
#elif defined (__code_model_medium__)
  fputs("the medium", stdout);
#elif defined (__code_model_small__)
  fputs("the small", stdout);
#else
  fputs("an unknown", stdout);
#endif
  puts(" code model.");
#if defined(__has_feature)
  fputs("It is ", stdout);
#if !__has_feature(address_sanitizer)
  fputs("not ", stdout);
#endif
  puts("using AddressSanitizer.");
#endif
  fputs("It uses ", stdout);
#if defined(__SSP__)
  fputs("the ", stdout);
#elif defined(__SSP_ALL__)
  fputs("the all ", stdout);
#elif defined(__SSP_STRONG__)
  fputs("the strong ", stdout);
#else
  fputs("no ", sdtout);
#endif
  puts("stack protector.");
  fputs("It uses ",stdout);
#if defined(__CET__)
#if __CET__ == 1
  fputs("branch ", stdout);
#elif __CET__ == 2
  fputs("return ", stdout);
#elif __CET__ == 3
  fputs("full ", stdout);
#else
  fputs("unknown ", stdout);
#endif
#else
  fputs("no ", stdout);
#endif
  puts("control-flow protection.");
#elif defined(__TINYC__)
  {
    int a,b,c;
    a=(int)(__TINYC__/10000);
    b=(int)((__TINYC__-(__TINYC__*a*10000))/100);
    c=(int)(__TINYC__%100);
    printf("Built with what claims to be tcc version %u.%u.%u\n",a,b,c);
  }
#if defined(__BOUNDS_CHECKING_ON)
  printf("Bounds checking is on\n");
#else
  printf("Bounds checking is off\n");
#endif
#elif defined(__PCC__)
  printf("Built with what claims to be pcc version %u.%u.%u\n",
         __PCC__,__PCC_MINOR__,__PCC_MINORMINOR__);
  fputs("It uses ", stdout);
#if defined(__SSP__)
  fputs("the ", stdout);
#else
  fputs("no ", stdout);
#endif
  puts("stack protector.");
#elif defined(__GNUC__)
  printf("Built with what claims to be gcc version %u.%u.%u\n",
         __GNUC__,__GNUC_MINOR__,__GNUC_PATCHLEVEL__);
  fputs("Program was built using ", stdout);
#if defined(__code_model_large__)
  fputs("the large", stdout);
#elif defined (__code_model_medium__)
  fputs("the medium", stdout);
#elif defined (__code_model_small__)
  fputs("the small", stdout);
#else
  fputs("an unknown", stdout);
#endif
  puts(" code model.");
  fputs("It is ", stdout);
#if !defined(__SANITIZE_ADDRESS__)
  fputs("not ", stdout);
#endif
  puts("using AddressSanitizer.");
  fputs("It uses ", stdout);
#if defined(__SSP__)
  fputs("the ", stdout);
#elif defined(__SSP_ALL__)
  fputs("the all ", stdout);
#elif defined(__SSP_STRONG__)
  fputs("the strong ", stdout);
#elif defined(__SSP_EXPLICIT__)
  fputs("the explicit ", stdout);
#else
  fputs("no ", stdout);
#endif
  puts("stack protector.");
  fputs("It uses ",stdout);
#if defined(__CET__)
#if __CET__ == 1
  fputs("branch ", stdout);
#elif __CET__ == 2
  fputs("return ", stdout);
#elif __CET__ == 3
  fputs("full ", stdout);
#elif __CET__ == 8
  fputs("check ", stdout);
#else
  fputs("unknown ", stdout);
#endif
#else
  fputs("no ", stdout);
#endif
  puts("control-flow protection.");
#else
  puts("Built with an unknown compiler; I'm amazed you could do that!");
#endif
#if defined (__linux__)
#if defined (__x86_64__)
  puts("Running on an AMD64/INTEL64/x86-64 Linux platform.");
  ok2run=true;
#else
  puts("Running on a Linux platform and cross-compiling.");
#endif
#elif defined (__unix__)
  puts("Running on a UNIX platform.");
#if __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
  // should be OK....
#else
  puts("WARNING: This platform is not little endian.");
#endif
#else
  puts("Running on an unknown platform; good luck, you'll need it....");
#endif
#if defined(__linux__)
  uname(&superbuf);
  printf("%s kernel version %s\n", superbuf.sysname, superbuf.release);
#endif
#if defined(__unix__) || defined(__linux__)
#if defined(_POSIX_VERSION)
  if ( sysconf( _SC_VERSION ) >= 200809L )
    puts("This platform claims to support POSIX.1-2008");
  else
    puts("This platform does not support POSIX.1-2008");
#else
  puts("But it is not POSIX compliant");
#endif
#else
  puts("But it does not claim to be a UNIX platform");
#endif
#if defined(__USE_ISOC11) && ( __USE_ISOC11 == 1 )
#if defined(__STDC_VERSION__) && ( __STDC_VERSION__ >= 201710L )
  puts("This program was properly compiled to support C17.");
#else
  puts("This program was properly compiled to support C11.");
#endif
#elif defined(__USE_ISOC99) && ( __USE_ISOC99 == 1 )
  puts("This program was compiled to support C99.  You may have problems...");
#endif
#if defined(__USE_FORTIFY_LEVEL)
  #if ( __USE_FORTIFY_LEVEL == 2 )
    puts("This program uses FORTIFY_SOURCE level 2.");
  #elif ( __USE_FORTIFY_LEVEL == 1 )
    puts("This program uses FORTIFY_SOURCE level 1.");
  #else
    puts("This program does not use FORTIFY_SOURCE.");
  #endif
#else
  puts("This program does not use FORTIFY_SOURCE.");
#endif
#ifdef __PIE__
  puts("This program was compiled as a position-independent executable.");
#else
  puts("This program was compiled as a normal executable.");
#endif
  if (!ok2run) {
    puts("Remember, you will need an AMD64/EM64T/INTEL-64/x86-64 Linux environment to\n"
         "actually run the programs you compile with this compiler.");
  }
  return;
}

//
// This procedure will print a simple usage message explaining the
// parameters, which are explained in more detail in the man page.
//
static void ecma55_usage(
    const char *progname) {
  printf("Usage: %s [-v] [-r] [-s] [-w] [-4] [-A] [-O opt] [-o outputfilename ] [-X] inputfilename\n"
         "              or\n"
         "       %s -h\n"
         "              or\n"
         "       %s -l\n"
         "              or\n"
         "       %s -L\n"
         "              or\n"
         "       %s -V\n", progname, progname, progname, progname, progname);
  puts("    -4 allows code generator to emit SSE4.1 instructions\n"
       "    -h Show this usage information\n"
       "    -l shows brief license information\n"
       "    -L shows full software license information\n"
       "    -o specify output file for assembly code (should have .s suffix).\n"
       "       Defaults to inputfilename with .BAS suffix replaced by .s suffix.\n"
       "    -O sets optimization level, and must be followed by an integer between");
  printf("       0 and %u inclusive, with higher numbers requesting more optimization\n",
         MAX_OPTIMIZATION_LEVEL);
  puts("    -P output reformatted version of program to stdout\n"
       "    -r do not run the peephole scan after compilation\n"
       "    -R output reformatted and renumbered version of program to stdout\n"
       "    -s uses single precision float math for arithmetic expressions\n"
       "    -v generates verbose diagnostics\n"
       "    -V shows the version number\n"
       "    -w uses double precision output, 132 columns instead of default 80 columns\n"
       "    -X allows extensions beyond strict ECMA-55");
  return;
}

//
// This function will load the file specified in the filename parameter into
// a dynamically allocated buffer and return a pointer to that buffer.  The
// caller is responsible for deallocating that buffer when it is no longer
// needed.  If the file cannot be loaded, NULL is returned to indicate failure.
// The file must exist and be readable, and it must be a UNIX format text file.
// Much of the code used in this function is UNIX/Linux-specific.
//
static char *load_file_into_buffer(
    const char *filename,
    uint64_t *bytecount) {
  char *buffer = NULL;
  FILE *f = NULL;
  struct stat sb;

  if (stat(filename, &sb) == -1) {
    fprintf(stderr, "Unable to access file '%s'\n", filename);
    return NULL;
  }
  if (!((S_ISREG(sb.st_mode) || S_ISLNK(sb.st_mode)))) {
    fprintf(stderr, "File '%s' is not a regular file\n", filename);
    return NULL;
  }
  if ((f = fopen(filename, "r")) == NULL) {
    sprintf(errbuffer, "Unable to open file '%s' for input", filename);
    perror(errbuffer);
    return NULL;
  }
  if (sb.st_size < 6) {
    fprintf(stderr, "Error: Input file '%s' is too short to be a real ECMA-55 Minimal BASIC program\n", filename);
    fclose(f);
    f = NULL;
    return NULL;
  }
  *bytecount = (uint64_t)sb.st_size;
  if ((buffer = mmap(NULL, (size_t)sb.st_size, PROT_READ, MAP_PRIVATE, fileno(f), 0)) == MAP_FAILED) {
     fprintf(stderr, "mmap error for input file '%s'\n",filename);
     fclose(f);
     f = NULL;
     return NULL;
  }
  fclose(f);
  f = NULL;
  return buffer;
}

//
// This procedure is used to display the full GPLv2 license on STDOUT
//
static void show_long_licenses(void) {
  puts("License for the ecma55 Minimal BASIC compiler itself, which is\n"
       "Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021,2023  John Gatewood Ham:\n");
  WRITEWITHNEWLINE(stdout, COPYING);
  puts("\nLicense for the ACOS/ANGLE/ASIN/ATAN/COS/COSH/EXP/LOG/LOG10/\n"
       "LOG2/SIN/SINH/TAN/TANH assembly code which is from Naoki Shibata's\n"
       "SLEEF version 3.5.1:\n");
  WRITEWITHNEWLINE(stdout, BOOST_LICENSE);
  puts("\nLicense for the floating point conversion routines:\n");
  WRITEWITHNEWLINE(stdout, LUCENT_LICENSE);
  puts("\nLicense for the vDSO parser:\n");
  WRITEWITHNEWLINE(stdout, CC0_LICENSE);
  puts("\nThe random number assembly langauge support code is public domain from\n"
       "Bob Jenkins' ISAAC64.");
  puts("\nThe assembly language support code for accessing the time zone database\n"
       "and converting date and time to localtime is from David Olson and is in\n"
       "the public domain.");
  puts("\nLicense for the puff raw zlib decompressor:\n");
  WRITEWITHNEWLINE(stdout, PUFF_LICENSE);
  return;
}

static int process_command_line_arguments(int *argc, char **argv, char **outname) {
  int retval=EXIT_SUCCESS;
  int32_t opt;                      // variable used by getopt() function

  while ((opt = getopt(*argc, argv, "hrsvw4PRVlLo:O:X")) != -1) {
    char *endptr = NULL;

    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case 'R': // renumber
        renumber = true;
        // intentionally fall through
      case 'P': // pretty print
        pretty_print = true;
        use_peephole = false;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 'w': // use full-precision output for displaying floating point values
                // and have 132 column output
        use_double_output = true;
        ERROR_BUFFER_LEN = 132UL;
        break;
      case 'r': // RAW output, do not run peephole scanner
        use_peephole = false;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'V': // show the version number of this compiler and then exit.
        show_version(argv[0]);
        retval=9;
        goto xit;
      case 'l': // show the brief license summary text and then exit.
        fputs(license_msg, stdout);
        retval=9;
        goto xit;
      case 'L': // show the full GPLv2 license text, the full
                // Boost license text, and then exit
        show_long_licenses();
        retval=9;
        goto xit;
      case 'o': // specify the name of the output file to contain the assembly code this compiler generates
        if (*outname) {
          fputs("-o option can only be used once\n", stderr);
          retval=EXIT_FAILURE;
          goto xit;
        }
        *outname = strdup(optarg);
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          retval=EXIT_FAILURE;
          goto xit;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval=EXIT_FAILURE;
          goto xit;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval=EXIT_FAILURE;
          goto xit;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval=EXIT_FAILURE;
          goto xit;
        }
        break;
      case 'h': // show help (usage) information and exit
        ecma55_usage(argv[0]);
        retval=9;
        goto xit;
      default: // unknown option encountered, show help (usage) information and exit with an indication of failure
        ecma55_usage(argv[0]);
        retval=EXIT_FAILURE;
        goto xit;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    retval=EXIT_FAILURE;
    goto xit;
  }
  // There should be one remaining option and it should be a file name
  if ((*argc - optind) != 1) { // if no file to compile was specified or multiple files were specified,
                              // report the error and exit with an indication of failure
    fputs("Expected exactly one filename after options.\n", stderr);
    ecma55_usage(argv[0]);
    retval=EXIT_FAILURE;
    goto xit;
  }
  return EXIT_SUCCESS;
xit:
  if (*outname) {
    free(*outname);
    *outname = NULL;
  }
  return retval;
}

//
// Returns number of lines in a buffer formatted as a UNIX text file
// This assumes ASCII content with charater 10 as the newline
//
static uint64_t get_linecount(
     const char *buffer,         // buffer to scan
     const uint64_t buflen) {    // number of bytes in buffer
  uint64_t lc = 0,               // line count
           i = 0;                // loop index to use scanning buffer

  if (buflen < 1)                // if buffer is eimpty
    return lc;                   // return zero
  if (buffer[buflen-1] != '\n') {  // if last line of buffer is not a newline
                                   // error out with an appropriate message
    fputs("Buffer does not end with a newline like it should\n", stderr);
    exit(EXIT_FAILURE);
  }
  while (i < buflen)             // for each byte in the buffer
    if ('\n' == buffer[i++])     // if the byte is a newline
      lc += 1;                   // inrecement the linecount
  return lc;                     // return final linecount
}

char *outname = NULL,            // name of output assembly language file this compiler will generate
     *inname = NULL,             // name of input Minimal BASIC source program this compiler will use as input
     *inbuf = NULL;              // pointer to buffer that contains the Minimal BASIC source program loaded from the inname file
uint64_t inlength = 0;           // number of bytes in inbuf[]

void finishup(void);
void finishup(void) {
#ifdef __GLIBC__
#if __GLIBC__ == 2
#if __GLIBC_MINOR__ < 33
  unsigned int rambytesallocated = (unsigned int)(mallinfo().uordblks + mallinfo().fordblks),
               rambytesallocated2;
#else
  size_t rambytesallocated = (size_t)(mallinfo2().uordblks + mallinfo2().fordblks),
         rambytesallocated2;
#endif
#endif
#endif
  // deallocate the buffer containing the Minimal BASIC source code
  if (inbuf) {
    munmap(inbuf,inlength);
    inbuf = NULL;
  }
  // deallocate the input file name buffer
  if (inname) {
    free(inname);
    inname = NULL;
  }
  // deallocate the output filename buffer
  if (outname) {
    free(outname);
    outname = NULL;
  }
  // deallocate symbol table dynamic memory
  clear_symbol_table();
#ifdef __GLIBC__
#if __GLIBC__ == 2
#if __GLIBC_MINOR__ < 33
  rambytesallocated2 = (unsigned int)(mallinfo().uordblks + mallinfo().fordblks);
#else
  rambytesallocated2 = (size_t)(mallinfo2().uordblks + mallinfo2().fordblks);
#endif
  if (verbose && ((rambytesallocated2 - rambytesallocated) != 0U)) {
#if __GLIBC_MINOR__ < 33
    fprintf(stderr, "Number of leaked bytes is %u\n", rambytesallocated2 - rambytesallocated);
#else
    fprintf(stderr, "Number of leaked bytes is %lu\n", rambytesallocated2 - rambytesallocated);
#endif
  } else {
    if (verbose)
      fputs("No dynamic memory leaks\n", stderr);
  }
  if (verbose)
    malloc_stats();
#endif
#endif
  return;
}

//
// This main function is the starting point for running this compiler.
// Different methods for invocation are possible.  These are briefly
// shown in the usage() function, and explained in detail in the man
// page for this compiler.
//
int main(int argc, char **argv) {
  int retval = EXIT_FAILURE;        // return value of main(), pessimistically assumes failure
  size_t tlen;                      // variable used to hold length of strings
  uint32_t linecount = 0;           // number of lines in the Minimal BASIC source program
  uint64_t pos = 0;                 // current position of scanner within infubf[]
#ifdef __GLIBC__
#if __GLIBC__ == 2
  mallopt(M_MMAP_MAX, 0);           // do not use mmap() for malloc() backing store
#endif
#endif
  if (atexit(finishup) != 0) {
    fprintf(stderr, "Cannot setup exit function!\n");
    exit(EXIT_FAILURE);
  }
//
// The FOSS compilers refuse to implement these standard features
//
// #if defined(__STDC_IEC_559__) && ( __STDC_IEC_559__ == 1 )
  init_debug_printf(stderr);        // initialize the debug output system
  optimization_level = 0U;          // set the optimization level to the default value of zero
  retval=process_command_line_arguments(&argc,argv,&outname);
  if (retval!=EXIT_SUCCESS)
    return retval;
  tlen = strlen(argv[optind]);
  // allocation buffer for input Minimal BASIC source file name
  inname = strdup(argv[optind]);
  if (!outname) { // if no output file name was specified
    if (!pretty_print) {
      // allocate buffer for output assembly language file name
      outname = (char *)xmalloc(__FILE__, __func__, __LINE__, sizeof(char) * (3U + tlen));
      // generate default output file name which is the input name with '.s' appended
      strncpy(outname, inname, tlen);
      outname[tlen] = '.';
      outname[tlen + 1] = 's';
      outname[tlen + 2] = 0;
    }
  }
  // if somehow the input name and output name are the same, report the error and exit with an indication of failure
  if (outname && (strcmp(outname, inname) == 0)) {
    fputs("Error: input and output must be different\n", stderr);
    free(inname);
    free(outname);
    inname = outname = NULL;
    ecma55_usage(argv[0]);
    return EXIT_FAILURE;
  }
  debug_printf("verbose output = %s\noptimization level = %u\ninput filename = '%s'\noutput filename is '%s'\n",
    (verbose ? "true" : "false"), optimization_level, inname, outname);
  if ((inbuf = load_file_into_buffer(inname,&inlength)) == NULL) { // if load of input Minimal BASIC source file fails
    retval = EXIT_FAILURE;                               // exit with indication of failure
    goto xit;
  }
  linecount = (uint32_t)get_linecount(inbuf, inlength);
  // run the parser
  if (!parseit(inbuf, inlength, &pos, linecount, inname, outname)) { // if the parse failed report the error and exit with an indication of failure
    fflush(stdout);
    fputs("parseit() failed\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  if (use_peephole) {
    if (!peephole_scan(outname)) {
      fflush(stdout);
      fprintf(stderr, "peephole_scan('%s') failed\n",outname);
      retval = EXIT_FAILURE;
      goto xit;
    }
  } else {
    if (!pretty_print)
      fputs("Skipping peephole scan as requested.\n", stderr);
  }
  // if we get here, everything was OK
  retval = EXIT_SUCCESS; // change return value to indicate the compile was successful

xit:
  if (retval == EXIT_FAILURE) { // if the compile failed
    if (!verbose) {             // and verbose diagnostics were not requested
      if (outname) {            // and the output filename is not NULL
        remove(outname);        // remove the output assembly language file
      }
    }
  }
  if (verbose)
    dump_symbol_table(true);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  if (verbose)
    dumpflags();
  finishup();
  return retval;
}
