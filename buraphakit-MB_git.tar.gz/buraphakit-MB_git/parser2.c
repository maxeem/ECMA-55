//
// parser2.c - This is the file containing the parser
//             for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021,2023  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <stdlib.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <math.h>
#include <ctype.h>
#include <stdarg.h>
#include "globals.h"
#include "error_messages.h"
#include "scanner3.h"
#include "dtoa5_normal.h"
#include "g_fmt_BASIC_normal.h"
#include "tree.h"
#include "dag.h"
#include "ast.h"
#include "asmgen.h"
#include "semantic_checks.h"
#include "parser2.h"

// numeric expression
static bool g_nvar(scanner_state *ss, treenode **node);
static bool g_navar(scanner_state *ss, treenode **node);
static bool g_integer(scanner_state *ss, treenode **node);
static bool g_real(scanner_state *ss, treenode **node);
static bool g_primary(scanner_state *ss, treenode **node);
static bool g_factor(scanner_state *ss, treenode **node);
static bool g_term(scanner_state *ss, treenode **node);
static bool g_string_expression(scanner_state *ss, treenode **node);
static bool g_numeric_expression(scanner_state *ss, treenode **node);
static bool g_relational_expression(scanner_state *ss, treenode **node);
static bool g_disjunction(scanner_state *ss, treenode **node);
static bool g_conjunction(scanner_state *ss, treenode **node);
static bool g_relational_term(scanner_state *ss, treenode **node);
static bool g_relational_primary(scanner_state *ss, treenode **node);
static bool g_comparison(scanner_state *ss, treenode **node);
// miscellaneous
static bool g_lineno(scanner_state *ss, uint32_t *lno, char *why, const bool jumptarget);
static bool g_lineno2(token *curtoken, uint32_t *lno, char *why, const bool jumptarget);
// normal statements
static bool g_defstmt(scanner_state *ss, treenode **node);
static bool g_ifstmt(scanner_state *ss, treenode **node);
static bool g_on_gotostmt(scanner_state *ss, treenode **node);
static bool g_target_variable(scanner_state *ss, treenode **node);
static bool g_inputstmt(scanner_state *ss, treenode **node);
static bool g_readstmt(scanner_state *ss, treenode **node);
static bool g_datum(token *curtoken);
static bool g_datastmt(scanner_state *ss, treenode **node);
static bool g_getdim(token *curtoken, uint32_t *dimvalue);
static bool g_dimstmt(scanner_state *ss, treenode **node);
static bool g_nextstmt(scanner_state *ss, treenode **node);
static bool g_forstmt(scanner_state *ss, treenode **node);
static bool g_printstmt(scanner_state *ss, treenode **node);
static bool g_letstmt(scanner_state *ss, treenode **node);
static bool g_randomizestmt(scanner_state *ss, treenode **node);
static bool g_restorestmt(scanner_state *ss, treenode **node);
static bool g_optionbasestmt(scanner_state *ss, treenode **node);
static bool g_gotostmt(scanner_state *ss, treenode **node);
static bool g_go_stmt(scanner_state *ss, treenode **node);
static bool g_gosubstmt(scanner_state *ss, treenode **node);
static bool g_returnstmt(scanner_state *ss, treenode **node);
static bool g_endstmt(scanner_state *ss, treenode **node);
static bool g_exitstmt(scanner_state *ss, treenode **node);
static bool g_remstmt(scanner_state *ss, treenode **node);
static bool g_stopstmt(scanner_state *ss, treenode **node);
static bool g_statement(scanner_state *ss, treenode **node);
static bool g_lines(scanner_state *ss, treenode **node, const uint32_t linecount, const char *inname);
static bool g_program(scanner_state *ss, treenode **node, const uint32_t linecount, const char *inname);
// built-in functions
static bool g_bif(scanner_state *ss, treenode **node, enum token_ids tid, char *bifname);
static bool g_bif2(scanner_state *ss, treenode **node, enum token_ids tid, char *bifname);
static bool g_bif0(scanner_state *ss, treenode **node, enum token_ids tid, char *bifname);
static bool g_bisf(scanner_state *ss, treenode **node, enum token_ids tid, const char *bifname);
static bool g_udf(scanner_state *ss, treenode **node);
// helper functions
static bool let_svar(scanner_state *ss, treenode *node);
static bool let_nvar(scanner_state *ss, treenode *node);
static bool let_navar(scanner_state *ss, treenode *node);
static bool convert_unsigned_integer(const char *s, uint32_t *uintvalue, char *why);
static bool match(scanner_state *ss,
                  enum token_ids tid, const char *from);
static bool match2(token *curtoken, enum token_ids tid, const char *from);
static void ERROR(const char *format, ...);
// global variables
static bool suppress_errors = false;        // set to true when trying speculative parse in
                                            // g_relational_primary

//
// This procedure will print an error message in the same way fprintf() does
// if suppress_errors is false, and does nothing if suppress_errors is true
//
static void ERROR(
    const char *format,   // printf() style format string
    ...) {                // zero or more arguments used by format

  if (!suppress_errors) {
    va_list arg;

    va_start(arg, format);
    vfprintf(stderr, format, arg);
    va_end(arg);
  }
  return;
}

//
// This function is used to convert an ASCIIZ string to an unsigned integer for
// DIM statements.  This function returns true on success, false otherwise.
//
static bool convert_unsigned_integer(
    const char *s,             // pointer to source ASCIIZ string
    uint32_t *uintvalue,       // pointer to integer variable to hold converted result
    char *why) {               // pointer to string containing error message if conversion
                               // fails, and must have room for ERROR_BUFFER_LEN bytes
  char *endptr = NULL;         // pointer to first unconverted byte in input string
  static unsigned long tuival; // temporary to hold return value of strtoul()

  errno = 0;                   // reset error flag to OK
  if ('-' == s[0]) {           // if the input string starts with a '-' then
    snprintf(why, ERROR_BUFFER_LEN, emsg[75], s);
    why[ERROR_BUFFER_LEN - 1U] = 0;   // ensure termination of ASCIIZ string
    return false;
  }
  tuival = strtoul(s, &endptr, 10);   // attempt the conversion
  switch (errno) {
    case 0:                           // OK
      break;
    case ERANGE:                      // number too big or too small
      snprintf(why, ERROR_BUFFER_LEN, emsg[159], s, UINT_MAX);
      why[ERROR_BUFFER_LEN - 1U] = 0; // ensure termination of ASCIIZ string
      return false;
    default:                          // Unknown error
      snprintf(why, ERROR_BUFFER_LEN, emsg[160], s);
      why[ERROR_BUFFER_LEN - 1U] = 0; // ensure termination of ASCIIZ string
      return false;
  }
  if (endptr != s + strnlen(s, 20)) { // if there was junk in the string after the converted part then
    snprintf(why, ERROR_BUFFER_LEN, emsg[161], s, endptr);
    why[ERROR_BUFFER_LEN - 1U] = 0;   // ensure termination of ASCIIZ string
    return false;
  }
  *uintvalue = (uint32_t)tuival;      // everything is OK, save the converted value
  return true;
}

//
// This function is used to ensure the next token is the desired token.
// It always consumes token.  It returns true on success, false otherwise.
//
static bool match(
    scanner_state *ss,
    enum token_ids tid,                                 // token identifier for desired token
    const char __attribute__((__unused__)) *from) {     // pointer to buffer with name of the calling function
  token *curtoken = get_next_token(ss);                 // next token from input token stream
  bool retval;                                          // function return value

  if (verbose) {
    if ((T_INTEGER == tid) || (T_REAL == tid) || (T_NVAR == tid) || (T_SVAR == tid) || (T_FNID == tid))
      deep_debug_printf("%s(%s,%s) with value '%s'\n", __func__, token_names[tid], from, curtoken->toketext);
    else
      deep_debug_printf("%s(%s,%s)\n", __func__, token_names[tid], from);
  }
  if (!(retval = (curtoken->tid == tid))) {             // if the match failed then
    // +2 is to skip the 'T_' prefix
    ERROR(emsg[162], curtoken->lno, token_names[tid] + 2, token_names[curtoken->tid] + 2);
    if (T_EOL != curtoken->tid)
      ERROR(emsg[163], curtoken->toketext);
    ERROR("%s", emsg[164]);
  }
  deep_debug_printf("%s() frees %s('%s')\n", __func__, token_names[curtoken->tid], curtoken->toketext);
  free(curtoken->toketext);
  curtoken->toketext = NULL;                            // either way, free the token memory
  free(curtoken);
  curtoken = NULL;
  return retval;                                        // and return true if the match was OK, false otherwise
}

//
// This function ensures a particular token is the desired token.
// Returns true on a success match, false otherwise.
//
static bool match2(
    token *curtoken,                                    // pointer to current token
    enum token_ids tid,                                 // token identifier of desired token
    const char __attribute__((__unused__)) *from) {    // pointer to buffer containing name of calling function

  if (verbose) {
    if ((T_INTEGER == tid) || (T_REAL == tid) || (T_NVAR == tid) || (T_SVAR == tid) || (T_FNID == tid))
      deep_debug_printf("%s(%s,%s) with value '%s'\n", __func__, token_names[tid], from, curtoken->toketext);
    else
      deep_debug_printf("%s(%s,%s)\n", __func__, token_names[tid], from);
  }
  if (curtoken->tid != tid) { // if the match failed then
    // +2 is to skip the 'T_' prefix
    ERROR(emsg[162], curtoken->lno, token_names[tid] + 2, token_names[curtoken->tid] + 2);
    if (T_EOL != curtoken->tid)
      ERROR(emsg[163], curtoken->toketext);
    ERROR("%s", emsg[164]);
    return false;
  }
  return true;                // match was OK
}
//
// parser code
//

//
// This function will parse code that calls the built-in function specified
// in the second parameter within an arithmetic expression.
// Returns true on success, false otherwise.
//
// g_whatever -> T_WHATEVER T_LPAREN g_numeric_expression T_RPAREN
//
// Where T_WHATEVER is a built-in function taking 1 argument, like T_COS, T_SIN, etc.
// which we know from the tid parameter, and g_whatever is the corresponding grammar
// nonterminal like g_cos, g_sin, etc.
//
static bool g_bif(
    scanner_state *ss,
    treenode **node,                         // pointer to AST node created on success
    enum token_ids tid,                      // token ID for built-in function name
    char *bifname) {                         // pointer to buffer containing grammar name
                                             // of built-in-function g_****, such as
                                             // "sin" for g_sin, etc.
  token *curtoken = get_next_token(ss);      // pointer to next token

  debug_printf("g_%s -> %s T_LPAREN g_numeric_expression T_RPAREN\n", bifname, token_names[curtoken->tid]);
  free(bifname); bifname = NULL;
  if (!match2(curtoken, tid, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  *node = create_tree_node2(1U, curtoken);
  return match(ss, T_LPAREN, __func__) &&
         g_numeric_expression(ss, &((*node)->children[0])) &&
         match(ss, T_RPAREN, __func__);
}

//
// This function will parse code that calls the built-in function specified
// in the second parameter.  That function takes two numeric expression arguments.
// Returns true on success, false otherwise.
//
// g_whatever -> T_WHATEVER T_LPAREN g_numeric_expression T_COMMA g_numeric_expression T_RPAREN
//
// Where T_WHATEVER is a built-in function taking 2 arguments, like T_MIN, T_MAX, etc.
// which we know from the tid parameter, and g_whatever is the corresponding grammar
// nonterminal like g_min, g_max, etc.
//
static bool g_bif2(
    scanner_state *ss,
    treenode **node,                         // pointer to AST node created on success
    enum token_ids tid,                      // token ID for built-in function name
    char *bifname) {                         // pointer to buffer containing grammar name
                                             // of built-in-function g_****, such as
                                             // "sin" for g_sin, etc.
  token *curtoken = get_next_token(ss);      // pointer to next token

  debug_printf("g_%s -> %s T_LPAREN g_numeric_expression T_COMMA g_numeric_expression T_RPAREN\n",
               bifname, token_names[curtoken->tid]);
  free(bifname); bifname = NULL;
  if (!match2(curtoken, tid, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  *node = create_tree_node2(2U, curtoken);
  return match(ss, T_LPAREN, __func__) &&
         g_numeric_expression(ss, &((*node)->children[0])) &&
         match(ss, T_COMMA, __func__) &&
         g_numeric_expression(ss, &((*node)->children[1])) &&
         match(ss, T_RPAREN, __func__);
}

//
// This function will parse code that calls the built-in function specified
// in the second parameter.  These function takes no arguments.
// Returns true on success, false otherwise.
//
// g_whatever -> T_WHATEVER
//
// Where T_WHATEVER is a built-in function taking 0 arguments, like T_PI, T_MAXNUM, etc.
// which we know from the tid parameter, and g_whatever is the corresponding grammar
// nonterminal like g_PI, g_MAXNUM, etc.
//
static bool g_bif0(
    scanner_state *ss,
    treenode **node,                         // pointer to AST node created on success
    enum token_ids tid,                      // token ID for built-in function name
    char *bifname) {                         // pointer to buffer containing grammar name
                                             // of built-in-function g_****, such as
                                             // "sin" for g_sin, etc.
  token *curtoken = get_next_token(ss);      // pointer to next token

  debug_printf("g_%s -> %s\n", bifname, token_names[curtoken->tid]);
  free(bifname); bifname = NULL;
  if (!match2(curtoken, tid, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  *node = create_tree_node2(0U, curtoken);
  return true;
}

//
// This function will parse code that calls the built-in function specified
// in the second parameter within a string expression.
// Returns true on success, false otherwise.
//
// g_whatever -> T_WHATEVER T_LPAREN g_string_expression T_RPAREN
//
// Where T_WHATEVER is a built-in function taking 1 argument, like T_LEN, etc.
// which we know from the tid parameter, and g_whatever is the corresponding grammar
// nonterminal like g_len, etc.
//
static bool g_bisf(
    scanner_state *ss,
    treenode **node,                         // pointer to AST node created on success
    enum token_ids tid,                      // token ID for built-in function name
    const char *bifname) {                   // pointer to buffer containing grammar name
                                             // of built-in-function g_****, such as
                                             // "sin" for g_sin, etc.
  token *curtoken = get_next_token(ss);      // pointer to next token

  debug_printf("g_%s -> %s T_LPAREN g_string_expression T_RPAREN\n", bifname, token_names[curtoken->tid]);
  if (!match2(curtoken, tid, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  *node = create_tree_node2(1U, curtoken);
  return match(ss, T_LPAREN, __func__) &&
         g_string_expression(ss, &((*node)->children[0])) &&
         match(ss, T_RPAREN, __func__);
}

//
// This function will convert the T_INTEGER token value to an ASCIIZ string
// using David M. Gay's g_fmt() and add a symbol table entry for the float literal.
// Returns true on success, false otherwise.  The g_fmt() is used to ensure the
// compile-time conversion will behave in exactly the same way as a run-time conversion
// using the assembly version of g_fmt used in the runtime library.
// The type of the token will be changed to T_REAL.
//
// g_integer -> T_INTEGER
//
static bool g_integer(
    scanner_state *ss,
    treenode **node) {                    // pointer to AST node created on success
  token *curtoken = get_next_token(ss);   // pointer to next token
  char *tbuf = NULL;                      // buffer used to hold the result of g_fmt() conversion
                                          // which is a properly formatted floating point value

  debug_printf("g_integer -> T_INTEGER <<<value is '%s'>>>\n", curtoken->toketext);
  if (!match2(curtoken, T_INTEGER, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  *node = create_tree_node2(0U, curtoken);
  tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
  if (use_double) {
    // convert integer ASCIIZ input to David M. Gay's 64bit double format
    (*node)->numeric_value.dvalue = dgstrtod(curtoken->toketext, NULL);
    g_fmt(tbuf, (*node)->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
  } else {
    // convert integer ASCIIZ input to David M. Gay's 32bit float format
    (*node)->numeric_value.fvalue = (float)dgstrtod(curtoken->toketext, NULL);
    g_fmt(tbuf, (*node)->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
  }
  free((*node)->leaftoken->toketext);
  (*node)->leaftoken->toketext = tbuf;
  (*node)->leaftoken->tid=T_REAL;
  return true;
}

//
// This function will convert the T_REAL token value to an ASCIIZ string
// using David M. Gay's g_fmt(), add a symbol table entry for the float literal.
// Returns true on success, false otherwise.  The g_fmt() is used to ensure the
// compile-time conversion will behave in exactly the same way as a run-time conversion
// using the assembly version of g_fmt used in the runtime library.
//
// Returns true on success, false otherwise.
//
// g_real -> T_REAL
//
static bool g_real(
    scanner_state *ss,
    treenode **node) {                    // pointer to AST node created on success
  token *curtoken = get_next_token(ss);   // pointer to next token

  debug_printf("g_real -> T_REAL <<<value is '%s'>>>\n", curtoken->toketext);
  if (!match2(curtoken, T_REAL, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  *node = create_tree_node2(0U, curtoken);
  if (use_double) {
    // convert real number ASCIIZ input to double
    (*node)->numeric_value.dvalue = dgstrtod(curtoken->toketext, NULL);
  } else {
    // convert real number ASCIIZ input to float
    (*node)->numeric_value.fvalue = (float)dgstrtod(curtoken->toketext, NULL);
  }
  return true;
}

//
// This function will parse code that calls a UDF within an arithmetic expression.
// Returns true on success, false otherwise.
//
// g_udf -> T_FNID g_function_tail
// g_function_tail -> T_LPAREN g_numeric_expression T_RPAREN
// g_function_tail -> epsilon
//
static bool g_udf(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success
  token *curtoken = get_next_token(ss); // pointer to next token

  debug_printf("%s", "g_udf -> T_FNID g_function_tail\n");
  if (!match2(curtoken, T_FNID, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  if (T_LPAREN == peek_next_tid(ss)) {  // function has an argument
    debug_printf("%s", "g_function_tail -> T_LPAREN g_numeric_expression T_RPAREN\n");
    *node = create_tree_node2(1U, curtoken);
    if (!match(ss, T_LPAREN, __func__))
      return false;
    // special error production check
    if (T_RPAREN == peek_next_tid(ss)) {
      ERROR(emsg[165], (*node)->leaftoken->lno, (*node)->leaftoken->toketext);
      return false;
    }
    if (!g_numeric_expression(ss, &((*node)->children[0])))
      return false;
    if (!match(ss, T_RPAREN, __func__))
      return false;
  } else {                                  // function does not have an argument
    debug_printf("%s", "g_function_tail -> epsilon\n");
    *node = create_tree_node2(0U, curtoken);
  }
  return true;
}

//
// This will parse code to read a numeric variable in an arithmetic expression.
// Returns true on success, false otherwise.
//
// g_nvar -> T_NVAR
//
static bool g_nvar(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  token *curtoken = get_next_token(ss); // pointer to next token

  debug_printf("%s", "g_nvar -> T_NVAR\n");
  if (!match2(curtoken, T_NVAR, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  *node = create_tree_node2(0U, curtoken);
  curtoken = NULL;
  return true;
}

//
// This will parse code for reading a numeric array variable in an arithmetic expression.
// Returns true on success, false otherwise.
//
// g_navar -> T_NAVAR T_LPAREN g_numeric_expression g_array_tail2 T_RPAREN
// g_array_tail2 -> T_COMMA g_numeric_expression
// g_array_tail2 -> epsilon
//
static bool g_navar(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  treenode *lhs = NULL;               // pointer to AST node for left-hand side child,
                                      // which is the g_numeric_expression tree for the
                                      // first index
  token *curtoken = get_next_token(ss); // pointer to next token

  debug_printf("%s", "g_navar -> T_NAVAR T_LPAREN g_numeric_expression g_array_tail2 T_RPAREN\n");
  if (!match2(curtoken, T_NAVAR, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  debug_printf("T_NAVAR <<<value is '%s'>>>\n", curtoken->toketext);
  if (!match(ss, T_LPAREN, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    *node = NULL;
    return false;
  }
  if (!g_numeric_expression(ss, &lhs)) {
    tree_delete_all(&lhs);
    *node = NULL;
    return false;
  }
  if (T_COMMA == peek_next_tid(ss)) { // 2-d matrix
    debug_printf("%s", "g_array_tail2 -> T_COMMA g_numeric_expression\n");
    *node = create_tree_node2(2U, curtoken);
    (*node)->children[0] = lhs;
    lhs = NULL;
    if (!match(ss, T_COMMA, __func__))
      return false;
    if (!g_numeric_expression(ss, &((*node)->children[1])))
      return false;
  } else {                                 // vector
    debug_printf("%s", "g_array_tail2 -> epsilon\n");
    *node = create_tree_node2(1U, curtoken);
    (*node)->children[0] = lhs;
    lhs = NULL;
  }
  curtoken = NULL;
  if (!match(ss, T_RPAREN, __func__))
    return false;
  return true;
}

//
// This is part of the processing of arithmetic expressions
// for calling the built-in arithmetic functions and
// user-defined functions.
// Returns true on success, false otherwise.
//
//  g_primary -> g_abs
//  g_primary -> g_atn
//  g_primary -> g_cos
//  g_primary -> g_cosh
//  g_primary -> g_acos
//  g_primary -> g_exp
//  g_primary -> g_int
//  g_primary -> g_log
//  g_primary -> g_sgn
//  g_primary -> g_sin
//  g_primary -> g_asin
//  g_primary -> g_sinh
//  g_primary -> g_sqr
//  g_primary -> g_tan
//  g_primary -> g_tanh
//  g_primary -> g_RND
//  g_primary -> g_PI
//  g_primary -> g_MAXNUM
//  g_primary -> g_DATE
//  g_primary -> g_TIME
//  g_primary -> g_deg
//  g_primary -> g_rad
//  g_primary -> g_min
//  g_primary -> g_max
//  g_primary -> g_integer
//  g_primary -> g_real
//  g_primary -> g_udf
//  g_primary -> g_nvar
//  g_primary -> g_navar
//  g_primary -> g_csc
//  g_primary -> g_sec
//  g_primary -> g_cot
//  g_primary -> g_len
//  g_primary -> T_LPAREN g_numeric_expression T_RPAREN
//
static bool g_primary(
    scanner_state *ss,                    // pointer to scanner state information
    treenode **node) {                    // pointer to AST node created on success
  token *curtoken = peek_next_token(ss);  // pointer to next token
  enum token_ids ttid = curtoken->tid;    // save token id for later
  uint32_t lno = curtoken->lno;           // save lno for later

  switch(ttid) {
    case T_ACOS:  // -X
    case T_ASIN:  // -X
    case T_CEIL:  // -X
    case T_COSH:  // -X
    case T_COT:   // -X
    case T_CSC:   // -X
    case T_DEG:   // -X
    case T_FP:    // -X
    case T_IP:    // -X
    case T_LOG10: // -X
    case T_LOG2:  // -X
    case T_RAD:   // -X
    case T_SEC:   // -X
    case T_SINH:  // -X
    case T_TANH:  // -X
      if (!extensions) { // These are not permitted without extensions enabled
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[ttid] + 2);
      }
      // FALL THROUGH
    case T_ABS:
    case T_ATN:
    case T_COS:
    case T_EXP:
    case T_INT:
    case T_LOG:
    case T_SGN:
    case T_SIN:
    case T_SQR:
    case T_TAN:
      {
        char *bifname = NULL;                // buffer to hold built-in function name (? bytes + terminator)
        unsigned int i = 0U;                 // loop index variable to iterate over characters of bifname[]
        unsigned long int len = 0UL;         // length of function name

        bifname = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_BIFNAME_LEN + 1U));
        len = strlen(token_names[ttid] + 2) + 1;
        memcpy(bifname, token_names[ttid] + 2, len);
        bifname[len] = 0;
        for (i = 0U; i < len; ++i)
          bifname[i] = (char)toupper(bifname[i]);
        debug_printf("g_primary -> g_%s\n", bifname);
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        return g_bif(ss, node, ttid, bifname);
      }
    case T_ANGLE:     // -X
    case T_MAX:       // -X
    case T_MIN:       // -X
    case T_MOD:       // -X
    case T_REMAINDER: // -X
    case T_ROUND:     // -X
    case T_TRUNCATE:  // -X
      {
        char *bifname = NULL;                // buffer to hold built-in function name (? bytes + terminator)
        unsigned int i = 0U;                 // loop index variable to iterate over characters of bifname[]
        unsigned long int len = 0UL;         // length of function name

        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        if (!extensions)                     // These functions are not permitted without extensions enabled
          FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[ttid] + 2);
        bifname = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_BIFNAME_LEN + 1U));
        len = strlen(token_names[ttid] + 2) + 1;
        memcpy(bifname, token_names[ttid] + 2, len);
        bifname[len] = 0;
        for (i = 0U; i < len; ++i)
          bifname[i] = (char)toupper(bifname[i]);
        debug_printf("g_primary -> g_%s\n", bifname);
        return g_bif2(ss, node, ttid, bifname);
      }
    case T_LEN: // -X
      {
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        if (!extensions)                     // These functions are not permitted without extensions enabled
          FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[ttid] + 2);
        debug_printf("g_primary -> g_len\n");
        return g_bisf(ss, node, ttid, token_names[ttid] + 2);
      }
    case T_DATE:   // -X
    case T_TIME:   // -X
    case T_MAXNUM: // -X
    case T_PI:     // -X
      if (!extensions) {                     // These functions are not permitted without extensions enabled
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[ttid] + 2);
      }
      // FALLS THROUGH
    case T_RND:
      {
        char *bifname = NULL;                // buffer to hold built-in function name (? bytes + terminator)
        unsigned int i = 0U;                 // loop index variable to iterate over characters of bifname[]
        unsigned long int len = 0UL;         // length of function name

        bifname = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_BIFNAME_LEN + 1U));
        len = strlen(token_names[ttid] + 2) + 1;
        memcpy(bifname, token_names[ttid] + 2, len);
        bifname[len] = 0;
        for (i = 0U; i < len; ++i)
          bifname[i] = (char)toupper(bifname[i]);
        debug_printf("g_primary -> g_%s\n", bifname);
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        return g_bif0(ss, node, ttid, bifname);
      }
    case T_INTEGER:
      debug_printf("%s", "g_primary -> g_integer\n");
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return g_integer(ss, node);
    case T_REAL:
      debug_printf("%s", "g_primary -> g_real\n");
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return g_real(ss, node);
    case T_FNID:        // user defined function call
      debug_printf("%s", "g_primary -> g_udf\n");
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return g_udf(ss, node);
    case T_NVAR:        // numeric variable
      debug_printf("%s", "g_primary -> g_nvar\n");
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return g_nvar(ss, node);
    case T_NAVAR:       // numeric array variable
      debug_printf("%s", "g_primary -> g_navar\n");
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return g_navar(ss, node);
    case T_LPAREN:
      debug_printf("%s", "g_primary -> T_LPAREN g_numeric_expression T_RPAREN\n");
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      if (!match(ss, T_LPAREN, __func__))
        return false;
      if (!g_numeric_expression(ss, node))
        return false;
      return match(ss, T_RPAREN, __func__);
    default:
      debug_printf("%s", "g_primary -> -=<([ CANNOT BE DETERMINED!!! ])>=-\n");
      ERROR(emsg[171], curtoken->lno, token_names[curtoken->tid], curtoken->toketext);
      *node = NULL;
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      // FALLS THROUGH
  }
  return false;
}

//
// This is part of the processing of arithmetic expressions
// for exponentiation.
// Returns true on success, false otherwise.
//
// g_factor -> g_primary g_factor_tail
// g_factor_tail -> T_POW g_primary
// g_factor_tail -> epsilon
//
static bool g_factor(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success
  bool retval = true;                // function return value
  treenode *nodeptr = NULL;          // pointer to hold current subtree during construction

  debug_printf("%s", "g_factor -> g_primary g_factor_tail\n");
  if (!g_primary(ss, &nodeptr)) {
    retval = false;
    goto done;
  }
  while (T_POW == peek_next_tid(ss)) {
    token *curtoken = get_next_token(ss); // pointer to actual next token
    treenode *nodeptr2 = NULL,          // pointer for g_primary subtree during construction
             *nodeptr3 = NULL;          // pointer for new parent subtree during construction

    debug_printf("%s", "g_factor_tail -> T_POW g_primary\n");
    if (!g_primary(ss, &nodeptr2)) {
      retval = false;
      tree_delete_all(&nodeptr2);
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      goto done;
    }
    nodeptr3 = create_tree_node2(2U, curtoken);
    nodeptr3->children[0] = nodeptr;
    nodeptr3->children[1] = nodeptr2;
    nodeptr = nodeptr3;
    nodeptr3 = nodeptr2 = NULL;
  }
  debug_printf("%s", "g_factor_tail -> epsilon\n");
done:
  *node = nodeptr;
  nodeptr = NULL;
  return retval;
}

//
// This is part of the processing of arithmetic expressions
// for binary multiplication and division.
// Returns true on success, false otherwise.
//
// g_term -> g_factor g_term_tail
// g_term_tail -> T_MUL g_factor g_term_tail
// g_term_tail -> T_DIV g_factor g_term_tail
// g_term_tail -> epsilon
//
static bool g_term(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success
  enum token_ids curtid;             // current token ID number (T_MUL or T_DIV)
  treenode *nodeptr = NULL;          // pointer to hold current subtree during construction
  bool retval = true;                // function return value

  debug_printf("%s", "g_term -> g_factor g_term_tail\n");
  if (!g_factor(ss, &nodeptr)) {
    retval = false;
    goto done;
  }
  curtid = peek_next_tid(ss);
  while ((T_MUL == curtid) || (T_DIV == curtid)) {
    token *curtoken = get_next_token(ss);   // copy of next token
    treenode *nodeptr2 = NULL,            // pointer for g_factor subtree during construction
             *nodeptr3 = NULL;            // pointer for new parent subtree during construction

    debug_printf("g_term_tail -> %s g_factor g_term_tail\n", token_names[curtid]);
    if (!g_factor(ss, &nodeptr2)) {
      retval = false;
      tree_delete_all(&nodeptr2);
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      goto done;
    }
    nodeptr3 = create_tree_node2(2U, curtoken);
    nodeptr3->children[0] = nodeptr;
    nodeptr3->children[1] = nodeptr2;
    nodeptr = nodeptr3;
    nodeptr3 = nodeptr2 = NULL;
    curtid = peek_next_tid(ss);
  }
  debug_printf("%s", "g_term_tail -> epsilon\n");
done:
  *node = nodeptr;
  nodeptr = NULL;
  return retval;
}

//
// This will process a string expression.  It is quite simple since Minimal BASIC
// has no string operators.
// Returns true on success, false otherwise.
//
// g_string_expression -> T_SVAR
// g_string_expression -> T_QSTRING
// g_string_expression -> T_DATES      (extension)
// g_string_expression -> T_TIMES      (extension)
//
static bool g_string_expression(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  bool retval = true;                 // function return value
  token *curtoken = get_next_token(ss); // pointer to next token
  treenode *nodeptr = NULL;           // pointer to hold current subtree during construction
  uint32_t lno = curtoken->lno;       // save line number for later
  enum token_ids ttid = curtoken->tid; // save tid for later

  switch (ttid) {
    case T_DATES:
    case T_TIMES:
        if (!extensions) {      // These string functions are not permitted without extensions enabled
          free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
          FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[ttid] + 2);
        }
        // FALLS THROUGH
    case T_SVAR:
    case T_QSTRING:
      debug_printf("g_string_expression -> %s\n", token_names[ttid]);
      nodeptr = create_tree_node2(0U, curtoken);
      break;
    default:
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      retval = false;
  }
  *node = nodeptr;
  nodeptr = NULL;
  return retval;
}

//
// This is the production that processes an arithmetic expression.
// Returns true on success, false otherwise.
//
// g_numeric_expression -> g_sign g_term g_numeric_expression_tail
// g_numeric_expression_tail -> %s g_term g_numeric_expression_tail
// g_numeric_expression_tail -> epsilon
//
static bool g_numeric_expression(
    scanner_state *ss,
    treenode **node) {                             // pointer to AST node created on success
  token *curtoken = NULL;                          // copy of next token
  bool neednegate = false;                         // flag to indicate g_sign was a unary minus
  enum token_ids curtid = peek_next_tid(ss);       // current token ID number
  treenode *nodeptr = NULL;                        // pointer to hold current subtree during construction
  bool retval = true;                              // function return value

  debug_printf("%s", "g_numeric_expression -> g_sign g_term g_numeric_expression_tail\n");
  if ((T_ADD == curtid) || (T_SUBTRACT == curtid)) {
    debug_printf("g_sign -> %s\n", token_names[curtid]);
    if (T_SUBTRACT == curtid)
      neednegate = true;
    curtoken = get_next_token(ss);
    if (T_ADD == curtid) {                       // discard unary +
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    }
  } else {
    debug_printf("%s", "g_sign ->\n");
  }
  if (!g_term(ss, &nodeptr)) {
    retval = false;
    if (curtoken) {
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    }
    goto done;
  }
  if (neednegate) {
    treenode *nodeptr2 = NULL;         // pointer to hold current subtree during construction

    nodeptr2 = create_tree_node2(1U, curtoken);
    nodeptr2->children[0] = nodeptr;
    nodeptr = nodeptr2;
    nodeptr2 = NULL;
  }
  curtid = peek_next_tid(ss);
  while ((T_ADD == curtid) || (T_SUBTRACT == curtid)) {
    treenode *nodeptr2 = NULL,         // pointer for g_numeric_expression_tail subtree during construction
             *nodeptr3 = NULL;         // pointer for new parent subtree during construction

    debug_printf("g_numeric_expression_tail -> %s g_term g_numeric_expression_tail\n", token_names[curtid]);
    curtoken = get_next_token(ss);
    if (!g_term(ss, &nodeptr2)) {
      retval = false;
      tree_delete_all(&nodeptr2);
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      goto done;
    }
    nodeptr3 = create_tree_node2(2U, curtoken);
    nodeptr3->children[0] = nodeptr;
    nodeptr3->children[1] = nodeptr2;
    nodeptr = nodeptr3;
    nodeptr3 = nodeptr2 = NULL;
    curtid = peek_next_tid(ss);
  }
  debug_printf("%s", "g_numeric_expression_tail -> epsilon\n");
done:
  *node = nodeptr;
  nodeptr = NULL;
  return retval;
}

//
// This is the root for any relational expression (used in IF statements)
// Returns true on success, false otherwise.
//
// g_relational_expression = g_disjunction
//
static bool g_relational_expression(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success

  debug_printf("g_relational_expression -> g_disjunction\n");
  return g_disjunction(ss, node);
}

//
// This is for handling OR in relational expressions.
// Returns true on success, false otherwise.
//
// g_disjunction = g_conjunction g_disjunction_tail
// g_disjunction_tail = OR g_conjunction g_disjunction_tail
// g_disjunction_tail = epsilon
//
static bool g_disjunction(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success
  treenode *nodeptr = NULL;          // pointer to hold current subtree during construction
  bool retval = true;                // function return value

  debug_printf("g_disjunction -> g_conjunction g_disjunction_tail\n");
  if (!g_conjunction(ss, &nodeptr)) {
    retval = false;
    goto done;
  }
  while (T_OR == peek_next_tid(ss)) {
    token *curtoken = get_next_token(ss); // copy of next token
    treenode *nodeptr2 = NULL,          // pointer for g_conjunction subtree during construction
             *nodeptr3 = NULL;          // pointer for new parent subtree during construction

    debug_printf("g_disjunction_tail -> %s g_conjunction g_disjunction_tail\n", token_names[T_OR]);
    if (!extensions) {                         // OR is not permitted without extensions enabled
      uint32_t lno = curtoken->lno;

      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[T_OR] + 2);
    }
    if (!g_conjunction(ss, &nodeptr2)) {
      retval = false;
      tree_delete_all(&nodeptr2);
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      goto done;
    }
    nodeptr3 = create_tree_node2(2U, curtoken);
    nodeptr3->children[0] = nodeptr;
    nodeptr3->children[1] = nodeptr2;
    nodeptr = nodeptr3;
    nodeptr3 = nodeptr2 = NULL;
  }
  debug_printf("g_disjunction_tail -> epsilon\n");
done:
  *node = nodeptr;
  nodeptr = NULL;
  return retval;
}

//
// This is for handling AND in relational expressions.
// Returns true on success, false otherwise.
//
// g_conjunction = g_relational_term g_conjunction_tail
// g_conjunction_tail = AND g_relational_term g_conjunction_tail
// g_conjunction_tail = epsilon
//
static bool g_conjunction(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success
  treenode *nodeptr = NULL;          // pointer to hold current subtree during construction
  bool retval = true;                // function return value

  debug_printf("g_conjunction -> g_relational_term g_conjunction_tail\n");
  if (!g_relational_term(ss, &nodeptr)) {
    retval = false;
    goto done;
  }
  while (T_AND == peek_next_tid(ss)) {
    token *curtoken = get_next_token(ss);   // copy of next token
    treenode *nodeptr2 = NULL,            // pointer for g_relational_term subtree during construction
             *nodeptr3 = NULL;            // pointer for new parent subtree during construction

    debug_printf("g_conjunction_tail -> %s g_relational_term g_conjunction_tail\n", token_names[T_AND]);
    if (!extensions) {                    // AND is not permitted without extensions enabled
      uint32_t lno = curtoken->lno;

      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[T_AND] + 2);
    }
    if (!g_relational_term(ss, &nodeptr2)) {
      retval = false;
      tree_delete_all(&nodeptr2);
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      goto done;
    }
    nodeptr3 = create_tree_node2(2U, curtoken);
    nodeptr3->children[0] = nodeptr;
    nodeptr3->children[1] = nodeptr2;
    nodeptr = nodeptr3;
    nodeptr3 = nodeptr2 = NULL;
  }
  debug_printf("g_conjunction_tail -> epsilon\n");
done:
  *node = nodeptr;
  nodeptr = NULL;
  return retval;
}

//
// This is is for handling optional NOT in logical expressions.
// Returns true on success, false otherwise.
//
// g_relational_term = g_not g_relational_primary
// g_not = NOT
// g_not = epsilon
//
static bool g_relational_term(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success
  treenode *nodeptr = NULL;          // pointer to hold current subtree during construction
  token *curtoken = NULL;            // pointer to current token
  bool notflag = false,              // we saw a T_NOT, defaults to false
       retval = true;                // function return value, defaults to true

  debug_printf("g_relational_term -> g_not g_relational_primary\n");
  if (T_NOT == peek_next_tid(ss)) {
    debug_printf("g_not -> %s\n", token_names[T_NOT]);
    notflag = true;
    curtoken = get_next_token(ss);
    if (!extensions) {               // NOT is not permitted without extensions enabled
      uint32_t lno = curtoken->lno;

      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[T_NOT] + 2);
    }
  } else {
    debug_printf("g_not -> epsilon\n");
  }
  if (!g_relational_primary(ss, &nodeptr)) {
    retval = false;
    tree_delete_all(&nodeptr);
    if (notflag) {
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    }
    goto done;
  }
  if (notflag) {
    treenode *nodeptr2 = NULL;

    nodeptr2 = create_tree_node2(1U, curtoken);
    nodeptr2->children[0] = nodeptr;
    nodeptr = nodeptr2;
    nodeptr2 = NULL;
  }
done:
  *node = nodeptr;
  nodeptr = NULL;
  return retval;
}

//
// This is part of handling AND/OR/NOT and parentheses in
// logical expressions.
// Returns true on success, false otherwise.
//
// g_relational_primary -> ( g_relational-expression )
// g_relational_primary -> g_comparison
//
// Tricky: The first production is tried, and if it fails then the
// parser backtracks (rewinds the token stream) and tries the second
// production instead.
//
static bool g_relational_primary(
    scanner_state *ss,
    treenode **node) {                       // pointer to AST node created on success
  uint32_t cur_column = ss->current_column_number; // remember column number in scanner
  uint64_t cur_input_buffer_position = ss->pos; // remember current absolute position in
                                             // input byte stream so we can backtrack
                                             // if necessary
  enum token_ids next_tid = peek_next_tid(ss); // next token identifier

  if (0U == cur_input_buffer_position)
    FATAL(__FILE__, __func__, __LINE__, "Bogus input position %" PRIu64 "\n", cur_input_buffer_position);
  if (T_LPAREN == next_tid) {
    bool result;                             // did speculative parse succeed?

    debug_printf("g_relational_primary -> ( g_relational_expression )\n");
    suppress_errors = true;
    result = match(ss, T_LPAREN, __func__) &&
             g_relational_expression(ss, node) &&
             match(ss, T_RPAREN, __func__);
    suppress_errors = false;
    if (result)
      return result;
    // OK, reset input position (rewind) to try again since T_LPAREN
    // must have been part of an arithmetic expression ....
    debug_printf("g_relational_primary match failed, backtracking to position %" PRIu64 "....\n", cur_input_buffer_position);
    // set_buffer_position(cur_input_buffer_position, cur_column);
    ss->current_column_number = cur_column;
    ss->pos = cur_input_buffer_position;
    next_tid = peek_next_tid(ss);
    if (T_LPAREN != next_tid)
      FATAL(__FILE__, __func__, __LINE__, "Expected T_LPAREN, got %s\n", token_names[next_tid]);
  }
  debug_printf("g_relational_primary -> g_comparison\n");
  return g_comparison(ss, node);
}

//
// This function will process simple relational expressions.
// Returns true on success, false otherwise.
//
// g_comparison -> g_string_expression g_relop2 g_string_expression
// g_relop2 -> T_EQ
// g_relop2 -> T_NE
// g_comparison -> g_numeric_expression g_relop g_numeric_expression
// g_relop -> T_EQ
// g_relop -> T_NE
// g_relop -> T_GT
// g_relop -> T_GE
// g_relop -> T_LT
// g_relop -> T_LE
//
static bool g_comparison(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success
  bool stringexpression = false;     // is this a string comparison? defaults to false
  token *nt = peek_next_token(ss);

  *node = create_tree_node(2U, T_EQ, "=", nt->lno, 0U);
  free(nt->toketext); nt->toketext = NULL; free(nt); nt = NULL;
  switch (peek_next_tid(ss)) {
    case T_QSTRING:
    case T_SVAR:
      stringexpression = true;                // signal this is a comparison between string expressions
      break;
    default:
      stringexpression = false;               // signal this is a comparison between arithmetic expressions
      break;
  }
  if (stringexpression) {                     // string comparison
    debug_printf("%s", "g_comparison -> g_string_expression g_relop2 g_string_expression\n");
    if (!g_string_expression(ss, &((*node)->children[0]))) {
      return false;
    }
  } else {                                    // numeric comparison
    debug_printf("%s", "g_comparison -> g_numeric_expression g_relop g_numeric_expression\n");
    if (!g_numeric_expression(ss, &((*node)->children[0]))) {
      return false;
    }
    if (verbose) {
      debug_printf("%s(): LHS Postfix evaluation plan:\n", __func__);
      tree_postorder((*node)->children[0], dump_tree_node_string);
      debug_printf("%s", "\n");
      fflush(stdout);
    }
  }
  free((*node)->leaftoken->toketext);
  (*node)->leaftoken->toketext = NULL;
  free((*node)->leaftoken);
  (*node)->leaftoken = NULL;
  (*node)->leaftoken = get_next_token(ss);
  switch((*node)->leaftoken->tid) {
    case T_LE:
      if (stringexpression && !extensions) {
        ERROR(emsg[172], (*node)->leaftoken->lno);
        return false;
      }
      if (!match2((*node)->leaftoken, T_LE, __func__))
        return false;
      break;
    case T_LT:
      if (stringexpression && !extensions) {
        ERROR(emsg[173], (*node)->leaftoken->lno);
        return false;
      }
      if (!match2((*node)->leaftoken, T_LT, __func__))
        return false;
      break;
    case T_GE:
      if (stringexpression && !extensions) {
        ERROR(emsg[174], (*node)->leaftoken->lno);
        return false;
      }
      if (!match2((*node)->leaftoken, T_GE, __func__))
        return false;
      break;
    case T_GT:
      if (stringexpression && !extensions) {
        ERROR(emsg[175], (*node)->leaftoken->lno);
        return false;
      }
      if (!match2((*node)->leaftoken, T_GT, __func__))
        return false;
      break;
    case T_EQ:
      if (!match2((*node)->leaftoken, T_EQ, __func__))
        return false;
      break;
    case T_NE:
      if (!match2((*node)->leaftoken, T_NE, __func__))
        return false;
      break;
    default:                                  // bogus relop
      ERROR(emsg[176], (*node)->leaftoken->lno, token_names[(*node)->leaftoken->tid] + 2);
      return false;
  }
  if (verbose) {
    if (stringexpression) {
      debug_printf("g_relop2 -> %s\n", token_names[(*node)->leaftoken->tid]);
    } else {
      debug_printf("g_relop -> %s\n", token_names[(*node)->leaftoken->tid]);
    }
  }
  if (stringexpression) {
    if (!g_string_expression(ss, &((*node)->children[1]))) {
      ERROR(emsg[177], (*node)->leaftoken->lno);
      return false;
    }
  } else {
    if (!g_numeric_expression(ss, &((*node)->children[1]))) {
      ERROR(emsg[178], (*node)->leaftoken->lno);
      return false;
    }
    if (verbose) {
      debug_printf("%s(): RHS Postfix evaluation plan:\n", __func__);
      tree_postorder((*node)->children[1], dump_tree_node_string);
      debug_printf("%s", "\n");
      fflush(stdout);
    }
  }
  return true;
}

//
// Parse a DEF statement for a UDF (user-defined function).
// Before calling g_numeric_expression,
// this function will set in_udf_definition to true so that arithmetic expression
// evaluation will prefix the normal symbol table lookup for scalar numeric variables
// by a test to see if the scalar variable name is actually the name of the parameter
// for the function, if one exists.  After g_numeric_expression returns, the
// in_udf_definition flag is set to false to resume normal processing of arithmetic
// expressions.
// During processing of the DEF, curfunc_name is set the the UDF function name and
// curfunc_argname is set the the UDF function parameter (argument) name, if one exists.
// Both of these are cleared after the DEF processing is complete.
// Returns true on success, false otherwise.
//
// g_defstmt -> T_DEF T_FNID g_def_arglist T_EQ g_numeric_expression
// g_def_arglist -> TLPAREN T_NVAR TRPAREN
// g_def_arglist -> epsilon
//
static bool g_defstmt(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  token *funcname_token = NULL,       // pointer to name token of UDF
        *funcarg_token = NULL,        // pointer to name token of UDF parameter (if there is one)
        *deftoken = get_next_token(ss); // pointer to T_DEFtoken

  debug_printf("%s", "g_defstmt -> T_DEF T_FNID g_def_arglist T_EQ g_numeric_expression\n");
  if (!match2(deftoken, T_DEF, __func__))
    goto f1;
  funcname_token = get_next_token(ss);
  if (!match2(funcname_token, T_FNID, __func__))
    goto f2;
  debug_printf("T_FNID is <<<%s>>>\n", funcname_token->toketext);
  if (T_LPAREN == peek_next_tid(ss)) {
    debug_printf("%s", "g_def_arglist -> TLPAREN T_NVAR TRPAREN\n");
    if (!match(ss, T_LPAREN, __func__))
      goto f2;
    funcarg_token = get_next_token(ss);
    if (!match2(funcarg_token, T_NVAR, __func__))
      goto f3;
    debug_printf("T_NVAR is <<<%s>>>\n", funcarg_token->toketext);
    if (!match(ss, T_RPAREN, __func__))
      goto f3;
    *node = create_tree_node2(3U, deftoken);
    (*node)->children[0] = create_tree_node2(0U, funcname_token);
    (*node)->children[1] = create_tree_node2(0U, funcarg_token);
  } else {
    debug_printf("%s", "g_def_arglist -> epsilon\n");
    *node = create_tree_node2(2U, deftoken);
    (*node)->children[0] = create_tree_node2(0U, funcname_token);
  }
  if (!match(ss, T_EQ, __func__))
    return false;
  return g_numeric_expression(ss, &((*node)->children[(*node)->numchildren - 1U])); // process body of UDF
  // error exit points
f3:
  free(funcarg_token->toketext); funcarg_token->toketext = NULL; free(funcarg_token); funcarg_token = NULL;
f2:
  free(funcname_token->toketext); funcname_token->toketext = NULL; free(funcname_token); funcname_token = NULL;
f1:
  free(deftoken->toketext); deftoken->toketext = NULL; free(deftoken); deftoken = NULL;
  return false;
}

//
// This is used when parsing a Minimal BASIC line number as part of another production.
// The why parameter, used for error messages, must have room for an 80 byte string.
// The lno is the actual Minimal BASIC line number T_INTEGER contains.
// Returns true on success, false otherwise.
//
// g_lineno -> T_INTEGER
//
static bool g_lineno(
    scanner_state *ss,
    uint32_t *lno,                           // pointer to buffer containing ASCIIZ text of line number
    char *why,                               // pointer to string containing error message on failure, and
                                             // must have room for ERROR_BUFFER_LEN bytes
    const bool jumptarget) {                 // If the jumptarget parameter is true, the line number must
                                             // start in the first column, and thus be a valid jump target.
  token *curtoken = get_next_token(ss);      // pointer to next token
  uint32_t tlineno;                          // numeric line number value for lno
  bool retval = false;                       // function return value, default to false

  debug_printf("g_lineno -> T_INTEGER <<<value is '%s'>>>\n", curtoken->toketext);
  if (!match2(curtoken, T_INTEGER, __func__))
    goto xit;
  deep_debug_printf("LINE %s on line %" PRIu32 " starts in column %" PRIu32 "\n", curtoken->toketext, curtoken->lno, curtoken->cno);
  if (jumptarget && (curtoken->cno != 1U)) { // jump target line numbers must begin in the first column
    snprintf(why, ERROR_BUFFER_LEN, emsg[166], curtoken->toketext);
    why[ERROR_BUFFER_LEN - 1U] = 0;          // ensure ASCIIZ string termination
    goto xit;
  }
  if (!convert_line_number(curtoken->toketext, &tlineno, why))
    goto xit;
  // range checks - lines must be between 1 and MAXLINENO inclusive
  if (tlineno < 1U) {
    snprintf(why, ERROR_BUFFER_LEN, emsg[167], tlineno);
    why[ERROR_BUFFER_LEN - 1U] = 0;          // ensure ASCIIZ string termination
    goto xit;
  }
  if (tlineno > MAXLINENO) {
    snprintf(why, ERROR_BUFFER_LEN, emsg[168], tlineno, MAXLINENO);
    why[ERROR_BUFFER_LEN - 1U] = 0;          // ensure ASCIIZ string termination
    goto xit;
  }
  why[0] = 0;     // no error, clear error message buffer
  *lno = tlineno; // copy line number value to return parameter
  retval = true;
xit:
  free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
  return retval;
}

//
// This is used when parsing a Minimal BASIC line number as part of another production.
// If the jumptarget parameter is true, the line number must start in the first column,
// and thus be a valid jump target.
// The why parameter, used for error messages, must have room for an 80 byte string.
// The lno is the actual Minimal BASIC line number T_INTEGER contains.
// Returns true on success, false otherwise.
//
// g_lineno2 -> T_INTEGER
//
static bool g_lineno2(
    token *curtoken,           // pointer to current token
    uint32_t *lno,             // pointer to buffer containing ASCIIZ text of line number
    char *why,                 // pointer to string containing error message on failure, and
                               // must have room for ERROR_BUFFER_LEN bytes
    const bool jumptarget) {   // If the jumptarget parameter is true, the line number must
                               // start in the first column, and thus be a valid jump target.
  uint32_t tlineno;            // numeric line number value of lno

  debug_printf("g_lineno2 -> T_INTEGER <<<value is '%s'>>>\n", curtoken->toketext);
  if (!match2(curtoken, T_INTEGER, __func__))
    return false;
  deep_debug_printf("LINE %s on line %" PRIu32 " starts in column %" PRIu32 "\n", curtoken->toketext, curtoken->lno, curtoken->cno);
  if (jumptarget && (curtoken->cno != 1U)) { // jump target line numbers must begin in the first column
    snprintf(why, ERROR_BUFFER_LEN, emsg[166], curtoken->toketext);
    why[ERROR_BUFFER_LEN - 1U] = 0;          // ensure ASCIIZ string termination
    return false;
  }
  if (!convert_line_number(curtoken->toketext, &tlineno, why))
    return false;
  // range checks - lines must be between 1 and MAXLINENO inclusive
  if (tlineno < 1U) {
    snprintf(why, ERROR_BUFFER_LEN, emsg[167], tlineno);
    why[ERROR_BUFFER_LEN - 1U] = 0;          // ensure ASCIIZ string termination
    return false;
  }
  if (tlineno > MAXLINENO) {
    snprintf(why, ERROR_BUFFER_LEN, emsg[168], tlineno, MAXLINENO);
    why[ERROR_BUFFER_LEN - 1U] = 0;          // ensure ASCIIZ string termination
    return false;
  }
  why[0] = 0;     // no error, clear error message buffer
  *lno = tlineno; // copy line number value to return parameter
  return true;
}

//
// Parse an IF statement.
// Returns true on success, false otherwise.
//
// This production is used if extensions are active and we want
// to support AND/OR/NOT and parenthesis:
//
// g_ifstmt -> T_IF g_relational_expression T_THEN g_lineno
//
// This production is used if extensions are not active and we want
// strict ECMA-55 Minimal BASIC compliance:
//
// g_ifstmt -> T_IF g_comparison T_THEN g_lineno
//
static bool g_ifstmt(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  token *iftoken = get_next_token(ss), // pointer to T_IF token
        *linenotoken = NULL;          // pointer to token with IF statement target line number
  uint32_t tlineno;                   // numeric target line number value to branch to if
                                      // g_relational_expression is true
  char msg[ERROR_BUFFER_LEN];         // pointer to buffer for error message

  debug_printf("%s", "g_ifstmt -> T_IF g_relational_expression T_THEN g_lineno\n");
  if (!match2(iftoken, T_IF, __func__)) {
    free(iftoken->toketext); iftoken->toketext = NULL; free(iftoken); iftoken = NULL;
    return false;
  }
  *node = create_tree_node2(2U, iftoken);
  if (extensions) {
    if (!g_relational_expression(ss, &((*node)->children[0])))
      return false;
  } else {
    if (!g_comparison(ss, &((*node)->children[0])))
      return false;
  }
  if (!match(ss, T_THEN, __func__))
    return false;
  linenotoken = get_next_token(ss);
  if (!g_lineno2(linenotoken, &tlineno, msg, false)) {
    fputs(msg, stderr);
    free(linenotoken->toketext); linenotoken->toketext = NULL; free(linenotoken); linenotoken = NULL;
    return false;
  }
  (*node)->children[1] = create_tree_node2(0U, linenotoken);
  linenotoken = NULL;
  (*node)->children[1]->numeric_value.uivalue = tlineno;
  return true;
}

//
// Parse ON .. GOTO statement.
// Returns true on success, false otherwise.
//
// g_on_gotostmt -> T_ON g_numeric_expression g_on_gotostmt_tail1
// g_on_gotostmt_tail1 -> T_GOTO g_lineno g_on_gotostmt_tail
// g_on_gotostmt_tail1 -> T_GO T_TO g_lineno g_on_gotostmt_tail
// g_on_gotostmt_tail -> T_COMMA g_lineno g_on_gotostmt_tail
// g_on_gotostmt_tail -> epsilon
//
static bool g_on_gotostmt(
    scanner_state *ss,
    treenode **node) {                       // pointer to AST node created on success
  uint32_t tlineno,                          // variable to hold a jump target line number
           mylineno,                         // line number of the ON..GOTO statement
           i;                                // loop index variable used to iterate over lineno[] when emitting the jump table
  char msg[ERROR_BUFFER_LEN];                // pointer to buffer for error message
  char **rlineno = (char **)xmalloc(__FILE__,__func__,__LINE__,sizeof(char *)*MAXONJUMPTARGETS);        // vector of jump target line numbers as strings
  uint32_t *lineno = (uint32_t *)xmalloc(__FILE__,__func__,__LINE__,sizeof(uint32_t)*MAXONJUMPTARGETS); // vector of jump target line numbers as 32 bit integers
  uint32_t curlinenoslot = 0U;               // index of current slot in lineno[]
  treenode *nodeptr = NULL;                  // pointer to AST for g_numeric_expression subexpression
  token *ontoken = get_next_token(ss), // pointer to T_ON token
        *nt = NULL;

  debug_printf("%s", "g_on_gotostmt -> T_ON g_numeric_expression g_on_gotostmt_tail1\n");
  if (!match2(ontoken, T_ON, __func__)) {
    free(ontoken->toketext); ontoken->toketext = NULL; free(ontoken); ontoken = NULL;
    free(rlineno); rlineno = NULL;
    free(lineno); lineno = NULL;
    return false;
  }
  nt = peek_next_token(ss);
  mylineno = nt->lno;
  free(nt->toketext); nt->toketext = NULL; free(nt); nt = NULL;
  if (!g_numeric_expression(ss, &nodeptr)) {
    free(ontoken->toketext); ontoken->toketext = NULL; free(ontoken); ontoken = NULL;
    free(rlineno); rlineno = NULL;
    free(lineno); lineno = NULL;
    return false;
  }
  if (verbose) {
    debug_printf("%s(): Postfix evaluation plan:\n", __func__);
    tree_postorder(nodeptr, dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  switch (peek_next_tid(ss)) {
    case T_GOTO:
      debug_printf("%s", "g_on_gotostmt_tail1 -> T_GOTO g_lineno g_on_gotostmt_tail\n");
      if (!match(ss, T_GOTO, __func__)) {
        free(ontoken->toketext); ontoken->toketext = NULL; free(ontoken); ontoken = NULL;
        free(rlineno); rlineno = NULL;
        free(lineno); lineno = NULL;
        return false;
      }
      break;
    case T_GO:
      debug_printf("%s", "g_on_gotostmt_tail1 -> T_GO T_TO g_lineno g_on_gotostmt_tail\n");
      if (!match(ss, T_GO, __func__)) {
        free(ontoken->toketext); ontoken->toketext = NULL; free(ontoken); ontoken = NULL;
        free(rlineno); rlineno = NULL;
        free(lineno); lineno = NULL;
        return false;
      }
      if (!match(ss, T_TO, __func__)) {
        free(ontoken->toketext); ontoken->toketext = NULL; free(ontoken); ontoken = NULL;
        free(rlineno); rlineno = NULL;
        free(lineno); lineno = NULL;
        return false;
      }
      break;
    default:
      return false;
  }
  do {
    nt = peek_next_token(ss);
    rlineno[curlinenoslot] = strdup(nt->toketext);
    free(nt->toketext); nt->toketext = NULL; free(nt); nt = NULL;
    if (!g_lineno(ss, &tlineno, msg, false)) {
      fputs(msg, stderr);
      free(ontoken->toketext); ontoken->toketext = NULL; free(ontoken); ontoken = NULL;
      free(rlineno); rlineno = NULL;
      free(lineno); lineno = NULL;
      return false;
    }
    lineno[curlinenoslot++] = tlineno;
    debug_printf("%s", "g_on_gotostmt_tail -> T_COMMA g_lineno g_on_gotostmt_tail\n");
    if (T_COMMA != peek_next_tid(ss))
      break;
    if (!match(ss, T_COMMA, __func__)) {
      free(rlineno); rlineno = NULL;
      free(lineno); lineno = NULL;
      return false;
    }
  } while (curlinenoslot - 1 < MAXONJUMPTARGETS);
  debug_printf("%s", "g_on_gotostmt_tail -> epsilon\n");
  if (MAXONJUMPTARGETS == curlinenoslot)
    ICE(__FILE__, __func__, __LINE__, emsg[34], __func__, MAXONJUMPTARGETS);
  *node = create_tree_node2(1 + curlinenoslot, ontoken);
  (*node)->children[0] = nodeptr;
  for (i = 0U; i < curlinenoslot; ++i) {
    (*node)->children[i + 1] = create_tree_node(0U, T_INTEGER, rlineno[i], mylineno, 0U);
    (*node)->children[i + 1]->numeric_value.uivalue = lineno[i];
    free(rlineno[i]);
    rlineno[i] = NULL;
  }
  free(rlineno); rlineno = NULL;
  free(lineno); lineno = NULL;
  return true;
}

//
// This is used as part of the LET and INPUT statement processing.  It will process a
// destination variable expression.
// Returns true on success, false otherwise.
//
// g_target_variable -> T_NAVAR T_LPAREN g_numeric_expression g_target_arraytail2 T_RPAREN
// g_target_arraytail2 -> T_COMMA g_numeric_expression
// g_target_arraytail2 -> epsilon
// g_target_variable -> T_NVAR
// g_target_variable -> T_SVAR
//
static bool g_target_variable(
    scanner_state *ss,
    treenode **node) {                 // pointer to AST node created on success
  token *curtoken = get_next_token(ss);  // pointer to next token
  treenode *firstindex = NULL;         // pointer to AST node for first index expression

  switch(curtoken->tid) {
    case T_NAVAR:       // numeric array variable
      debug_printf("%s", "g_target_variable -> T_NAVAR T_LPAREN g_numeric_expression g_target_arraytail2 T_RPAREN\n");
      debug_printf("T_NAVAR <<<value is '%s'>>>\n", curtoken->toketext);
      if (!match(ss, T_LPAREN, __func__)) {
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        return false;
      }
      if (!g_numeric_expression(ss, &firstindex)) {
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        return false;
      }
      if (T_COMMA == peek_next_tid(ss)) { // 2-d matrix
        debug_printf("%s", "g_target_arraytail2 -> T_COMMA g_numeric_expression\n");
        *node = create_tree_node2(2U, curtoken);
        if (!match(ss, T_COMMA, __func__))
          return false;
        if (!g_numeric_expression(ss, &(*node)->children[1]))
          return false;
      } else {                                 // 1-d vector
        debug_printf("%s", "g_target_arraytail2 -> epsilon\n");
        *node = create_tree_node2(1U, curtoken);
      }
      if (!match(ss, T_RPAREN, __func__))
        return false;
      (*node)->children[0] = firstindex;
      firstindex = NULL;
      if (verbose) {
        debug_printf("%s", "g_target_variable(): Postfix evaluation plan:\n");
        tree_postorder(*node, dump_tree_node_string);
        debug_printf("%s", "\n");
        fflush(stdout);
      }
      break;
    case T_NVAR:                               // numeric scalar variable
      debug_printf("%s", "g_target_variable -> T_NVAR\n");
      *node = create_tree_node2(0U, curtoken);
      debug_printf("T_NVAR <<<value is '%s'>>>\n", (*node)->leaftoken->toketext);
      break;
    case T_SVAR:                               // string scalar variable
      debug_printf("%s", "g_target_variable -> T_SVAR\n");
      *node = create_tree_node2(0U, curtoken);
      debug_printf("T_SVAR <<<value is '%s'>>>\n", (*node)->leaftoken->toketext);
      break;
    case T_COMMA:                              // error production
      ERROR(emsg[179], curtoken->lno);
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return false;
    default:
      ERROR(emsg[180], token_names[T_READ] + 2, curtoken->lno);
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return false;
  }
  return true;
}

//
// Parse an INPUT statement.
// Returns true on success, false otherwise.
//
// g_inputstmt -> T_INPUT g_target_variable g_inputstmt_tail
// g_inputstmt_tail -> g_target_variable g_inputstmt_tail
// g_inputstmt_tail -> epsilon
//
static bool g_inputstmt(
    scanner_state *ss,
    treenode **node) {                       // pointer to AST node created on success
  bool retval = true;                        // return value of this function, defaults to true
  token *inputtoken = get_next_token(ss);    // pointer to T_INPUT token
  struct iitem {                             // A linked list of nodes is created, each of which has
                                             // a pointer to the AST node for a g_target_variable, as
                                             // we go and then later put them into the INPUT statement's
                                             // AST after the entire INPUT statement has been parsed
    treenode *n;                             // pointer to AST node for a g_target_variable
    struct iitem *next;                      // pointer to next node in linked list
  } *head = NULL,                            // pointer to head of linked list of iitem
    *tail = NULL;                            // pointer to tail of linked list of iitem
  uint32_t iitemcount = 0U;                  // count of number of iitem nodes in linked list
  unsigned int i;                            // loop index variable

  debug_printf("%s", "g_inputstmt -> T_INPUT g_target_variable g_inputstmt_tail\n");
  if (!match2(inputtoken, T_INPUT, __func__)) {
    free(inputtoken->toketext); inputtoken->toketext = NULL; free(inputtoken); inputtoken = NULL;
    return false;
  }
  do {
    treenode *nodeptr = NULL;

    if (!g_target_variable(ss, &nodeptr)) {
      retval = false;
      tree_delete_all(&nodeptr);
      goto xit;
    }
    if (!head) {
      head = (struct iitem *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct iitem));
      tail = head;
    } else {
      tail->next = (struct iitem *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct iitem));
      tail = tail->next;
    }
    tail->n = nodeptr;
    tail->next = NULL;
    iitemcount++;
    if (T_COMMA != peek_next_tid(ss))
      break;
    if (!match(ss, T_COMMA, __func__)) {
      debug_printf("%s", "g_inputstmt_tail -> epsilon\n");
      retval = false;
      goto xit;
    }
    debug_printf("%s", "g_inputstmt_tail -> g_target_variable g_inputstmt_tail\n");
  } while (true);
xit:
  *node = create_tree_node2(iitemcount, inputtoken);
  inputtoken = NULL;
  for (i = 0U; i < iitemcount; ++i) {
    struct iitem *temp = head;
    head = head->next;
    if (retval) {
      (*node)->children[i] = temp->n;
    } else {
      tree_delete_all(&(temp->n));
    }
    temp->n = NULL;
    free(temp);
    temp = NULL;
  }
  return retval;
}

//
// Parse a READ statement.
// Returns true on success, false otherwise.
//
// g_readstmt -> T_READ g_target_variable g_readstmt_tail
// g_readstmt_tail -> g_target_variable g_readstmt_tail
// g_readstmt_tail -> epsilon
//
static bool g_readstmt(
    scanner_state *ss,
    treenode **node) {                       // pointer to AST node created on success
  bool retval = true;                        // return value from this function, defaults to false
  token *readtoken = get_next_token(ss);// pointer to token for T_READ
  struct ritem {                             // A linked list of nodes is created, each of which has
                                             // a pointer to the AST node for a g_target_variable, as
                                             // we go and then later put into the READ statement's
                                             // AST after the entire READ statement has been parsed
    treenode *n;                             // pointer to AST node for a g_target_variable
    struct ritem *next;                      // pointer to the next node in linked list
  } *head = NULL,                            // pointer to head of linked list of ritems
    *tail = NULL;                            // pointer to tail of linked list of ritems
  uint32_t ritemcount = 0U;                  // count of number of ritem nodes in linked list
  unsigned int i;                            // loop index variable

  debug_printf("%s", "g_readstmt -> T_READ g_target_variable g_readstmt_tail\n");
  if (!match2(readtoken, T_READ, __func__)) {
    free(readtoken->toketext); readtoken->toketext = NULL; free(readtoken); readtoken = NULL;
    return false;
  }
  do {
    treenode *nodeptr = NULL;

    if (!g_target_variable(ss, &nodeptr)) {
      retval = false;
      goto xit;
    }
    if (verbose) {
      debug_printf("%s(): Postfix evaluation plan:\n", __func__);
      tree_postorder(nodeptr, dump_tree_node_string);
      debug_printf("%s", "\n");
      fflush(stdout);
    }
    if (!head) {
      head = (struct ritem *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct ritem));
      tail = head;
    } else {
      tail->next = (struct ritem *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct ritem));
      tail = tail->next;
    }
    tail->n = nodeptr;
    tail->next = NULL;
    ritemcount++;
    debug_printf("%s", "g_readstmt_tail -> g_target_variable g_readstmt_tail\n");
    if (T_COMMA != peek_next_tid(ss))
      break;
    if (!match(ss, T_COMMA, __func__)) {
      retval = false;
      goto xit;
    }
  } while (true);
  *node = create_tree_node2(ritemcount, readtoken);
  readtoken = NULL;
xit:
  if (readtoken != NULL) {
    free(readtoken->toketext); readtoken->toketext = NULL; free(readtoken); readtoken = NULL;
  }
  for (i = 0U; i < ritemcount; ++i) {
    struct ritem *temp = head;
    head = head->next;
    if (retval) {
      (*node)->children[i] = temp->n;
    } else {
      tree_delete_all(&(temp->n));
    }
    temp->n = NULL;
    free(temp);
    temp = NULL;
  }
  debug_printf("%s", "g_readstmt_tail -> epsilon\n");
  return retval;
}

//
// Parse a single DATA statement item.
// Returns true on success, false otherwise.
//
// g_datum_value -> T_UQSTRING
// g_datum_value -> T_QSTRING
// g_datum_value -> T_INTEGER
// g_datum_value -> T_REAL
// g_datum_value -> T_PI       // -X
// g_datum_value -> T_MAXNUM   // -X
//
static bool g_datum(
    token *curtoken) {                // pointer to current token

  debug_printf("%s", "g_datum -> g_datum_value\n");
  switch(curtoken->tid) {
    case T_UQSTRING:
      debug_printf("g_datum_value -> T_UQSTRING <<<value is '%s'>>>\n", curtoken->toketext);
      if (strlen(curtoken->toketext) > MAX_STRING_BYTES) {
        ERROR(emsg[181], curtoken->lno, MAX_STRING_BYTES);
        return false;
      }
      break;
    case T_QSTRING:
      debug_printf("g_datum_value -> T_QSTRING <<<value is '%s'>>>\n", curtoken->toketext);
      if (strlen(curtoken->toketext) > MAX_STRING_BYTES) {
        ERROR(emsg[182], curtoken->lno, MAX_STRING_BYTES);
        return false;
      }
      break;
    case T_INTEGER:
      debug_printf("g_datum_value -> T_INTEGER <<<value is '%s'>>>\n", curtoken->toketext);
      break;
    case T_REAL:
      debug_printf("g_datum_value -> T_REAL <<<value is '%s'>>>\n", curtoken->toketext);
      break;
    case T_PI:
      if (extensions) debug_printf("g_datum_value -> T_PI <<<value is '%s'>>>\n", curtoken->toketext);
      break;
    case T_MAXNUM:
      if (extensions) debug_printf("g_datum_value -> T_MAXNUM <<<value is '%s'>>>\n", curtoken->toketext);
      break;
    case T_COMMA:       // error production
      ERROR(emsg[183], token_names[T_DATA] + 2, curtoken->lno);
      // FALLS THROUGH
    default:
      return false;
  }
  return true;
}

//
// Parse the DATA statement.
// Returns true on success, false otherwise.
//
// g_datastmt -> T_DATA g_datum g_datastmt_tail
// g_datastmt_tail -> T_COMMA g_datum g_datastmt_tail
// g_datastmt_tail -> epsilon
//
static bool g_datastmt(
    scanner_state *ss,
    treenode **node) {                       // pointer to AST node created on success
  bool retval = false;                       // return value of function
  token *datatoken = get_next_token(ss),     // T_DATA token
        *curtoken = NULL;                    // next token
  struct ditem {                             // A linked list of pointers to tokens is created as
                                             // we go and then later put into the DATA statement's
                                             // AST after the entire DATA statement has been parsed
     token *curtoken;                        // pointer to the token structure for this ditem
     struct ditem *next;                     // pointer to the next node in linked list
  } *head = NULL,                            // pointer to the head of the linked lists of ditems
    *tail = NULL;                            // pointer to the tail of the linked lists of ditems
  uint32_t datacount = 0U;                   // count of number of ditem nodes in linked list
  unsigned int i;                            // loop index variable

  debug_printf("%s", "g_datastmt -> T_DATA g_datum g_datastmt_tail\n");
  if (!match2(datatoken, T_DATA, __func__)) {
    free(datatoken->toketext); datatoken->toketext = NULL; free(datatoken); datatoken = NULL;
    return false;
  }
  do {
    curtoken = get_next_token(ss);
    if (!g_datum(curtoken)) {
      free(datatoken->toketext); datatoken->toketext = NULL; free(datatoken); datatoken = NULL;
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      goto xit;
    }
    if (!head) {
      head = (struct ditem *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct ditem));
      tail = head;
    } else {
      tail->next = (struct ditem *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct ditem));
      tail = tail->next;
    }
    tail->curtoken = curtoken;
    tail->next = NULL;
    curtoken = NULL;
    datacount++;
    if (T_COMMA != peek_next_tid(ss))
      break;
    debug_printf("%s", "g_datastmt_tail -> T_COMMA g_datum g_datastmt_tail\n");
    if (!match(ss, T_COMMA, __func__)) {
      free(datatoken->toketext); datatoken->toketext = NULL; free(datatoken); datatoken = NULL;
      goto xit;
    }
  } while (true);
  debug_printf("%s", "g_datastmt_tail -> epsilon\n");
  *node = create_tree_node2(datacount, datatoken);
  retval = true;
xit:
  for (i = 0U; i < datacount; ++i) {
    struct ditem *temp = head;
    head = head->next;
    if (retval) { // only if we were successful
      (*node)->children[i] = create_tree_node2(0U, temp->curtoken);
    } else {
      free(temp->curtoken->toketext);
      temp->curtoken->toketext = NULL;
      free(temp->curtoken);
    }
    temp->curtoken = NULL;
    temp->next = NULL;
    free(temp);
  }
  head = tail = NULL;
  return retval;
}

//
// This function converts a T_INTEGER token to a dimension value.
// This is a helper called by g_dimstmt()
// Returns true on success, false otherwise.
//
static bool g_getdim(
    token *curtoken,              // pointer to current token
    uint32_t *dimvalue) {         // pointer to output unsigned integer variable
  char msg[ERROR_BUFFER_LEN];     // pointer to error message buffer

  if (!match2(curtoken, T_INTEGER, __func__))
    return false;
  if (!convert_unsigned_integer(curtoken->toketext, dimvalue, msg)) {
    ERROR(emsg[169], msg, curtoken->lno);
    return false;
  }
  if (*dimvalue > MAX_SUBSCRIPT_VALUE) {
    ERROR(emsg[170], token_names[T_DIM] + 2, curtoken->lno, *dimvalue, MAX_SUBSCRIPT_VALUE);
    return false;
  }
  return true;
}

//
// Parse the DIM statement.
// Returns true on success, false otherwise.
//
// g_dimstmt -> T_DIM T_NAVAR T_LPAREN T_INTEGER g_matrix T_RPAREN g_dimtail
// g_dimtail -> T_COMMA T_NAVAR T_LPAREN T_INTEGER g_matrix T_RPAREN g_dimtail
// g_dimtail -> epsilon
// g_matrix -> T_COMMA T_INTEGER
// g_matrix -> epsilon
//
static bool g_dimstmt(
    scanner_state *ss,
    treenode **node) {                    // pointer to AST node created on success
  bool retval = false;                    // function return value
  uint32_t dim1,                          // numeric value of first dimension token (or only for 1-D)
           dim2;                          // numeric value of second dimension token (only for 2-D)
  token *dimtoken = NULL,                 // pointer to T_DIM token
        *array_name_token = NULL,         // pointer to array name token
        *dim1_token = NULL,               // pointer to first dimension token (or only for 1-D)
        *dim2_token = NULL;               // pointer to second dimension token (only for 2-D)
  uint32_t dimcount = 0U;                 // number of arrays specified in DIM statement
                                          // also the number of elements in linked list of onedim
  struct onedim {                         // A linked list of nodes is created, each of which has
                                          // a pointer to the AST node for one array declaration as
                                          // we go and then later they are inserted into the DIM
                                          // statement AST after the entire DIM statement has been
                                          // parsed
    treenode *n;                          // pointer to AST for one array declaration
    struct onedim *next;                  // pointer to next node in linked list
  } *head = NULL,                         // pointer to head of linked list of onedim
    *tail = NULL;                         // pointer to tail of linked list of onedim
  treenode *tn = NULL;                    // temporary AST node pointer used when constructing nodes
                                          // for the linked list
  unsigned int i;                         // loop index variable

  debug_printf("%s", "g_dimstmt -> T_DIM T_NAVAR T_LPAREN T_INTEGER g_matrix T_RPAREN g_dimtail\n");
  dimtoken = get_next_token(ss);
  if (!match2(dimtoken, T_DIM, __func__)) {
    free(dimtoken->toketext); dimtoken->toketext = NULL; free(dimtoken); dimtoken = NULL;
    return false;
  }
  do {
    array_name_token = get_next_token(ss);
    if (!match2(array_name_token, T_NAVAR, __func__)) {
      free(dimtoken->toketext); dimtoken->toketext = NULL; free(dimtoken); dimtoken = NULL;
      free(array_name_token->toketext); array_name_token->toketext = NULL; free(array_name_token); array_name_token = NULL;
      goto xit;
    }
    if (!match(ss, T_LPAREN, __func__)) {
      free(dimtoken->toketext); dimtoken->toketext = NULL; free(dimtoken); dimtoken = NULL;
      free(array_name_token->toketext); array_name_token->toketext = NULL; free(array_name_token); array_name_token = NULL;
      goto xit;
    }
    dim1_token = get_next_token(ss);
    if (!g_getdim(dim1_token, &dim1)) {
      free(dimtoken->toketext); dimtoken->toketext = NULL; free(dimtoken); dimtoken = NULL;
      free(array_name_token->toketext); array_name_token->toketext = NULL; free(array_name_token); array_name_token = NULL;
      free(dim1_token->toketext); dim1_token->toketext = NULL; free(dim1_token); dim1_token = NULL;
      goto xit;
    }
    if (T_COMMA == peek_next_tid(ss)) { // matrix
      debug_printf("%s", "g_matrix -> T_COMMA T_INTEGER\n");
      if (!match(ss, T_COMMA, __func__)) {
        free(dimtoken->toketext); dimtoken->toketext = NULL; free(dimtoken); dimtoken = NULL;
        free(array_name_token->toketext); array_name_token->toketext = NULL; free(array_name_token); array_name_token = NULL;
        free(dim1_token->toketext); dim1_token->toketext = NULL; free(dim1_token); dim1_token = NULL;
        goto xit;
      }
      dim2_token = get_next_token(ss);
      if (!g_getdim(dim2_token, &dim2)) {
        free(dimtoken->toketext); dimtoken->toketext = NULL; free(dimtoken); dimtoken = NULL;
        free(array_name_token->toketext); array_name_token->toketext = NULL; free(array_name_token); array_name_token = NULL;
        free(dim1_token->toketext); dim1_token->toketext = NULL; free(dim1_token); dim1_token = NULL;
        free(dim2_token->toketext); dim2_token->toketext = NULL; free(dim2_token); dim2_token = NULL;
        goto xit;
      }
      tn = create_tree_node2(2U, array_name_token);
      array_name_token = NULL;
      tn->children[0] = create_tree_node2(0U, dim1_token);
      tn->children[0]->numeric_value.uivalue = dim1;
      dim1_token = NULL;
      tn->children[1] = create_tree_node2(0U, dim2_token);
      tn->children[1]->numeric_value.uivalue = dim2;
      dim2_token = NULL;
    } else { // vector
      debug_printf("%s", "g_matrix -> epsilon\n");
      tn = create_tree_node2(1U, array_name_token);
      array_name_token = NULL;
      tn->children[0] = create_tree_node2(0U, dim1_token);
      tn->children[0]->numeric_value.uivalue = dim1;
      dim1_token = NULL;
    }
    if (!match(ss, T_RPAREN, __func__)) {
      free(dimtoken->toketext); dimtoken->toketext = NULL; free(dimtoken); dimtoken = NULL;
      goto xit;
    }
    if (!head) {
      tail = (struct onedim *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct onedim));
      head = tail;
    } else {
      tail->next = (struct onedim *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct onedim));
      tail = tail->next;
    }
    tail->n = tn;
    tail->next = NULL;
    tn = NULL;
    ++dimcount;
    if (T_COMMA != peek_next_tid(ss))
      break;
    debug_printf("%s", "g_dimtail -> T_COMMA T_NAVAR T_LPAREN T_INTEGER g_matrix T_RPAREN g_dimtail\n");
    if (!match(ss, T_COMMA, __func__)) {
      free(dimtoken->toketext); dimtoken->toketext = NULL; free(dimtoken); dimtoken = NULL;
      goto xit;
    }
  } while (true);
  debug_printf("%s", "g_dimtail -> epsilon\n");
  *node = create_tree_node2(dimcount, dimtoken);
  retval = true;
xit:
  for (i = 0U; i < dimcount; ++i) {
    struct onedim *temp;
    temp = head;
    head = head->next;
    if (retval) // only if things went well
      (*node)->children[i] = temp->n;
    temp->n = NULL;
    temp->next = NULL;
    free(temp);
  }
  tail = NULL;
  return retval;
}

//
// Parse the NEXT statement.
// Returns true on success, false otherwise.
//
// g_nextstmt -> T_NEXT T_NVAR
//
static bool g_nextstmt(
    scanner_state *ss,
    treenode **node) {                 // pointer to AST node created on success
  token *nextvartoken = NULL,          // pointer to T_NVAR (loop index variable) token
        *nexttoken = get_next_token(ss); // pointer to T_NEXT token

  debug_printf("%s", "g_nextstmt -> T_NEXT T_NVAR\n");
  if (!match2(nexttoken, T_NEXT, __func__)) {
    free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
    return false;
  }
  nextvartoken = get_next_token(ss);
  if (!match2(nextvartoken, T_NVAR, __func__)) {
    free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
    free(nextvartoken->toketext); nextvartoken->toketext = NULL; free(nextvartoken); nextvartoken = NULL;
    return false;
  }
  debug_printf("T_NVAR <<<value is '%s'>>>\n", nextvartoken->toketext);
  // child 0 is index variable
  // child 1 will be loop body label (filled in later in sc_nextstmt())
  // child 2 will be bottom of loop label (filled in later in sc_nextstmt())
  // child 3 will be test of loop exit condition label (filled in later in sc_nextstmt())
  // child 4 will be increment variable (filled in later in sc_nextstmt())
  // child 5 will be limit variable (filled in later in sc_nextstmt())
  *node = create_tree_node2(6U, nexttoken);
  nexttoken = NULL;
  (*node)->children[0] = create_tree_node2(0U, nextvartoken);
  nextvartoken = NULL;
  return true;
}

//
// Parse the FOR statement.
// Returns true on success, false otherwise.
//
// g_forstmt -> T_FOR T_NVAR T_EQ g_numeric_expression T_TO g_numeric_expression g_for_tail
// g_for_tail -> T_STEP g_numeric_expression
// g_for_tail -> epsilon
//
static bool g_forstmt(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  token *fortoken = get_next_token(ss), // pointer to T_FOR token
        *indextoken = NULL;           // pointer to T_NVAR (loop index variable) token

  debug_printf("%s", "g_forstmt -> T_FOR T_NVAR T_EQ g_numeric_expression T_TO g_numeric_expression g_for_tail\n");
  if (!match2(fortoken, T_FOR, __func__)) {
    free(fortoken->toketext); fortoken->toketext = NULL; free(fortoken); fortoken = NULL;
    return false;
  }
  // children[0] is index variable
  // children[1] is start expression
  // children[2] is stop expression
  // children[3] is increment expression
  // children[4] is test of loop exit condition label (filled in later)
  // children[5] is body of loop label (filled in later)
  // children[6] is bottom of loop label (filled in later)
  // children[7] is hidden increment variable name (filled in later)
  // children[8] is hidden limit variable name (filled in later)
  *node = create_tree_node2(9U, fortoken);
  fortoken = NULL;
  indextoken = get_next_token(ss);
  if (!match2(indextoken, T_NVAR, __func__)) {
    free(indextoken->toketext); indextoken->toketext = NULL; free(indextoken); indextoken = NULL;
    return false;
  }
  (*node)->children[0] = create_tree_node2(0U, indextoken);
  indextoken = NULL;
  if (!match(ss, T_EQ, __func__))
    return false;
  // initial value for loop index
  if (!g_numeric_expression(ss, &((*node)->children[1])))
    return false;
  if (verbose) {
    debug_printf("%s(): Postfix evaluation plan:\n", __func__);
    tree_postorder((*node)->children[1], dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  if (!match(ss, T_TO, __func__))
    return false;
  // termination value for loop index
  if (!g_numeric_expression(ss, &((*node)->children[2])))
    return false;
  if (verbose) {
    debug_printf("%s(): Postfix evaluation plan:\n", __func__);
    tree_postorder((*node)->children[2], dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  if (T_STEP == peek_next_tid(ss)) { // if they specify an increment
    debug_printf("%s", "g_for_tail -> T_STEP g_numeric_expression\n");
    if (!match(ss, T_STEP, __func__))
      return false;
    // increment value for loop index
    if (!g_numeric_expression(ss, &((*node)->children[3])))
      return false;
    if (verbose) {
      debug_printf("%s(): Postfix evaluation plan:\n", __func__);
      tree_postorder((*node)->children[3], dump_tree_node_string);
      debug_printf("%s", "\n");
      fflush(stdout);
    }
  } else {                                // use default value of 1
    debug_printf("%s", "g_for_tail -> epsilon\n");
    (*node)->children[3] = create_tree_node(0U, T_INTEGER, "1", (*node)->leaftoken->lno, 0U);
    (*node)->children[3]->numeric_value.uivalue = 1U;
  }
  return true;
}

//
// Macro to insert one node into the linked list of nodes that serves as the temporary holding area
// while nodes are gathered from the argument list to PRINT before allocating the n-ary tree node
// in the AST to which they will ultimately be moved.
//
#define LL_INSERT(anode) \
      { \
        if (!head) { \
          head = (struct pitem *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct pitem)); \
          tail = head; \
        } else { \
          tail->next = (struct pitem *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct pitem)); \
          tail = tail->next; \
        } \
        tail->n = anode; \
        tail->next = NULL; \
        datacount++; \
      }

//
// Parse the PRINT statement.
// Returns true on success, false otherwise.
//
// g_printstmt -> T_PRINT g_printlist
//
static bool g_printstmt(
    scanner_state *ss,
    treenode **node) {                       // pointer to AST node created on success
  bool lastwascommaorsemi = true;            // flag to indicate whether the last item encountered was a separator
                                             // (T_COMMA or T_SEMI) between print expressions or not
                                             // This facilitates checking that we never get two expressions without
                                             // an intervening separator, and that the TAB() is always called
                                             // immediately after a separator
  bool done = false;                         // flag to terminate parse of g_printstmt when an end of line
                                             // (T_EOL) is reached
  bool retval = false;                       // function return value
  bool neednewline = true;                   // flag to indicate whether to flush the output buffer to STDOUT or not
                                             // it is set to false if the token just seen is T_COMMA or T_SEMI, and
                                             // true otherwise
  token *curtoken = NULL,                    // pointer to current token
        *printtoken = get_next_token(ss);    // pointer to T_PRINT token
  struct pitem {                             // A linked list of nodes is created as we go, each of which
                                             // has a pointer to an AST of an expression to be printed, and
                                             // later they are inserted into the PRINT statement AST after
                                             // the entire PRINT statement has been parsed
    treenode *n;                             // pointer to the root of an expression AST to be printed
    struct pitem *next;                      // pointer to next pitem in linked list
  } *head = NULL,                            // pointer to head of linked list of pitem
    *tail = NULL;                            // pointer to tail of linked list of pitem
  uint32_t datacount = 0U;                   // count of pitem in linked list
  unsigned int i;                            // loop index variable
  treenode *tempnode;                        // temporary used when building linked list

  debug_printf("%s", "g_printstmt -> T_PRINT g_printlist\n");
  if (!match2(printtoken, T_PRINT, __func__)) {
    free(printtoken->toketext); printtoken->toketext = NULL; free(printtoken); printtoken = NULL;
    return false;
  }
  if (T_EOL == peek_next_tid(ss))
    debug_printf("%s", "g_printlist -> epsilon\n");
  else
    debug_printf("%s", "g_printlist -> g_print_item g_print_item_tail\n");
  while (!done) {
    token *temptoken=peek_next_token(ss);
    deep_debug_printf("g_printstmt() at beginning of switch, examining %s('%s') with neednewline=%s\n",
                      token_names[peek_next_tid(ss)],
                      temptoken->toketext, neednewline ? "true" : "false");
    switch (temptoken->tid) {
      case T_EOL:
        if (datacount)
          debug_printf("%s", "g_print_item_tail -> espilon\n");
        retval = true;
        done = true;
        break;
      case T_TIMES:     // -X
      case T_DATES:     // -X
        if (!extensions) {      // These string functions are not permitted without extensions enabled
          uint32_t lno = temptoken->lno;
          enum token_ids ttid = temptoken->tid;

          free(temptoken->toketext); temptoken->toketext = NULL; free(temptoken); temptoken = NULL;
          FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[ttid] + 2);
        }
        // FALLS THROUGH
      case T_QSTRING:
      case T_SVAR:
        if (!lastwascommaorsemi) {
          // +2 is to skip the 'T_' prefix
          curtoken = peek_next_token(ss);
          ERROR(emsg[184], curtoken->lno, token_names[T_EOL] + 2, token_names[curtoken->tid] + 2, curtoken->toketext);
          free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
          free(temptoken->toketext); temptoken->toketext = NULL; free(temptoken); temptoken = NULL;
          retval = false;
          goto xit;
        }
        debug_printf("%s", "g_print_item -> g_string_expression\n");
        retval = g_string_expression(ss, &tempnode);
        if (retval) {
          LL_INSERT(tempnode);
        } else {
          tree_delete_all(&tempnode);
        }
        tempnode=NULL;
        neednewline = true;
        lastwascommaorsemi = false;
        break;
      case T_COMMA:
        curtoken = get_next_token(ss);
        debug_printf("g_print_item_tail -> %s g_print_item g_print_item_tail\n", token_names[curtoken->tid] + 2);
        retval = match2(curtoken, T_COMMA, __func__);
        if (retval)
          LL_INSERT(create_tree_node2(0U, curtoken));
        neednewline = false;
        lastwascommaorsemi = true;
        break;
      case T_SEMI:
        curtoken = get_next_token(ss);
        debug_printf("g_print_item_tail -> %s g_print_item g_print_item_tail\n", token_names[curtoken->tid] + 2);
        retval = match2(curtoken, T_SEMI, __func__);
        if (retval)
          LL_INSERT(create_tree_node2(0U, curtoken));
        neednewline = false;
        lastwascommaorsemi = true;
        break;
      case T_ACOS:       // -X
      case T_ANGLE:      // -X
      case T_ASIN:       // -X
      case T_CEIL:       // -X
      case T_COSH:       // -X
      case T_DEG:        // -X
      case T_FP:         // -X
      case T_IP:         // -X
      case T_LEN:        // -X
      case T_LOG10:      // -X
      case T_LOG2:       // -X
      case T_MAX:        // -X
      case T_MAXNUM:     // -X
      case T_MIN:        // -X
      case T_MOD:        // -X
      case T_PI:         // -X
      case T_RAD:        // -X
      case T_REMAINDER:  // -X
      case T_ROUND:      // -X
      case T_SINH:       // -X
      case T_TANH:       // -X
      case T_TRUNCATE:   // -X
      case T_DATE:       // -X
      case T_TIME:       // -X
        if (!extensions) {      // These functions are not permitted without extensions enabled
          uint32_t lno = temptoken->lno;
          enum token_ids ttid = temptoken->tid;

          free(temptoken->toketext); temptoken->toketext = NULL; free(temptoken); temptoken = NULL;
          FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[ttid] + 2);
        }
        // FALLS THROUGH
      case T_FNID:
      case T_REAL:
      case T_INTEGER:
      case T_ADD:
      case T_SUBTRACT:
      case T_LPAREN:
      case T_NVAR:
      case T_NAVAR:
      case T_ABS:
      case T_ATN:
      case T_COS:
      case T_EXP:
      case T_INT:
      case T_LOG:
      case T_RND:
      case T_SGN:
      case T_SIN:
      case T_SQR:
      case T_TAN:
        if (!lastwascommaorsemi) {
          // +2 is to skip the 'T_' prefix
          curtoken = peek_next_token(ss);
          ERROR(emsg[184], curtoken->lno, token_names[T_EOL] + 2, token_names[curtoken->tid] + 2, curtoken->toketext);
          free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
          retval = false;
          free(temptoken->toketext); temptoken->toketext = NULL; free(temptoken); temptoken = NULL;
          goto xit;
        }
        debug_printf("%s", "g_print_item -> g_numeric_expression\n");
        retval = g_numeric_expression(ss, &tempnode);
        if (retval) {
          LL_INSERT(tempnode);
        } else {
          tree_delete_all(&tempnode);
        }
        tempnode=NULL;
        neednewline = true;
        lastwascommaorsemi = false;
        break;
      case T_TAB:
        if (!lastwascommaorsemi) {
          // +2 is to skip the 'T_' prefix
          curtoken = peek_next_token(ss);
          ERROR(emsg[184], curtoken->lno, token_names[T_EOL] + 2, token_names[curtoken->tid] + 2, curtoken->toketext);
          free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
          retval = false;
          free(temptoken->toketext); temptoken->toketext = NULL; free(temptoken); temptoken = NULL;
          goto xit;
        }
        debug_printf("%s", "g_print_item -> T_TAB T_LPAREN g_numeric_expression T_RPAREN\n");
        curtoken = get_next_token(ss);
        if (!match2(curtoken, T_TAB, __func__)) {
          free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
          retval = false;
          free(temptoken->toketext); temptoken->toketext = NULL; free(temptoken); temptoken = NULL;
          goto xit;
        }
        if (!match(ss, T_LPAREN, __func__)) {
          retval = false;
          free(temptoken->toketext); temptoken->toketext = NULL; free(temptoken); temptoken = NULL;
          goto xit;
        }
        {
          treenode *tn = create_tree_node2(1U, curtoken);
          LL_INSERT(tn);
          tn = NULL;
        }
        retval = g_numeric_expression(ss, &(tail->n->children[0]));
        if (retval)
          retval = match(ss, T_RPAREN, __func__);
        neednewline = true;
        lastwascommaorsemi = false;
        break;
      default:
        {
          curtoken = peek_next_token(ss);
          ERROR(emsg[185], curtoken->lno, token_names[T_PRINT] + 2, curtoken->toketext);
          free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        }
        retval = false;
    }
    free(temptoken->toketext); temptoken->toketext = NULL; free(temptoken); temptoken = NULL;
    if (!retval)
      goto xit;
    deep_debug_printf("g_printstmt() at end of switch, neednewline=%s\n", neednewline ? "true" : "false");
  }
  if (retval && neednewline) {
    curtoken = peek_next_token(ss);
    LL_INSERT(create_tree_node(1U, T_QSTRING, "\\n", curtoken->lno, curtoken->cno));
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
  }
xit:
  if (retval) {
    deep_debug_printf("%s", "creating PRINT node\n");
    *node = create_tree_node2(datacount, printtoken);
  } else {
    deep_debug_printf("%s", "NOT creating PRINT node\n");
    free(printtoken->toketext); printtoken->toketext = NULL; free(printtoken); printtoken = NULL;
  }
  for (i = 0U; i < datacount; ++i) {
    struct pitem *temp = head;
    head = head->next;
    if (retval) { // only if we were successful
      deep_debug_printf("Adding %s to PRINT node\n", temp->n->leaftoken->toketext);
      (*node)->children[i] = temp->n;
    } else {
      deep_debug_printf("NOT Adding %s to PRINT node\n", temp->n->leaftoken->toketext);
      tree_delete_all(&(temp->n));
    }
    temp->n = NULL;
    temp->next = NULL;
    free(temp);
    temp = NULL;
  }
  head = tail = NULL;
  deep_debug_printf("g_printstmt(): returning %s\n", retval ? "true" : "false");
  return retval;
}

//
// Do a LET statement for a string variable
// g_letstmt_tail -> T_SVAR T_EQ g_string_expression
//
// but caller already consumed T_SVAR...
//
static bool let_svar(
    scanner_state *ss,
    treenode *node) {                // pointer to AST node created on success

  debug_printf("%s", "g_letstmt_tail -> g_target_variable T_EQ g_string_expression\n");
  if (!g_target_variable(ss, &(node->children[0])))
    return false;
  if (T_SVAR != node->children[0]->leaftoken->tid)
    ICE(__FILE__, __func__, __LINE__, emsg[60], token_names[T_SVAR],
        token_names[node->children[0]->leaftoken->tid],
        node->children[0]->leaftoken->lno);
  if (!match(ss, T_EQ, __func__))
    return false;
  if (!g_string_expression(ss, &(node->children[1]))) {
    ERROR(emsg[68], node->children[0]->leaftoken->toketext, node->children[0]->leaftoken->lno);
    return false;
  }
  return true;
}

//
// Do a LET statement for a scalar numeric variable
// g_letstmt_tail -> T_NVAR T_EQ g_numeric_expression
//
// but caller already consumed T_NVAR...
//
static bool let_nvar(
    scanner_state *ss,
    treenode *node) {                // pointer to AST node created on success

  debug_printf("%s", "g_letstmt_tail -> g_target_variable T_EQ g_numeric_expression\n");
  if (!g_target_variable(ss, &(node->children[0])))
    return false;
  if (T_NVAR != node->children[0]->leaftoken->tid)
    ICE(__FILE__, __func__, __LINE__, emsg[60], __func__, token_names[T_NVAR],
        token_names[node->children[0]->leaftoken->tid], node->children[0]->leaftoken->lno);
  if (T_LPAREN == peek_next_tid(ss)) {
    ERROR(emsg[186], node->children[0]->leaftoken->toketext, node->children[0]->leaftoken->lno);
    return false;
  }
  if (!match(ss, T_EQ, __func__))
    return false;
  if (!g_numeric_expression(ss, &node->children[1]))
    return false;
  if (verbose) {
    debug_printf("%s(): Numeric Postfix evaluation plan:\n", __func__);
    tree_postorder(node->children[1], dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  return true;
}

//
// Do a LET statement for an array numeric variable
// g_letstmt_tail -> g_target_variable T_EQ g_numeric_expression
//
// but caller already consumed T_NAVAR...
//
static bool let_navar(
    scanner_state *ss,
    treenode *node) {                // pointer to AST node created on success

  debug_printf("%s", "g_letstmt_tail -> g_target_variable T_EQ g_numeric_expression\n");
  if (!g_target_variable(ss, &(node->children[0])))
    return false;
  if (T_NAVAR != node->children[0]->leaftoken->tid)
    ICE(__FILE__, __func__, __LINE__, emsg[60], __func__, token_names[T_NAVAR],
        token_names[node->children[0]->leaftoken->tid], node->children[0]->leaftoken->lno);
  if (!match(ss, T_EQ, __func__))
    return false;
  if (!g_numeric_expression(ss, &(node->children[1])))
    return false;
  if (verbose) {
    debug_printf("%s():Numeric Postfix evaluation plan:\n", __func__);
    tree_postorder(node->children[1], dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  return true;
}

//
// Parse the LET statement.
// Returns true on success, false otherwise.
//
// g_letstmt -> T_LET g_letstmt_tail
// g_letstmt_tail -> g_target_variable T_EQ g_string_expression
//
// The production chosen depends on the type of g_target_variable
//
static bool g_letstmt(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  token *curtoken = get_next_token(ss); // pointer to next token

  debug_printf("%s", "g_letstmt -> T_LET g_letstmt_tail\n");
  if (!match2(curtoken, T_LET, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    return false;
  }
  *node = create_tree_node2(2U, curtoken);
  curtoken = peek_next_token(ss);
  switch (curtoken->tid) {
    case T_SVAR:                // assignment to a string scalar variable
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return let_svar(ss, *node);
    case T_NVAR:                // assignment to a numeric scalar variable
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return let_nvar(ss, *node);
    case T_NAVAR:               // assignment to a numeric array variable
      free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      return let_navar(ss, *node);
    default:
      ERROR(emsg[187], token_names[T_LET] + 2, curtoken->lno, token_names[curtoken->tid] + 2);
      break;
  }
  free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
  return false;
}

//
// Parse the RANDOMIZE statement.
// Returns true on success, false otherwise.
//
// g_randomizestmt -> T_RANDOMIZE
//
static bool g_randomizestmt(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  token *curtoken = get_next_token(ss); // pointer to next token

  debug_printf("%s", "g_randomizestmt -> T_RANDOMIZE\n");
  if (!match2(curtoken, T_RANDOMIZE, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    return false;
  }
  *node = create_tree_node2(0U, curtoken);
  return true;
}

//
// Parse the RESTORE statement.
// Returns true on success, false otherwise.
//
// g_restorestmt -> T_RESTORE
//
static bool g_restorestmt(
    scanner_state *ss,
    treenode **node) {                    // pointer to AST node created on success
  token *restoretoken = get_next_token(ss); // pointer to T_RESTORE token

  debug_printf("%s", "g_restorestmt -> T_RESTORE\n");
  if (!match2(restoretoken, T_RESTORE, __func__)) {
    free(restoretoken->toketext); restoretoken->toketext = NULL; free(restoretoken); restoretoken = NULL;
    return false;
  }
  *node = create_tree_node2(0U, restoretoken);
  return true;
}

//
// Parse the OPTION BASE statement.
// On success, true is returned, otherwise false is returned.
//
// g_optionbasestmt -> T_OPTION T_BASE T_INTEGER
//
static bool g_optionbasestmt(
    scanner_state *ss,
    treenode **node) {     // pointer to AST node created on success
  token *curtoken = NULL;  // pointer to current token

  debug_printf("%s", "g_optionbasestmt -> T_OPTION T_BASE T_INTEGER\n");
  curtoken = get_next_token(ss);
  if (!match2(curtoken, T_OPTION, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    return false;
  }
  *node = create_tree_node2(2U, curtoken);
  curtoken = get_next_token(ss);
  if (!match2(curtoken, T_BASE, __func__)) {
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    return false;
  }
  (*node)->children[0] = create_tree_node2(1U, curtoken);
  curtoken = get_next_token(ss);
  // not match2() because of the custom error message
  if (T_INTEGER != curtoken->tid) {
    ERROR(emsg[188], curtoken->lno);
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    return false;
  }
  (*node)->children[0]->children[0] = create_tree_node2(0U, curtoken);
  debug_printf("T_INTEGER <<<value is %s>>>\n", (*node)->children[0]->children[0]->leaftoken->toketext);
  return true;
}

//
// Parse the GO statement as either GOTO or GOSUB, depending on
// whether the token stream had 'SUB' or 'TO' after the 'GO'.
// Returns true on success, false otherwise.
//
// g_go_stmt -> T_GO g_gotail
// g_gotail -> T_TO g_lineno
// g_gotail -> T_SUB g_lineno
//
static bool g_go_stmt(
    scanner_state *ss,
    treenode **node) {                   // pointer to AST node created on success
  uint32_t tlineno;                      // target line number of the branch
  uint32_t colno;                        // column number where GO started
  char msg[ERROR_BUFFER_LEN];            // pointer to buffer for error message
  token *gotoken = get_next_token(ss),   // pointer to T_GO token
        *subtoken = NULL,                // pointer to T_SUB token
        *totoken = NULL,                 // pointer to T_TO token
        *linenotoken = NULL;             // pointer to target line number (g_lineno)
  bool isgoto = false;                   // flag to indicate whether this is a GOTO (true) or GOSUB (false)

  debug_printf("%s", "g_go_stmt -> T_GO g_gotail\n");
  if (!match2(gotoken, T_GO, __func__)) {
    free(gotoken->toketext); gotoken->toketext = NULL; free(gotoken); gotoken = NULL;
    return false;
  }
  colno = gotoken->lno;
  free(gotoken->toketext); gotoken->toketext = NULL; free(gotoken); gotoken = NULL;
  switch (peek_next_tid(ss)) {
    case T_TO:
      debug_printf("%s", "g_gotail -> T_TO g_lineno\n");
      totoken = get_next_token(ss);
      if (!match2(totoken, T_TO, __func__)) {
        free(totoken->toketext); totoken->toketext = NULL; free(totoken); totoken = NULL;
        return false;
      }
      free(totoken->toketext); totoken->toketext = NULL; free(totoken); totoken = NULL;
      isgoto = true;
      break;
    case T_SUB:
      debug_printf("%s", "g_gotail -> T_SUB g_lineno\n");
      subtoken = get_next_token(ss);
      if (!match2(subtoken, T_SUB, __func__)) {
        free(subtoken->toketext); subtoken->toketext = NULL; free(subtoken); subtoken = NULL;
        return false;
      }
      free(subtoken->toketext); subtoken->toketext = NULL; free(subtoken); subtoken = NULL;
      break;
    default:
      return false;
  }
  linenotoken = get_next_token(ss);
  if (!g_lineno2(linenotoken, &tlineno, msg, false)) {
    free(linenotoken->toketext); linenotoken->toketext = NULL; free(linenotoken); linenotoken = NULL;
    fputs(msg, stderr);
    return false;
  }
  if (isgoto)
    *node = create_tree_node(1U, T_GOTO, "GOTO", linenotoken->lno, colno);
  else
    *node = create_tree_node(1U, T_GOSUB, "GOSUB", linenotoken->lno, colno);
  (*node)->children[0] = create_tree_node2(0U, linenotoken);
  (*node)->numeric_value.uivalue = tlineno;
  // update lineno module information
  return true;
}

//
// Parse the GOTO statement.
// Returns true on success, false otherwise.
//
// g_gotostmt -> T_GOTO g_lineno
//
static bool g_gotostmt(
    scanner_state *ss,
    treenode **node) {                  // pointer to AST node created on success
  uint32_t tlineno;                     // target line number of the branch
  char msg[ERROR_BUFFER_LEN];           // pointer to error message buffer
  token *gototoken = get_next_token(ss),  // pointer to T_GOTO token
        *linenotoken = NULL;            // pointer to g_lineno token

  debug_printf("%s", "g_gotostmt -> T_GOTO g_lineno\n");
  if (!match2(gototoken, T_GOTO, __func__)) {
    free(gototoken->toketext); gototoken->toketext = NULL; free(gototoken); gototoken = NULL;
    return false;
  }
  linenotoken = get_next_token(ss);
  if (!g_lineno2(linenotoken, &tlineno, msg, false)) {
    free(gototoken->toketext); gototoken->toketext = NULL; free(gototoken); gototoken = NULL;
    free(linenotoken->toketext); linenotoken->toketext = NULL; free(linenotoken); linenotoken = NULL;
    fputs(msg, stderr);
    return false;
  }
  *node = create_tree_node2(1U, gototoken);
  (*node)->children[0] = create_tree_node2(0U, linenotoken);
  (*node)->numeric_value.uivalue = tlineno;
  return true;
}

//
// Parse the GOSUB statement.
// Returns true on success, false otherwise.
//
// g_gosubstmt -> T_GOSUB g_lineno
//
static bool g_gosubstmt(
    scanner_state *ss,
    treenode **node) {                  // pointer to AST node created on success
  uint32_t tlineno;                     // target line number of the branch
  char msg[ERROR_BUFFER_LEN];           // pointer to error message buffer
  token *gosubtoken = get_next_token(ss), // pointer to T_GOSUB token
        *linenotoken = NULL;            // pointer to g_lineno token

  debug_printf("%s", "g_gosubstmt -> T_GOSUB g_lineno\n");
  if (!match2(gosubtoken, T_GOSUB, __func__)) {
    free(gosubtoken->toketext); gosubtoken->toketext = NULL; free(gosubtoken); gosubtoken = NULL;
    return false;
  }
  linenotoken = get_next_token(ss);
  if (!g_lineno2(linenotoken, &tlineno, msg, false)) {
    free(gosubtoken->toketext); gosubtoken->toketext = NULL; free(gosubtoken); gosubtoken = NULL;
    free(linenotoken->toketext); linenotoken->toketext = NULL; free(linenotoken); linenotoken = NULL;
    fputs(msg, stderr);
    return false;
  }
  *node = create_tree_node2(1U, gosubtoken);
  (*node)->children[0] = create_tree_node2(0U, linenotoken);
  (*node)->numeric_value.uivalue = tlineno;
  return true;
}

//
// Parse the RETURN statement.
// Returns true on success, false otherwise.
//
// g_returnstmt -> T_RETURN
//
static bool g_returnstmt(
    scanner_state *ss,
    treenode **node) {               // pointer to AST node created on success
  token *rettoken = get_next_token(ss); // pointer to T_RETURN token

  debug_printf("%s", "g_returnstmt -> T_RETURN\n");
  if (!match2(rettoken, T_RETURN, __func__)) {
    free(rettoken->toketext); rettoken->toketext = NULL; free(rettoken); rettoken = NULL; return false;
  }
  *node = create_tree_node2(0U, rettoken);
  return true;
}

//
// Parse the END statement.
// Returns true on success, false otherwise.
//
// g_endstmt -> T_END
//
static bool g_endstmt(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  token *endtoken = get_next_token(ss); // pointer to T_END token

  debug_printf("%s", "g_endstmt -> T_END\n");
  if (!match2(endtoken, T_END, __func__)) {
    free(endtoken->toketext); endtoken->toketext = NULL; free(endtoken); endtoken = NULL;
    return false;
  }
  *node = create_tree_node2(0U, endtoken);
  return true;
}

//
// Parse the EXIT statement.
// Returns true on success, false otherwise.
//
// g_exitstmt -> T_EXIT T_FOR
//
static bool g_exitstmt(
    scanner_state *ss,
    treenode **node) {                  // pointer to AST node created on success
  token *exittoken = get_next_token(ss),  // pointer to T_EXIT token
        *fortoken = NULL;               // pointer to T_FOR token

  debug_printf("%s", "g_exitstmt -> T_EXIT T_FOR\n");
  if (!match2(exittoken, T_EXIT, __func__)) {
    free(exittoken->toketext); exittoken->toketext = NULL; free(exittoken); exittoken = NULL;
    return false;
  }
  fortoken = get_next_token(ss);
  if (!match2(fortoken, T_FOR, __func__)) {
    free(fortoken->toketext); fortoken->toketext = NULL; free(fortoken); fortoken = NULL;
    return false;
  }
  *node = create_tree_node2(1U, exittoken);
  exittoken = NULL;
  (*node)->children[0] = create_tree_node2(1U, fortoken);
  // child 0 of fortoken node will be bottom of loop label (filled in later)
  fortoken = NULL;
  return true;
}

//
// Parse the REM statement.
// Returns true on success, false otherwise.
//
// g_remstmt -> T_REM
//
static bool g_remstmt(
    scanner_state *ss,
    treenode **node) {                // pointer to AST node created on success
  token *remtoken = get_next_token(ss); // pointer to T_REM token

  debug_printf("%s", "g_remstmt -> T_REM\n");
  if (!match2(remtoken, T_REM, __func__)) {
    free(remtoken->toketext); remtoken->toketext = NULL; free(remtoken); remtoken = NULL;
    return false;
  }
  *node = create_tree_node2(0U, remtoken);
  return true;
}

//
// Parse the STOP statement.
// Returns true on success, false otherwise.
//
// g_stopstmt -> T_STOP
//
static bool g_stopstmt(
    scanner_state *ss,
    treenode **node) {                 // pointer to AST node created on success
  token *stoptoken = get_next_token(ss); // pointer to T_STOP token

  debug_printf("%s", "g_stopstmt -> T_STOP\n");
  if (!match2(stoptoken, T_STOP, __func__)) {
    free(stoptoken->toketext); stoptoken->toketext = NULL; free(stoptoken); stoptoken = NULL;
    return false;
  }
  *node = create_tree_node2(0U, stoptoken);
  return true;
}

//
// Process the NEXT statement.
// Returns true on success, false otherwise.
//
// g_statement -> g_endstmt
// g_statement -> g_defstmt
// g_statement -> g_ifstmt
// g_statement -> g_on_gotostmt
// g_statement -> g_inputstmt
// g_statement -> g_readstmt
// g_statement -> g_datastmt
// g_statement -> g_dimstmt
// g_statement -> g_nextstmt
// g_statement -> g_forstmt
// g_statement -> g_printstmt
// g_statement -> g_letstmt
// g_statement -> g_randomizestmt
// g_statement -> g_restorestmt
// g_statement -> g_optionbasestmt
// g_statement -> g_remstmt
// g_statement -> g_stopstmt
// g_statement -> g_returnstmt
// g_statement -> g_go_stmt
// g_statement -> g_gotostmt
// g_statement -> g_gosubstmt
//
static bool g_statement(
    scanner_state *ss,
    treenode **node) {                  // pointer to AST node created on success
  token *nexttoken = peek_next_token(ss); // pointer to the next token (which is not consumed)
  uint32_t lno = nexttoken->lno;

  switch(nexttoken->tid) {
    case T_EXIT:
      debug_printf("%s", "g_statement -> g_exitstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      if (!extensions)
        FATAL(__FILE__, __func__, __LINE__, emsg[97], lno, token_names[T_EXIT] + 2);
      return g_exitstmt(ss, node);
    case T_END:
      debug_printf("%s", "g_statement -> g_endstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_endstmt(ss, node);
    case T_DEF:
      debug_printf("%s", "g_statement -> g_defstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_defstmt(ss, node);
    case T_IF:
      debug_printf("%s", "g_statement -> g_ifstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_ifstmt(ss, node);
    case T_ON:
      debug_printf("%s", "g_statement -> g_on_gotostmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_on_gotostmt(ss, node);
    case T_INPUT:
      debug_printf("%s", "g_statement -> g_inputstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_inputstmt(ss, node);
    case T_READ:
      debug_printf("%s", "g_statement -> g_readstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_readstmt(ss, node);
    case T_DATA:
      debug_printf("%s", "g_statement -> g_datastmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_datastmt(ss, node);
    case T_DIM:
      debug_printf("%s", "g_statement -> g_dimstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_dimstmt(ss, node);
    case T_NEXT:
      debug_printf("%s", "g_statement -> g_nextstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_nextstmt(ss, node);
    case T_FOR:
      debug_printf("%s", "g_statement -> g_forstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_forstmt(ss, node);
    case T_PRINT:
      debug_printf("%s", "g_statement -> g_printstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_printstmt(ss, node);
    case T_LET:
      debug_printf("%s", "g_statement -> g_letstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_letstmt(ss, node);
    case T_RANDOMIZE:
      debug_printf("%s", "g_statement -> g_randomizestmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_randomizestmt(ss, node);
    case T_RESTORE:
      debug_printf("%s", "g_statement -> g_restorestmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_restorestmt(ss, node);
    case T_OPTION:
      debug_printf("%s", "g_statement -> g_optionbasestmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_optionbasestmt(ss, node);
    case T_REM:
      debug_printf("%s", "g_statement -> g_remstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_remstmt(ss, node);
    case T_STOP:
      debug_printf("%s", "g_statement -> g_stopstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_stopstmt(ss, node);
    case T_RETURN:
      debug_printf("%s", "g_statement -> g_returnstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_returnstmt(ss, node);
    case T_GO:
      debug_printf("%s", "g_statement -> g_go_stmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_go_stmt(ss, node);
    case T_GOTO:
      debug_printf("%s", "g_statement -> g_gotostmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_gotostmt(ss, node);
    case T_GOSUB:
      debug_printf("%s", "g_statement -> g_gosubstmt\n");
      free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
      return g_gosubstmt(ss, node);
    case T_NVAR: // error production to catch the common forgotten LET in the assignment statement
    case T_SVAR:
    case T_NAVAR:
      {
        token *curtoken = get_next_token(ss);   // next token from input token stream
        if (T_EQ == peek_next_tid(ss)) {
          ERROR(emsg[189], curtoken->lno, token_names[T_LET] + 2);
        } else {
          ERROR(emsg[197], curtoken->lno);
          ERROR("%s", emsg[198]);
          ERROR(" %s", token_names[T_DATA] + 2);
          ERROR(", %s", token_names[T_DEF] + 2);
          ERROR(", %s", token_names[T_DIM] + 2);
          ERROR(", %s", token_names[T_END] + 2);
          ERROR(", %s", token_names[T_FOR] + 2);
          ERROR(", %s", token_names[T_GO] + 2);
          ERROR(", %s", token_names[T_GOSUB] + 2);
          ERROR(", %s", token_names[T_GOTO] + 2);
          ERROR(", %s", token_names[T_IF] + 2);
          ERROR(", %s", token_names[T_INPUT] + 2);
          ERROR(", %s", token_names[T_LET] + 2);
          ERROR(", %s", token_names[T_NEXT] + 2);
          ERROR(", %s", token_names[T_ON] + 2);
          ERROR(", %s", token_names[T_OPTION] + 2);
          ERROR(", %s", token_names[T_PRINT] + 2);
          ERROR(", %s", token_names[T_RANDOMIZE] + 2);
          ERROR(", %s", token_names[T_READ] + 2);
          ERROR(", %s", token_names[T_REM] + 2);
          ERROR(", %s", token_names[T_RESTORE] + 2);
          ERROR(", %s", token_names[T_RETURN] + 2);
          ERROR(", %s", token_names[T_STOP] + 2);
          ERROR("\n");
        }
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
      }
      break;
    default:
      ERROR(emsg[197], nexttoken->lno);
      ERROR("%s", emsg[198]);
      ERROR(" %s", token_names[T_DATA] + 2);
      ERROR(", %s", token_names[T_DEF] + 2);
      ERROR(", %s", token_names[T_DIM] + 2);
      ERROR(", %s", token_names[T_END] + 2);
      if (extensions)
        ERROR(", %s", token_names[T_EXIT] + 2);
      ERROR(", %s", token_names[T_FOR] + 2);
      ERROR(", %s", token_names[T_GO] + 2);
      ERROR(", %s", token_names[T_GOSUB] + 2);
      ERROR(", %s", token_names[T_GOTO] + 2);
      ERROR(", %s", token_names[T_IF] + 2);
      ERROR(", %s", token_names[T_INPUT] + 2);
      ERROR(", %s", token_names[T_LET] + 2);
      ERROR(", %s", token_names[T_NEXT] + 2);
      ERROR(", %s", token_names[T_ON] + 2);
      ERROR(", %s", token_names[T_OPTION] + 2);
      ERROR(", %s", token_names[T_PRINT] + 2);
      ERROR(", %s", token_names[T_RANDOMIZE] + 2);
      ERROR(", %s", token_names[T_READ] + 2);
      ERROR(", %s", token_names[T_REM] + 2);
      ERROR(", %s", token_names[T_RESTORE] + 2);
      ERROR(", %s", token_names[T_RETURN] + 2);
      ERROR(", %s", token_names[T_STOP] + 2);
      ERROR("\n");
      break;
  }
  free(nexttoken->toketext); nexttoken->toketext = NULL; free(nexttoken); nexttoken = NULL;
  return false;
}

//
// Returns true on success, false otherwise.
//
// glines -> g_lineno g_statement T_EOL g_linestail
// g_lines -> epsilon
// g_linestail -> g_lineno g_statement T_EOL g_linestail
// g_linestail -> epsilon
//
static bool g_lines(
    scanner_state *ss,
    treenode **node,                   // pointer to AST node created on success
    const uint32_t linecount,          // number of source lines in the input BASIC program
    const char *inname) {              // pointer to text name of the input BASIC program
  uint32_t tlineno;                    // line number of current line of Minimal BASIC program being compiled
  char msg[ERROR_BUFFER_LEN];          // pointer to error message buffer
  uint32_t whichline = 0U;             // counter for source line, zero-based, used for slot numbers (children
                                       // array positions) for the lines of code counted as 0,1,2,... not by
                                       // the ECMA-55 Minimal BASIC line number, which is tlineno

  debug_printf("%s", "glines -> g_lineno g_statement T_EOL g_linestail\n");
  *node = create_tree_node(linecount, T_PROGRAM, inname, 0U, 0U);
  do {
    uint64_t cur_offset = ss->pos;     // record current position, which is start of line
    char *tbuf = NULL,                 // buffer for one line
         *c, *p;

    token *curtoken = get_next_token(ss);
    if (!g_lineno2(curtoken, &tlineno, msg, true)) {
      fputs(msg, stderr);
      free(curtoken->toketext); curtoken->toketext = NULL;
      free(curtoken); curtoken = NULL;
      return false;
    }
    debug_printf("\n=========================>Processing line number %" PRIu32 "<===============================\n\n", tlineno);
    //
    //                                  quite tricky stuff to just print the current line.....
    //
    c = strchr(ss->buffer+cur_offset, '\n');                 // find the next newline after curpos
    p = (char *)(c-((char *)ss->buffer + cur_offset));       // compute distance between that newline
                                                             // and the start of the line
    tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*((size_t)p+2));      // allocate tbuf
                                                             // Should be <= (INPUT_WIDTH+2)
                                                             // +2 is newline + terminator
                                                             // but this is dynamically allocated just in case
                                                             // some bozo has an input line that is too long....
    strncpy(tbuf, ss->buffer+cur_offset, (size_t)p+1);       // copy the bytes from curpos upto including
                                                             // newline to tbuf
    tbuf[(size_t)p+1]=0;                                     // and then terminate tbuf
    if (verbose) {
      debug_printf("%s", tbuf);                              // and finally display tbuf if -v set
    }
    //
    (*node)->children[whichline] = create_tree_node(2U, T_LINE, tbuf, (uint32_t)tlineno, 1U);
    free(tbuf);                                              // deallocate tbuf
    tbuf = NULL;
    (*node)->children[whichline]->children[0] = create_tree_node2(0U, curtoken);
    (*node)->children[whichline]->children[0]->numeric_value.uivalue = tlineno;
    curtoken = NULL;
    if (!g_statement(ss, &((*node)->children[whichline++]->children[1])))
      return false;
    if (!match(ss, T_EOL, __func__))
      return false;
    if ((T_END == peek_next_tid(ss)) && (T_EOF != peek_next_tid(ss))) {
      ERROR(emsg[190], tlineno);
      return false;
    }
    if (T_EOF != peek_next_tid(ss))
      debug_printf("%s", "g_linestail -> g_lineno g_statement T_EOL g_linestail\n");
  } while (T_EOF != peek_next_tid(ss));
  debug_printf("%s", "g_linestail -> epsilon\n");
  return true;
}

//
// This is the start production for the grammar.  It returns true if the input
// token stream generates a program that is in the language described by the
// grammar, false otherwise.  To enforce the rule that the END statement must
// be the final statement, the rest of the parse is done by g_lines(), with
// this final production guaranteeing that the last line is an END statement.
// Returns true on success, false otherwise.
//
// g_program -> g_lines T_EOF
//
// Once T_EOF is hit, a separate semantic check to ensure the last line was
// in fact a line number followed by T_END T_EOL is done.
//
static bool g_program(
    scanner_state *ss,
    treenode **node,    // pointer to AST root node g_program created on success
    const uint32_t linecount,   // number of source lines in the input BASIC program
    const char *inname) {       // pointer to text name of the input BASIC program

  debug_printf("%s", "g_program -> g_lines T_EOF\n");
  // final line number
  if (!g_lines(ss, node, linecount, inname))
    return false;
  // final synthetic EOF token to signal end of token stream
  if (!match(ss, T_EOF, __func__)) {
    ERROR("%s", emsg[191]);
    return false;
  }
  return true;
}

//
// This is the external entry point for the parser.  This parser is a
// recursive-descent predictive parser with an almost LL(1) grammar.  Semantic
// checking is done after a successful parse.  Regurgitating pretty-printed source
// is done if the pretty_print flag is set, otherwise code generation is done
// after the semantic checks pass.  Tokens are obtained using the scanner2
// module API.  In a few places in the parser extra error checking for bad
// matches occurs which is semantically like using error productions.  For
// example, when looking for statements some people used to other BASIC
// dialects forget the T_LET token, so when looking for statements if the first
// token is T_NVAR, T_NAVAR, or T_SVAR the parser will guess that an assignment
// with T_LET was intended, and it will report an error about missing T_LET
// token.  The g_relational_primary() production is tricky and if the first
// token is a T_LPAREN it first tries to match a parenthesized g_relational_expression
// but if that fails, then backtracks and tries g_comparison instead.  This is
// the only backtracking in this parser, and can only occur if extensions are
// enabled.
//
// It is the responsibility of the parser to free tokens after they are no longer
// needed.
//
// The linecount is the number of lines in the MinimalBASIC source program.
// This function returns true if the parser was successful, false otherwise.
//
bool parseit(
    const char * const buffer,
    const uint64_t buflen,
    uint64_t *pos,
    const uint32_t linecount,        // number of lines in the input BASIC source file
    const char *inname,              // pointer to text name of input BASIC source file
    const char *outname) {           // pointer to text name of output assembly language file
  treenode *program = NULL;          // pointer to root node of generated AST
  bool retval = false;               // function return value
  scanner_state ss = { buffer, buflen, *pos, 0, 1, 1, T_EOL, NULL, false, extensions };

  if (g_program(&ss, &program, linecount, inname)) {    // call the recursive descent parser's start symbol
    debug_printf("%s:%s() parse successful\n", __FILE__, __func__);
    if (semantic_checks(program)) {                // do semantic checks
      debug_printf("%s:%s() semantic_checks successful\n", __FILE__, __func__);
      if (pretty_print) {                          // regenerate source
        regenerate_source(program, outname);
        retval = true;
      } else {                                     // emit assembly code
        if ((retval = generate_assembly(program, outname)))
          debug_printf("%s:%s() generate_assembly() successful\n", __FILE__, __func__);
        else
          debug_printf("%s:%s() generate_assembly() failed\n", __FILE__, __func__);
      }
    } else {
      debug_printf("%s:%s() semantic_checks failed\n", __FILE__, __func__);
    }
  } else {
    debug_printf("%s:%s() parse failed\n", __FILE__, __func__);
  }
  dag_delete_all(&program);
  return retval;
}

//
// This is code to test the module and is not normally used.
// If you compile with UNIT_TEST defined, then this module will
// be a stand-alone program with its own main() that runs some
// self-tests.
//
#ifdef UNIT_TEST
#include "g_fmt_BASIC_normal.h"
#include <string.h>
#include <unistd.h>
#include <getopt.h>

bool generate_assembly(treenode __attribute__((unused)) *n, const char __attribute__((unused)) *outname) { return true; }
static bool test1(void);
static bool test2(void);

static const char sample_code[] = "\
10 OPTION BASE 1\n\
11 REM THIS IS A TEST\n\
12 RANDOMIZE\n\
13 LET A=INT(360/0.31415926535E-1+2*4/(1+(-2))-1)+SIN(B2)/TAN(LOG(0^0))\n\
14 LET A=INT(360/0.31415926535E-1+2*3/(4+(-5))-6)+SIN(B2)/TAN(LOG(7^8))\n\
15 FOR I=1 TO 10\n\
16   FOR J=9 TO 0 STEP -1\n\
17     PRINT I*J\n\
24   NEXT J\n\
25 NEXT I\n\
26 GOSUB 100\n\
27 GO SUB 100\n\
28 RESTORE\n\
29 LET X=RND\n\
30 GO TO 190\n\
31 GOTO 190\n\
32 PRINT ABS(-1)\n\
100 REM START OF SUBROUTINE\n\
110 RETURN\n\
190 STOP\n\
200 DIM Z(20),B(5,5)\n\
210 LET X=RND/6\n\
220 LET B(X,X)=X\n\
230 LET Z(5)=4\n\
240 LET Z(Z(5))=5\n\
245 PRINT Q(3,3)\n\
250 PRINT Z(Q(3,2))\n\
254 ON RND/6 GO TO 10,29,30,100,200,256\n\
255 ON RND/6 GOTO 10,29,30,100,200,256\n\
256 IF Z(1)<(B(3,2)*SIN(X)) THEN 11\n\
260 READ Z(1),Z(2+X),Q(Z(1),RND),X\n\
300 DATA 1,0.1,.1,-1,-.1,-0.001E+3\n\
310 LET A$ = \"HELLO\"\n\
315 PRINT TAB(10);A1,A$,Z(1),Z(X)\n\
320 INPUT A1,A$,Z(1),Z(X)\n\
321 PRINT 3*X - Y^2, -X/Y, Z(1)+Z(2)+Z(3), SQR(X^2+Y^2),2^(-X)\n\
322 PRINT X,A$,V(3),W(X,X+Y/2),S$,C$\n\
330 READ A1,A$,Z(1),Z(X)\n\
340 DATA 1,\"DOG\",99,\"BIG FAT DOGGIE\"\n\
341 DATA 1,500,-21.,.255,1E10,5E-1,.4E+1,\"XYZ\",\"X - 3B2\",\"1E10\"\n\
350 IF A$ = \"DOG\" THEN 360\n\
360 IF \"DOG\" <> A$ THEN 400\n\
361 DEF FNF(X) = X^4 - 1\n\
362 DEF FNA(X) = A*X + X\n\
363 DEF FNP = 3.14159\n\
364 LET P = 3.14159\n\
365 LET Q(X,3) = SIN(X)*Y + 1\n\
366 LET A$ = \"ABC\"\n\
367 LET A$ = B$\n\
368 IF 1=2 THEN 400\n\
369 PRINT \"DONE\"\n\
400 END\n\
";
static const size_t sample_code_lines=52U; // MUST BE UPDATED BY HAND

static bool test1(void) {
  token *t = NULL;
  bool rez=false;
  size_t linecount = sample_code_lines;
  uint64_t pos = 0,
           buflen = (uint64_t)strlen(sample_code);
  scanner_state ss = { sample_code, buflen, 0, 0, 1, 1, T_EOL, NULL, false, extensions };

  // ensure we can peek the first token
  t = peek_next_token(&ss);
  // and it is an unsigned integer
  if (T_INTEGER != t->tid) {
    ERROR("%s", emsg[192]);
    goto test1_xit;
  }
  // with value '10'
  if (strcmp(t->toketext, "10") != 0) {
    ERROR(emsg[193], t->toketext);
    goto test1_xit;
  }
  rez=parseit(sample_code, buflen, &pos, (uint32_t)linecount, "SELFTEST.BAS", "SELFTEST.BAS.s");
  fflush(stdout);
  unlink("SELFTEST.BAS.s");
  if (rez) {
    if (sample_code_lines == linecount) {
      printf("%s passed\n", __func__);
      rez = true;
      goto test1_xit;
    }
    printf("Expected %lu lines, but only got %lu lines.\n",
           sample_code_lines, linecount);
  }
  ERROR("%s", emsg[194]);
  fflush(stdout);
  ERROR("%s", emsg[196]);

test1_xit:
  free(t->toketext); t->toketext = NULL; free(t); t = NULL;
  fflush(stdout);
  clear_symbol_table();
  return rez;
}

static const char sample_extension_code[] = "\
10 PRINT LEN(\"HELLO\")\n\
20 LET S$=\"BYE\"\n\
30 PRINT LEN(S$)\n\
40 LET X=3*LEN(S$)\n\
50 PRINT X\n\
55 PRINT MAX(A,B)\n\
56 IF MOD(3,4)=REMAINDER(3,4) THEN 60\n\
57 PRINT MAXNUM\n\
60 LET X=CEIL(1.1)\n\
70 PRINT ANGLE(3,2)\n\
71 PRINT DATE\n\
72 PRINT TIME\n\
73 PRINT DATE$\n\
74 PRINT TIME$\n\
75 LET T=TIME\n\
76 LET T$=TIME$\n\
90 END\n\
";
static size_t sample_extension_code_lines=17U; // MUST BE UPDATED BY HAND

static bool test2(void) {
  token *t = NULL;
  bool rez=false;
  size_t linecount = sample_extension_code_lines;
  uint64_t pos = 0,
           buflen = (uint64_t)strlen(sample_extension_code);
  scanner_state ss = { sample_extension_code, buflen, 0, 0, 1, 1, T_EOL, NULL, false, extensions };

  // ensure we can peek the first token
  t = peek_next_token(&ss);
  // and it is an unsigned integer
  if (T_INTEGER != t->tid) {
    ERROR("%s", emsg[192]);
    goto test2_xit;
  }
  // with value '10'
  if (strcmp(t->toketext, "10") != 0) {
    ERROR(emsg[193], t->toketext);
    goto test2_xit;
  }
  rez=parseit(sample_extension_code, buflen, &pos, (uint32_t)linecount, "SELFTEST2.BAS", "SELFTEST2.BAS.s");
  fflush(stdout);
  unlink("SELFTEST2.BAS.s");
  if (rez) {
    if (sample_extension_code_lines == linecount) {
      printf("%s passed\n", __func__);
      goto test2_xit;
    }
    printf("Expected %lu lines, but only got %lu lines.\n",
           sample_extension_code_lines, linecount);
  }
  ERROR("%s", emsg[194]);
  fflush(stdout);
  ERROR("%s", emsg[196]);

test2_xit:
  fflush(stdout);
  clear_symbol_table();
  return rez;
}

int main(int argc, char *argv[]) {
  int retval;
  int32_t opt; // variable used by getopt() function

  optimization_level=0U;
  extensions=use_SSE4_1=verbose=false;
  use_double=true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:X")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0], false);
        retval = EXIT_SUCCESS;
        goto xit;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        retval = EXIT_FAILURE;
        goto xit;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  init_debug_printf(stderr);
  retval = test1();
  if (retval && extensions)
    retval = test2();
xit:
  clear_symbol_table();
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return (retval ? EXIT_SUCCESS : EXIT_FAILURE);
}
#endif
