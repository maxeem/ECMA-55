//
// ast.c - This file contains functions for processing the AST.
//
// Copyright (C) 2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "ast.h"
#include "globals.h"
#include "error_messages.h"

static unsigned int set_parent_precedence(const enum token_ids tid);
static char *myitoa(const int n);
static void regenerate_unary_operator(treenode const * const child,
                                      treenode const * const parent,
                                      FILE *outfile);
static void regenerate_binary_operator(treenode const * const child,
                                       treenode const * const parent,
                                       FILE *outfile);
static void regenerate_bif_0args(treenode const * const node, FILE *outfile);
static void regenerate_bif_1arg(treenode const * const node, FILE *outfile);
static void regenerate_bif_2args(treenode const * const node, FILE *outfile);
static void regenerate_float_literal(treenode const * const child, FILE *outfile);
static void regenerate_expression(treenode const * const child,
                                  treenode const * const parent,
                                  FILE *outfile);
static void regenerate_print(treenode const * const node, FILE *outfile);
static void regenerate_data(treenode const * const node, FILE *outfile);
static void regenerate_read(treenode const * const node, FILE *outfile);
static void regenerate_input(treenode const * const node, FILE *outfile);
static void regenerate_dim(treenode const * const node, FILE *outfile);
static void regenerate_on_goto(treenode const * const node, FILE *outfile);
static void regenerate_def(treenode const * const node, FILE *outfile);
static void regenerate_option(treenode const * const node, FILE *outfile);
static void regenerate_goto(treenode const * const node, FILE *outfile);
static void regenerate_gosub(treenode const * const node, FILE *outfile);
static void regenerate_restore(treenode const * const node, FILE *outfile);
static void regenerate_randomize(treenode const * const node, FILE *outfile);
static void regenerate_return(treenode const * const node, FILE *outfile);
static void regenerate_stop(treenode const * const node, FILE *outfile);
static void regenerate_end(treenode const * const node, FILE *outfile);
static void regenerate_rem(treenode const * const node, FILE *outfile);
static void regenerate_exit_for(treenode const * const node, FILE *outfile);
static void regenerate_next(treenode const * const node, FILE *outfile);
static void regenerate_if(treenode const * const node, FILE *outfile);
static void regenerate_let(treenode const * const node, FILE *outfile);
static void regenerate_for(treenode const * const node, FILE *outfile);

static unsigned int set_parent_precedence(
  const enum token_ids tid) {        // parent token id
  unsigned int parent_precedence;    // computed precedence value for child

  switch(tid) {
    case T_NOT:       // -X
      parent_precedence = 3U;
      break;
    case T_AND:       // -X
      parent_precedence = 2U;
      break;
    case T_OR:        // -X
      parent_precedence = 1U;
      break;
    case T_ADD:
    case T_SUBTRACT:
      parent_precedence = 5U;
      break;
    case T_DIV:
    case T_MUL:
      parent_precedence = 6U;
      break;
    case T_POW:
      parent_precedence = 7U;
      break;
    case T_LE:
    case T_LT:
    case T_GE:
    case T_GT:
    case T_EQ:
    case T_NE:
      parent_precedence = 4U;
      break;
    case T_NAVAR:
    case T_FNID:
    // built-in functions without parameters
    case T_MAXNUM:     // -X
    case T_PI:         // -X
    case T_RND:
    // built-in functions with one parameter
    case T_ABS:
    case T_ACOS:       // -X
    case T_ASIN:       // -X
    case T_ATN:
    case T_CEIL:       // -X
    case T_COS:
    case T_COSH:       // -X
    case T_COT:        // -X
    case T_CSC:        // -X
    case T_DEG:        // -X
    case T_EXP:
    case T_FP:         // -X
    case T_INT:
    case T_IP:         // -X
    case T_LOG:
    case T_LOG10:      // -X
    case T_LOG2:       // -X
    case T_RAD:        // -X
    case T_SEC:        // -X
    case T_SGN:
    case T_SIN:
    case T_SINH:       // -X
    case T_SQR:
    case T_TAB:
    case T_TAN:
    case T_TANH:       // -X
    // built-in functions with two parameters
    case T_MAX:        // -X
    case T_MIN:        // -X
    case T_MOD:        // -X
    case T_REMAINDER:  // -X
    case T_ROUND:      // -X
    case T_TRUNCATE:   // -X
      parent_precedence = 0U; // Lie about it so we don't get duplicate parenthesis pairs
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[204], token_names[tid]);
  }
  return parent_precedence;
}

static void regenerate_def(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  regenerate_expression(node->children[0], NULL, outfile);
  if (3U == node->numchildren) {
    fputc('(', outfile);
    regenerate_expression(node->children[1], NULL, outfile);
    fputc(')', outfile);
  }
  fputc('=', outfile);
  regenerate_expression(node->children[node->numchildren - 1], NULL, outfile);
  return;
}

static void regenerate_option(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s %s %s", token_names[node->leaftoken->tid] + 2,
          token_names[node->children[0]->leaftoken->tid] + 2,
          node->children[0]->children[0]->leaftoken->toketext);
  return;
}

static void regenerate_goto(treenode const * const node, FILE *outfile) {
  if (node &&
      node->children &&
      (node->numchildren > 0) &&
      node->children[0])
    fprintf(outfile, "%s %" PRIu32,
            token_names[node->leaftoken->tid] + 2,
            node->children[0]->numeric_value.uivalue);
  else
    fprintf(outfile, "%s ?",
            token_names[node->leaftoken->tid] + 2);
  return;
}

static void regenerate_gosub(treenode const * const node, FILE *outfile) {
  if (node &&
      node->children &&
      (node->numchildren > 0) &&
      node->children[0])
    fprintf(outfile, "%s %" PRIu32,
            token_names[node->leaftoken->tid] + 2,
            node->children[0]->numeric_value.uivalue);
  else
    fprintf(outfile, "%s ?",
            token_names[node->leaftoken->tid] + 2);
  return;
}

static void regenerate_restore(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s", token_names[node->leaftoken->tid] + 2);
  return;
}

static void regenerate_randomize(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s", token_names[node->leaftoken->tid] + 2);
  return;
}

static void regenerate_return(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s", token_names[node->leaftoken->tid] + 2);
  return;
}

static void regenerate_stop(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s", token_names[node->leaftoken->tid] + 2);
  return;
}

static void regenerate_rem(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s%s", token_names[node->leaftoken->tid] + 2,
          node->leaftoken->toketext + 3);
  return;
}

static void regenerate_end(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s", token_names[node->leaftoken->tid] + 2);
  return;
}

static void regenerate_exit_for(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s %s", token_names[node->leaftoken->tid] + 2,
          token_names[node->children[0]->leaftoken->tid] + 2);
  return;
}

static void regenerate_next(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s %s", token_names[node->leaftoken->tid] + 2,
          node->children[0]->leaftoken->toketext);
  return;
}

static void regenerate_if(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  regenerate_expression(node->children[0], NULL, outfile);
  fprintf(outfile, " %s %" PRIu32, token_names[T_THEN] + 2,
          node->children[1]->numeric_value.uivalue);
  return;
}

static void regenerate_let(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  if (T_SVAR == node->children[0]->leaftoken->tid) { // string assignment
    fprintf(outfile, "%s=", node->children[0]->leaftoken->toketext); // LHS
    if (T_QSTRING == node->children[1]->leaftoken->tid) // RHS
      fprintf(outfile, "\"%s\"", node->children[1]->leaftoken->toketext);
    else
      fprintf(outfile, "%s", node->children[1]->leaftoken->toketext);
  } else {                                          // numeric assignment
    regenerate_expression(node->children[0], NULL, outfile); // LHS
    fputc('=', outfile);
    regenerate_expression(node->children[1], NULL, outfile); // RHS
  }
  return;
}

static void regenerate_for(treenode const * const node, FILE *outfile) {
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  // assign initial value to loop index
  regenerate_expression(node->children[0], NULL, outfile); // LHS
  fputc('=', outfile);
  regenerate_expression(node->children[1], NULL, outfile); // RHS
  fprintf(outfile, " %s ", token_names[T_TO] + 2);
  regenerate_expression(node->children[2], NULL, outfile); // limit
  if ((T_INTEGER == node->children[3]->leaftoken->tid) &&
      (1U == node->children[3]->numeric_value.uivalue)) {
    // Do not emit a step since the default is 1
  } else { // step
    fprintf(outfile, " %s ", token_names[T_STEP] + 2);
    regenerate_expression(node->children[3], NULL, outfile);
  }
  return;
}

static void regenerate_bif_0args(treenode const * const node,
                                 FILE *outfile) {
  switch (node->leaftoken->tid) {
    case T_PI:
    case T_MAXNUM:
      if (!extensions)  // this is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      break;
    default:
      break;
  }
  fprintf(outfile, "%s", token_names[node->leaftoken->tid] + 2);
  return;
}

static void regenerate_bif_1arg(treenode const * const node,
                                FILE *outfile) {
  switch (node->leaftoken->tid) {
    case T_LEN:
    case T_CEIL:
    case T_IP:
    case T_FP:
    case T_DEG:
    case T_RAD:
      if (!extensions)  // this is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      break;
    default:
      break;
  }
  fprintf(outfile, "%s(", token_names[node->leaftoken->tid] + 2);
  regenerate_expression(node->children[0], node, outfile);
  fputc(')', outfile);
  return;
}

static void regenerate_bif_2args(treenode const * const node,
                                 FILE *outfile) { // output file handle
  switch (node->leaftoken->tid) {
    case T_MAX:
    case T_MIN:
    case T_MOD:
    case T_REMAINDER:
    case T_ROUND:
    case T_TRUNCATE:
      if (!extensions)  // this is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      break;
    default:
      break;
  }
  fprintf(outfile, "%s(", token_names[node->leaftoken->tid] + 2);
  regenerate_expression(node->children[0], node, outfile);
  fputc(',', outfile);
  regenerate_expression(node->children[1], node, outfile);
  fputc(')', outfile);
  return;
}

static void regenerate_unary_operator(
    treenode const * const child,   // pointer to child AST node
    treenode const * const parent,  // pointer to parent AST node
    FILE *outfile) {                // output file handle
  bool needparen = false;           // flag used to emit parenthesis if required

  switch(child->leaftoken->tid) {
    case T_NOT:
      // This is not actually needed and makes clang whine....
      // child_precedence = 3U;
      fprintf(outfile, "%s ", token_names[child->leaftoken->tid] + 2);
      break;
    case T_NAVAR: // numeric one-dimensional array
    case T_FNID:  // user-defined numeric function with one argument
      needparen = true;
      // This is not actually needed and makes clang whine....
      // child_precedence = 9U;
      fprintf(outfile, "%s", child->leaftoken->toketext);
      break;
    case T_SUBTRACT:            // unary minus
      if (OP_UMINUS != child->oid)
        abort();
      // This is not actually needed and makes clang whine....
      // child_precedence = 8U;

      // very tricky logic - if parent is not null AND we are left child surround with parenthesis with (-expr)
      //                     otherwise if expr is not a leaf then emit -(expr)
      //                     else emit -expr
      if (parent && (parent->children[0] == child))
        if ((parent->oid != OP_BIF) && (parent->oid != OP_UDF))
          fputc('(', outfile);
      fprintf(outfile, "%s", child->leaftoken->toketext);       // this is the unary minus
      if (child->children[0]->numchildren > 0U)
        fputc('(', outfile);
      regenerate_expression(child->children[0], child, outfile);
      if (child->children[0]->numchildren > 0U)
        fputc(')', outfile);
      if (parent && (parent->children[0] == child))
        if ((parent->oid != OP_BIF) && (parent->oid != OP_UDF))
          fputc(')', outfile);
      return;                                                   // note we return, not break, here
    default:
      needparen = false;
      fprintf(outfile, "%s", child->leaftoken->toketext);
      break;
  }
  if (needparen)
    fputc('(', outfile);
  regenerate_expression(child->children[0], child, outfile);
  if (needparen)
    fputc(')', outfile);
  return;
}

static void regenerate_binary_operator(
    treenode const * const child,   // pointer to child AST node
    treenode const * const parent,  // pointer to parent AST node
    FILE *outfile) {                // output file handle
  bool needparen = false;           // flag used to emit parenthesis if required
  unsigned int child_precedence;    // computed precedence value for child

  if (T_NAVAR == child->leaftoken->tid) { // two-dimensional numeric array
    fprintf(outfile, "%s(", child->leaftoken->toketext);
    regenerate_expression(child->children[0], child, outfile);
    fputc(',', outfile);
    regenerate_expression(child->children[1], child, outfile);
    fputc(')', outfile);
  } else {                                // binary operator
    unsigned int parent_precedence;       // computed precedence value for parent

    if (parent) {
      parent_precedence = set_parent_precedence(parent->leaftoken->tid);
    } else {
      parent_precedence = 0U;
    }
    switch(child->leaftoken->tid) {
      case T_AND:
        child_precedence = 2U;
        break;
      case T_OR:
        child_precedence = 1U;
        break;
      case T_ADD:
      case T_SUBTRACT:
        child_precedence = 5U;
        break;
      case T_DIV:
      case T_MUL:
        child_precedence = 6U;
        break;
      case T_POW:
        child_precedence = 7U;
        break;
      case T_LE:
      case T_LT:
      case T_GE:
      case T_GT:
      case T_EQ:
      case T_NE:
        child_precedence = 4U;
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[205], token_names[child->leaftoken->tid]);
    }
    needparen = (parent_precedence > child_precedence); // if parent has greater precedence, must parenthesize
    if (parent &&                                       // if parent exists
        (parent_precedence == child_precedence) &&      // and parent has same precedence
        (2U == parent->numchildren) &&                  // and is a binary operator
        (parent->children[1] == child) &&               // and this is the right child
        ((T_SUBTRACT == parent->leaftoken->tid) ||      // and the binary operator is -,/, or ^
         (T_POW == parent->leaftoken->tid) ||           // then must parenthesize
         (T_DIV == parent->leaftoken->tid)))
      needparen = true;
    if (needparen)
      fputc('(', outfile);
    regenerate_expression(child->children[0], child, outfile);
    switch(child->leaftoken->tid) {
      case T_AND:
      case T_OR:
        fprintf(outfile, " %s ", token_names[child->leaftoken->tid] + 2);
        break;
      default:
        fprintf(outfile, "%s", child->leaftoken->toketext);
        break;
    }
    if ((2U != child->children[1]->numchildren) &&
        ('-' == child->children[1]->leaftoken->toketext[0]))
      fputc('(', outfile);
    regenerate_expression(child->children[1], child, outfile);
    if ((2U != child->children[1]->numchildren) &&
        ('-' == child->children[1]->leaftoken->toketext[0]))
      fputc(')', outfile);
    if (needparen)
      fputc(')', outfile);
  }
  return;
}

static void regenerate_float_literal(
    treenode const * const child,   // pointer to child AST node
    FILE *outfile) {                // output file handle
  char *t = NULL;

  t = trim(strdup(child->leaftoken->toketext));
  fprintf(outfile, "%s", t);
  free(t);
  t = NULL;
  return;
}

//
// This procedure takes a pointer to an operator node (child) and its
// parent (parent) and regenerates the ECMA-55 Minimal BASIC source
// corresponding to the AST and stores it in the file whose handle is
// specified (outname).  If it cannot successfully recreate the
// expression, an ICE occurs and halts the compiler.
//
// For an arithmetic operator, if parent exists and is higher precedence
// operator, then binary or unary operator must have parenthesis, otherwise
// it should not.
//
// Precedence from high to low:
// const       10     (constant or variable)
// UDF          9     (user-defined numeric function)
// BIF          9     (built-in numeric function)
// -            8     (unary minus)
// ^            7     (power)
// * /          6     (multiply, divide)
// + -          5     (add, subtract)
// relop        4     (all relational operators)
// NOT          3     (logical not)
// AND          2     (logical and)
// OR           1     (logical or)
//
static void regenerate_expression(
    treenode const * const child,    // pointer to child AST node
    treenode const * const parent,   // pointer to parent AST node
    FILE *outfile) {                 // output file handle
  char *t = NULL;                    // temporary pointer for trim()'ed strings

  debug_printf("regenerate_expression(%s='%s' address=%p,parent='%s' address=%p)\n",
               !parent?"root        ":((child==parent->children[0])?"left  child ":"right child "),
               (OP_UMINUS==child->oid)?"_":child->leaftoken->toketext,
               (void *)child,
               !parent?"NULL":((OP_UMINUS==parent->oid)?"_":parent->leaftoken->toketext),
               (void *)parent);
  switch(child->numchildren) {
    case 0U: // constant or scalar variable
      switch (child->oid) {
        case OP_BIF:
          regenerate_bif_0args(child, outfile);
          break;
        default:
          switch(child->leaftoken->tid) {
            case T_NVAR:
              t = trim(strdup(child->leaftoken->toketext));
              if ('.' == t[0])                 // if it is a function parameter
                fprintf(outfile, "%s", t + 6); // strip prefix
              else                             // otherwise
                fprintf(outfile, "%s", t);     // display name as normal
              free(t);
              t = NULL;
              break;
            case T_REAL:
              regenerate_float_literal(child, outfile);
              break;
            case T_QSTRING:
              fprintf(outfile, "\"%s\"", child->leaftoken->toketext);
              break;
            case T_INTEGER:
              // intentionally fall through
            default:
              t = trim(strdup(child->leaftoken->toketext));
              fprintf(outfile, "%s", t);
              free(t);
              t = NULL;
              break;
              break;
          }
          break;
      }
      // This is not actually needed and makes clang whine....
      // child_precedence = 10U;
      break;
    case 1U:  // one child
      switch (child->oid) {
        case OP_BIF:
          regenerate_bif_1arg(child, outfile);
          break;
        default:
          regenerate_unary_operator(child, parent, outfile);
          break;
      }
      break;
    case 2U: // two children
      switch (child->oid) {
        case OP_BIF:
           regenerate_bif_2args(child, outfile);
           break;
        default:
           regenerate_binary_operator(child, parent, outfile);
           break;
      }
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[13], __func__);
  }
  return;
}

static void regenerate_print(
    treenode const * const node,  // node of AST
    FILE *outfile) {              // name of output file, or NULL if
                                  // you want output to go to STDOUT
  // output PRINT keyword
  fprintf(outfile, "%s", token_names[node->leaftoken->tid] + 2);
  // if this is not a bare PRINT statement, output a space after the PRINT
  if (strcmp(node->children[0]->leaftoken->toketext, "\\n") != 0)
    fputc(' ', outfile);
  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    switch(node->children[i]->leaftoken->tid) {
      case T_QSTRING:
        if (strcmp(node->children[i]->leaftoken->toketext, "\\n") != 0)
          fprintf(outfile, "\"%s\"", node->children[i]->leaftoken->toketext);
        break;
      case T_COMMA:
      case T_SEMI:
      case T_UQSTRING:
      case T_SVAR:
        fprintf(outfile, "%s", node->children[i]->leaftoken->toketext);
        break;
      // extensions
      case T_ACOS:      // -X
      case T_ASIN:      // -X
      case T_CEIL:      // -X
      case T_COSH:      // -X
      case T_COT:       // -X
      case T_CSC:       // -X
      case T_DEG:       // -X
      case T_FP:        // -X
      case T_IP:        // -X
      case T_LEN:       // -X
      case T_LOG10:     // -X
      case T_LOG2:      // -X
      case T_MAX:       // -X
      case T_MAXNUM:    // -X
      case T_MIN:       // -X
      case T_MOD:       // -X
      case T_PI:        // -X
      case T_RAD:       // -X
      case T_REMAINDER: // -X
      case T_ROUND:     // -X
      case T_SEC:       // -X
      case T_SINH:      // -X
      case T_TANH:      // -X
      case T_TRUNCATE:  // -X
      // ECMA-55 operators
      case T_ADD:
      case T_DIV:
      case T_MUL:
      case T_POW:
      case T_SUBTRACT:
      // ECMA-55 user-defined functions
      case T_FNID:
      // ECMA-55 arrays
      case T_NAVAR:
      // ECMA-55 numeric scalars
      case T_NVAR:
      // ECMA-55 numeric literals
      case T_INTEGER:
      case T_REAL:
      // ECMA-55 built-in mathematical functions
      case T_ABS:
      case T_ATN:
      case T_COS:
      case T_EXP:
      case T_INT:
      case T_LOG:
      case T_RND:
      case T_SGN:
      case T_SIN:
      case T_SQR:
      case T_TAB:
      case T_TAN:
        regenerate_expression(node->children[i], NULL, outfile);
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[14],
            token_names[node->children[i]->leaftoken->tid] + 2);
    }
  }
  return;
}

static void regenerate_data(
    treenode const * const node,  // node of AST
    FILE *outfile) {              // name of output file, or NULL if
                                  // you want output to go to STDOUT
  // output DATA keyword
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  // for each datum on the DATA statement
  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    switch(node->children[i]->leaftoken->tid) {
      case T_QSTRING: // output the quoted string
        fprintf(outfile, "\"%s\"", node->children[i]->leaftoken->toketext);
        break;
      default:        // output the unquoted string or number
        fprintf(outfile, "%s", node->children[i]->leaftoken->toketext);
        break;
    }
    // if this is not the last datum, emit a comma separator
    if (i < node->numchildren - 1U)
      fputc(',', outfile);
  }
  return;
}

static void regenerate_read(
    treenode const * const node,  // node of AST
    FILE *outfile) {              // name of output file, or NULL if
                                  // you want output to go to STDOUT
  // output READ keyword
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  // for each variable in the READ statement
  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    if (T_SVAR == node->children[i]->leaftoken->tid) {
      // string scalar variable
      fprintf(outfile, "%s", node->children[i]->leaftoken->toketext);
    } else {
      // numeric variable
      regenerate_expression(node->children[i], NULL, outfile);
    }
    // if this is not the last variable in the list, emit a comma separator
    if (i != node->numchildren - 1U)
      fputc(',', outfile);
  }
  return;
}

static void regenerate_input(
    treenode const * const node,  // node of AST
    FILE *outfile) {              // name of output file, or NULL if
                                  // you want output to go to STDOUT
  // output INPUT keyword
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  // for each variable in the INPUT statement
  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    if (T_SVAR == node->children[i]->leaftoken->tid) {
      // string scalar variable
      fprintf(outfile, "%s", node->children[i]->leaftoken->toketext);
    } else {
      // numeric variable
      regenerate_expression(node->children[i], NULL, outfile);
    }
    // if this is not the last variable in the list, emit a comma separator
    if (i != node->numchildren - 1U)
      fputc(',', outfile);
  }
  return;
}

static void regenerate_dim(
    treenode const * const node,  // node of AST
    FILE *outfile) {              // name of output file, or NULL if
                                  // you want output to go to STDOUT
  // output DIM keyword
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  // for each array in the DIM statement
  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    regenerate_expression(node->children[i], NULL, outfile);
    // if this is not the last variable in the list, emit a comma separator
    if (i != node->numchildren - 1U)
      fputc(',', outfile);
  }
  return;
}

static void regenerate_on_goto(
    treenode const * const node,  // root node of AST
    FILE *outfile) {              // name of output file, or NULL if
                                  // you want output to go to STDOUT
  // output ON keyword
  fprintf(outfile, "%s ", token_names[node->leaftoken->tid] + 2);
  regenerate_expression(node->children[0], NULL, outfile);
  // output GOTO keyword
  fprintf(outfile, " %s ", token_names[T_GOTO] + 2);
  // for each jump target in the list
  for (unsigned int i = 1U; i < node->numchildren; ++i) {
    // compute jump target BASIC source line number
    uint32_t target_lineno = node->children[i]->numeric_value.uivalue;
    // output jump target BASIC source line number
    fprintf(outfile, "%" PRIu32, target_lineno);
    // if this is not the last variable in the list, emit a comma separator
    if (i != node->numchildren - 1U)
      fputc(',', outfile);
  }
  return;
}

//
// returns a pointer to a static buffer that will
// contain an ASCIIZ string representation of the
// integer specified by the paramter n.  The caller
// should copy the string to another buffer if they
// intend to modify the buffer.
//
static char *myitoa(const int n) {
  static unsigned char buffer[40] = { 0 };
  int destructable_n = (int)n;
  int i = sizeof(buffer) - 1;
  bool neg = false;

  memset(buffer, 0, 40);
  if (destructable_n < 0) {
     neg = true;
     destructable_n = 0 - destructable_n;
  }
  buffer[i]=0; // paranoia
  do {
    buffer[--i] = (unsigned char)((destructable_n % 10) + 48); // assumes ASCII, '0' = 48
    destructable_n /= 10;
  } while (destructable_n > 0);
  if (neg)
    buffer[--i] = '-';
  return((char *)(buffer + i));
}

//
// This function takes a pointer to an AST node (node) and regenerates
// the ECMA-55 Minimal BASIC source corresponding to the AST and stores
// it in the file whose name is specified (outname).  If outname is
// specified as NULL, the output is sent to STDOUT.  It returns true
// on success, false otherwise.
//
bool regenerate_source(
    treenode const * const node,   // root node of AST
    char const * const outname) {  // name of output file, or NULL if
                                   // you want output to go to STDOUT
  unsigned int lineno;             // logical line number index used to
                                   // loop through all N lines of the
                                   // program, 0..N-1 (not the line number
                                   // specified in the BASIC source code)
  FILE *outfile = NULL;            // output file handle
  bool retval;                     // return value for this function

  if (!outname || !outname[0]) {
    outfile = stdout;
  } else {
    if ((outfile = fopen(outname, "w")) == NULL) {
      fprintf(stderr, "Unable to open file '%s' for output.\n", outname);
      retval = false;
      goto xit2;
    }
  }
  if (renumber) {
    uint32_t curlineno,  // current newly generated BASIC source code line number
             increment;  // increment to use between lines

    if (node->numchildren < 1000U) {
      increment = curlineno = 10U;
    } else {
      if (node->numchildren < 5000U) {
        curlineno = increment = 2U;
      } else {
        increment = curlineno = 1U;
      }
    }
    // for each line of the input program
    for (lineno = 0U; lineno < (uint32_t)node->numchildren; ++lineno) {
      if (!node->children[lineno])
        ICE(__FILE__, __func__, __LINE__, "The %" PRIu32 "%s line of the program is missing\n",
            lineno+1, suffix(lineno+1));
      // replace token text
      free(node->children[lineno]->children[0]->leaftoken->toketext);
      node->children[lineno]->children[0]->leaftoken->toketext = strdup(myitoa((int)curlineno));
      // replace token numeric value
      node->children[lineno]->children[0]->numeric_value.uivalue = curlineno;
      // update line's numeric value
      node->children[lineno]->numeric_value.uivalue = curlineno;
      curlineno += increment;
    }
  } else {
    // for each line of the input program
    for (lineno = 0U; lineno < (uint32_t)node->numchildren; ++lineno) {
      // copy token's numeric value into line's numeric value
      if (!node->children[lineno])
        ICE(__FILE__, __func__, __LINE__, "The %" PRIu32 "%s line of the program is missing\n",
            lineno+1, suffix(lineno+1));
      node->children[lineno]->numeric_value = node->children[lineno]->children[0]->numeric_value;
    }
  }
  // for each line of the input program
  for (lineno = 0U; lineno < (uint32_t)node->numchildren; ++lineno) {
    // the BASIC program line number and a space
    fprintf(outfile, "%" PRIu32 " ", node->children[lineno]->numeric_value.uivalue);
    switch(node->children[lineno]->children[1]->leaftoken->tid) {
      case T_PRINT:
        regenerate_print(node->children[lineno]->children[1], outfile);
        break;
      case T_OPTION:
        regenerate_option(node->children[lineno]->children[1], outfile);
        break;
      case T_GOTO:
        regenerate_goto(node->children[lineno]->children[1], outfile);
        break;
      case T_GOSUB:
        regenerate_gosub(node->children[lineno]->children[1], outfile);
        break;
      case T_ON:
        regenerate_on_goto(node->children[lineno]->children[1], outfile);
        break;
      case T_RESTORE:
        regenerate_restore(node->children[lineno]->children[1], outfile);
        break;
      case T_RANDOMIZE:
        regenerate_randomize(node->children[lineno]->children[1], outfile);
        break;
      case T_RETURN:
        regenerate_return(node->children[lineno]->children[1], outfile);
        break;
      case T_STOP:
        regenerate_stop(node->children[lineno]->children[1], outfile);
        break;
      case T_END:
        regenerate_end(node->children[lineno]->children[1], outfile);
        break;
      case T_REM:
        regenerate_rem(node->children[lineno]->children[1], outfile);
        break;
      case T_DATA:
        regenerate_data(node->children[lineno]->children[1], outfile);
        break;
      case T_LET:
        regenerate_let(node->children[lineno]->children[1], outfile);
        break;
      case T_IF:
        regenerate_if(node->children[lineno]->children[1], outfile);
        break;
      case T_READ:
        regenerate_read(node->children[lineno]->children[1], outfile);
        break;
      case T_INPUT:
        regenerate_input(node->children[lineno]->children[1], outfile);
        break;
      case T_EXIT:
        regenerate_exit_for(node->children[lineno]->children[1], outfile);
        break;
      case T_NEXT:
        regenerate_next(node->children[lineno]->children[1], outfile);
        break;
      case T_FOR:
        regenerate_for(node->children[lineno]->children[1], outfile);
        break;
      case T_DEF:
        regenerate_def(node->children[lineno]->children[1], outfile);
        break;
      case T_DIM:
        regenerate_dim(node->children[lineno]->children[1], outfile);
        break;
      default:
        fprintf(outfile, emsg[211], token_names[node->children[lineno]->children[1]->leaftoken->tid] + 2);
        retval = false;
        goto xit;
    }
    fputc('\n', outfile);
  }
  retval = (lineno > 0U);
xit:
  if (outfile != stdout)
    fclose(outfile);
xit2:
  outfile = NULL;
  return retval;
}

#ifdef UNIT_TEST
#include <errno.h>
#include <getopt.h>

bool test1(void);

bool test1(void) {
  unsigned int curline = 0U;
  bool retval;
  treenode *n = NULL;

  n = create_tree_node((extensions?14U:10U), T_PROGRAM, "Entire Program", 0U, 0U);

  n->children[curline] = create_tree_node(2U, T_LINE, "5 OPTION BASE 1", 5U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "5", 5U, 1U);
  n->children[curline]->children[1] = create_tree_node(1U, T_OPTION, "OPTION", 5U, 3U);
  n->children[curline]->children[1]->children[0] = create_tree_node(1U, T_BASE, "BASE", 5U, 10U);
  n->children[curline++]->children[1]->children[0]->children[0] = create_tree_node(0U, T_INTEGER, "1", 5U, 15U);

  n->children[curline] = create_tree_node(2U, T_LINE, "197 GOSUB 290", 197U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "197", 197U, 1U);
  n->children[curline]->children[1] = create_tree_node(1U, T_GOSUB, "GOSUB", 197U, 5U);
  // 4 means 4th line, not literally line 4, it is an indirect address, in this case line 290
  n->children[curline]->children[1]->numeric_value.uivalue = 4U;
  n->children[curline++]->children[1]->children[0] = create_tree_node(0U, T_INTEGER, "290", 197U, 10U);

  n->children[curline] = create_tree_node(2U, T_LINE, "198 GOTO 199", 198U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "198", 198U, 1U);
  n->children[curline]->children[1] = create_tree_node(1U, T_GOTO, "GOTO", 198U, 5U);
  // 3 means 3rd line, not literally line 3, it is an indirect address, in this case line 199
  n->children[curline]->children[1]->numeric_value.uivalue = 3U;
  n->children[curline++]->children[1]->children[0] = create_tree_node(0U, T_INTEGER, "199", 198U, 10U);

  n->children[curline] = create_tree_node(2U, T_LINE, "199 STOP", 199U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "199", 199U, 1U);
  n->children[curline++]->children[1] = create_tree_node(0U, T_STOP, "STOP", 199U, 5U);

  n->children[curline] = create_tree_node(2U, T_LINE, "290 REM THIS IS A TEST", 290U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "290", 290U, 1U);
  n->children[curline++]->children[1] = create_tree_node(0U, T_REM, "REM THIS IS A TEST", 290U, 5U);

  n->children[curline] = create_tree_node(2U, T_LINE, "291 PRINT +9.99999E+35;A", 291U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "291", 291U, 1U);
  n->children[curline]->children[1] = create_tree_node(4U, T_PRINT, "PRINT", 291U, 5U);
  n->children[curline]->children[1]->children[0] = create_tree_node(0U, T_REAL, "+9.99999E+35", 291U, 11U);
  n->children[curline]->children[1]->children[1] = create_tree_node(0U, T_SEMI, ";", 291U, 23U);
  n->children[curline]->children[1]->children[2] = create_tree_node(0U, T_NVAR, "A", 291U, 24U);
  n->children[curline++]->children[1]->children[3] = create_tree_node(0U, T_QSTRING, "\\n", 291U, 25U);

  n->children[curline] = create_tree_node(2U, T_LINE, "298 PRINT \"HELLO\",\"BOB\"", 298U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "298", 298U, 1U);
  n->children[curline]->children[1] = create_tree_node(4U, T_PRINT, "PRINT", 298U, 5U);
  n->children[curline]->children[1]->children[0] = create_tree_node(0U, T_QSTRING, "HELLO", 298U, 11U);
  n->children[curline]->children[1]->children[1] = create_tree_node(0U, T_COMMA, ",", 298U, 18U);
  n->children[curline]->children[1]->children[2] = create_tree_node(0U, T_QSTRING, "BOB", 298U, 19U);
  n->children[curline++]->children[1]->children[3] = create_tree_node(0U, T_QSTRING, "\\n", 298U, 24U);

  n->children[curline] = create_tree_node(2U, T_LINE, "299 RETURN", 299U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "299", 299U, 1U);
  n->children[curline++]->children[1] = create_tree_node(0U, T_RETURN, "RETURN", 299U, 5U);

  n->children[curline] = create_tree_node(2U, T_LINE, "300 PRINT LEN(A$)", 300U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "300", 300U, 1U);
  n->children[curline]->children[1] = create_tree_node(1U, T_PRINT, "PRINT", 300U, 5U);
  n->children[curline++]->children[1]->children[0] = create_tree_node(0U, T_RND, "RND", 300U, 11U);

  if (extensions) {
    n->children[curline] = create_tree_node(2U, T_LINE, "301 PRINT LEN(A$)", 301U, 1U);
    n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "301", 301U, 1U);
    n->children[curline]->children[1] = create_tree_node(1U, T_PRINT, "PRINT", 301U, 5U);
    n->children[curline]->children[1]->children[0] = create_tree_node(1U, T_LEN, "LEN", 301U, 11U);
    n->children[curline++]->children[1]->children[0]->children[0] = create_tree_node(0U, T_SVAR, "A$", 301U, 15U);

    n->children[curline] = create_tree_node(2U, T_LINE, "310 LET X=LEN(A$)", 310U, 1U);
    n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "300", 310U, 1U);
    n->children[curline]->children[1] = create_tree_node(2U, T_LET, "LET", 310U, 5U);
    n->children[curline]->children[1]->children[0] = create_tree_node(0U, T_NVAR, "X", 310U, 9U);
    n->children[curline]->children[1]->children[1] = create_tree_node(1U, T_LEN, "LEN", 310U, 11U);
    n->children[curline++]->children[1]->children[1]->children[0] = create_tree_node(0U, T_SVAR, "A$", 310U, 15U);

    n->children[curline] = create_tree_node(2U, T_LINE, "311 LET X=MIN(A,B)", 311U, 1U);
    n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "300", 311U, 1U);
    n->children[curline]->children[1] = create_tree_node(2U, T_LET, "LET", 311U, 5U);
    n->children[curline]->children[1]->children[0] = create_tree_node(0U, T_NVAR, "X", 311U, 9U);
    n->children[curline]->children[1]->children[1] = create_tree_node(2U, T_MIN, "MIN", 311U, 11U);
    n->children[curline]->children[1]->children[1]->children[0] = create_tree_node(0U, T_NVAR, "A", 311U, 15U);
    n->children[curline++]->children[1]->children[1]->children[1] = create_tree_node(0U, T_NVAR, "B", 311U, 17U);

    n->children[curline] = create_tree_node(2U, T_LINE, "320 PRINT PI", 320U, 1U);
    n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "320", 320U, 1U);
    n->children[curline]->children[1] = create_tree_node(1U, T_PRINT, "PRINT", 320U, 5U);
    n->children[curline++]->children[1]->children[0] = create_tree_node(0U, T_PI, "PI", 320U, 11U);
  }

  n->children[curline] = create_tree_node(2U, T_LINE, "320 END", 320U, 1U);
  n->children[curline]->children[0] = create_tree_node(0U, T_INTEGER, "320", 320U, 1U);
  n->children[curline++]->children[1] = create_tree_node(0U, T_END, "END", 320U, 5U);

  retval = regenerate_source(n, "");
  tree_delete_all(&n);
  n = NULL;
  return retval;
}

int main(int argc, char *argv[]) {
  int retval;
  int32_t opt; // variable used by getopt() function

  optimization_level=0U;
  extensions=use_SSE4_1=verbose=false;
  use_double=true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:X")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0], false);
        retval = EXIT_SUCCESS;
        goto xit;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        retval = EXIT_FAILURE;
        goto xit;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  init_debug_printf(stderr);
  retval = test1();
xit:
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return (retval ? EXIT_SUCCESS : EXIT_FAILURE);
}
#endif
