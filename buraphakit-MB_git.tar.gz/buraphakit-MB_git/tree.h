#ifndef TREE_H
#define TREE_H
//
// tree.h - This file contains the header file for tree.c
//
// Copyright (C) 2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include "scanner3.h"
#include "symbol_table.h"

// The operations supported for expression trees are distinct from token IDs,
// since we need to distinguish between unary and binary subtraction.
enum opids {
OP_NOOP=0,       // no operation (used for leaves, and also for freshly created nodes)
OP_UMINUS,       // unary minus
OP_SUBTRACT,     // binary subtraction
OP_ADD,          // binary addition
OP_DIVIDE,       // binary division
OP_MULTIPLY,     // binary multiplication
OP_POWER,        // binary power (x^y)
OP_BIF,          // call built-in function
OP_UDF,          // call user-defined function
OP_VARR,         // vector (1 index) array read
OP_MARR,         // matrix (2 index) array read
OP_DELETED,      // used to mark a node as deleted
};
extern unsigned int const opid_count;
extern char const * const opid_names[];

typedef struct tree_node treenode;
typedef struct tree_node {
  treenode **children;           // pointer to dynamically allocated array of pointers
                                 // to children, or NULL if this is a leaf node
  unsigned int numchildren;      // number of elements in children[], if children is non-NULL
  token *leaftoken;              // pointer to token (must free)
  char *d_regname;               // register name for use by this node (must free)
  char *labelname;               // label name for literal or variable (must free)
  arraydata *ad;                 // pointer to array data (NULL for non-arrays), DO NOT FREE!
  enum opids oid;                // operator id (only used for internal nodes)
  // the following 4 fields are unused for tree, but used for dag
  unsigned int parent_count;         // number of incoming edges for a dag node (used for traversal, register assignment)
  unsigned int parent_count2;        // number of incoming edges for a dag node (used for deletion)
  unsigned int leftchild_height;     // height of left child dag
  unsigned int rightchild_height;    // height of right child dag
  union {
    double dvalue;               // double numeric value (if use_double is true)
    float fvalue;                // float numeric value (if use_double is false)
    uint32_t uivalue;            // unsigned 32 bit integer value (lineno, array dimension, etc.)
  } numeric_value;
} treenode;

treenode *create_tree_node(                // Create a new node in the AST
    unsigned int const maxchildren,        // Number of children this node can have
    enum token_ids const tid,              // Token ID number
    char const * consttoketext,            // Token text
    uint32_t const lno,                    // Source line number
    uint32_t const cno);                   // Source column number
treenode *create_tree_node2(               // Create a new node in the AST
    unsigned int const maxchildren,        // Number of children this node can have
    token const * const token);            // Pointer to token to use to initialize this
                                           // AST node
void tree_delete_all(                      // Delete the AST tree rooted at proot
    treenode **proot);                     // Pointer to the root of the tree
void tree_postorder(                       // Perform a post-order traversal of the tree
                                           // rooted at proot, executing function v on
                                           // each node
    treenode const * const proot,          // Pointer to the root of the tree
    void (*v)(const treenode *n));         // Pointer to function to execute at each node
void tree_postorder_rw(                    // Perform a post-order traversal of the tree
                                           // rooted at proot, executing function v on
                                           // each node
    treenode const * const proot,          // Pointer to the root of the tree
    void (*v)(treenode *n));               // Pointer to function to execute at each node
unsigned int tree_height(                  // Return height of the tree rooted at proot
    treenode const * const proot);         // Pointer to the root of the tree
void dump_tree_node_string(                // Display the value of a node label or token text
    treenode const * const node);          // Pointer to the node to dump
void dump_tree_node(                       // Display all the values of a node
    treenode const * const node);          // Pointer to the node to dump
#endif
