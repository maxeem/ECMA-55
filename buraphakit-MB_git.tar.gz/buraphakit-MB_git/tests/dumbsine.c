/*
 gcc -Wall -Wextra -pedantic -std=c99 -D_GNU_SOURCE -O0 \
   -m64 -march=core2 -mtune=core2 -frounding-math -mno-recip \
   -mcmodel=large -mno-recip -fno-associative-math -fmerge-constants \
   -fno-inline -fno-builtin dumbsine.c -o dumbsine -lm -static
 */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <fenv.h>

static double Z[4000], A, D, I, J, K, N, R, S, T, X;
static int set_excepts;

static double FNP(void) { return 3.1415926535989793; }

static void mysin(void) {
  double temp;

  R=0.0; S=0.0; I=1.0;
  while (1) {
    if (I>5.0) break;
    set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
    if (set_excepts & FE_INVALID) goto fail;
    if (set_excepts & FE_OVERFLOW) {
      fprintf(stderr,"FE_OVERFLOW exception\n");
      I=INFINITY;
    }
    T=1.0; N=1.0; J=1.0;
    while (1) {
      temp=I*2.0;
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      temp=temp-1.0;
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      if (J>temp) break;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW | FE_UNDERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        J=INFINITY;
      }
      if (set_excepts & FE_UNDERFLOW) {
        fprintf(stderr,"FE_UNDERFLOW exception\n");
        J=0.0;
      }
      N=N*A;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW | FE_UNDERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        N=(A<0?-INFINITY:INFINITY);
      }
      if (set_excepts & FE_UNDERFLOW) {
        fprintf(stderr,"FE_UNDERFLOW exception\n");
        N=0.0;
      }
      temp=J+1.0;
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      J=temp;
    }
    D=1.0; J=1.0;
    while (1) {
      temp=I*2.0;
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      temp=temp-1.0;
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      if (J>temp) break;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW | FE_UNDERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        J=INFINITY;
      }
      if (set_excepts & FE_UNDERFLOW) {
        fprintf(stderr,"FE_UNDERFLOW exception\n");
        J=0.0;
      }
      D=D*J;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW | FE_UNDERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        D=(J<0?-INFINITY:INFINITY);
      }
      if (set_excepts & FE_UNDERFLOW) {
        fprintf(stderr,"FE_UNDERFLOW exception\n");
        D=0.0;
      }
      temp=J+1.0;
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      J=temp;
    }
    T=N/D;
    set_excepts = fetestexcept(FE_INVALID | FE_UNDERFLOW | FE_DIVBYZERO);
    if (set_excepts & FE_INVALID) goto fail;
    if (set_excepts & FE_UNDERFLOW) {
      fprintf(stderr,"FE_UNDERFLOW exception\n");
      T=0.0;
    }
    if (set_excepts & FE_DIVBYZERO) {
      fprintf(stderr,"FE_DIVBYZERO exception\n");
      goto fail2;
    }
    if (S==0) {
      R=R+T;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        R=INFINITY;
      }
      S=1.0;
    } else {
      R=R-T;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        R=-INFINITY;
      }
      S=0.0;
    }
    temp=I+1.0;
    if (set_excepts & FE_INVALID) goto fail;
    if (set_excepts & FE_OVERFLOW) {
      fprintf(stderr,"FE_OVERFLOW exception\n");
      temp=INFINITY;
    }
    I=temp;
  }
  return;
fail2:
  fprintf(stderr,"FE_DIVBYZERO exception\n");
  goto gameover;
fail:
  fprintf(stderr,"FE_INVALID exception\n");
gameover:
  abort();
}

int main(void) {
  double temp;

//#pragma STDC FENV_ACCESS ON     // No support for this on Fedora 20

  // initialize global data
  for (X=0;X<4000;X++) Z[(unsigned int)round(X)]=NAN;
  A = NAN; D = NAN; I = NAN; J = NAN; K = NAN; 
  N = NAN; R = NAN; S = NAN; T = NAN; X = NAN;
  set_excepts = 0;

  feclearexcept(FE_INVALID|FE_OVERFLOW);

  K=1.0;
  while (1) {
    if (K>1000.0) break;
    X=0.0001;
    while (1) {
      temp=FNP();
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      temp=temp/8.0;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      if (X>FNP()/8.0) break;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        X=INFINITY;
      }
      A=X;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        A=(X<0?-INFINITY:INFINITY);
      }
      mysin();
      Z[(unsigned int)round(1000.0*X)]=R;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        Z[(unsigned int)round(1000.0*X)]=(R<0?-INFINITY:INFINITY);
      }
      temp=X+0.0001;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      X=temp;
    }
    X=0.0001;
    while (1) {
      temp=FNP();
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      temp=temp/8.0;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      if (X>temp) break;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        X=INFINITY;
      }
      printf("MY SIN( %17.15lg ) IS %17.15lg ACTUAL IS %17.15lg",
        X,Z[(unsigned int)round(1000.0*X)],sin(X));
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        abort();
      }
      printf(" DIFF %17.15lg\n",fabs(sin(X)-Z[(unsigned int)round(1000.0*X)]));
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        abort();
      }
      temp=X+0.0001;
      set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
      if (set_excepts & FE_INVALID) goto fail;
      if (set_excepts & FE_OVERFLOW) {
        fprintf(stderr,"FE_OVERFLOW exception\n");
        temp=INFINITY;
      }
      X=temp;
    }
    temp=K+1.0;
    set_excepts = fetestexcept(FE_INVALID | FE_OVERFLOW);
    if (set_excepts & FE_INVALID) goto fail;
    if (set_excepts & FE_OVERFLOW) {
      fprintf(stderr,"FE_OVERFLOW exception\n");
      temp=INFINITY;
    }
    K=temp;
  }
  return EXIT_SUCCESS;
fail:
  fprintf(stderr,"FE_INVALID exception\n");
  return EXIT_FAILURE;
}
