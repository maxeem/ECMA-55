#ifndef G_FMT_BASIC_NORMAL_H
#define G_FMT_BASIC_NORMAL_H
char *g_fmt(char *, double, signed long int, char);
#endif
