#ifndef CODEGEN_H
#define CODEGEN_H
//
// codegen.h - This file contains the header file for codegen.c
//             for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2013,2014,2105,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdio.h>
#include <stdbool.h>
#include <inttypes.h>

enum relop { LT=0, LE, EQ, GE, GT, NE, AND, OR, NOT }; // type definition for comparison operators

void write_prologue(FILE *f, const char *inname);
void write_epilogue(FILE *f);
void do_INPUT(FILE *f, const char *fmt);
void push_string_literal(FILE *f, const char *label, const char *txt);
void push_svar(FILE *f, const char *varname);
void dofpneg(FILE *f, const char *fp);
void dofpadd(FILE *f, const char *fp1, const char *fp2);
void dofpsub(FILE *f, const char *fp1, const char *fp2);
void dofpmul(FILE *f, const char *fp1, const char *fp2);
void dofpdiv(FILE *f, const char *fp1, const char *fp2);
void dofppow(FILE *f, const char *fp1, const char *fp2);
void load_nparm(FILE *f, const char *varname, const char *fpregname);
void load_nvar(FILE *f, const char *varname, const char *fpregname);
void load_float_literal(FILE *f, const char *flitname, const char *flitval, const char *fpregname);
void load_1D_navar(FILE *f, const char *varname, const uint32_t maxindex, const char *fpregname);
void load_2D_navar(FILE *f, const char *varname, const uint32_t rows, const uint32_t columns,
                   const char *row_fpregname, const char *column_fpregname);
void do_abs(FILE *f, const char *regname);
void do_sgn(FILE *f, const char *regname);
void do_sqr(FILE *f, const char *fpregname);
void do_int(FILE *f, const char *regname);
void do_rnd(FILE *f, const char *regname);
void do_pi(FILE *f, const char *regname);
void do_maxnum(FILE *f, const char *regname);
void do_date(FILE *f, const char *regname);
void do_time(FILE *f, const char *regname);
void do_dates(FILE *f);
void do_times(FILE *f);
void do_deg(FILE *f, const char *regname);
void do_rad(FILE *f, const char *regname);
void do_max(FILE *f, const char *lhs_fpregname, const char *rhs_fpregname);
void do_min(FILE *f, const char *lhs_fpregname, const char *rhs_fpregname);
void do_mod(FILE *f, const char *lhs_fpregname, const char *rhs_fpregname);
void do_remainder(FILE *f, const char *lhs_fpregname, const char *rhs_fpregname);
void do_round(FILE *f, const char *lhs_fpregname, const char *rhs_fpregname);
void do_truncate(FILE *f, const char *lhs_fpregname, const char *rhs_fpregname);
void do_angle(FILE *f, const char *lhs_fpregname, const char *rhs_fpregname);
void do_sin(FILE *f, const char *regname);
void do_sinh(FILE *f, const char *regname);
void do_asin(FILE *f, const char *regname);
void do_ceil(FILE *f, const char *regname);
void do_ip(FILE *f, const char *regname);
void do_fp(FILE *f, const char *regname);
void do_cos(FILE *f, const char *regname);
void do_cosh(FILE *f, const char *regname);
void do_acos(FILE *f, const char *regname);
void do_tan(FILE *f, const char *regname);
void do_tanh(FILE *f, const char *regname);
void do_atan(FILE *f, const char *regname);
void do_log(FILE *f, const char *regname);
void do_log2(FILE *f, const char *regname);
void do_log10(FILE *f, const char *regname);
void do_exp(FILE *f, const char *regname);
void do_sec(FILE *f, const char *regname);
void do_csc(FILE *f, const char *regname);
void do_cot(FILE *f, const char *regname);
void dorandomize(FILE *f);
void dostore_nvar(FILE *f, const char *varname, const char *regname);
void dostore_svar(FILE *f, const char *varname);
void dostore_1D_navar(FILE *f, const char *varname, const uint32_t maxrows,
                      const char *index_fpregname, const char *expression_fpregname);
void dostore_2D_navar(FILE *f, const char *varname, const uint32_t maxrows, const uint32_t maxcolumns,
                      const char *row_fpregname, const char *column_fpregname, const char *expression_fpregname);
void doloc(FILE *f, const uint32_t lineno);
void doprint_number(FILE *f);
void doprint_string(FILE *f);
void doprint_newline(FILE *f);
void doprint_nextfield(FILE *f);
void do_stop(FILE *f);
void do_goto(FILE *f, const uint32_t target_lineno);
void do_logical_not(FILE *f);
void do_numeric_comparison(FILE *f, const enum relop op, const char *lhs_regname, const char *rhs_regname);
void do_conditional_branch(FILE *f, const uint32_t target_lineno);
void do_string_comparison2(FILE *f, const enum relop op);
void do_gosub(FILE *f, const uint32_t target_lineno);
void do_return(FILE *f);
void do_ongotostart(FILE *f, const uint32_t maxchoice, const char *fpregname);
void do_ongotochoice(FILE *f, const uint32_t target_lineno);
void do_ongotoend(FILE *f);
void do_forloopstart(FILE *f, const char *ndex_var, const char *inc_var, char *test_label, char *body_label);
void do_forloopexit(FILE *f, const char *bot_label);
void do_forloopend(FILE *f, const char *ndex_var, const char *inc_var, const char *limit_var,
                   const char *test_label, const char *body_label, const char *bol_label);
void do_tab(FILE *f, const char *fpregname);
void do_input_nvar(FILE *f, const char *varname, const uint32_t slotno, const unsigned int lno);
void do_input_svar(FILE *f, const char *varname);
void do_input_navar(FILE *f, const char *varname, const uint32_t slotno, const uint32_t lno);
void do_input_nvar_phase2(FILE *f, const char *varname, const uint32_t slotno);
void do_input_svar_phase2(FILE *f, const char *varname, const uint32_t slotno);
void do_input_1D_navar_phase2(FILE *f, const char *varname, const uint32_t maxcolumns, const uint32_t slotno,
                              const char *colreg, const char *destreg);
void do_input_2D_navar_phase2(FILE *f, const char *varname, const uint32_t maxrows, const uint32_t maxcolumns,
                              const uint32_t slotno, const char *rowreg, const char *colreg, const char *destreg);
void do_read_nvar(FILE *f, const char *varname);
void do_read_svar(FILE *f, const char *varname);
void do_read_1D_navar(FILE *f, const char *varname, const uint32_t maxcolumns,
                      const char *column_fpregname, const char *expression_fpregname);
void do_read_2D_navar(FILE *f, const char *varname, const uint32_t maxrows, const uint32_t maxcolumns,
                  const char *row_fpregname, const char *column_fpregname, const char *expression_fpregname);
void do_restore(FILE *f);
void do_call_udf(FILE *f, const char *fname, const char *fpregname);
void do_udf_header(FILE *f, const char *fname, const char *argname);
void do_udf_footer(FILE *f, const char *udfname, const char *fpregname);
void emit_comment(FILE *f, const char *fmt, ...)  __attribute__ ((format (printf, 2, 3)));
void freg_to_freg(FILE *outfile, const char *freg1, const char *freg2);
void gen_stack(FILE *f);
const char *generate_label(void);
void emit_label(FILE *f, char const * const label);
void jump_if_true(FILE *f, char const * const label);
void jump_if_false(FILE *f, char const * const label);
void do_len(FILE *f, const char *regname);
void do_define_nlit(FILE *f, const char *, const char *);
void do_begin_data(FILE *f, const uint32_t item_count);
void do_unique_data_blocks(FILE *f);
void do_data_item_string(FILE *f, const char *symname, const char *sval);
void do_data_item_numeric(FILE *f, const char *symname, const char *sval, const char *nval, const char *fptype);
void do_read_data_array_start(FILE *f);
void do_emit_data_item_pointer(FILE *f, const char *symname);
void do_end_data(FILE *f);
void do_begin_ds_literals(FILE *f);
void do_define_slit(FILE *f, const char *symname, const char *litval);
void do_define_nvar(FILE *f, const char *varname);
void do_define_1D_navar(FILE *f, const char *varname, uint32_t element_count);
void do_define_2D_navar(FILE *f, const char *varname, uint32_t row_element_count, uint32_t columnt_element_count);
void do_begin_nvars(FILE *f);
void do_end_nvars(FILE *f);
void do_begin_svars(FILE *f);
void do_define_svar(FILE *f, const char *varname);
void do_end_svars(FILE *f);
void do_balign(FILE *f);
#endif
