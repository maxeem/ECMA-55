/*
------------------------------------------------------------------------------
derived from isaac64.c: My random number generator for 64-bit machines.
By Bob Jenkins, 1996.  Public Domain.
------------------------------------------------------------------------------
*/
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stddef.h>
#include <sys/time.h>
#include <time.h>

#define RAND_MAX 9223372036854775807ULL
#define RS_SCALE (1.0 / (1.0 + RAND_MAX))
#define RANDSIZL   (8)
#define RANDSIZ    (1 << RANDSIZL)

static unsigned long long randrsl[RANDSIZ], randcnt;
static unsigned long long mm[RANDSIZ];
static unsigned long long aa = 0ULL, bb = 0ULL, cc = 0ULL;
static double thevalue = 0.0;

/*
------------------------------------------------------------------------------
 If (flag == 1), then use the contents of randrsl[0..255] as the seed.
------------------------------------------------------------------------------
*/
void randinit(int flag);

void isaac64(void);


/*
------------------------------------------------------------------------------
 Call myrand() to retrieve a single 64-bit random value
------------------------------------------------------------------------------
*/
#define myrand() \
   (!randcnt-- ? (isaac64(), randcnt = RANDSIZ - 1, randrsl[randcnt]) : \
                 randrsl[randcnt])

#define ind(mm,x)  (*(unsigned long long *)((unsigned char *)(mm) + ((x) & ((RANDSIZ - 1) << 3))))
#define rngstep(mix, a, b, mm, m, m2, r, x) \
{ \
  x = *m;  \
  a = (mix) + *(m2++); \
  *(m++) = y = ind(mm, x) + a + b; \
  *(r++) = b = ind(mm, y >> RANDSIZL) + x; \
}

#if defined(__clang__)
__attribute__((no_sanitize("integer")))
#endif
void isaac64(void)
{
  register unsigned long long a, b, x, y, *m, *m2, *r, *mend;
  r = randrsl;
  a = aa; b = bb + (++cc);
  for (m = mm, mend = m2 = m + (RANDSIZ / 2); m < mend; )
  {
    rngstep( ~ (a ^ (a << 21)), a, b, mm, m, m2, r, x);
    rngstep(    a ^ (a >> 5)  , a, b, mm, m, m2, r, x);
    rngstep(    a ^ (a << 12) , a, b, mm, m, m2, r, x);
    rngstep(    a ^ (a >> 33) , a, b, mm, m, m2, r, x);
  }
  for (m2 = mm; m2 < mend; )
  {
    rngstep( ~ (a ^ (a << 21)), a, b, mm, m, m2, r, x);
    rngstep(    a ^ (a >> 5)  , a, b, mm, m, m2, r, x);
    rngstep(    a ^ (a << 12) , a, b, mm, m, m2, r, x);
    rngstep(    a ^ (a >> 33) , a, b, mm, m, m2, r, x);
  }
  bb = b; aa = a;
}

#define mix(a,b,c,d,e,f,g,h) \
{ \
   a -= e; f ^= h >> 9;  h += a; \
   b -= f; g ^= a << 9;  a += b; \
   c -= g; h ^= b >> 23; b += c; \
   d -= h; a ^= c << 15; c += d; \
   e -= a; b ^= d >> 14; d += e; \
   f -= b; c ^= e << 20; e += f; \
   g -= c; d ^= f >> 17; f += g; \
   h -= d; e ^= g << 14; g += h; \
}

#if defined(__clang__)
__attribute__((no_sanitize("integer")))
#endif
void randinit(int flag)
{
   int i;
   unsigned long long a, b, c, d, e, f, g, h;
   aa = bb = cc = 0ULL;
   a = b = c = d = e = f = g = h = 0x9e3779b97f4a7c13ULL;  /* the golden ratio */

   for (i = 0; i < 4; ++i)                    /* scramble it */
   {
     mix(a, b, c, d, e, f, g, h);
   }

   for (i = 0; i < RANDSIZ; i += 8)   /* fill in mm[] with messy stuff */
   {
     if (flag)                  /* use all the information in the seed */
     {
       a += randrsl[i  ];   b += randrsl[i + 1]; c += randrsl[i + 2]; d += randrsl[i + 3];
       e += randrsl[i + 4]; f += randrsl[i + 5]; g += randrsl[i + 6]; h += randrsl[i + 7];
     }
     mix(a, b, c, d, e, f, g, h);
     mm[i  ] = a; mm[i + 1] = b; mm[i + 2] = c; mm[i + 3] = d;
     mm[i+4] = e; mm[i + 5] = f; mm[i + 6] = g; mm[i + 7] = h;
   }

   if (flag)
   {        /* do a second pass to make all of the seed affect all of mm */
     for (i = 0; i < RANDSIZ; i += 8)
     {
       a += mm[i  ];   b += mm[i + 1]; c += mm[i + 2]; d += mm[i + 3];
       e += mm[i + 4]; f += mm[i + 5]; g += mm[i + 6]; h += mm[i + 7];
       mix(a, b, c, d, e, f, g, h);
       mm[i  ] = a;   mm[i + 1] = b; mm[i + 2] = c; mm[i + 3] = d;
       mm[i + 4] = e; mm[i + 5] = f; mm[i + 6] = g; mm[i + 7] = h;
     }
   }

   isaac64();          /* fill in the first set of results */
   randcnt = RANDSIZ;  /* prepare to use the first set of results */
}

/*
 *  returns a random double d such that 0 <= d < 1
 */
static double drand (void) {
    double d;
    do {
       d = (((myrand() * RS_SCALE) + myrand()) * RS_SCALE + myrand()) * RS_SCALE;
    } while (d >= 1.0); /* Round off */
    return d;
}

static void realinit(int flag) {
  unsigned long long i;
  for (i = 0ULL; i < RANDSIZ; ++i)
    mm[i] = 0ULL;
  aa = bb = cc = (unsigned long long)0ULL;
  if (flag) {
    struct timespec ts;

    clock_gettime(CLOCK_REALTIME, &ts);
    i = 0ULL;
    randrsl[i += 2ULL] = (unsigned long long)(ts.tv_sec);
    randrsl[i += 2ULL] = (unsigned long long)(ts.tv_nsec) << 3;
    randrsl[i += 2ULL] = (unsigned long long)((ts.tv_nsec*ts.tv_sec & 0x000FFFFFFFFFFFFF)) << 9;
    randrsl[i += 2ULL] = (unsigned long long)(ts.tv_sec) << 13;
    randrsl[i] = ts.tv_sec << 29;
    randinit(1);
  } else {
    randinit(0);
  }
  return;
}

#ifdef UNIT_TEST
int main(void)
{
  realinit(0);
  thevalue = drand();
  printf("%30.28lf\n", thevalue);
  realinit(1);
  thevalue = drand();
  printf("%30.28lf\n", thevalue);
  return 0;
}
#endif
