//
// dag.c - This is the file containing the DAG code
//         for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <fenv.h>
#include <float.h>
#include "raw_registers.h"
#include "globals.h"
#include "error_messages.h"
#include "symbol_table.h"
#include "g_fmt_BASIC_normal.h"
#include "dag.h"

#define MAXDAGGER 50
static struct dagrec {                 // one record of DAG information
  treenode *node;                      // pointer to node
  unsigned int leftchild;              // index of left child record in dagger[] (0 for None)
  unsigned int leftchild_height;       // height of left child sub-DAG
  unsigned int rightchild;             // index of right child record in dagger[] (0 for None)
  unsigned int rightchild_height;      // height of right child sub-DAG
  unsigned int parent_count;           // number of incoming arcs to this node in the DAG
} dagger[MAXDAGGER];                   // array of DAG records
// record 0 is not used, so it can represent null for left/right child
static unsigned int nextdagger = 1U;   // next available record in dagger[]

static unsigned int generate_dagger(treenode const * const node);
static void init_dagger(void);
static bool exists_in_dagger(const struct dagrec *needle, unsigned int *where);
static unsigned int add_to_dagger(const struct dagrec *needle);
static treenode *build_dag(const unsigned int ndex);
static void promote_int2fp(treenode *node);
static void dag_fold_negation(treenode *node, unsigned int *changecount);
static void dag_fold_subtract(treenode *node, unsigned int *changecount);
static void dag_fold_add(treenode *node, unsigned int *changecount);
static void dag_fold_multiply(treenode *node, unsigned int *changecount);
static void dag_fold_divide(treenode *node, unsigned int *changecount);
static void dag_fold_power(treenode *node, unsigned int *changecount);

//
// Convert a T_INTEGER node to a T_REAL node by changing the tid and
// numeric_value of the leaftoken
//
static void promote_int2fp(treenode *node) {
  if (T_INTEGER == node->leaftoken->tid) {
    node->leaftoken->tid=T_REAL;
    if (use_double) {
      node->numeric_value.dvalue=(double)node->numeric_value.uivalue;
      debug_printf("promoted integer %s to float %lf\n", node->leaftoken->toketext, node->numeric_value.dvalue);
    } else {
      node->numeric_value.fvalue=(float)node->numeric_value.uivalue;
      debug_printf("promoted integer %s to double %f\n", node->leaftoken->toketext, node->numeric_value.fvalue);
    }
  }
  return;
}

//
// DAG folding for the unary - operator
//
// Fold any -(C) to (-C) for any constant C in the DAG
//
static void dag_fold_negation(
    treenode *node,                  // Pointer to the root DAG node for this numeric expression
    unsigned int *changecount) {     // Counter for number of folding changes, incremented each time
                                     // this procedure changes the DAG

  promote_int2fp(node->children[0]);
  if (T_REAL == node->children[0]->leaftoken->tid) {
    char *tbuf = NULL;               // buffer used to hold the result of g_fmt() conversion
                                     // which is a properly formatted floating point value
    if (strstr(node->children[0]->leaftoken->toketext,"INF")==NULL) {
      debug_printf("Must not fold anything with INFINITY\n");
      return;
    }
    tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
    if (use_double) {
      node->numeric_value.dvalue = -node->children[0]->numeric_value.dvalue;
      g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
    } else {
      node->numeric_value.fvalue = -node->children[0]->numeric_value.fvalue;
      g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
    }
    free(node->leaftoken->toketext);
    node->leaftoken->toketext = tbuf;
    node->leaftoken->tid = T_REAL;
    node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
    dag_delete_all(&node->children[0]);
    node->children[0] = NULL;
    free(node->children);
    node->children = NULL;
    node->numchildren = node->leftchild_height = node->rightchild_height = 0U;
    (*changecount)++;
  }
  return;
}

//
// DAG folding for the binary - operator
//
// Fold ?-? to 0
//      0-? to -(?)
//      ?-0 to ?
// and  C-C to C' (normally done by fold_numeric_expression(), but new constants 0 and 1
//                 can be generated during DAG simplification....)
//
static void dag_fold_subtract(
    treenode *node,                  // Pointer to the root DAG node for this numeric expression
    unsigned int *changecount) {             // Counter for number of folding changes, incremented each time
                                             // this procedure changes the DAG

  promote_int2fp(node->children[0]);
  promote_int2fp(node->children[1]);
  if (optimization_level > 2U) {
     if ((T_REAL == node->children[0]->leaftoken->tid) &&
         (T_REAL == node->children[1]->leaftoken->tid)) {
       if (node->children[0] == node->children[1]) { // ?-? -> 0
          free(node->leaftoken->toketext);
          node->leaftoken->toketext = strdup("0");
          node->leaftoken->tid = T_REAL;
          node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
          dag_delete_all(&node->children[0]);
          dag_delete_all(&node->children[1]);
          node->leftchild_height = node->rightchild_height = 0U;
          node->children[0] = node->children[1] = NULL;
          free(node->children);
          node->children = NULL;
          node->numchildren = 0U;
          if (use_double) {
            node->numeric_value.dvalue = 0.0;
          } else {
            node->numeric_value.fvalue = 0.0f;
          }
          (*changecount)++;
          return;
      }
      if ( (use_double && (0.0 == node->children[0]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[0]->numeric_value.fvalue)) ) { // 0-? -> -(?)
         treenode *tempnode;

         debug_printf("Constant folder special case for 0-?\n");
         tempnode = node->children[1];
         dag_delete_all(&node->children[0]);
         node->children[0] = NULL;
         node->children[1] = NULL;
         free(node->children);
         node->children = (treenode **)xmalloc(__FILE__,__func__,__LINE__,sizeof(treenode *) * 1U);
         node->children[0] = tempnode;
         node->numchildren = 1U;
         node->oid = OP_UMINUS;
         (*changecount)++;
         return;
      }
      if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
            (!use_double && (0.0f == node->children[1]->numeric_value.fvalue)) ) { // ?-0 -> ?
         treenode **leftchildren = NULL;
         debug_printf("Constant folder special case for ?-0\n");

         // delete RHS zero
         dag_delete_all(&node->children[1]);
         // delete '-' leaftoken
         free(node->leaftoken->toketext);
         free(node->leaftoken);

         // copy in data from LHS
         // deep copy leaftoken
         node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
         node->leaftoken->toketext = strdup(node->children[0]->leaftoken->toketext);
         node->leaftoken->tid = node->children[0]->leaftoken->tid;
         node->leaftoken->lno = node->children[0]->leaftoken->lno;
         node->leaftoken->cno = node->children[0]->leaftoken->cno;
         node->leaftoken->pos = node->children[0]->leaftoken->pos;
         node->numeric_value = node->children[0]->numeric_value;
         node->oid = node->children[0]->oid;
         node->numeric_value = node->children[0]->numeric_value;
         node->leftchild_height = node->children[0]->leftchild_height;
         node->rightchild_height = node->children[0]->rightchild_height;
         node->numchildren = node->children[0]->numchildren;
         if (node->numchildren > 0) {
           leftchildren = node->children[0]->children;
           node->children[0]->numchildren = 0U;
           node->children[0]->children = NULL;
         }
         dag_delete_all(&node->children[0]);
         free(node->children);
         node->children = leftchildren;
         leftchildren = NULL;
         (*changecount)++;
         return;
      }
    }
  }
  if ( (T_REAL == node->children[0]->leaftoken->tid) &&
       (T_REAL == node->children[1]->leaftoken->tid) ) {
     char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                                // which is a properly formatted floating point value
     float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
     double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

     feclearexcept(FE_ALL_EXCEPT);
     if (use_double) {
       dvalue = node->children[0]->numeric_value.dvalue - node->children[1]->numeric_value.dvalue;
     } else {
       fvalue = node->children[0]->numeric_value.fvalue - node->children[1]->numeric_value.fvalue;
     }
     if (fetestexcept(FE_OVERFLOW|FE_INVALID)) {
       feclearexcept(FE_ALL_EXCEPT);
       debug_printf("%s(): Cannot fold the constant subtraction since it would prevent a required exception.\n", __func__);
       return;
     }
     tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
     if (use_double) {
       node->numeric_value.dvalue = dvalue;
       g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
     } else {
       node->numeric_value.fvalue = fvalue;
       g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
     }
     node->leaftoken->tid = T_REAL;
     node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
     free(node->leaftoken->toketext);
     node->leaftoken->toketext = tbuf;
     dag_delete_all(&node->children[0]);
     dag_delete_all(&node->children[1]);
     free(node->children);
     node->children = NULL;
     node->numchildren = 0U;
     node->leftchild_height = node->rightchild_height = 0U;
     (*changecount)++;
  }
  return;
}

//
// DAG folding for the binary + operator
//
// Fold 0+? to ?
//      ?+0 to ?
// and  C+C to C' (normally done by fold_numeric_expression(), but new constants 0 and 1
//                 can be generated during DAG simplification....)
//
static void dag_fold_add(
    treenode *node,                  // Pointer to the root DAG node for this numeric expression
    unsigned int *changecount) {             // Counter for number of folding changes, incremented each time
                                             // this procedure changes the DAG

  promote_int2fp(node->children[0]);
  promote_int2fp(node->children[1]);
  if (optimization_level > 2U) {
    if ((T_REAL == node->children[0]->leaftoken->tid) &&
        (T_REAL == node->children[1]->leaftoken->tid)) {
       if ( (use_double && (0.0 == node->children[0]->numeric_value.dvalue)) ||
            (!use_double && (0.0f == node->children[0]->numeric_value.fvalue)) ) { // 0+? -> ?
         treenode *temp_node_ptr;

         debug_printf("Constant folder special case for 0+?, swap kids\n");
         // swap kids so it becomes ?+0 case
         temp_node_ptr = node->children[0];
         node->children[0] = node->children[1];
         node->children[1] = temp_node_ptr;
         temp_node_ptr = NULL;
         (*changecount)++;
       }
       if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
            (!use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ) { // ?+0 -> ?
         treenode **leftchildren = NULL;
         debug_printf("Constant folder special case for ?+0\n");

         // delete RHS zero
         dag_delete_all(&node->children[1]);
         // delete '+' leaftoken
         free(node->leaftoken->toketext);
         free(node->leaftoken);

         // copy in data from LHS
         // deep copy leaftoken
         node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
         node->leaftoken->toketext = strdup(node->children[0]->leaftoken->toketext);
         node->leaftoken->tid = node->children[0]->leaftoken->tid;
         node->leaftoken->lno = node->children[0]->leaftoken->lno;
         node->leaftoken->cno = node->children[0]->leaftoken->cno;
         node->leaftoken->pos = node->children[0]->leaftoken->pos;
         node->numeric_value = node->children[0]->numeric_value;
         node->oid = node->children[0]->oid;
         node->numeric_value = node->children[0]->numeric_value;
         node->leftchild_height = node->children[0]->leftchild_height;
         node->rightchild_height = node->children[0]->rightchild_height;
         node->numchildren = node->children[0]->numchildren;
         if (node->numchildren > 0) {
           leftchildren = node->children[0]->children;
           node->children[0]->numchildren = 0U;
           node->children[0]->children = NULL;
         }
         dag_delete_all(&node->children[0]);
         free(node->children);
         node->children = leftchildren;
         leftchildren = NULL;
         (*changecount)++;
         return;
       }
    }
  }
  if ( (T_REAL == node->children[0]->leaftoken->tid) &&
       (T_REAL == node->children[1]->leaftoken->tid) ) {
     char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                                // which is a properly formatted floating point value
     float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
     double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

     debug_printf("%s():normal constant fold add\n", __func__);
     feclearexcept(FE_ALL_EXCEPT);
     if (use_double) {
       dvalue = node->children[0]->numeric_value.dvalue+node->children[1]->numeric_value.dvalue;
     } else {
       fvalue = node->children[0]->numeric_value.fvalue+node->children[1]->numeric_value.fvalue;
     }
     if (fetestexcept(FE_OVERFLOW|FE_INVALID)) {
       feclearexcept(FE_ALL_EXCEPT);
       debug_printf("%s(): Cannot fold the constant addition since it would prevent a required exception.\n", __func__);
       return;
     }
     tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
     if (use_double) {
       node->numeric_value.dvalue = dvalue;
       g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
     } else {
       node->numeric_value.fvalue = fvalue;
       g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
     }
     node->leaftoken->tid = T_REAL;
     node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
     free(node->leaftoken->toketext);
     node->leaftoken->toketext = tbuf;
     dag_delete_all(&node->children[0]);
     dag_delete_all(&node->children[1]);
     free(node->children);
     node->children = NULL;
     node->numchildren = 0U;
     node->leftchild_height = node->rightchild_height = 0U;
     (*changecount)++;
  }
  return;
}

//
// DAG folding for the * operator
//
// Fold 0*? to 0
//      ?*0 to 0
//      1*? to ?
//      ?*1 to ?
// and  C*C to C' (normally done by fold_numeric_expression(), but new constants 0 and 1
//                 can be generated during DAG simplification....)
//
static void dag_fold_multiply(
    treenode *node,                  // Pointer to the root DAG node for this numeric expression
    unsigned int *changecount) {             // Counter for number of folding changes, incremented each time
                                             // this procedure changes the DAG

  promote_int2fp(node->children[0]);
  promote_int2fp(node->children[1]);
  if (optimization_level > 2U) {
    if ((T_REAL == node->children[0]->leaftoken->tid) &&
        (T_REAL == node->children[1]->leaftoken->tid)) {
       if ( (use_double && (0.0 == node->children[0]->numeric_value.dvalue)) ||
            (!use_double && (0.0f == node->children[0]->numeric_value.fvalue)) ) { // 0*? -> ?*0
         treenode *temp_node_ptr = NULL;
         debug_printf("Constant folder special case for 0*?, swap kids\n");
         // swap kids so it becomes ?*0 case
         temp_node_ptr = node->children[0];
         node->children[0] = node->children[1];
         node->children[1] = temp_node_ptr;
         temp_node_ptr = NULL;
         (*changecount)++;
         // INTENTIONALLY FALL THROUGH!!!
       }
       if ( (use_double && (1.0 == node->children[0]->numeric_value.dvalue)) ||
            (!use_double && (1.0f == node->children[0]->numeric_value.fvalue)) ) { // 1*? -> ?*1
         treenode *temp_node_ptr = NULL;
         debug_printf("Constant folder special case for 1*?, swap kids\n");
         // swap kids so it becomes ?*1 case
         temp_node_ptr = node->children[0];
         node->children[0] = node->children[1];
         node->children[1] = temp_node_ptr;
         temp_node_ptr = NULL;
         (*changecount)++;
         // INTENTIONALLY FALL THROUGH!!!
       }
       if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
            (!use_double && (0.0f == node->children[1]->numeric_value.fvalue)) ) { // ?*0 -> 0
         debug_printf("Constant folder special case for ?*0\n");
         // delete LHS with ?
         dag_delete_all(&node->children[0]);
         // delete RHS with 0
         dag_delete_all(&node->children[1]);
         // delete children array
         free(node->children);
         node->children = NULL;
         node->numchildren = 0U;
         // free node's current '*' token text
         free(node->leaftoken->toketext);
         node->leaftoken->toketext = strdup("0");
         node->leaftoken->tid = T_REAL;
         node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
         node->leftchild_height = node->rightchild_height = 0U;
         if (use_double) {
           node->numeric_value.dvalue = 0.0;
         } else {
           node->numeric_value.fvalue = 0.0f;
         }
         (*changecount)++;
         return;
       }
       if ( (use_double && (1.0 == node->children[1]->numeric_value.dvalue)) ||
            (!use_double && (1.0f == node->children[1]->numeric_value.fvalue)) ) { // ?*1 -> ?
         treenode **leftchildren = NULL;
         debug_printf("Constant folder special case for ?*1\n");

         // delete RHS one
         dag_delete_all(&node->children[1]);
         // delete '*' leaftoken
         free(node->leaftoken->toketext);
         free(node->leaftoken);

         // copy in data from LHS
         // deep copy leaftoken
         node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
         node->leaftoken->toketext = strdup(node->children[0]->leaftoken->toketext);
         node->leaftoken->tid = node->children[0]->leaftoken->tid;
         node->leaftoken->lno = node->children[0]->leaftoken->lno;
         node->leaftoken->cno = node->children[0]->leaftoken->cno;
         node->leaftoken->pos = node->children[0]->leaftoken->pos;
         node->numeric_value = node->children[0]->numeric_value;
         node->oid = node->children[0]->oid;
         node->numeric_value = node->children[0]->numeric_value;
         node->leftchild_height = node->children[0]->leftchild_height;
         node->rightchild_height = node->children[0]->rightchild_height;
         node->numchildren = node->children[0]->numchildren;
         if (node->numchildren > 0) {
           leftchildren = node->children[0]->children;
           node->children[0]->numchildren = 0U;
           node->children[0]->children = NULL;
         }
         dag_delete_all(&node->children[0]);
         free(node->children);
         node->children = leftchildren;
         leftchildren = NULL;
         (*changecount)++;
         return;
       }
    }
    // INTENTIONALLY FALL THROUGH!!!
  }
  if ( (T_REAL == node->children[0]->leaftoken->tid) &&
       (T_REAL == node->children[1]->leaftoken->tid) ) {
     char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                                // which is a properly formatted floating point value
     float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
     double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

     debug_printf("%s():fold multiply\n", __func__);
     feclearexcept(FE_ALL_EXCEPT);
     if (use_double) {
       dvalue = node->children[0]->numeric_value.dvalue*node->children[1]->numeric_value.dvalue;
     } else {
       fvalue = node->children[0]->numeric_value.fvalue*node->children[1]->numeric_value.fvalue;
     }
     if (fetestexcept(FE_OVERFLOW | FE_UNDERFLOW | FE_INVALID)) {
       feclearexcept(FE_ALL_EXCEPT);
       debug_printf("%s(): Cannot fold multiply operator since it would prevent a required exception.\n", __func__);
       return;
     }
     tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
     if (use_double) {
       node->numeric_value.dvalue = dvalue;
       g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
     } else {
       node->numeric_value.fvalue = fvalue;
       g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
     }
     node->leaftoken->tid = T_REAL;
     node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
     free(node->leaftoken->toketext);
     node->leaftoken->toketext = tbuf;
     dag_delete_all(&node->children[0]);
     dag_delete_all(&node->children[1]);
     free(node->children);
     node->children = NULL;
     node->numchildren = 0U;
     node->leftchild_height = node->rightchild_height = 0U;
     (*changecount)++;
     // INTENTIONALLY FALL THROUGH!!!!
  }
  return;
}

//
// DAG folding for the / operator
//
// Fold ?/? to 1  (for ? != 0; this fails to generate required exceptions if ? is Nan or infinite)
//      ?/0 to ?
// and  C/C to C' (normally done by fold_numeric_expression(), but new constants 0 and 1
//                 can be generated during DAG simplification....)
//
static void dag_fold_divide(
    treenode *node,                  // Pointer to the root DAG node for this numeric expression
    unsigned int *changecount) {             // Counter for number of folding changes, incremented each time
                                             // this procedure changes the DAG

  promote_int2fp(node->children[0]);
  promote_int2fp(node->children[1]);
  if (T_REAL == node->children[1]->leaftoken->tid) {
     if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
          (!use_double && (0.0f == node->children[1]->numeric_value.fvalue)) ) { // ?/0 cannot be folded
       debug_printf("Constant folder special case for ?/0\n");
       return;
     }
  }
  if ((T_REAL == node->children[0]->leaftoken->tid) &&
      (T_REAL == node->children[1]->leaftoken->tid)) {
    if (node->children[0] == node->children[1]) { // ?/? -> 1
       debug_printf("Constant folder special case for ?/?\n");
       free(node->leaftoken->toketext);
       node->leaftoken->toketext = strdup("1");
       node->leaftoken->tid = T_REAL;
       node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
       dag_delete_all(&node->children[0]);
       dag_delete_all(&node->children[1]);
       node->leftchild_height = node->rightchild_height = 0U;
       node->children[0] = node->children[1] = NULL;
       free(node->children);
       node->children = NULL;
       node->numchildren = 0U;
       if (use_double) {
         node->numeric_value.dvalue = 1.0;
       } else {
         node->numeric_value.fvalue = 1.0f;
       }
       (*changecount)++;
       return;
    }
  }
  if (optimization_level > 2U) {
    if ((T_REAL == node->children[0]->leaftoken->tid) &&
        (T_REAL == node->children[1]->leaftoken->tid)) {
       if ( (use_double && (1.0 == node->children[1]->numeric_value.dvalue)) ||
            (!use_double && (1.0f == node->children[1]->numeric_value.fvalue)) ) { // ?/1 -> ?
         treenode **leftchildren = NULL;
         debug_printf("Constant folder special case for ?/1\n");

         // delete RHS one
         dag_delete_all(&node->children[1]);
         // free node's current '/' token
         free(node->leaftoken->toketext);
         free(node->leaftoken);

         // copy in data from LHS
         // deep copy leaftoken
         node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
         node->leaftoken->toketext = strdup(node->children[0]->leaftoken->toketext);
         node->leaftoken->tid = node->children[0]->leaftoken->tid;
         node->leaftoken->lno = node->children[0]->leaftoken->lno;
         node->leaftoken->cno = node->children[0]->leaftoken->cno;
         node->leaftoken->pos = node->children[0]->leaftoken->pos;
         node->numeric_value = node->children[0]->numeric_value;
         node->oid = node->children[0]->oid;
         node->numeric_value = node->children[0]->numeric_value;
         node->leftchild_height = node->children[0]->leftchild_height;
         node->rightchild_height = node->children[0]->rightchild_height;
         node->numchildren = node->children[0]->numchildren;
         if (node->numchildren > 0) {
           leftchildren = node->children[0]->children;
           node->children[0]->numchildren = 0U;
           node->children[0]->children = NULL;
         }
         dag_delete_all(&node->children[0]);
         free(node->children);
         node->children = leftchildren;
         leftchildren = NULL;
         (*changecount)++;
         return;
       }
    }
    // INTENTIONALLY FALL THROUGH!!!
  }
  if ( (T_REAL == node->children[0]->leaftoken->tid) &&
       (T_REAL == node->children[1]->leaftoken->tid) ) {
     char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                                // which is a properly formatted floating point value
     float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
     double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

     debug_printf("%s():fold_divide\n", __func__);
     feclearexcept(FE_ALL_EXCEPT);
     if (use_double) {
       if (node->children[1]->numeric_value.dvalue < DBL_MIN) {
         debug_printf("%s(): Cannot fold the constant division since it would prevent a required exception.\n", __func__);
         return;
       }
       dvalue = node->children[0]->numeric_value.dvalue/node->children[1]->numeric_value.dvalue;
     } else {
       if (node->children[1]->numeric_value.fvalue < FLT_MIN) {
         debug_printf("%s(): Cannot fold the constant division since it would prevent a required exception.\n", __func__);
         return;
       }
       fvalue = node->children[0]->numeric_value.fvalue/node->children[1]->numeric_value.fvalue;
     }
     if (fetestexcept(FE_DIVBYZERO | FE_INVALID | FE_UNDERFLOW | FE_OVERFLOW)) {
       feclearexcept(FE_ALL_EXCEPT);
       debug_printf("%s(): Cannot fold the constant division since it would prevent a required exception.\n", __func__);
       return;
     }
     tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
     if (use_double) {
       node->numeric_value.dvalue = dvalue;
       g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
     } else {
       node->numeric_value.fvalue = fvalue;
       g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
     }
     node->leaftoken->tid = T_REAL;
     node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
     free(node->leaftoken->toketext);
     node->leaftoken->toketext = tbuf;
     dag_delete_all(&node->children[0]);
     dag_delete_all(&node->children[1]);
     free(node->children);
     node->children = NULL;
     node->numchildren = 0U;
     node->leftchild_height = node->rightchild_height = 0U;
     // INTENTIONALLY FALL THROUGH!!!!
  }
  return;
}

//
// DAG folding for the ^ operator
//
// Fold ?^0 to 1
//      1^? to 1
//      ?^1 to ?
// and  C^C to C' (normally done by fold_numeric_expression(), but new constants 0 and 1
//                 can be generated during DAG simplification....)
//
static void dag_fold_power(
    treenode *node,                  // Pointer to the root DAG node for this numeric expression
    unsigned int *changecount) {             // Counter for number of folding changes, incremented each time
                                             // this procedure changes the DAG

  promote_int2fp(node->children[0]);
  promote_int2fp(node->children[1]);
  if (optimization_level > 2U) {
    if ((T_REAL == node->children[0]->leaftoken->tid) &&
        (T_REAL == node->children[1]->leaftoken->tid)) {
      if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[1]->numeric_value.fvalue)) ) { // ?^0 -> 1
        debug_printf("fold_power ?^0 -> 1\n");
        dag_delete_all(&node->children[0]);
        dag_delete_all(&node->children[1]);
        free(node->children);
        node->children = NULL;
        node->numchildren = 0U;
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
        node->leaftoken->toketext = strdup("1");
        node->leaftoken->tid = T_REAL;
        node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
        if (use_double) {
          node->numeric_value.dvalue = 1.0;
        } else {
          node->numeric_value.fvalue = 1.0f;
        }
        (*changecount)++;
        return;
      }
      if ( (use_double && (1.0 == node->children[0]->numeric_value.dvalue)) ||
           (!use_double && (1.0f == node->children[0]->numeric_value.fvalue)) ) { // 1^? -> 1
        debug_printf("fold_power 1^? -> 1\n");
        dag_delete_all(&node->children[0]);
        dag_delete_all(&node->children[1]);
        free(node->children);
        node->children = NULL;
        node->numchildren = 0U;
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
        node->leaftoken->toketext = strdup("1");
        node->leaftoken->tid = T_REAL;
        node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
        if (use_double) {
          node->numeric_value.dvalue = 1.0;
        } else {
          node->numeric_value.fvalue = 1.0f;
        }
        (*changecount)++;
        return;
      }
      if ( (use_double && (1.0 == node->children[1]->numeric_value.dvalue)) ||
            (!use_double && (1.0f == node->children[1]->numeric_value.fvalue)) ) { // ?^1 -> ?
        treenode **leftchildren = NULL;

        debug_printf("Constant folder special case for ?^1\n");
        // delete RHS one
        dag_delete_all(&node->children[1]);
        // delete '^' leaftoken
        free(node->leaftoken->toketext);
        free(node->leaftoken);

        // copy in data from LHS
        // deep copy leaftoken
        node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
        node->leaftoken->toketext = strdup(node->children[0]->leaftoken->toketext);
        node->leaftoken->tid = node->children[0]->leaftoken->tid;
        node->leaftoken->lno = node->children[0]->leaftoken->lno;
        node->leaftoken->cno = node->children[0]->leaftoken->cno;
        node->leaftoken->pos = node->children[0]->leaftoken->pos;
        node->numeric_value = node->children[0]->numeric_value;
        node->oid = node->children[0]->oid;
        node->numeric_value = node->children[0]->numeric_value;
        node->leftchild_height = node->children[0]->leftchild_height;
        node->rightchild_height = node->children[0]->rightchild_height;
        node->numchildren = node->children[0]->numchildren;
        if (node->numchildren > 0) {
          leftchildren = node->children[0]->children;
          node->children[0]->numchildren = 0U;
          node->children[0]->children = NULL;
        }
        dag_delete_all(&node->children[0]);
        free(node->children);
        node->children = leftchildren;
        leftchildren = NULL;
        (*changecount)++;
        return;
      }
    }
    // INTENTIONALLY FALL THROUGH!!!
  }
  if ( (T_REAL == node->children[0]->leaftoken->tid) &&
       (T_REAL == node->children[1]->leaftoken->tid) ) {
     char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                                // which is a properly formatted floating point value
     float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
     double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

     debug_printf("%s():fold power\n", __func__);
     feclearexcept(FE_ALL_EXCEPT);
     if (use_double) {
       dvalue = pow(node->children[0]->numeric_value.dvalue, node->children[1]->numeric_value.dvalue);
     } else {
       fvalue = powf(node->children[0]->numeric_value.fvalue, node->children[1]->numeric_value.fvalue);
     }
     if (fetestexcept(FE_INVALID))
       ICE(__FILE__, __func__, __LINE__, emsg[16], node->leaftoken->lno);
     if (fetestexcept(FE_DIVBYZERO | FE_OVERFLOW | FE_UNDERFLOW)) {
       feclearexcept(FE_ALL_EXCEPT);
       debug_printf("%s(): Cannot fold power operator since the result gives a range error and must throw an exception.\n", __func__);
       return;
     }
     tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
     if (use_double) {
       node->numeric_value.dvalue = dvalue;
       g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
     } else {
       node->numeric_value.fvalue = fvalue;
       g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
     }
     node->leaftoken->tid = T_REAL;
     node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
     free(node->leaftoken->toketext);
     node->leaftoken->toketext = tbuf;
     dag_delete_all(&node->children[0]);
     dag_delete_all(&node->children[1]);
     free(node->children);
     node->children = NULL;
     node->numchildren = 0U;
     node->leftchild_height = node->rightchild_height = 0U;
     (*changecount)++;
     // INTENTIONALLY FALL THROUGH!!!!
  }
  return;
}

//
// Do folding on a DAG, for constants and some algebraic cases like ?-? and ?/?
//
// Only with -X and -O3 should this be used, since required exceptions may not occur
// after simplification, and values with NaN or +-Infinity may not work as they are
// required to by the ECMA-55 Minimal BASIC specification.  However, for `normal'
// real numbers things work fine.
//
treenode *improve_dag(
    treenode *node,                  // Pointer to the root DAG node for this numeric expression
    unsigned int *changecount) {             // Counter for number of folding changes, incremented each time
                                             // this procedure changes the DAG

  if (node->rightchild_height > node->leftchild_height) {
     node->children[1] = improve_dag(node->children[1], changecount);
     if (node->leftchild_height > 1U)
        node->children[0] = improve_dag(node->children[0], changecount);
  } else {
     if (node->leftchild_height > 1U)
        node->children[0] = improve_dag(node->children[0], changecount);
     if (node->rightchild_height > 1U)
        node->children[1] = improve_dag(node->children[1], changecount);
  }
  debug_printf("improve_dag for %p\n", (void *)node);
  switch(node->leaftoken->tid) {
    case T_POW:
      dag_fold_power(node, changecount);
      break;
    case T_ADD:
      dag_fold_add(node, changecount);
      break;
    case T_MUL:
      dag_fold_multiply(node, changecount);
      break;
    case T_DIV:
      dag_fold_divide(node, changecount);
      break;
    case T_SUBTRACT:
      switch (node->oid) {
        case OP_SUBTRACT:
          dag_fold_subtract(node, changecount);
          break;
        case OP_UMINUS:
          dag_fold_negation(node, changecount);
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, "%s", emsg[203]);
          break;
      }
      break;
    default:
      break;
  }
  return node;
}

//
// This procedure will initialize the dagger[] array and nextdagger so that
// they are ready to convert a new expression AST to a DAG.  The first row
// is not used so that index 0 can represent NULL (no children).
//
static void init_dagger(void) {
  /*
  for (unsigned int ndex = 0U; ndex < MAXDAGGER; ++ndex) {
    dagger[ndex].node = NULL,
    dagger[ndex].leftchild = 0U;
    dagger[ndex].leftchild_height = 0U;
    dagger[ndex].rightchild = 0U;
    dagger[ndex].rightchild_height = 0U;
    dagger[ndex].parent_count = 0U;
  }
  */
  memset(dagger, 0, sizeof(struct dagrec)*MAXDAGGER);
  // slot 0 is unused so 0 can represent that no child exists
  nextdagger = 1U;
  return;
}

//
// This function will search the dagger[] array looking for a record that
// matches the data specified in the needle parameter.  If a record that
// matches is found, then the index in the array where that record exists is
// copied into the location specified by the where parameter and true is
// returned.  If no matching record is found then where is not modified and
// false is returned.  A simple linear scan is used.
//
static bool exists_in_dagger(
    const struct dagrec *needle,      // pointer to a record containing the DAG triple
    unsigned int *where) {            // pointer to storage location for index
                                      // in dagger[] where needle was found (if it was)
  unsigned int ndex;                  // loop index variable

  debug_printf("exists_in_dagger for '%s' %u %u ",
        OP_UMINUS==needle->node->oid?"_":needle->node->leaftoken->toketext,
        needle->leftchild,
        needle->rightchild);
  // RND needs to be called every time it is encountered, since
  // RND+RND needs to call it twice, not once, so every RND is
  // unique and cannot be merged
  if (T_RND == needle->node->leaftoken->tid) {
    debug_printf("'%s' is not mergable!\n",
                 token_names[needle->node->leaftoken->tid]);
  } else {
    // slot 0 is unused so 0 can represent that no child exists
    // search for A op B
    for (ndex = 1U; ndex < nextdagger; ++ndex) {
      if ((dagger[ndex].leftchild == needle->leftchild) &&
          (dagger[ndex].rightchild == needle->rightchild) &&
          (dagger[ndex].node->leaftoken->tid == needle->node->leaftoken->tid) &&
          (strcmp(dagger[ndex].node->leaftoken->toketext, needle->node->leaftoken->toketext) == 0) &&
          (dagger[ndex].node->oid == needle->node->oid)) {
        *where = ndex;
        debug_printf("hit at record %u\n", ndex);
        return true;
      }
      // if '+' or '*', then try B op A since these operators are commutative
      if ((needle->node->leaftoken->tid == T_ADD) ||
          (needle->node->leaftoken->tid == T_MUL)) {
        if ((dagger[ndex].leftchild == needle->rightchild) &&
            (dagger[ndex].rightchild == needle->leftchild) &&
            (dagger[ndex].node->leaftoken->tid == needle->node->leaftoken->tid) &&
            (strcmp(dagger[ndex].node->leaftoken->toketext, needle->node->leaftoken->toketext) == 0) &&
            (dagger[ndex].node->oid == needle->node->oid)) {
          *where = ndex;
          debug_printf("hit at record %u\n", ndex);
          return true;
        }
      }
    }
  }
  debug_printf("miss\n");
  return false;
}

//
// This function will first check if the dagger[] array already has a record
// that matches the data specified in the needle parameter.  If a record that
// matches is found, then the index in the array where that record exists is
// returned to the caller.  If no such record is found, then it is added, and
// the resulting new index is returned to the caller.
//
#define max(a, b) ((a > b) ? a : b)
static unsigned int add_to_dagger(
    const struct dagrec *needle) {     // pointer to a record containing the DAG triple
  unsigned int ndex;                   // variable to hold the index in dagger[] where the
                                       // record for the needle exists

  if (exists_in_dagger(needle, &ndex))
    return ndex;
  if (!(nextdagger + 1 < MAXDAGGER))
    ICE(__FILE__, __func__, __LINE__, "%s", "dagger full\n");
  ndex = nextdagger++;
  dagger[ndex].node = needle->node;
  dagger[ndex].leftchild = needle->leftchild;
  if (needle->leftchild) {                     // if a left child exists
    dagger[needle->leftchild].parent_count++;  // increment its parent count
                                               // treeheight is 1 + maximum child tree height
    dagger[ndex].leftchild_height = 1U + max(dagger[needle->leftchild].leftchild_height,
                                         dagger[needle->leftchild].rightchild_height);
  } else {                                     // leaf node
                                               // parent count already 0 from initialization
    dagger[ndex].leftchild_height = 1U;        // treeheight of leaf is 1
  }
  dagger[ndex].rightchild = needle->rightchild;
  if (needle->rightchild) {                    // if a right child exists
    dagger[needle->rightchild].parent_count++; // increment its parent count
                                               // treeheight is 1 + maximum child tree height
    dagger[ndex].rightchild_height = 1U + max(dagger[needle->rightchild].leftchild_height,
                                          dagger[needle->rightchild].rightchild_height);
  } else {                                     // leaf node
                                               // parent count already 0 from initialization
    dagger[ndex].rightchild_height = 1U;       // treeheight of leaf is 1
  }
  return ndex;
}

//
// This function will take the subtree specified by the AST node parameter and
// create DAG data in the dagger[] array.  It returns the index in dagger that
// contains the node which is the root of the DAG that corresponds to the AST
// specified by the function's node parameter.  This is essentially a postorder
// traversal, with the DAG records created after all child trees (if any) have
// been processed.  Normally one would pass in the root of the expression AST,
// and then later create the DAG using the resulting data in dagger, using the
// record number which is the return value from this function as to access the
// node which will be the root of the resulting DAG.  This function requires a
// valid AST and performs NO error checking.
//
unsigned int generate_dagger(
    treenode const * const node) {   // Pointer to the root AST node for this numeric expression
  struct dagrec temp_dagrec;                 // temporary DAG record created to pass data to the
                                             // add_to_dagger() function

  temp_dagrec.node = (treenode *)node;
  switch (node->leaftoken->tid) {
    case T_FNID:
      if (1U == node->numchildren)
        temp_dagrec.leftchild = generate_dagger(node->children[0]);
      else
        temp_dagrec.leftchild = 0U;
      temp_dagrec.rightchild = 0U;
      break;
    // built-in functions with two arguments
    case T_ANGLE:      // -X
    case T_MAX:        // -X
    case T_MIN:        // -X
    case T_MOD:        // -X
    case T_REMAINDER:  // -X
    case T_ROUND:      // -X
    case T_TRUNCATE:   // -X
      if (!extensions) // These are not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      temp_dagrec.leftchild = generate_dagger(node->children[0]);
      temp_dagrec.rightchild = generate_dagger(node->children[1]);
      break;
    // built-in functions with one argument
    case T_ACOS:       // -X
    case T_ASIN:       // -X
    case T_CEIL:       // -X
    case T_COSH:       // -X
    case T_COT:        // -X
    case T_CSC:        // -X
    case T_DEG:        // -X
    case T_FP:         // -X
    case T_IP:         // -X
    case T_LEN:        // -X
    case T_LOG10:      // -X
    case T_LOG2:       // -X
    case T_RAD:        // -X
    case T_SEC:        // -X
    case T_SINH:       // -X
    case T_TANH:       // -X
      if (!extensions) // These are not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      // FALLS THROUGH
    case T_ABS:
    case T_ATN:
    case T_COS:
    case T_EXP:
    case T_INT:
    case T_LOG:
    case T_SGN:
    case T_SIN:
    case T_SQR:
    case T_TAB:
    case T_TAN:
      temp_dagrec.leftchild = generate_dagger(node->children[0]);
      temp_dagrec.rightchild = 0U;
      break;
    // built-in functions with no argument
    case T_MAXNUM:     // -X
    case T_PI:         // -X
      if (!extensions) // These are not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      // FALLS THROUGH
    case T_RND:
    // other leaf nodes for literal values
    case T_QSTRING:
    case T_SVAR:
    case T_INTEGER:
    case T_REAL:
    case T_NVAR:
      temp_dagrec.leftchild = 0U;
      temp_dagrec.rightchild = 0U;
      break;
    // arrays
    case T_NAVAR:
      temp_dagrec.leftchild = generate_dagger(node->children[0]);
      if (2U == node->ad->dims) // matrix
        temp_dagrec.rightchild = generate_dagger(node->children[1]);
      else                      // vector
        temp_dagrec.rightchild = 0U;
      break;
    // binary and unary arithmetic operators
    case T_SUBTRACT:
      temp_dagrec.leftchild = generate_dagger(node->children[0]);
      if (OP_SUBTRACT == node->oid)
        temp_dagrec.rightchild = generate_dagger(node->children[1]);
      else if (OP_UMINUS == node->oid)
        temp_dagrec.rightchild = 0U;
      else {
        fprintf(stderr, "node->oid = %s, node->leaftoken->toketext=%s\n", opid_names[node->oid], node->leaftoken->toketext);
        ICE(__FILE__, __func__, __LINE__, "%s", emsg[203]);
      }
      break;
    case T_ADD:
    case T_MUL:
    case T_DIV:
    case T_POW:
      temp_dagrec.leftchild = generate_dagger(node->children[0]);
      temp_dagrec.rightchild = generate_dagger(node->children[1]);
      break;
    default:
      debug_printf("%s():nothing to do for %s\n", __func__, token_names[node->leaftoken->tid]);
      temp_dagrec.leftchild = 0U;
      temp_dagrec.rightchild = 0U;
      break;
  }
  return add_to_dagger(&temp_dagrec);
}

//
// Create a DAG from dagger[] data, cloning tokens as necessary.  To create a
// DAG from a tree, first do generate_dagger().  That procedure will populate
// dagger[] which is the input for this subroutine.  The last actually used row
// in dagger[] will be in slot (ndextdagger-1) and it is also the return value
// from generate_dagger().  To create a new dag from dagger[], call this
// recursive procedure with nextdagger-1 as an argument, and the returned value
// will be a pointer to the root of the new DAG.  The tokens are cloned, so it
// is safe to delete the original tree node and change the parent to point to
// this DAG instead.  This builds the tree bottom-up.
//
static treenode *build_dag(
    const unsigned int last) {         // index of root node in dagger[]
                                       // which will be the last used slot in
                                       // the array
  treenode *node;              // pointer to node we are building
  struct token *curtoken;              // pointer to token we build for the node
  unsigned int childcount;             // number of child nodes for this node
  unsigned int ndex;                   // loop index

  for (ndex = 1U; ndex <= last; ndex++) {
    // determine number of children
    childcount = 0U;
    if (dagger[ndex].leftchild)
      childcount++;
    if (dagger[ndex].rightchild)
      childcount++;
    // create clone token
    curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
    curtoken->toketext = strdup(dagger[ndex].node->leaftoken->toketext);
    curtoken->tid = dagger[ndex].node->leaftoken->tid;
    curtoken->lno = dagger[ndex].node->leaftoken->lno;
    curtoken->cno = dagger[ndex].node->leaftoken->cno; // will not be accurate if there are multiple parents
    curtoken->pos = dagger[ndex].node->leaftoken->pos; // will not be accurate if there are multiple parents
    // create new node
    node = create_tree_node2(childcount, curtoken);
    // copy as much data from original node to new node as we can
    node->ad = dagger[ndex].node->ad;
    node->oid = dagger[ndex].node->oid;
    if (dagger[ndex].node->d_regname)
       node->d_regname = strdup(dagger[ndex].node->d_regname);
    if (dagger[ndex].node->labelname)
       node->labelname = strdup(dagger[ndex].node->labelname);
    node->numeric_value.dvalue = dagger[ndex].node->numeric_value.dvalue;
    // connect left child node if necessary
    if (dagger[ndex].leftchild)
      node->children[0] = dagger[dagger[ndex].leftchild].node;
    // connect right child node if necessary
    if (dagger[ndex].rightchild)
      node->children[1] = dagger[dagger[ndex].rightchild].node;
    // save left/right child DAG heights and parent count
    node->parent_count = node->parent_count2 = dagger[ndex].parent_count;
    node->leftchild_height = dagger[ndex].leftchild_height;
    node->rightchild_height = dagger[ndex].rightchild_height;
    dagger[ndex].node = node;
  }
  return dagger[last].node;
}

//
// This function converts an AST for a numeric expression specified
// by the root parameter and returns a pointer to the root of a new
// DAG for the numeric expression.
//
treenode *dag_numeric_expression(
    treenode const * const root) {   // pointer to root node of AST
  unsigned int dagger_root;             // index in dagger[] of root node

  init_dagger();
  dagger_root = generate_dagger(root);
  return build_dag(dagger_root);
}

//
// This procedure will dump the contents of the dagger[] array for diagnostic purposes.
//
void dump_dagger(void) {
  unsigned int ndex;                   // loop index variable

  puts("Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------");
  // slot 0 is unused so 0 can represent that no child exists
  for (ndex = 1U; ndex < nextdagger; ++ndex) {
    printf("%3u:  %10s('%10s'), %3u,   %3u,   %3u,   %3u,   %3u\n",
      ndex,
      token_names[dagger[ndex].node->leaftoken->tid],
      dagger[ndex].node->leaftoken->toketext,
      dagger[ndex].leftchild,
      dagger[ndex].leftchild_height,
      dagger[ndex].rightchild,
      dagger[ndex].rightchild_height,
      dagger[ndex].parent_count);
  }
  puts("End dagger dump");
  return;
}

//
// This is used to delete the dag pointed to by the *node parameter.
// It uses the parent_count2 field as a counter for the number
// of remaining parents.  A delete will decrement that counter.
// Only when it reaches zero can the delete actually take place.
//
void dag_delete_all(
    treenode **node) {  // address of pointer to the root AST node for this numeric expression
  // if it's already deleted, just return
  if (!(*node))
     return;
  // decrease delete parent count
  if ((*node)->parent_count2)
    (*node)->parent_count2--;
  // if delete parent count has reached zero, then actually do the delete
  if (0U == (*node)->parent_count2) {
    // if there are any children, delete them first
    if ((*node)->numchildren) {
      for (size_t i=0;i<(*node)->numchildren;++i)
         dag_delete_all(&((*node)->children[i]));
      free((*node)->children);
      (*node)->children = NULL;
      (*node)->numchildren = 0U;
    }
    // delete the token data if it exists
    if ((*node)->leaftoken) {
      free((*node)->leaftoken->toketext);
      (*node)->leaftoken->toketext = NULL;
      free((*node)->leaftoken);
      (*node)->leaftoken = NULL;
    } else {
      fputs("Warning: empty leaftoken encountered\n", stderr);
    }
    // deallocate the other data fields
    if ((*node)->d_regname) {
      free((*node)->d_regname);
      (*node)->d_regname = NULL;
    }
    if ((*node)->labelname) {
      free((*node)->labelname);
      (*node)->labelname = NULL;
    }
    (*node)->ad = NULL;
    // and finally delete the node itself
    free(*node);
    *node = NULL;
  }
  return;
}

#ifdef UNIT_TEST
#include <errno.h>
#include <getopt.h>

static void dump_tree_node_string2(const treenode *node);
static void dump_tree_node_ptr(const treenode *node);
static int test1(void);
static int test2(void);
static int test3(void);
static int test4(void);
static int test5(void);
static int test6(void);
static int test7(void);
static int test8(void);
static int test9(void);
static int test10(void);
static int test11(void);
static int test12(void);
static int test13(void);

static void dump_tree_node_string2(        // Display token text of a node
    const treenode *node) {                // Pointer to the node to dump
  char *thecopy=NULL;
  if ((T_SUBTRACT == node->leaftoken->tid) && (OP_UMINUS == node->oid)) {
    fputs("_ ", stdout);
    return;
  }
  thecopy=trim(strdup(node->leaftoken->toketext));
  printf("%s ", thecopy);
  free(thecopy);thecopy=NULL;
  return;
}

static void dump_tree_node_ptr(            // Display the hex pointer value of a node
    const treenode *node) {        // Pointer to the node to dump
  fprintf(stderr, "%p", (void *)node);
  if (node->leaftoken && node->leaftoken->toketext)
    fprintf(stderr, "(%s)", node->leaftoken->toketext);
  fputc('\n', stderr);
  return;
}

//
// Test dag will form even with subtrees using commutative property
//
static int test1(void) {
  treenode *root = NULL,
                   *dagroot = NULL;
  struct token *curtoken = NULL;
  unsigned int theroot;

  puts("Original expression: (A+B)+(A+B)\n"
       "TREE:\n"
       "        +\n"
       "     /     \\\n"
       "   +         +\n"
       " /   \\     /   \\\n"
       "A     B   A     B\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  curtoken->pos = 3U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  curtoken->pos = 9U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  root->children[1]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  printf("Postorder tree traversal should print   : A B + A B + +\n"
         "Postorder tree traversal actually prints: ");
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  puts("DAG:\n"
       "        +\n"
       "     /     \\\n"
       "   +  <-----\n"
       " /   \\\n"
       "A     B\n");
  fflush(stdout);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         A'),   0,     1,     0,     1,     1\n"
       "  2:      T_NVAR('         B'),   0,     1,     0,     1,     1\n"
       "  3:       T_ADD('         +'),   1,     2,     2,     2,     2\n"
       "  4:       T_ADD('         +'),   3,     3,     3,     3,     0\n"
       "End dagger dump\n\nYou actually got this:");
  fflush(stdout);
  init_dagger();
  theroot = generate_dagger(root);
  dump_dagger();

  dagroot = build_dag(theroot);
  fputs("Postorder DAG traversal should print   : A B + A B + +\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// Test ?/? where ? has indegree higher than 2 on the dag
//
static int test2(void) {
  treenode *root = NULL,
                   *dagroot = NULL;
  struct token *curtoken = NULL;

  puts("\n\nOriginal expression: A+(A+B)+(A+B)/(A+B)+B\n"
       "TREE:\n"
       "                +\n"
       "            /       \\\n"
       "          +            B\n"
       "       /      \\\n"
       "     +          / \n"
       "  /    \\     /     \\\n"
       "A       +   +        +\n"
       "     /  |   | \\    /   \\\n"
       "    A   B   A  B  A     B\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 20U;
  curtoken->pos = 20U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root->children[0]->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[0]->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[0]->children[0]->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root->children[0]->children[0]->children[1]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("/");
  curtoken->tid = T_DIV;
  curtoken->lno = 1U;
  curtoken->cno = 14U;
  curtoken->pos = 14U;
  root->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 11U;
  curtoken->pos = 11U;
  root->children[0]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  root->children[0]->children[1]->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 12U;
  curtoken->pos = 12U;
  root->children[0]->children[1]->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 17U;
  curtoken->pos = 17U;
  root->children[0]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 16U;
  curtoken->pos = 16U;
  root->children[0]->children[1]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 18U;
  curtoken->pos = 18U;
  root->children[0]->children[1]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 21U;
  curtoken->pos = 21U;
  root->children[1] = create_tree_node2(2U, curtoken);

  printf("Height of tree should print   :5\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A A B + + A B + A B + / + B +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  puts("DAG:\n"
       "              +\n"
       "          /       \\\n"
       "       +           |\n"
       "    /     \\        |\n"
       "   +    ___ /      |\n"
       "/    \\ /       \\   |\n"
       "|     +________/   |\n"
       " \\ /  |            |\n"
       "  A   B____________|\n");
  fflush(stdout);
  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         A'),   0,     1,     0,     1,     2\n"
       "  2:      T_NVAR('         B'),   0,     1,     0,     1,     2\n"
       "  3:       T_ADD('         +'),   1,     2,     2,     2,     3\n"
       "  4:       T_ADD('         +'),   1,     2,     3,     3,     1\n"
       "  5:       T_DIV('         /'),   3,     3,     3,     3,     1\n"
       "  6:       T_ADD('         +'),   4,     4,     5,     4,     1\n"
       "  7:       T_ADD('         +'),   6,     5,     2,     2,     0\n"
       "End dagger dump\n\nYou actually got this:");
  fflush(stdout);
  dump_dagger();
  fputs("Postorder DAG traversal should print   : A A B + + A B + A B + / + B +\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// special case of unmergable RND calls
//
static int test3(void) {
  treenode *root = NULL,
                   *dagroot = NULL;
  struct token *curtoken = NULL;

  puts("\nOriginal expression: RND+RND\n"
       "TREE:\n"
       "              +\n"
       "          /       \\\n"
       "        RND        RND\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("RND");
  curtoken->tid = T_RND;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("RND");
  curtoken->tid = T_RND;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :2\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : RND RND +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  puts("DAG:\n"
       "              +\n"
       "          /       \\\n"
       "        RND        RND\n");
  fflush(stdout);
  init_debug_printf(stderr); // initialize the debug output system
  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:       T_RND('       RND'),   0,     1,     0,     1,     1\n"
       "  2:       T_RND('       RND'),   0,     1,     0,     1,     1\n"
       "  3:       T_ADD('         +'),   1,     2,     2,     2,     0\n"
       "End dagger dump\n\nYou actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : RND RND +\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

static int test4(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int changecount;

  //
  // special case of ?-? causing tree to drop down to just 0
  //
  puts("\nOriginal expression: (B-B)-(A/A)\n"
       "TREE:\n"
       "                -\n"
       "           /         \\\n"
       "         -             /\n"
       "       /   \\         /   \\\n"
       "      B     B       A     A");
  fflush(stdout);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  curtoken->pos = 3U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("/");
  curtoken->tid = T_DIV;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  curtoken->pos = 9U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  root->children[1]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A A - B B / -\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  puts("DAG:\n"
       "                -\n"
       "           /         \\\n"
       "         -             /\n"
       "       /   \\         /   \\\n"
       "       \\   /         \\   /\n"
       "         B             A");
  fflush(stdout);
  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         B'),   0,     1,     0,     1,     2\n"
       "  2:  T_SUBTRACT('         -'),   1,     2,     1,     2,     1\n"
       "  3:      T_NVAR('         A'),   0,     1,     0,     1,     2\n"
       "  4:       T_DIV('         /'),   3,     2,     3,     2,     1\n"
       "  5:  T_SUBTRACT('         -'),   2,     3,     4,     3,     0\n"
       "End dagger dump\n\nYou actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : B B - A A / -\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  puts("\nNow we try to simplify the DAG\n");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder DAG traversal should print   : -1\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// special case of ?-? causing tree to drop down to just 0
//
static int test5(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int changecount;

  puts("\nOriginal expression: (C-C)-(C-C)\n"
       "TREE:\n"
       "                -\n"
       "           /         \\\n"
       "         -             -\n"
       "       /   \\         /   \\\n"
       "      C     C       C     C");
  fflush(stdout);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  curtoken->pos = 3U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  curtoken->pos = 9U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  root->children[1]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : C C - C C - -\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  puts("DAG:\n"
       "         -\n"
       "       /   \\\n"
       "       \\   /\n"
       "         -\n"
       "       /   \\\n"
       "       \\   /\n"
       "         C");
  fflush(stdout);
  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         C'),   0,     1,     0,     1,     2\n"
       "  2:  T_SUBTRACT('         -'),   1,     2,     1,     2,     2\n"
       "  3:  T_SUBTRACT('         -'),   2,     3,     2,     3,     0\n"
       "End dagger dump\n\nYou actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : C C - C C - -\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  puts("\nNow we try to simplify the DAG\n");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    fflush(stdout);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    fflush(stdout);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder DAG traversal should print   : 0\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// special case of ?-? causing tree to drop down to just 0
//
static int test6(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int changecount;

  puts("\nOriginal expression: C*(C-C)-(C-C)\n"
       "TREE:\n"
       "                -\n"
       "           /         \\\n"
       "         *             -\n"
       "       /   \\         /   \\\n"
       "      C     -       C     C\n"
       "           /  \\\n"
       "          C    C");
  fflush(stdout);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("*");
  curtoken->tid = T_MUL;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 11U;
  curtoken->pos = 11U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  root->children[0]->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 12U;
  curtoken->pos = 12U;
  root->children[0]->children[1]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root->children[1]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :4\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : C C C - * C C - -\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  puts("DAG:\n"
       "                -\n"
       "           /         \\\n"
       "         *            |\n"
       "       /   \\         |\n"
       "      |     -  <------\n"
       "      |    /  \\\n"
       "      \\  /    |\n"
       "       C  <---");
  fflush(stdout);
  optimization_level = 3U;
  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         C'),   0,     1,     0,     1,     3\n"
       "  2:  T_SUBTRACT('         -'),   1,     2,     1,     2,     2\n"
       "  3:       T_MUL('         *'),   1,     2,     2,     3,     1\n"
       "  4:  T_SUBTRACT('         -'),   3,     4,     2,     3,     0\n"
       "End dagger dump\n\nYou actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : C C C - * C C - -\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  if (verbose) {
    tree_postorder(dagroot, dump_tree_node_ptr);
    fputc('\n', stdout);
    fflush(stdout);
  }

  puts("Now we try to simplify the DAG\n");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    fflush(stdout);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    fflush(stdout);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder optimized DAG traversal should print   :  0\n"
        "Postorder optimized DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// ugly torture test
//
static int test7(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int changecount;

  puts("\nOriginal expression: C*(C-C+2-(1+1))-(C-C+2-(1+1))\n"
       "TREE:\n"
       "                       -\n"
       "             ________/   \\_________\n"
       "           /                        \\\n"
       "         *                           -\n"
       "       /   \\                       /   \\\n"
       "      C     -                     +     +\n"
       "          /   \\                  / \\   / \\\n"
       "         +     +                -   2  1  1\n"
       "        / \\   /  \\             / \\\n"
       "       -   2  1   1           C   C\n"
       "      / \\\n"
       "     C   C");
  fflush(stdout);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 16U;
  curtoken->pos = 16U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("*");
  curtoken->tid = T_MUL;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  curtoken->pos = 9U;
  root->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 21U;
  curtoken->pos = 21U;
  root->children[0]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 26U;
  curtoken->pos = 26U;
  root->children[0]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[0]->children[1]->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("2");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[0]->children[1]->children[0]->children[1] = create_tree_node2(0U, curtoken);
  root->children[0]->children[1]->children[0]->children[1]->numeric_value.dvalue=2.0;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 11U;
  curtoken->pos = 11U;
  root->children[0]->children[1]->children[1]->children[0] = create_tree_node2(0U, curtoken);
  root->children[0]->children[1]->children[1]->children[0]->numeric_value.dvalue=1.0;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 13U;
  curtoken->pos = 13U;
  root->children[0]->children[1]->children[1]->children[1] = create_tree_node2(0U, curtoken);
  root->children[0]->children[1]->children[1]->children[1]->numeric_value.dvalue=1.0;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0]->children[1]->children[0]->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[0]->children[1]->children[0]->children[0]->children[1] = create_tree_node2(0U, curtoken);

// top-level RHS starts here

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 23U;
  curtoken->pos = 23U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 21U;
  curtoken->pos = 21U;
  root->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 26U;
  curtoken->pos = 26U;
  root->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 19U;
  curtoken->pos = 19U;
  root->children[1]->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("2");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 22U;
  curtoken->pos = 22U;
  root->children[1]->children[0]->children[1] = create_tree_node2(0U, curtoken);
  root->children[1]->children[0]->children[1]->numeric_value.dvalue=2.0;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 1U;
  curtoken->cno = 25U;
  curtoken->pos = 25U;
  root->children[1]->children[1]->children[0] = create_tree_node2(0U, curtoken);
  root->children[1]->children[1]->children[0]->numeric_value.uivalue=1U;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 1U;
  curtoken->cno = 27U;
  curtoken->pos = 27U;
  root->children[1]->children[1]->children[1] = create_tree_node2(0U, curtoken);
  root->children[1]->children[1]->children[1]->numeric_value.uivalue=1U;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 18U;
  curtoken->pos = 18U;
  root->children[1]->children[0]->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 20U;
  curtoken->pos = 20U;
  root->children[1]->children[0]->children[0]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :6\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : C C C - 2 + 1 1 + - * C C - 2 + 1 1 + - -\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  puts("DAG:\n"
       "             -\n"
       "           /   \\\n"
       "          /     |\n"
       "         *     /\n"
       "       /   \\  /\n"
       "      /      -\n"
       "     /     /   \\\n"
       "    /     +     +\n"
       "   |     / \\   / \\\n"
       "   |    -   2  \\ /\n"
       "   |    |\\      1\n"
       "    \\   | \\\n"
       "     \\  |  |\n"
       "      \\ | /\n"
       "       \\|/\n"
       "        C");
  fflush(stdout);

  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         C'),   0,     1,     0,     1,     3\n"
       "  2:  T_SUBTRACT('         -'),   1,     2,     1,     2,     1\n"
       "  3:      T_REAL('         2'),   0,     1,     0,     1,     1\n"
       "  4:       T_ADD('         +'),   2,     3,     3,     2,     1\n"
       "  5:      T_REAL('         1'),   0,     1,     0,     1,     2\n"
       "  6:       T_ADD('         +'),   5,     2,     5,     2,     1\n"
       "  7:  T_SUBTRACT('         -'),   4,     4,     6,     3,     2\n"
       "  8:       T_MUL('         *'),   1,     2,     7,     5,     1\n"
       "  9:  T_SUBTRACT('         -'),   8,     6,     7,     5,     0\n"
       "End dagger dump\n\nYou actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : C C C - 2 + 1 1 + - * C C - 2 + 1 1 + - -\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  if (verbose) {
    tree_postorder(dagroot, dump_tree_node_ptr);
    fputc('\n', stdout);
    fflush(stdout);
  }

  puts("Now we try to simplify the DAG\n");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    fflush(stdout);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    fflush(stdout);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder optimized DAG traversal should print   :  0\n"
        "Postorder optimized DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// ugly torture test 2
//
static int test8(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int changecount;

  puts("\nOriginal expression: (C+C)*2+(A-(-B)*2+1)*(C+C)\n"
       "TREE:\n"
       "                       +\n"
       "             ________/   \\___________\n"
       "           /                          \\\n"
       "          *                            *\n"
       "        /   \\                       /    \\\n"
       "       +     2                    +      +\n"
       "     /   \\                       /  \\    / \\\n"
       "    C     C                    -    1  C   C\n"
       "                              /   \\\n"
       "                             A     *\n"
       "                                 /   \\\n"
       "                                -     2\n"
       "                               /\n"
       "                              B");
  fflush(stdout);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("*");
  curtoken->tid = T_MUL;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("*");
  curtoken->tid = T_MUL;
  curtoken->lno = 1U;
  curtoken->cno = 21U;
  curtoken->pos = 21U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  curtoken->pos = 3U;
  root->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("2");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  curtoken->pos = 7U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);
  root->children[0]->children[1]->numeric_value.uivalue=2U;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 18U;
  curtoken->pos = 18U;
  root->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 24U;
  curtoken->pos = 24U;
  root->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0]->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[0]->children[0]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 11U;
  curtoken->pos = 11U;
  root->children[1]->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 1U;
  curtoken->cno = 19U;
  curtoken->pos = 19U;
  root->children[1]->children[0]->children[1] = create_tree_node2(0U, curtoken);
  root->children[1]->children[0]->children[1]->numeric_value.uivalue=1U;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 23U;
  curtoken->pos = 23U;
  root->children[1]->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 25U;
  curtoken->pos = 25U;
  root->children[1]->children[1]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  root->children[1]->children[0]->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("*");
  curtoken->tid = T_MUL;
  curtoken->lno = 1U;
  curtoken->cno = 16U;
  curtoken->pos = 16U;
  root->children[1]->children[0]->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 13U;
  curtoken->pos = 13U;
  root->children[1]->children[0]->children[0]->children[1]->children[0] = create_tree_node2(1U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("2");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 1U;
  curtoken->cno = 17U;
  curtoken->pos = 17U;
  root->children[1]->children[0]->children[0]->children[1]->children[1] = create_tree_node2(0U, curtoken);
  root->children[1]->children[0]->children[0]->children[1]->children[1]->numeric_value.uivalue=2U;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 14U;
  curtoken->pos = 14U;
  root->children[1]->children[0]->children[0]->children[1]->children[0]->children[0] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :7\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : C C + 2 * A B - 2 * - 1 + C C + * +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  puts("DAG:\n"
       "                       +\n"
       "             ________/   \\___________\n"
       "           /                          \\\n"
       "          *                            *\n"
       "        /   \\                       /    \\\n"
       "       |     |                    +       |\n"
       "       |     |                  /  \\      |\n"
       "       |     |                 -    1     |\n"
       "       |     |                /   \\       |\n"
       "       |     |               A     *      |\n"
       "       |     |                   /   \\    |\n"
       "       |     |                  -     |   |\n"
       "       |     |                 /      |   |\n"
       "       |     |                B       |   |\n"
       "       |     |                       /    |\n"
       "       |     2 <---------------------    /\n"
       "       |                                /\n"
       "       + <------------------------------\n"
       "     /   \\\n"
       "    C     C");
  fflush(stdout);

  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         C'),   0,     1,     0,     1,     2\n"
       "  2:       T_ADD('         +'),   1,     2,     1,     2,     2\n"
       "  3:   T_INTEGER('         2'),   0,     1,     0,     1,     2\n"
       "  4:       T_MUL('         *'),   2,     3,     3,     2,     1\n"
       "  5:      T_NVAR('         A'),   0,     1,     0,     1,     1\n"
       "  6:      T_NVAR('         B'),   0,     1,     0,     1,     1\n"
       "  7:  T_SUBTRACT('         -'),   6,     2,     0,     1,     1\n"
       "  8:       T_MUL('         *'),   7,     3,     3,     2,     1\n"
       "  9:  T_SUBTRACT('         -'),   5,     2,     8,     4,     1\n"
       " 10:   T_INTEGER('         1'),   0,     1,     0,     1,     1\n"
       " 11:       T_ADD('         +'),   9,     5,    10,     2,     1\n"
       " 12:       T_MUL('         *'),  11,     6,     2,     3,     1\n"
       " 13:       T_ADD('         +'),   4,     4,    12,     7,     0\n"
       "End dagger dump\n\nYou actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : C C + 2 * A B - 2 * - 1 + C C + * +\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  if (verbose) {
    tree_postorder(dagroot, dump_tree_node_ptr);
    fputc('\n', stdout);
    fflush(stdout);
  }

  puts("Attempting DAG simplification....");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    fflush(stdout);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    fflush(stdout);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder optimized DAG traversal should print   : C C + 2 * A B - 2 * - 1 + C C + * +\n"
        "Postorder optimized DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// ugly torture test 3
//
static int test9(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int changecount;

  puts("\nOriginal expression: 0-0+(1+C)\n"
       "TREE:\n"
       "             +\n"
       "           /   \\\n"
       "          -     +\n"
       "        /  \\   /  \\\n"
       "       0    0 1    C");
  fflush(stdout);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  curtoken->pos = 7U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("0");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);
  root->children[0]->children[0]->numeric_value.uivalue=0U;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("0");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  curtoken->pos = 3U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);
  root->children[0]->children[1]->numeric_value.uivalue=0U;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root->children[1]->children[0] = create_tree_node2(0U, curtoken);
  root->children[1]->children[0]->numeric_value.uivalue=1U;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[1]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : 0 0 - 1 C + +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  puts("DAG:\n"
       "             +\n"
       "           /   \\\n"
       "          -     +\n"
       "        /  \\   /  \\\n"
       "       0    0 1    C");
  fflush(stdout);

  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:   T_INTEGER('         0'),   0,     1,     0,     1,     2\n"
       "  2:  T_SUBTRACT('         -'),   1,     2,     1,     2,     1\n"
       "  3:   T_INTEGER('         1'),   0,     1,     0,     1,     1\n"
       "  4:      T_NVAR('         C'),   0,     1,     0,     1,     1\n"
       "  5:  T_SUBTRACT('         +'),   3,     2,     4,     2,     1\n"
       "  6:       T_ADD('         +'),   2,     3,     5,     3,     0\n"
       "End dagger dump\n\nYou actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : 0 0 - 1 C + +\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  if (verbose) {
    tree_postorder(dagroot, dump_tree_node_ptr);
    fputc('\n', stdout);
    fflush(stdout);
  }

  puts("Attempting DAG simplification....");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    fflush(stdout);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    fflush(stdout);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder optimized DAG traversal should print   : 1 C +\n"
        "Postorder optimized DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// commutativity test
//
static int test10(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int changecount;

  puts("\nOriginal expression: (A+B)-(B+A)\n"
       "TREE:\n"
       "             -\n"
       "           /   \\\n"
       "          +     +\n"
       "        /  \\   /  \\\n"
       "       A    B B    A");
  fflush(stdout);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("-");
  curtoken->tid = T_SUBTRACT;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  curtoken->pos = 3U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  curtoken->pos = 9U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  root->children[1]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A B + B A + -\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  puts("DAG:\n"
       "             -\n"
       "           /   \\\n"
       "          + <---\n"
       "        /  \\\n"
       "       A    B");
  fflush(stdout);

  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         A'),   0,     1,     0,     1,     1\n"
       "  2:      T_NVAR('         B'),   0,     1,     0,     1,     1\n"
       "  3:       T_ADD('         +'),   1,     2,     2,     2,     2\n"
       "  4:  T_SUBTRACT('         -'),   3,     3,     3,     3,     0\n"
       "End dagger dump\n\nYou actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : A B + A B + -\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  if (verbose) {
    tree_postorder(dagroot, dump_tree_node_ptr);
    fputc('\n', stdout);
    fflush(stdout);
  }

  puts("Attempting DAG simplification....");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    fflush(stdout);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    fflush(stdout);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder optimized DAG traversal should print   : 0\n"
        "Postorder optimized DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

static int test11(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int changecount;

  //
  // torture test
  //
  puts("\nOriginal expression: (A+(A+B))+((A+B)/(A+B))+B\n"
       "TREE:\n"
       "                   '+'\n"
       "                  /   \\\n"
       "               '+'     B \n"
       "              /  \\\n"
       "            /      ----\\\n"
       "         '+'           '/'\n"
       "        /  \\          /   \\\n"
       "       A   '+'     '+'    '+'\n"
       "          /   \\    /  \\   /  \\\n"
       "         A    B   A   B  A    B");
  fflush(stdout);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 24U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  root->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("/");
  curtoken->tid = T_DIV;
  curtoken->lno = 1U;
  curtoken->cno = 17U;
  root->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  root->children[0]->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  root->children[0]->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  root->children[0]->children[0]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  root->children[0]->children[0]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 14U;
  root->children[0]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 20U;
  root->children[0]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 13U;
  root->children[0]->children[1]->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 15U;
  root->children[0]->children[1]->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 19U;
  root->children[0]->children[1]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 21U;
  root->children[0]->children[1]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  printf("Height of tree should print   :5\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A A B + + A B + A B + / + B +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  puts("DAG:\n"
       "                   '+'\n"
       "                  /   \\\n"
       "               '+'      \\\n"
       "              /  \\        \\\n"
       "            /      ----\\    \\\n"
       "         '+'           '/'    \\\n"
       "        /  \\   ______ /   \\   |\n"
       "      /     \\ /            \\  |\n"
       "     |      '+'------------/  /\n"
       "      \\   /    \\ ___________/\n"
       "        A       B");
  fflush(stdout);

  dagroot = dag_numeric_expression(root);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_NVAR('         A'),   0,     1,     0,     1,     2\n"
       "  2:      T_NVAR('         B'),   0,     1,     0,     1,     2\n"
       "  3:       T_ADD('         +'),   1,     2,     2,     2,     3\n"
       "  4:       T_ADD('         +'),   1,     2,     3,     3,     1\n"
       "  5:       T_DIV('         /'),   3,     3,     3,     3,     1\n"
       "  6:       T_ADD('         +'),   4,     4,     5,     4,     1\n"
       "  7:       T_ADD('         +'),   6,     5,     2,     2,     0\n"
       "End dagger dump\n"
       "\n"
       "You actually got this:");
  dump_dagger();
  fputs("Postorder DAG traversal should print   : A A B + + A B + A B + / + B +\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  if (verbose) {
    tree_postorder(dagroot, dump_tree_node_ptr);
    fputc('\n', stdout);
    fflush(stdout);
  }

  puts("Attempting DAG simplification....");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    fflush(stdout);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    fflush(stdout);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder optimized DAG traversal should print   : A A B + + 1 + B +\n"
        "Postorder optimized DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

//
// Test dag with LEN
//
static int test12(void) {
  treenode *root = NULL,
                   *dagroot = NULL;
  struct token *curtoken = NULL;
  unsigned int theroot;

  puts("Original expression: LEN(S$)\n"
       "TREE:\n"
       "       LEN\n"
       "     /\n"
       "   S$\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("LEN");
  curtoken->tid = T_LEN;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root = create_tree_node2(1U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("S$");
  curtoken->tid = T_SVAR;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[0] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :2\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : S$ LEN\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  puts("DAG:\n"
       "       LEN\n"
       "     /\n"
       "   S$\n");
  fflush(stdout);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_SVAR('        S$'),   0,     1,     0,     1,     1\n"
       "  2:       T_LEN('       LEN'),   1,     2,     0,     1,     0\n"
       "End dagger dump\n\nYou actually got this:");
  fflush(stdout);
  init_dagger();
  theroot = generate_dagger(root);
  dump_dagger();

  dagroot = build_dag(theroot);
  fputs("Postorder DAG traversal should print   : S$ LEN\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  fflush(stdout);
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

static int test13(void) {
  treenode *root = NULL,
                   *dagroot = NULL,
                   *dagroot2 = NULL;
  struct token *curtoken = NULL;
  unsigned int theroot;
  unsigned int changecount;

  puts("Original expression: (1+2)+(3+B)\n"
       "        +\n"
       "     /     \\\n"
       "   +         +\n"
       " /   \\     /   \\\n"
       "1     2   3     B\n");
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("2");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("3");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  root->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  root->children[1]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : 1 2 + 3 B + +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  puts("DAG:\n"
       "     +\n"
       "  /     \\\n"
       "3         +\n"
       "        /   \\\n"
       "       3     B\n");
  fflush(stdout);
  puts("You should see this:\n"
       "Begin dagger dump\n"
       "                    token       left   left   right  right\n"
       "          token     string      child  child  child  child  parent\n"
       "index       id  (   value    ), index  height index  height count\n"
       "-----    -------  ----------    -----  -----  -----  ------ ------\n"
       "  1:      T_REAL('         1'),   0,     1,     0,     1,     1\n"
       "  2:      T_REAL('         2'),   0,     1,     0,     1,     1\n"
       "  3:       T_ADD('         +'),   1,     2,     2,     2,     1\n"
       "  4:      T_REAL('         3'),   0,     1,     0,     1,     1\n"
       "  5:      T_NVAR('         B'),   0,     1,     0,     1,     1\n"
       "  6:       T_ADD('         +'),   4,     2,     5,     2,     1\n"
       "  7:       T_ADD('         +'),   3,     3,     6,     3,     0\n"
       "End dagger dump\n\nYou actually got this:");
  fflush(stdout);
  init_dagger();
  theroot = generate_dagger(root);
  dump_dagger();

  dagroot = build_dag(theroot);
  fputs("Postorder DAG traversal should print   : 1 2 + 3 B + +\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  puts("\nNow we try to simplify the DAG\n");
  optimization_level = 3U;
  do {
    changecount = 0U;
    // go through an optimize dag, but may generate multiple new zeros
    debug_printf("Before improvement, changecount=%u\n", changecount);
    dagroot = improve_dag(dagroot, &changecount);
    debug_printf("After improvement, changecount=%u\n", changecount);
    // rebuild new dag that will merge any duplicate zeros
    dagroot2 = dag_numeric_expression(dagroot);
    // delete dag with potential multiple zeros
    dag_delete_all(&dagroot);
    dagroot = dagroot2;
    dagroot2 = NULL;
  } while(changecount > 0U);

  fputs("Postorder DAG traversal should print   : 3 3 B + +\n"
        "Postorder DAG traversal actually prints: ", stdout);
  tree_postorder(dagroot, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);
  dag_delete_all(&dagroot);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}

int main(int argc, char **argv) {
  int retval=EXIT_SUCCESS;
  int32_t opt; // variable used by getopt() function

  optimization_level=0U;
  extensions=use_SSE4_1=verbose=false;
  use_double=true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:X")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0], false);
        retval = EXIT_SUCCESS;
        goto xit;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        retval = EXIT_FAILURE;
        goto xit;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  init_debug_printf(stderr);
  retval=test1();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test2();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test3();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test4();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test5();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test6();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test7();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test8();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test9();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test10();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  retval=test11();
  if (EXIT_SUCCESS!=retval)
    goto xit;
  if (extensions) {
    retval=test12();
    if (EXIT_SUCCESS!=retval)
      goto xit;
  }
  retval=test13();
xit:
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return retval;
}
#endif
