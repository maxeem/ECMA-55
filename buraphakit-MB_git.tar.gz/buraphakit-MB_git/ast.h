#ifndef AST_H
#define AST_H
//
// ast.h - This file contains the header file for ast.c
//
// Copyright (C) 2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include "tree.h"

bool regenerate_source(            // generate ECMA-55 Minimal BASIC
                                   // source program from the AST with
                                   // root 'node' and store it in file
                                   // 'outname'
    treenode const * const node,   // root node of AST
    char const * const outname);   // name of output file, or NULL if
                                   // you want output to go to STDOUT
#endif
