//
// hexdump2.c - This is the file containing a hexdump utility 
//              for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
// Coded to handle files up to 256 TB - 1 byte
// but I couldn't create one that large for testing, so ....
//
#define _DEFAULT_SOURCE
#define _POSIX_C_SOURCE 200112L
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/mman.h>
#include "hexdump2.h"

static unsigned const char *gethex[] = {
(unsigned const char *)"00", (unsigned const char *)"01", (unsigned const char *)"02", (unsigned const char *)"03", (unsigned const char *)"04", (unsigned const char *)"05", (unsigned const char *)"06", (unsigned const char *)"07", (unsigned const char *)"08", (unsigned const char *)"09", (unsigned const char *)"0a", (unsigned const char *)"0b", (unsigned const char *)"0c", (unsigned const char *)"0d", (unsigned const char *)"0e", (unsigned const char *)"0f",
(unsigned const char *)"10", (unsigned const char *)"11", (unsigned const char *)"12", (unsigned const char *)"13", (unsigned const char *)"14", (unsigned const char *)"15", (unsigned const char *)"16", (unsigned const char *)"17", (unsigned const char *)"18", (unsigned const char *)"19", (unsigned const char *)"1a", (unsigned const char *)"1b", (unsigned const char *)"1c", (unsigned const char *)"1d", (unsigned const char *)"1e", (unsigned const char *)"1f",
(unsigned const char *)"20", (unsigned const char *)"21", (unsigned const char *)"22", (unsigned const char *)"23", (unsigned const char *)"24", (unsigned const char *)"25", (unsigned const char *)"26", (unsigned const char *)"27", (unsigned const char *)"28", (unsigned const char *)"29", (unsigned const char *)"2a", (unsigned const char *)"2b", (unsigned const char *)"2c", (unsigned const char *)"2d", (unsigned const char *)"2e", (unsigned const char *)"2f",
(unsigned const char *)"30", (unsigned const char *)"31", (unsigned const char *)"32", (unsigned const char *)"33", (unsigned const char *)"34", (unsigned const char *)"35", (unsigned const char *)"36", (unsigned const char *)"37", (unsigned const char *)"38", (unsigned const char *)"39", (unsigned const char *)"3a", (unsigned const char *)"3b", (unsigned const char *)"3c", (unsigned const char *)"3d", (unsigned const char *)"3e", (unsigned const char *)"3f",
(unsigned const char *)"40", (unsigned const char *)"41", (unsigned const char *)"42", (unsigned const char *)"43", (unsigned const char *)"44", (unsigned const char *)"45", (unsigned const char *)"46", (unsigned const char *)"47", (unsigned const char *)"48", (unsigned const char *)"49", (unsigned const char *)"4a", (unsigned const char *)"4b", (unsigned const char *)"4c", (unsigned const char *)"4d", (unsigned const char *)"4e", (unsigned const char *)"4f",
(unsigned const char *)"50", (unsigned const char *)"51", (unsigned const char *)"52", (unsigned const char *)"53", (unsigned const char *)"54", (unsigned const char *)"55", (unsigned const char *)"56", (unsigned const char *)"57", (unsigned const char *)"58", (unsigned const char *)"59", (unsigned const char *)"5a", (unsigned const char *)"5b", (unsigned const char *)"5c", (unsigned const char *)"5d", (unsigned const char *)"5e", (unsigned const char *)"5f",
(unsigned const char *)"60", (unsigned const char *)"61", (unsigned const char *)"62", (unsigned const char *)"63", (unsigned const char *)"64", (unsigned const char *)"65", (unsigned const char *)"66", (unsigned const char *)"67", (unsigned const char *)"68", (unsigned const char *)"69", (unsigned const char *)"6a", (unsigned const char *)"6b", (unsigned const char *)"6c", (unsigned const char *)"6d", (unsigned const char *)"6e", (unsigned const char *)"6f",
(unsigned const char *)"70", (unsigned const char *)"71", (unsigned const char *)"72", (unsigned const char *)"73", (unsigned const char *)"74", (unsigned const char *)"75", (unsigned const char *)"76", (unsigned const char *)"77", (unsigned const char *)"78", (unsigned const char *)"79", (unsigned const char *)"7a", (unsigned const char *)"7b", (unsigned const char *)"7c", (unsigned const char *)"7d", (unsigned const char *)"7e", (unsigned const char *)"7f",
(unsigned const char *)"80", (unsigned const char *)"81", (unsigned const char *)"82", (unsigned const char *)"83", (unsigned const char *)"84", (unsigned const char *)"85", (unsigned const char *)"86", (unsigned const char *)"87", (unsigned const char *)"88", (unsigned const char *)"89", (unsigned const char *)"8a", (unsigned const char *)"8b", (unsigned const char *)"8c", (unsigned const char *)"8d", (unsigned const char *)"8e", (unsigned const char *)"8f",
(unsigned const char *)"90", (unsigned const char *)"91", (unsigned const char *)"92", (unsigned const char *)"93", (unsigned const char *)"94", (unsigned const char *)"95", (unsigned const char *)"96", (unsigned const char *)"97", (unsigned const char *)"98", (unsigned const char *)"99", (unsigned const char *)"9a", (unsigned const char *)"9b", (unsigned const char *)"9c", (unsigned const char *)"9d", (unsigned const char *)"9e", (unsigned const char *)"9f",
(unsigned const char *)"a0", (unsigned const char *)"a1", (unsigned const char *)"a2", (unsigned const char *)"a3", (unsigned const char *)"a4", (unsigned const char *)"a5", (unsigned const char *)"a6", (unsigned const char *)"a7", (unsigned const char *)"a8", (unsigned const char *)"a9", (unsigned const char *)"aa", (unsigned const char *)"ab", (unsigned const char *)"ac", (unsigned const char *)"ad", (unsigned const char *)"ae", (unsigned const char *)"af",
(unsigned const char *)"b0", (unsigned const char *)"b1", (unsigned const char *)"b2", (unsigned const char *)"b3", (unsigned const char *)"b4", (unsigned const char *)"b5", (unsigned const char *)"b6", (unsigned const char *)"b7", (unsigned const char *)"b8", (unsigned const char *)"b9", (unsigned const char *)"ba", (unsigned const char *)"bb", (unsigned const char *)"bc", (unsigned const char *)"bd", (unsigned const char *)"be", (unsigned const char *)"bf",
(unsigned const char *)"c0", (unsigned const char *)"c1", (unsigned const char *)"c2", (unsigned const char *)"c3", (unsigned const char *)"c4", (unsigned const char *)"c5", (unsigned const char *)"c6", (unsigned const char *)"c7", (unsigned const char *)"c8", (unsigned const char *)"c9", (unsigned const char *)"ca", (unsigned const char *)"cb", (unsigned const char *)"cc", (unsigned const char *)"cd", (unsigned const char *)"ce", (unsigned const char *)"cf",
(unsigned const char *)"d0", (unsigned const char *)"d1", (unsigned const char *)"d2", (unsigned const char *)"d3", (unsigned const char *)"d4", (unsigned const char *)"d5", (unsigned const char *)"d6", (unsigned const char *)"d7", (unsigned const char *)"d8", (unsigned const char *)"d9", (unsigned const char *)"da", (unsigned const char *)"db", (unsigned const char *)"dc", (unsigned const char *)"dd", (unsigned const char *)"de", (unsigned const char *)"df",
(unsigned const char *)"e0", (unsigned const char *)"e1", (unsigned const char *)"e2", (unsigned const char *)"e3", (unsigned const char *)"e4", (unsigned const char *)"e5", (unsigned const char *)"e6", (unsigned const char *)"e7", (unsigned const char *)"e8", (unsigned const char *)"e9", (unsigned const char *)"ea", (unsigned const char *)"eb", (unsigned const char *)"ec", (unsigned const char *)"ed", (unsigned const char *)"ee", (unsigned const char *)"ef",
(unsigned const char *)"f0", (unsigned const char *)"f1", (unsigned const char *)"f2", (unsigned const char *)"f3", (unsigned const char *)"f4", (unsigned const char *)"f5", (unsigned const char *)"f6", (unsigned const char *)"f7", (unsigned const char *)"f8", (unsigned const char *)"f9", (unsigned const char *)"fa", (unsigned const char *)"fb", (unsigned const char *)"fc", (unsigned const char *)"fd", (unsigned const char *)"fe", (unsigned const char *)"ff",
};

// assumes little-endian byte order ....
static void addr2string(unsigned char *buf,             // buffer must be generous (numdigits+2 for odd, numdigts+1 for even)
                        const unsigned long int val,    // value we want to convert to string of hexadecimal digits
                        const unsigned int numdigits) { // any number > 0 supported
  unsigned long int tval = (unsigned long int)val;
  unsigned int i=(numdigits&1)?numdigits+1:numdigits;

  while (i>0) {
    unsigned char *s=(unsigned char *)gethex[tval&0xff];
    tval >>= 8;
    buf[(i--)-1]=s[1];
    buf[(i--)-1]=s[0];
  }
  if (numdigits&1) // odd number of digits, sheft left 1 byte
    for (i=0;i<numdigits;++i)
      buf[i]=buf[i+1];
  buf[numdigits]=0;
}

//
// HEX_BYTE_COUNT is the number of hex bytes per line
// but for things to work without division, don't change
// HEX_BYTE_COUNT or WHEN_TO_FLUSH
//
#define HEX_BYTE_COUNT 16
//
// WHEN_TO_FLUSH is the number of lines to buffer before issing a puts
//
#define WHEN_TO_FLUSH  512
//
// util-linux hexdump -vC format, address in left column and then
// HEX_BYTE_COUNT hex bytes, then ASCII in the right-hand column.
//
// For file sizes who are >=(2<<31)-1, we use 12 bytes of address instead of 8
// For hexdump from util-linux 2.37.2, this means:
// 8 bytes of addres:  (hexdump -vC, which is short for):
// hexdump -v -e '"%08.8_Ax\n"' -e '"%08.8_ax  " 8/1 "%02x " "  " 8/1 "%02x " ' -e '"  |" 16/1 "%_p" "|\n"' "$1"
// 12 bytes of addres:
// hexdump -v -e '"%012.12_Ax\n"' -e '"%012.12_ax  " 8/1 "%02x " "  " 8/1 "%02x " ' -e '"  |" 16/1 "%_p" "|\n"' "$1"
//
extern void hexdump(const void *addr,        // pointer to block of memory
             const unsigned long int base,   // offset in file to start with for display
             const unsigned long int len,    // number of bytes in addr memory block
             const unsigned char done,       // 0 means this is not the last block, 1 means it is,
                                             // 2 means this is not last block from pipe
             const unsigned int address_digits, // number of hex digits to use for address
             FILE *outfile) {                // where to print it to, often stdout
  unsigned int i,j;                          // index into block pointed to by addr
  static unsigned char buff[HEX_BYTE_COUNT + 1];    // buffer to hold ASCII representation
  unsigned char *pc = (unsigned char*)addr;  // convert block to char *
  static unsigned char *outline = NULL;
  unsigned int which_outline = 0, line_length;
  unsigned int outpos,tpos;
  unsigned long int junk;
  char tbuf[256];

  if (!addr) {
    fprintf(stderr, "  hexdump(): NULL ptr to data\n");
    return;
  }
  line_length = 71 + address_digits; // 70 + 1 null + address digits
  snprintf(tbuf, 256, "Unable to allocate %lu bytes of memory for output buffer\n",
           sizeof(unsigned char)*WHEN_TO_FLUSH*line_length);
  if (posix_memalign((void **)&outline,32,sizeof(unsigned char)*WHEN_TO_FLUSH*line_length)<0) {
    perror(tbuf);
    abort();
  }
  mlock(outline, sizeof(unsigned char)*WHEN_TO_FLUSH*line_length);
  outpos=0;
  if (len==0) goto dribbling_address;
  *(outline+which_outline*line_length+outpos)=0;
  // for each byte in the data
  for (i = 0U; i < len; i++) {
#if HEX_BYTE_COUNT==16
    tpos = i & 15;
#else
    tpos = i % HEX_BYTE_COUNT;
#endif
    // Multiple of HEX_BYTE_COUNT means new line (with line offset).
    if (!tpos) {
      // No ASCII to output first time through
      if (i) {
        *(outline+which_outline*line_length+outpos++) = ' ';
        *(outline+which_outline*line_length+outpos++) = ' ';
        *(outline+which_outline*line_length+outpos++) = '|';
        j=0;
        while(buff[j])
          *(outline+which_outline*line_length+outpos++)=buff[j++];
        *(outline+which_outline*line_length+outpos++) = '|';
        *(outline+which_outline*line_length+outpos++) = '\n';
#if HEX_BYTE_COUNT==16
#if WHEN_TO_FLUSH==512
        if (!((i >> 4) & 511)) {                            // flush output
#else
        if (!((i >> 4) % WHEN_TO_FLUSH)) {                  // flush output
#endif
#else
        if (!((i / HEX_BYTE_COUNT) % WHEN_TO_FLUSH)) {      // flush output
#endif
           *(outline+which_outline*line_length+(outpos)) = 0;
           fwrite((void *)outline, WHEN_TO_FLUSH*line_length, 1, outfile);
           fflush(outfile);
           which_outline=0;
        } else {
           which_outline++;
        }
        outpos=0;
      }
      // Output the offset.
      junk = i+base;
      addr2string(outline+which_outline*line_length,junk,address_digits);
      outpos += address_digits;
      *(outline+which_outline*line_length+outpos++) = ' ';
    }
    if (tpos == 8U)
      *(outline+which_outline*line_length+outpos++) = ' ';
    // Now the hex code for the specific byte.
    *(outline+which_outline*line_length+outpos++) = ' ';
    *(outline+which_outline*line_length+outpos++) = gethex[pc[i]][0];
    *(outline+which_outline*line_length+outpos++) = gethex[pc[i]][1];
    // And store a printable ASCII character for later.
    buff[tpos]=(isprint(pc[i])?pc[i]:'.');
    buff[tpos + 1] = '\0';
  }
  // Pad out last line if not exactly HEX_BYTE_COUNT characters.
#if HEX_BYTE_COUNT==16
  tpos = i & 15;
#else
  tpos = i % HEX_BYTE_COUNT;
#endif
  if (tpos) { // If we didn't end on a line with a full HEX_BYTE_COUNT bytes
              // then pad the hex zone with spaces
    for (; tpos < HEX_BYTE_COUNT; ++tpos) {
      if (tpos == 8U)
        *(outline+which_outline*line_length+outpos++) = ' ';
      *(outline+which_outline*line_length+outpos++) = ' ';
      *(outline+which_outline*line_length+outpos++) = ' ';
      *(outline+which_outline*line_length+outpos++) = ' ';
    }
  }
  // And print the final ASCII bit.
  *(outline+which_outline*line_length+outpos++) = ' ';
  *(outline+which_outline*line_length+outpos++) = ' ';
  *(outline+which_outline*line_length+outpos++) = '|';
  j=0;
  while(buff[j])
    *(outline+which_outline*line_length+outpos++)=buff[j++];
  *(outline+which_outline*line_length+outpos++) = '|';
  *(outline+which_outline*line_length+outpos++) = '\n';
  *(outline+which_outline*line_length+outpos) = 0;
  fwrite((void *)outline, which_outline*line_length+outpos, 1, outfile);
  fflush(outfile);
dribbling_address:
  if (done==1) {
    // Output the the dribbling address
    junk = len + base;
    addr2string(outline,junk,address_digits);
    outpos += address_digits;
    *(outline+outpos++) = '\n';
    *(outline+outpos) = 0;
    fwrite((void *)outline, outpos, 1, outfile);
    fflush(outfile);
    munlock(outline, sizeof(unsigned char)*WHEN_TO_FLUSH*line_length);
    free(outline); outline = NULL;
  }
  return;
}

#ifdef STANDALONE
#include <linux/limits.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <getopt.h>
#define my_min(a,b) (((a) < (b)) ? (a) : (b))
#define my_max(a,b) (((a) > (b)) ? (a) : (b))
#ifdef USE_MMAP
#define MAXCHUNK (1<<17)
#else
#define MAXCHUNK (1<<16)
#endif

static void crashinfo(void) {
  static char ebuf[256];
  size_t rez;
#if defined(__TINYC__)
  int a,b,c;
#endif
#if defined(__linux__) && defined(__x86_64__)
  puts("Running on an AMD64/INTEL64/x64 system.");
#else
  puts("Not running on a 64bit AMD64 system, which is not supported.");
#endif
#if defined(__GNUC__) || defined(__clang__)
  fputs("Program was built using ", stdout);
#if defined(__code_model_large__)
  fputs("the large", stdout);
#elif defined (__code_model_medium__)
  fputs("the medium", stdout);
#elif defined (__code_model_small__)
  fputs("the small", stdout);
#else
  fputs("an unknown", stdout);
#endif
  puts(" code model.");
#endif
#if defined(__clang__)
  printf("Built with what claims to be LLVM/clang version %u.%u.%u\n",
         __clang_major__, __clang_minor__, __clang_patchlevel__);
#elif defined(__TINYC__)
  a=(int)(__TINYC__/10000);
  b=(int)((__TINYC__-(__TINYC__*a*10000))/100);
  c=(int)(__TINYC__%100);
  printf("Built with what claims to be tcc version %u.%u.%u\n",a,b,c);
#elif defined(__PCC__)
printf("Built with what claims to be pcc version %u.%u.%u\n",
       __PCC__,__PCC_MINOR__,__PCC_MINORMINOR__);
#elif defined(__GNUC__)
  // this has to be last, since they all claim to be gcc to make
  // crap header files work....
  printf("Built with what claims to be gcc version %u.%u.%u\n",
          __GNUC__,__GNUC_MINOR__,__GNUC_PATCHLEVEL__);
#else
  puts("Built with an unknown compiler.");
#endif
  rez = confstr(_CS_GNU_LIBC_VERSION, ebuf, 120);
  if (rez < 1) strcpy(ebuf, "unknown libc");
  printf("Using %s\n", ebuf);
}

#define BUFMAX (PATH_MAX+129)
int main(int argc, char *argv[]) {
  int fd = -1, ispipe = 0, isfile = 0, wide = 0;
  struct stat sb;
  char *tbuf = NULL;
  unsigned long int filesize = 0UL, howmany = 0UL, offset = 0UL;
#ifndef USE_MMAP
  ssize_t ret_from_read;
#endif
  int32_t opt; //variable used by getopt() function
  unsigned char *data_buffer = NULL;
  char *system_outbuffer = NULL;
  unsigned int adigits;

  if ((tbuf = (char *)malloc(sizeof(char)*BUFMAX))==NULL) {
    fprintf(stderr, "Unable to allocate %lu bytes for error buffer!\n", sizeof(char)*BUFMAX);
    return EXIT_FAILURE;
  }
  opterr = 0;
  while ((opt = getopt(argc, argv, ":w")) != -1) {
    switch (opt) {
      case 'w': // wide (12 hex digits of address, used for pipes)
        adigits = 12;
        wide = 1;
        break;
      default: // unknown option encountered
        fprintf(stderr,"Unknown option '%c'\n", optopt);
        return EXIT_FAILURE;
    }
  }
  // There should be at most one remaining option, a filename
  if ((argc - optind) > 1) {
    fputs("Garbage after last option\n", stderr);
    return EXIT_FAILURE;
  }
  if ((argc-optind)==0) {
    if (fstat(STDIN_FILENO, &sb) == -1) {
      perror("fstat failed");
      return EXIT_FAILURE;
    }
    if ((sb.st_mode & S_IFMT) == S_IFIFO) { // we are reading from a pipe
      ispipe = 1;
    } else {
      if ((sb.st_mode & S_IFREG) == S_IFREG) { // we are reading from redirected file
        isfile = 1;
      } else {
        fprintf(stderr, "No file to hexdump specified and nothing piped in!\n");
#if 0
        printf("File type:                ");
        switch (sb.st_mode & S_IFMT) {
          case  S_IFBLK: printf("block device\n");       break;
          case  S_IFCHR: printf("character device\n");   break;
          case  S_IFDIR: printf("directory\n");          break;
          case  S_IFIFO: printf("FIFO/pipe\n");          break;
          case  S_IFLNK: printf("symlink\n");            break;
          case  S_IFREG: printf("regular file\n");       break;
          case S_IFSOCK: printf("socket\n");             break;
                default: printf("unknown?\n");           break;
        }
#endif
        return EXIT_FAILURE;
      }
    }
  }

  if (ispipe) {
    struct sigaction sa = { 0 };

#ifdef USE_MMAP
    fprintf(stderr, "Sorry, I cannot mmap a pipe.\n");
    return EXIT_FAILURE;
#endif
    fd = STDIN_FILENO;
    if (sigaction(SIGPIPE, NULL, &sa)<0) {
       perror("sigaction to fetch SIGPIPE settings");
       return EXIT_FAILURE;
    }
    sa.sa_handler = SIG_IGN;
    if (sigaction(SIGPIPE, &sa, NULL)<0) {
       perror("sigaction to ignore SIGPIPE");
       return EXIT_FAILURE;
    }
    fd = STDIN_FILENO;
    filesize = 0;
  } else {
    snprintf(tbuf, BUFMAX, "Unable to open file '%s' for read access.  Linux says", argv[optind]);
    tbuf[BUFMAX-1]=0;
    if (isfile == 0) {
      if ((fd=open(argv[optind], O_RDONLY))<0) {
        perror(tbuf);
        crashinfo();
        return EXIT_FAILURE;
      }
    } else {
      fd = STDIN_FILENO;
    }
    snprintf(tbuf,BUFMAX,"Stat of '%s' failed.  Linux says", argv[optind]);
    tbuf[BUFMAX-1]=0;
    if (fstat(fd, &sb) < 0) {
      perror(tbuf);
      crashinfo();
      return EXIT_FAILURE;
    }
    if (isfile == 0) {
      if ((sb.st_mode & S_IFMT) != S_IFREG) {
        fprintf(stderr,"I don't know what \"%s\" is, but it is not a regular file.\n", argv[optind]);
        crashinfo();
        return EXIT_FAILURE;
      }
    }
    filesize =  (unsigned long int)sb.st_size;
  }
  if ((wide==1) || (filesize>4294967295))
    adigits = 12;
  else
    adigits = 8;
  snprintf(tbuf, BUFMAX, "Failed to allocate %lu bytes of memory.  Linux says", sizeof(char)*32768);
  tbuf[BUFMAX-1]=0;
  if (posix_memalign((void **)&system_outbuffer,256,sizeof(char)*32768)<0) {
    perror(tbuf);
    return EXIT_FAILURE;
  }
  mlock(system_outbuffer,sizeof(char)*32768);
  setvbuf(stdout,system_outbuffer,_IOFBF,sizeof(char)*32768);
#ifdef USE_MMAP
  // Linux freaks at about a page before 4GB unless you jump through crazy hoops with
  // admin rights to setup huge pages, so let's use 1GB pages
  howmany = my_min(filesize - offset,MAXCHUNK);
  while (howmany) {
    snprintf(tbuf,BUFMAX,"mmap of '%s' from %lu to %lu failed.  Linux says", argv[1], offset, offset+howmany-1);
    tbuf[BUFMAX-1]=0;
    if ((data_buffer = (unsigned char *)mmap(NULL, howmany, PROT_READ, MAP_PRIVATE, fd, (long int)offset))==MAP_FAILED) {
      perror(tbuf);
      crashinfo();
      return EXIT_FAILURE;
    }
    //mlock(data_buffer,sizeof(unsigned char)*(MAXCHUNK+1));   // doesn't work. why?
    madvise(data_buffer,howmany,MADV_DONTDUMP);
    madvise(data_buffer,howmany,MADV_SEQUENTIAL);
    hexdump(data_buffer, offset, howmany, (offset+howmany)==filesize?1:0, adigits, stdout);
    //munlock(data_buffer,sizeof(unsigned char)*(MAXCHUNK+1));   // doesn't work since earlier mlock failed.
    munmap(data_buffer, howmany);
    tbuf = NULL;
    offset += howmany;
    howmany = my_min(filesize - offset,MAXCHUNK);
  }
#else
  snprintf(tbuf, BUFMAX, "Failed to allocate %lu bytes of memory.  Linux says", sizeof(unsigned char)*(MAXCHUNK+1));
  tbuf[BUFMAX-1]=0;
  if (posix_memalign((void **)&data_buffer,256,sizeof(unsigned char)*(MAXCHUNK+1))<0) {
    perror(tbuf);
    crashinfo();
    return EXIT_FAILURE;
  }
  mlock(data_buffer,sizeof(unsigned char)*(MAXCHUNK+1));
  if (ispipe==0) {
    if (fdatasync(fd)<0) {
      perror(tbuf);
      crashinfo();
      return EXIT_FAILURE;
    }
    if (posix_fadvise(fd, 0, (off_t)filesize, POSIX_FADV_SEQUENTIAL)<0) {
      perror(tbuf);
      crashinfo();
      return EXIT_FAILURE;
    }
    if (posix_fadvise(fd, 0, (off_t)filesize, POSIX_FADV_NOREUSE)<0) {
      perror(tbuf);
      crashinfo();
      return EXIT_FAILURE;
    }
  }
  while ((ret_from_read = read(fd, data_buffer, MAXCHUNK))>=0) {
    howmany = (unsigned long int)ret_from_read;
    if (ispipe==0) {
      hexdump(data_buffer, offset, howmany, howmany==0?1:0, adigits, stdout);
    } else {
      hexdump(data_buffer, offset, howmany, howmany==0?1:2, adigits, stdout);
      filesize += offset;
    }
    offset += howmany;
    if (ret_from_read==0) break;
  }
  if (ret_from_read < 0) {
    perror("Failed read.  Linux says");
    crashinfo();
    return EXIT_FAILURE;
  }
  close(fd);
  munlock(data_buffer,sizeof(unsigned char)*(MAXCHUNK+1));
  free(data_buffer); data_buffer = NULL;
  if ((ispipe==0) && (offset != filesize)) {
    fprintf(stderr, "Read %lu bytes, expected %lu bytes\n",
            offset, filesize);
    return EXIT_FAILURE;
  }
#endif
  setvbuf(stdout,NULL,_IOLBF,0);
  munlock(system_outbuffer,sizeof(char)*32768);
  free(system_outbuffer); system_outbuffer = NULL;
  free(tbuf); tbuf = NULL;
  return EXIT_SUCCESS;
}
#endif
