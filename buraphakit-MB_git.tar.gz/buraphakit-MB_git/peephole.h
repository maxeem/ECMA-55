#ifndef PEEPHOLE_H
#define PEEPHOLE_H
//
// peephole.h - This is the file with the header for peephole.c
//              for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdbool.h>
bool peephole_scan(const char *filename);
#endif
