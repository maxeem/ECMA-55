#ifndef DTOA5_NORMAL_H
#define DTOA5_NORMAL_H
double dgstrtod(const char *s00, char **se);
char *dgdtoa(double dd, int mode, int ndigits, int *decpt, int *sign, char **rve);
void freedtoa(char*);
#endif
