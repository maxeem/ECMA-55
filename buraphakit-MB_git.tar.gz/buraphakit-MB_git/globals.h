#ifndef GLOBALS_H
#define GLOBALS_H
//
// globals.h - This is the file with the header for globals.c
//             for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#if __STDC_VERSION__ < 199901L
#error "You need a C99 compiler"
#endif
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#if defined(__STDC_VERSION__) && ( __STDC_VERSION__ >= 201112L ) // If we have C11
#if defined(__clang__) || defined(__GNUC__)
#include <stdnoreturn.h>
#endif
#if !defined(noreturn)
#define noreturn _Noreturn
#endif
#else                 //    This version of C is inferior to C11
#if defined(noreturn) //    Remove any existing noreturn extension
#undef noreturn
#endif
#define noreturn      //    And define noreturn as nothing
#endif
#ifndef INPUT_WIDTH
#define INPUT_WIDTH 72
#elif INPUT_WIDTH < 72
#error INPUT_WIDTH must be at least 72
#endif
// specify maximum length of an ASCIIZ literal value
#define LITVAL_MAX_BYTES (INPUT_WIDTH - 1)
extern const char version[];
extern const uint32_t SIGNIFICANCE_WIDTH_NARROW_OUTPUT,
                      SIGNIFICANCE_WIDTH_WIDE_OUTPUT,
                      SIGNIFICANCE_WIDTH_INTERNAL,
                      MAX_SUBSCRIPT_VALUE,
                      MAX_STRING_OPERANDS,
                      MAXLINENO,
                      MAXCOLUMN,
                      MAXONJUMPTARGETS,
                      FLOAT_BUFFER_LEN,
                      MAX_LINENO_DIGITS;
extern const char EXRAD_NARROW_OUTPUT,
                  EXRAD_WIDE_OUTPUT,
                  MAX_OPTIMIZATION_LEVEL;
extern unsigned long int ERROR_BUFFER_LEN;
extern const unsigned long int MAX_BIFNAME_LEN;
extern const unsigned int FORSTACK_DEPTH,
                          MAX_GOSUB_DEPTH,
                          MAX_STRING_BYTES,
                          MAX_LABELWIDTH,
                          MAX_VARNAME_LEN;
extern bool use_SSE4_1,
            base_is_one,
            extensions,
            need_ACOS,
            need_ADD,
            need_ANGLE,
            need_ASIN,
            need_ATN,
            need_BSS_numeric,
            need_BSS_string,
            need_CEIL,
            need_COS,
            need_COSH,
            need_DIVIDE,
            need_DATE,
            need_DATES,
            need_EXP,
            need_FORNEXT,
            need_INPUT,
            need_INPUT_NAVAR_1D,
            need_INPUT_NAVAR_2D,
            need_INPUT_NVAR,
            need_INT,
            need_IP,
            need_FP,
            need_MOD,
            need_REMAINDER,
            need_LOADREAL,
            need_LOG,
            need_LOG10,
            need_LOG2,
            need_MULTIPLY,
            need_ONGOTO,
            need_POWER,
            need_PRINT,
            need_PRINT_NUMERIC,
            need_READSTMT,
            need_READSTMT_NAVAR_1D,
            need_READSTMT_NAVAR_2D,
            need_READSTMT_NVAR,
            need_READSTMT_SVAR,
            need_READ_1D,
            need_READ_2D,
            need_RND,
            need_ROUND,
            need_SIN,
            need_SINH,
            need_SQR,
            need_STRINGS,
            need_SUBROUTINE,
            need_SUBTRACT,
            need_TAB,
            need_TAN,
            need_TANH,
            need_TIME,
            need_TIMES,
            need_UDF,
            need_WRITE_1D,
            need_WRITE_2D,
            need_strcmp,
            need_strcpy,
            pretty_print,
            renumber,
            use_double,
            use_double_output,
            need_SEC,
            need_CSC,
            need_COT,
            verbose;
extern uint8_t optimization_level;
extern FILE *diagnostic_stream;
noreturn void ICE(const char *filename, const char *functname,
                  const unsigned int lineno, const char *format, ...)
                  __attribute__((format(printf, 4, 5)));
noreturn void FATAL(const char *filename, const char *functname,
                    const unsigned int lineno, const char *format, ...)
                    __attribute__((format(printf, 4, 5)));
void debug_printf(const char *format, ...)
                 __attribute__((format(printf, 1, 2)));
#ifdef DEEP_DEBUG
#define deep_debug_printf(format, ...) \
  do \
    { if (verbose) fprintf(diagnostic_stream, format, __VA_ARGS__); } \
  while (0)
#else
#define deep_debug_printf(format, ...) do {} while (0)
#endif
void init_debug_printf(FILE *f);
char *fixbackslashes(const char *instring);
const char *suffix(const uint32_t n);
char *trim(char *instring);
bool convert_line_number(const char *s, uint32_t *lineno, char *why);
void dumpflags(void);
#define calloc(c, e) \
  ICE(__FILE__, __func__, __LINE__, "calloc must not be used")
#ifdef MJOLNIR
#define malloc(s) mymalloc(__FILE__, __func__, __LINE__, s)
#define realloc(p, s) myrealloc(__FILE__, __func__, __LINE__, p, s)
#define free(p) myfree(__FILE__, __func__, __LINE__, p)
#ifdef strdup
#undef strdup
#endif
#define strdup(s) mystrdup(__FILE__, __func__, __LINE__, s)
#else
#define malloc(s) xmalloc(__FILE__, __func__, __LINE__, s)
#define realloc(p, s) xrealloc(__FILE__, __func__, __LINE__, p, s)
#ifdef strdup
#undef strdup
#endif
#define strdup(s) xstrdup(__FILE__, __func__, __LINE__, s)
#endif
void *xrealloc(const char *filename, const char *funcname,
               const unsigned int lineno, void *ptr, size_t size);
void *xmalloc(const char *filename, const char *funcname,
               const unsigned int lineno, size_t size);
char *xstrdup(const char *filename, const char *funcname,
               const unsigned int lineno, const char *s);
void myshowleakdata(void);
void *mymalloc(const char *filename, const char *funcname,
               const unsigned int lineno, size_t size);
void myfree(const char *filename, const char *funcname,
               const unsigned int lineno, void *ptr);
void *myrealloc(const char *filename, const char *funcname,
               const unsigned int lineno, void *ptr, size_t size);
char *mystrdup(const char *filename, const char *funcname,
               const unsigned int lineno, const char *s);
uint32_t mybsearch(const void *key, const void *base,
      const uint32_t nmemb, const uint32_t size,
      int (*)(const void *, const void *));
void usage(const char *progname, const bool has_V);
#endif
