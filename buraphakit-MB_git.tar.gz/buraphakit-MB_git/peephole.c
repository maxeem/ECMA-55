//
// peephole.c - This is the file containing the peephole optimizer
//              for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2014,2105,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of peephole.
//
// peephole is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// peephole is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with peephole.  If not, see <http://www.gnu.org/licenses/>.
//
#define _DEFAULT_SOURCE
#define _BSD_SOURCE
#if __STDC_VERSION__ < 199901L
#error "You need a C99 compiler"
#endif
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include "peephole.h"

#define PEEPHOLE_MAXLINEWIDTH 201        // number of coluns in input buffer
                                         // for a max of 200 bytes & trailing NULL
#define PEEPHOLE_WINDOWSIZE 2            // number of lines in input buffer

static bool peephole_match(const char *haystack, const char *needle);

//
// return true if string in needle parameter matches
// the string in the haystack parameter after the haystack
// parameter string has had whitespace removed, ignoring any
// trailing comment, otherwise return false
// Assumptions (which will be true for compiler generated assembly):
// 1) neither haystack nor needle contain a newline
// 2) neither haystack nor needle contain any non-trailing NULL
// 3) both haystack and needle are non-empty ASCIIZ strings
//
static bool peephole_match(
    const char *haystack,           // pointer to ASCIIZ string buffer to search
    const char *needle) {           // pointer to ASCIIZ string buffer of text
                                    // which we seek
  if (haystack) {
    if (needle) {
      size_t len = strlen(needle);
      while (*haystack != 0) {
        while ((*haystack == ' ') || (*haystack == '\t'))
          haystack++; // eat leading whitespace
        if (haystack && (strcmp(haystack, needle) != 0))
          return false;
        haystack += len;
        if (haystack)
          while ((*haystack == ' ') || (*haystack == '\t'))
            haystack++; // eat whitespace
        if (haystack && ((*haystack == '#') || (*haystack == '\n')))
          return true;
        return false;
      }
    }
  }
  return false;
}

//
// This procedure implments a simple peephole optimizer for GNU gas
// AMD64 code using the normal AT&T assmebly dialect which is output by
// the compiler.  This function will verify its argument, open the files,
// then scan the input file with a 2 line logical window looking for
// redundant push/pop sequences that can be safely removed.
// This peephole scanner only works for GNU GAS AMD64 code.
//
bool peephole_scan(
    const char *input_filename) {   // pointer to buffer containing the name of the
                                    // assembly language input text file
  char output_filename[] = "tmpXXXXXX"; // assembly language output text file
  int in;                           // input file handle
  int out;                          // output file handle
  signed long int howmany;          // number of bytes read by the read() system call
  unsigned int curline;             // current line of the input file
  unsigned int curpos;              // current column position in read buffer
  unsigned int curlineno;           // current line in the input buffer
  unsigned int inlines;             // number of lines read in the input file
  unsigned int outlines;            // number of files written to the output file
  char c;                           // input byte buffer used by the read() system call
  static char BUFFER[PEEPHOLE_WINDOWSIZE][PEEPHOLE_MAXLINEWIDTH];   // input buffer matrix

  curline = curpos = 0U;
  curlineno = inlines = outlines = 0U;
  if ((in = open(input_filename, O_EXCL | O_RDONLY)) < 0) {
    fprintf(stderr, "Unable to open '%s' for input\n", input_filename);
    return false;
  }
  if ((out = mkstemp(output_filename)) < 0) {
    fprintf(stderr, "Unable to open '%s' for output\n", output_filename);
    close(in);
    return false;
  }
  // while true attempt to read 1 byte from input file
  while ((howmany = read(in, &c, 1))) {
    if (howmany < 1)                        // if input file exhausted
      break;                                // exit while
    if (0U == curpos)                       // if start of new line
      ++curlineno;                          // move to next line of buffer
    BUFFER[curline][curpos++] = c;          // put charater into buffer
    if ('\n' == c) {                        // if input character is a newline then
      ++inlines;
      BUFFER[curline][curpos] = 0;          // terminate current line in buffer
      if (1U == curline) {                  // if we have two lines buffered
                                            // then look for patterns to match
        if (peephole_match(BUFFER[0], "pushsaddr") && peephole_match(BUFFER[1], "popsaddr %rdi") ) {
          curline = curpos = 0U;            // discard buffer because the pattern matched
        } else {
          if (write(out, BUFFER[0], strlen(BUFFER[0])) < 0) {       // write first line of buffer to output file
            fprintf(stderr, "Unable to write to file '%s'\n", output_filename);
            close(in);
            close(out);
            return EXIT_FAILURE;
          }
          ++outlines;
          strcpy(BUFFER[0], BUFFER[1]);     // move second line of buffer to first line of buffer
          curpos = 0U;                      // and reset buffer to begin filling second line
        }
      } else {                              // saw end of first line of buffer, so switch to filling
                                            // second line of buffer
        curline = 1U;
        curpos = 0U;
      }
    } else {                                // character is not a newline
      if (curpos >= PEEPHOLE_MAXLINEWIDTH) {                // if the line was too long report error and exit while
        fprintf(stderr, "Line %u of the assembly input is too long.\n", curlineno);
        fprintf(stderr, "Maximum supported line width is %u bytes.\n", PEEPHOLE_MAXLINEWIDTH);
        break;
      }
      // everything OK, loop back up to read next byte
    }
  }
  close(in);                                // close the input file
  fflush(stdout);
  if (1U == curline) {                      // if we were filling the second line of the buffer
    if (write(out, BUFFER[0], strlen(BUFFER[0])) < 0) {     // write the first line in the buffer to the output file
      close(out);
      fprintf(stderr, "Unable to write to file '%s'\n", output_filename);
      return false;
    }
    ++outlines;
    if (curpos > 0U) {                      // if the second line of the buffer is non-empty
      if (write(out, BUFFER[1], strlen(BUFFER[0])) < 0) {   // write the second line in the buffer to the output file
        close(out);
        fprintf(stderr, "Unable to write to file '%s'\n", output_filename);
        return false;
      }
      ++outlines;
    }
  } else {                                  // we were filling first line of the buffer
    if (curpos > 0U) {                      // if the first line of the buffer is non-empty
      if (write(out, BUFFER[0], strlen(BUFFER[0])) < 0) {   // write the first line in the buffer to the output file
        close(out);
        fprintf(stderr, "Unable to write to file '%s'\n", output_filename);
        return false;
      }
      ++outlines;
    }
  }
  close(out);                               // close the output file
  unlink(input_filename);
  rename(output_filename,input_filename);
#ifdef VERBOSE
                                            // report statistics if compiled with VERBOSE flag
  if (inlines != outlines)
    printf("Removed %u lines\n", inlines - outlines);
  else
    printf("Removed no lines\n");
#endif
  return true;
}

#ifdef UNIT_TEST
int main(int argc, char **argv) {

  if (argc != 2) {
    printf("Usage:  %s INFILENAME\n", argv[0]);
    printf("had %d argument(s), need exactly 1 argument\n", argc);
    return EXIT_FAILURE;
  }
  return peephole_scan(argv[1]) ? EXIT_SUCCESS : EXIT_FAILURE;
}
#endif
