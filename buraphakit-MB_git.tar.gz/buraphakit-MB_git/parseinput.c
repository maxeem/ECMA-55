//
// parseinput.c - This is C version of the INPUT support
//                for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdlib.h>
#if defined(UNIT_TEST) || defined(TROUBLE)
#include <stdio.h>
#endif

#define __NR_write 1UL
#define __NR_read 0UL
#define __NR_fstat 5UL
#define __NR_exit  60UL
#define OUTPUT_WIDTH 80        // number of ASCII character per output line
                               // 80 for narrow, 132 for wide
#define MAX_ZONE 5             // maximum zone number, zones go from 1 to 5
#define ZONE_WIDTH 15          // EXRAD_WIDTH = 3, SIGNIFICANCE_WIDTH = 18
                               // Need room for leading sign/space, the E and it's sign/space, and a decimal,
                               // and a trailing space
                               // 18 + 3 + 1 + 2 + 1 + 1 = 26
                               // EXRAD_WIDTH = 2, SIGNIFICANCE_WIDTH = 7
                               // 7 + 2 + 1 + 2 + 1 + 1 + 1 = 15
#define S_IFMT 0170000         // These bits determine file type.
#define S_IFCHR 0020000        // Character device.

#define T_COMMA 4              // token for ','
#define T_EOL 12               // token for '\n'
#define T_REAL 43              // token for a real number string
#define T_UQSTRING 62          // token for an unquoted string
#define T_QSTRING 40           // token for a quoted string
#define MAX_STRING_BYTES 18U   // maximum number of bytes that a quoted or unquoted
                               // string can contain
#define MAX_INPUT_BYTES 80U    // maximum number of bytes that can be input at once in
                               // response to an INPUT query
#define MAX_INPUT_VARS 30U     // maximum number of variables permitted on one INPUT line (and in runtime INPUT stack)
#define STDIN 0                // file number for STDIN
#define STDOUT 1               // file number for STDOUT
#define STDERR 2               // file number for STDERR

static struct rt_token {                          // type of one element in temporary input stack
  unsigned char tokeid;                           // numeric token id
  char toketext[2 * MAX_STRING_BYTES + 1];        // 2*MAX_STRING_BYTES + 1 terminator
} rt_nput_stack[MAX_INPUT_VARS];                  // runtime INPUT temporary stack
static unsigned long int rt_nput_stack_top = 0UL; // runtime INPUT stack pointer, 0UL means empty
static char informat[MAX_INPUT_VARS + 1] = { 0 }; // format statement (+1 for terminator) for actual types found by scan

// At runtime, scanning values is required for the INPUT statment.
// This is done using a DFSM (deterministic finite state machine).
// This machine uses character classes and states.
//
// The character_class is a conversion map to convert between
// an input 7 bit ASCII value and a character class number for use
// with the DFSM used by the INPUT statement scanner.
// character_class is a vector in which there are 127 elements.
// The ASCII code of the byte in question is used as an
// index into the character_class vector to get the
// character class number which is stored in that element.
//
//  0  is A..D,F..Z upper case
//  1  is E upper case
//  2  is DIGIT
//  3  is ADD
//  4  is MINUS
//  5  is COMMA
//  6  is SPACE
//  7  is NEWLINE
//  8  is DOT
//  9  is QUOTE
// 10  is anything else
static const unsigned char character_class[128] = {
  10, 10, 10, 10, 10, 10, 10, 10, 10, 10,  7, 10, 10, 10, 10, 10, 10, 10, 10, 10,
  10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,  6, 10,  9, 10, 10, 10, 10, 10,
  10, 10, 10,  3,  5,  4,  8, 10,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2, 10, 10,
  10, 10, 10, 10, 10,  0,  0,  0,  0,  1,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
   0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0, 10, 10, 10, 10, 10, 10, 10, 10, 10,
  10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10,
  10, 10, 10, 10, 10, 10, 10, 10
};

// states is a matrix containing the DFSM used to scan
// data from an INPUT statement.  The rows correspond to the
// states, and the columns correspond to character classes.
// To find the next action, the character class value for the
// current byte is used as the column index, and the current
// state is used as the row index in the states matrix.
// Actions can be accept (see list below), moving to a new
// state, or reject.
//  13 accept T_COMMA, 14 accept T_EOL, 15 accept T_INTEGER, 16 accept T_REAL,
//  17 accept T_UQSTRING, 18 accept T_QSTRING, 19 reject
//
//state      A..D     E    digit    +      -      ,   space   eol      .      "   other
//           F..Z
static const unsigned char states[][11] = {
/*   0 */   { 8UL,   8UL,   2UL,   1UL,   1UL,  13UL,   0UL,  14UL,   3UL,   9UL,  19UL, },
/*   1 */   { 8UL,   8UL,   2UL,   8UL,   8UL,  17UL,   8UL,  17UL,   3UL,  19UL,  19UL, },
/*   2 */   { 8UL,   5UL,   2UL,   8UL,   8UL,  15UL,  11UL,  15UL,   3UL,  19UL,  19UL, },
/*   3 */   { 8UL,   5UL,   4UL,   8UL,   8UL,  16UL,  12UL,  16UL,   8UL,  19UL,  19UL, },
/*   4 */   { 8UL,   5UL,   4UL,   8UL,   8UL,  16UL,  12UL,  16UL,   8UL,  19UL,  19UL, },
/*   5 */   { 8UL,   8UL,   7UL,   6UL,   6UL,  17UL,   8UL,  17UL,   8UL,  19UL,  19UL, },
/*   6 */   { 8UL,   8UL,   7UL,   8UL,   8UL,  17UL,   8UL,  17UL,   8UL,  19UL,  19UL, },
/*   7 */   { 8UL,   8UL,   7UL,   8UL,   8UL,  16UL,  12UL,  16UL,   8UL,  19UL,  19UL, },
/*   8 */   { 8UL,   8UL,   8UL,   8UL,   8UL,  17UL,  10UL,  17UL,   8UL,  19UL,  19UL, },
/*   9 */   { 9UL,   9UL,   9UL,   9UL,   9UL,   9UL,   9UL,  19UL,   9UL,  18UL,   9UL, },
/*  10 */   { 8UL,   8UL,   8UL,   8UL,   8UL,  17UL,  10UL,  17UL,   8UL,  19UL,  19UL, },
/*  11 */   { 8UL,   8UL,   8UL,   8UL,   8UL,  15UL,  11UL,  15UL,   8UL,  19UL,  19UL, },
/*  12 */   { 8UL,   8UL,   8UL,   8UL,   8UL,  16UL,  12UL,  16UL,   8UL,  19UL,  19UL, },
};

static char OBUF[OUTPUT_WIDTH + 2] = "OUTPUT BUFFER IS UNINITIALIZED"; // the actual one-line output buffer
static unsigned long int obuf_next = 1UL;  // next byte of output buffer to use
static unsigned long int curzone = 1UL;    // current zone to use for output
static char EBUF[OUTPUT_WIDTH + 2] = "ERROR BUFFER IS UNINITIALIZED"; // the actual one-line output buffer
static unsigned long int ebuf_next = 1UL;  // next byte of output buffer to use
static unsigned long int curezone = 1UL;   // current zone to use for output

#ifdef __clang__
#define NOKLONE
#else
#define NOKLONE noclone,
#endif
#define WRITE(WHERE,SPTR,SLEN,retval) \
      asm volatile ( \
            "syscall" \
            : "=a" (retval) \
            : "0"(__NR_write), "D"(WHERE), "S"(SPTR), "d"(SLEN) \
            : "cc", "rcx", "r11", "memory" \
      );

static char *uitoa(unsigned long int n) __attribute__((noinline, NOKLONE, used));
static void mystrcpy(char *dest, const char *source) __attribute__((noinline, NOKLONE, used));
static unsigned long int mystrlen(const char *s) __attribute__((noinline, NOKLONE, used));
static int mystrcmp(const char *left, const char *right) __attribute__((noinline, NOKLONE, used));
static void mytrim(char *s) __attribute__((noinline, NOKLONE, used));
static char parseinput_case18(const char *buffer, unsigned long int *curstate, unsigned long int *bufpos, unsigned long int *tokepos, unsigned long int *itemcount, char *tokestring);
static unsigned char parseinput(const char buffer[], const unsigned long int buflen) __attribute__((noinline, NOKLONE, used));
static unsigned long int doinput(char *infmt) __attribute__((noinline, NOKLONE, used));
static signed long int INPUT(char *buffer, unsigned long int buflen) __attribute__((noinline, NOKLONE, used));
static signed int isterminal(int fd) __attribute__((noinline, NOKLONE, used));
static signed int ISTERMINAL = -1;
void initbuffer(char *OBUF, unsigned long int *obuf_next, unsigned long int *curzone) __attribute__((noinline, NOKLONE, used));
void outputbuffer(char *OBUF, unsigned long int *obuf_next, unsigned long int *curzone) __attribute__((noinline, NOKLONE, used));
void appendbuffer(char *OBUF, unsigned long int *obuf_next, unsigned long int *curzone, const char *s) __attribute__((noinline, NOKLONE, used));
static void process_stack(char *fmt);

//
// This function will convert the unsigned integer value passed in the n
// parameter into a string and return a pointer to that string.
// NOTE:The string is recycled every time, so make a copy if you need it.
//
static char *uitoa(unsigned long int n) {
  static char buffer[20];
  unsigned char pos;
  unsigned long int remainder;

  pos=19;
  buffer[pos]=0;
  do {
    remainder = n % 10U;
    n = n / 10U;
    // depends on ASCII
    buffer[--pos]=(char)(remainder+'0');
  } while (n>0);
  return buffer+pos;
}

//
// This procedure will initialize the output system.  It will first initialize
// the output buffer to all spaces.  Then it will set the current output
// position in the buffer to 1, and set the current output zone to 1.
// Columns and zones are 1-based.
//
void initbuffer(
    char *POBUF,
    unsigned long int *pobuf_next,
    unsigned long int *pcurzone) {
  for (unsigned long int i = 0UL; i < OUTPUT_WIDTH; i++) // initialize output buffer contents
    POBUF[i] = ' ';                    // to all spaces
  POBUF[OUTPUT_WIDTH] = (char)0;       // terminate the output buffer
  *pobuf_next = *pcurzone = 1UL;       // set output position to first column and first zone
  return;
}

//
// This procedure will first terminate the output buffer contents so that
// it is a valid ASCIIZ string.  Then it writes the output buffer contents
// to STDOUT, followed by a newline.  If either write fails, the program
// will abort.  If the writes are successful, then the output buffer is
// re-initialized by calling the initbuf() procedure.
//
void outputbuffer(
    char *POBUF,
    unsigned long int *pobuf_next,
    unsigned long int *pcurzone) {
  POBUF[OUTPUT_WIDTH] = (char)0;
  signed long int ret = 0;
  unsigned long int w = OUTPUT_WIDTH;

  do {
    WRITE(STDOUT,(POBUF+OUTPUT_WIDTH-w),w,ret);
    w -= ret;
  } while ((w > 0L) && (ret > 0L));
  if (ret < 0L)                                 // if the write fails
    abort();                                    // abort the program (no error can be displayed)
  WRITE(STDOUT,"\n",1U,ret);
  if (ret < 0L)                                 // if the write fails
    abort();                                    // abort the program (no error can be displayed)
  initbuffer(POBUF, pobuf_next, pcurzone);      // re-initialize buffer
  return;
}

//
// This procedure will cause the ASCIIZ string specified by the s parameter
// to be output to STDOUT through the buffered print system.
// Columns and zones are 1-based.
//
void appendbuffer(char *POBUF,
    unsigned long int *pobuf_next,
    unsigned long int *pcurzone,
    const char *s) {
  unsigned long int slen;    // length of ASCIIZ string s
  unsigned long int i = 0UL; // index of position in ASCIIZ string s, zero-based
  unsigned long int newpos;  // column position of start of current zone

  if (!s) {                                         // if argument was bogus then
    signed long int ret;

    WRITE(STDERR,"NULL pointer sent to appendbuf\n",32U,ret);
    abort();
  }
  newpos = ((*pcurzone - 1UL) * ZONE_WIDTH) + 1UL;  // calculate start columnt of current zone
  if (*pobuf_next < newpos)                         // if output position is less than current zone then
    *pobuf_next = newpos;                           // move to start of current zone
  slen = mystrlen(s);                               // calculate length of string s
  if ((*pobuf_next > 1UL) &&                        // if the output position is not the first column
      (*pobuf_next + slen - 1UL > OUTPUT_WIDTH))    // and s will not fit on this line then
    outputbuffer(POBUF, pobuf_next, pcurzone);      // output buffer and a newline and move to column 1
  while (i < slen) {                                // while there are characters (bytes) in string s
    POBUF[(*pobuf_next)++ - 1] = s[i++];            // copy the character from s to the output buffer
    if ((i < slen) && (*pobuf_next > OUTPUT_WIDTH)) // if the output buffer is full but we are not at the end of s
      outputbuffer(POBUF, pobuf_next, pcurzone);    // output buffer and a newline and move to column 1
  }
  *pcurzone = ((*pobuf_next - 1UL) / ZONE_WIDTH) + 1UL;  // update curzone zone number to next available zone
  return;
}

// returns 1 if file specified by fd is a tty, 0 otherwise
static signed int isterminal(
    int fd) {                    // file descriptor
  signed long int ret;
  static unsigned char buf[144] = { 0 };            // struct stat buf;

  asm volatile (
     "syscall"
     : "=a" (ret)
     : "0"(__NR_fstat), "D"(STDIN), "S"(&buf)
     : "cc", "rcx", "r11", "memory"
  );
  // I assume it cannot actually fail, but ...
  // if (ret < 0L) errno = -ret;
  // buf + 24 is buf. st_mode
  return ((*(unsigned int *)(buf + 24) & S_IFMT) == S_IFCHR) ? 1 : 0;
}

// ASCIIZ string copy routine
// Copy the ASCIIZ string passed in source buffer to the
// dest buffer.  The dest buffer must be large enough, and
// it cannot be NULL.
static void mystrcpy(
    char *dest,                  // pointer to ASCIIZ string destination buffer
    const char *source) {        // pointer to ASCIIZ string source buffer
  while ((*dest++ = *source++))
    ;  // do nothing, everything is a side-effect of while condition
}

// ASCIIZ string length routine
// this will return the number of bytes in the ASCIIZ string passed
// in the s parameter.  zero is returned for two cases:
// s is NULL, or the first byte of S is zero.
static unsigned long int mystrlen(
    const char *s) {             // pointer to ASCIIZ string buffer
  unsigned long int n = 0UL;     // number of bytes in ASCIIZ string in s, initialize to zero

  while (*s++)                   // while the next byte in s is not the end of string
    ++n;                         // add one to the counter n and move to the next byte
  return n;                      // return number of bytes in ASCIIZ string in s
}

//
// ASCIIZ string compare routine
// this will compare two ASCIIZ strings stored in the left and right
// buffers and return a value indicating whether the left is less than,
// equal to, or greater than the right.  This will return a number less
// than zero if ASCIIZ string stored in the left buffer is less than
// the ASCIIZ string stored in the right buffer, zero if they are equal,
// or a positive number if the ASCIIZ string stored in the left buffer
// is greater than the ASCIIZ string stored in the right buffer.
//
static int mystrcmp(
    const char *left,            // pointer to left-hand-side ASCIIZ string buffer
    const char *right) {         // pointer to right-hand-side ASCIIZ string buffer
  while (*left  && *right && (*left == *right))        // while the left string still has a non-zero byte and
                                                       // the right string still has a non-zero byte and
                                                       // the correspnding bytes are equal
     left++, right++;                                  // move to the next byte in both strings
  return (*left - *right);                             // return the result
}

//
// ASCIIZ string trim (remove leading and trailing spaces
//                     inplace)
// s is an input ASCIIZ string that we modify in place (destructive)
//
static void mytrim(
    char *s) {              // pointer to non-NULL ASCIIZ string buffer to trim
  unsigned long int sindex; // index from front of string
  unsigned long int eindex; // index from end of string
  unsigned long int l;      // length of string after trim

  if (!s[0])                // don't do anything if the string is empty
    return;
                            // first we go forward
  sindex = 0UL;             // start with first byte
  while ((s[sindex]) &&       // while it is not the end of the string
         ((' ' == s[sindex]) || ('\t' == s[sindex])))  // but the current byte is whitespace
    ++sindex;               // move to the next byte
  eindex = sindex;          // assume first non-blank is final non-blank
  while (s[eindex])         // while it is not the end of the string
    ++eindex;               // move to the next byte
  --eindex;                 // ok, that last move was past the end, so undo it
                            // now we back up
  while ((eindex > sindex) && // while we are still in the part that is not leading whitespace
         ((' ' == s[eindex]) || ('\t' == s[eindex]))) // and we are still in trailing whitespace
    --eindex;               // move to the previous byte
  l = eindex - sindex + 1UL;  // calculate length of string after trim
  for (unsigned long int i = 0UL; i < l; ++i) // for each final destination byte
    s[i] = s[i + sindex];   // move source byte into place
  s[l] = 0;                 // terminate string
}

// returns 1 to indicate we are done processing, 0 otherwise
static char parseinput_case18(
  const char *buffer,                               // text of current line we are processing
  unsigned long int *curstate,                      // current state in DFSM
  unsigned long int *bufpos,                        // current position in buffer[]
  unsigned long int *tokepos,                       // current position in tokestring[]
  unsigned long int *itemcount,                     // total number of tokens encountered so far
  char *tokestring) {                               // text of current token we are building

  ++(*itemcount);                                   // add 1 to the total number of items accepted so far
  // tricky - we must consume the quote for mytrim(), then remove it after
  tokestring[(*tokepos)++] = buffer[*bufpos];        // DO NOT INCREMENT bufpos HERE
  if (!((*itemcount & 1UL) == 1UL)) { // error
    appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: QUOTED STRING ENCOUNTERED WHEN COMMA OR NEWLINE EXPECTED"); // output error message
    outputbuffer(EBUF, &ebuf_next, &curezone);
    *curstate = 19UL;                               // and reject
    return 1;                                       // end processing buffer[]
  }
  tokestring[*tokepos] = 0;                         // terminate token string
  mytrim(tokestring);                               // remove any leading and trailing whitespace
  if (mystrlen(tokestring) > MAX_STRING_BYTES + 2U) {   // add 2 for the quotes that get removed
    appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: QUOTED STRING MAXIMUM SIZE IS ");
    appendbuffer(EBUF, &ebuf_next, &curezone, uitoa(MAX_STRING_BYTES));
    appendbuffer(EBUF, &ebuf_next, &curezone, " BYTES"); // output error message
    outputbuffer(EBUF, &ebuf_next, &curezone);
    *curstate = 19UL;                               // and reject
    return 1;                                       // end processing buffer[]
  }
#ifdef TROUBLE
  fprintf(stderr, "Length of tokestring '%s' is %lu\n", tokestring, mystrlen(tokestring));
#endif
  if (tokestring[0])                                // if tokestring is not empty
     tokestring[mystrlen(tokestring) - 1U] = 0;     // remove trailing quote now
  (*bufpos)++;                                      // and move to next byte
  if (rt_nput_stack_top >= MAX_INPUT_VARS) {        // if runtime INPUT stack is full
    appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: RUNTIME FAILURE: TOO MANY INPUT VARIABLES"); // output error message
    outputbuffer(EBUF, &ebuf_next, &curezone);
    *curstate = 19UL;                               // and reject
    return 1;                                       // end processing buffer[]
  }
  informat[rt_nput_stack_top] = 'S';                // record the fact that this token was a string in the 'found' format string
  // push token record onto runtime INPUT stack
  rt_nput_stack[rt_nput_stack_top].tokeid = T_QSTRING;// token ID
  mystrcpy(rt_nput_stack[rt_nput_stack_top++].toketext, tokestring + 1);  // token text, +1 to skip leading quote
  tokestring[0] = 0;                                // make tokestring[] an empty string
  *tokepos = 0UL;                                   // reset index into tokestring[] to beginning
  *curstate = 0UL;                                  // reset current state to start state for next token
  return 0;
}

// This boolean function will parse the input line buffer passed in
// buffer with the length passed inbuflen.  It will push the values
// obtained onto the rt_nput_stack and generate a new format string
// in informat.  returns true if the input is valid, false otherwise
// buffer is the buffer that was fetched from the user with a line input
// buflen is the length of the buffer in bytes
static unsigned char parseinput(
    const char buffer[],
    const unsigned long int buflen) {
  unsigned char done = 0;
  unsigned long int curstate = 0UL,     // current state in DFSM
                    bufpos = 0UL,       // current position in buffer[]
                    tokepos = 0UL,      // current position in tokestring[]
                    itemcount = 0UL;    // total number of tokens encountered so far
  char tokestring[MAX_INPUT_BYTES + 1]; // text of current token we are building (+1 for terminator)

  rt_nput_stack_top = 0UL;              // reset stack to empty
  informat[0] = 0;                      // reset format string to empty
  tokestring[tokepos] = 0;              // reset current token string to empty
  while (!done) {                       // while bytes remain in buffer[] to process
#ifdef TROUBLE
    unsigned long int oldstate = curstate; // save current state (becomes previous state)
#endif
    // move to next state
    curstate = states[curstate][character_class[(unsigned int)buffer[bufpos]]];
#ifdef TROUBLE
    fprintf(stderr, "transition from %lu to %lu on %u\n", oldstate, curstate, (unsigned int)buffer[bufpos]);
#endif
    switch (curstate) {                                     // check for final states
      case 13UL:                                            // accept comma token
          ++itemcount;                                      // add 1 to the total number of items accepted so far
          bufpos++;
          if (itemcount & 1UL) {                            // if an odd number of previous tokens have been processed
            appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: COMMA ENCOUNTERED WHEN DATA EXPECTED"); // output error message
            outputbuffer(EBUF, &ebuf_next, &curezone);
            done = 1;                                       // end processing buffer[]
            curstate = 19UL;                                // and reject
            break;
          }
          tokepos = 0UL;                                    // reset token string to empty
          tokestring[0] = 0;                                // make tokestring[] an empty string
          curstate = 0UL;                                   // reset  DFSM state to start state to search for next token
          break;
      case 14UL:                                            // accept end-of-line token
          ++itemcount;                                      // add 1 to the total number of items accepted so far
          if (itemcount & 1UL) {                            // if an odd number of previous tokens have been processed
            appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: NEWLINE ENCOUNTERED WHEN DATA EXPECTED"); // output error message
            outputbuffer(EBUF, &ebuf_next, &curezone);
            curstate = 19UL;                                // reject
          }
          informat[rt_nput_stack_top] = 0;                  // terminate token string
          done = 1;                                         // and end processing buffer[]
          break;
      case 15UL:                                            // accept integer
      case 16UL:                                            // accept real number
          ++itemcount;                                      // add 1 to the total number of items accepted so far
          if (!(itemcount & 1UL)) {                         // if an even number of previous tokens have been processed
            appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: NUMBER ENCOUNTERED WHEN COMMA OR NEWLINE EXPECTED"); // output error message
            outputbuffer(EBUF, &ebuf_next, &curezone);
            done = 1;                                       // end processing buffer[]
            curstate = 19UL;                                // and reject
            break;
          }
          tokestring[tokepos] = 0;                          // terminate token string
          if (mystrlen(tokestring) > 2 * MAX_STRING_BYTES) {
            appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: NUMERIC CONSTANT STRING MAXIMUM SIZE IS 36 BYTES"); // output error message
            outputbuffer(EBUF, &ebuf_next, &curezone);
            done = 1;                                       // end processing buffer[]
            curstate = 19UL;                                // and reject
            break;
          }
          if (rt_nput_stack_top >= MAX_INPUT_VARS) {        // if runtime INPUT stack is full
            appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: RUNTIME FAILURE: TOO MANY INPUT VARIABLES"); // output error message
            outputbuffer(EBUF, &ebuf_next, &curezone);
            done = 1;                                       // end processing buffer[]
            curstate = 19UL;                                // and reject
            break;
          }
          informat[rt_nput_stack_top] = 'N';                // mark this item as numeric in format string
          rt_nput_stack[rt_nput_stack_top].tokeid = T_REAL; // token ID
          mystrcpy(rt_nput_stack[rt_nput_stack_top++].toketext, tokestring); // token text
          tokestring[0] = 0;                                // make tokestring[] an empty string
          tokepos = 0UL;                                    // reset index into token string to the beginning
          curstate = 0UL;                                   // reset current state to start state for next token
          break;
      case 17UL:                                            // accept unquoted string
          ++itemcount;                                      // add 1 to the total number of items accepted so far
          if (!(itemcount & 1UL)) {                         // if an even number of previous tokens have been processed
            appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: UNQUOTED STRING ENCOUNTERED WHEN COMMA OR NEWLINE EXPECTED"); // output error message
            outputbuffer(EBUF, &ebuf_next, &curezone);
            done = 1;                                       // end processing buffer[]
            curstate = 19UL;                                // and reject
            break;
          }
          tokestring[tokepos] = 0;                          // terminate token string
          mytrim(tokestring);                               // remove any leading or trailing whitespace
          if (mystrlen(tokestring) > MAX_STRING_BYTES) {    // if input token text is too long
            appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: UNQUOTED STRING MAXIMUM SIZE IS ");
            appendbuffer(EBUF, &ebuf_next, &curezone, uitoa(MAX_STRING_BYTES));
            appendbuffer(EBUF, &ebuf_next, &curezone, " BYTES"); // output error message
            outputbuffer(EBUF, &ebuf_next, &curezone);
            done = 1;                                       // end processing buffer[]
            curstate = 19UL;                                // and reject
            break;
          }
#ifdef TROUBLE
          fprintf(stderr, "Length of tokestring '%s' is %lu\n", tokestring, mystrlen(tokestring));
#endif
          if (rt_nput_stack_top >= MAX_INPUT_VARS) {        // if runtime INPUT stack is full
            appendbuffer(EBUF, &ebuf_next, &curezone, "ERROR: RUNTIME FAILURE: TOO MANY INPUT VARIABLES"); // output error message
            outputbuffer(EBUF, &ebuf_next, &curezone);
            done = 1;                                       // end processing buffer[]
            curstate = 19UL;                                // and reject
            break;
          }
          informat[rt_nput_stack_top] = 'U';                // mark this item as an unquoted string in format string
          // push token record onto runtime INPUT stack
          rt_nput_stack[rt_nput_stack_top].tokeid = T_UQSTRING;  // token ID
          mystrcpy(rt_nput_stack[rt_nput_stack_top++].toketext, tokestring); // token text
          tokestring[0] = 0;                                // make tokestring[] an empty string
          tokepos = 0UL;                                    // reset index into token string to the beginning
          curstate = 0UL;                                   // reset current state to start state for next token
          break;
      case 18UL:                                            // accept quoted string
          done=parseinput_case18(buffer,&curstate,&bufpos,&tokepos,&itemcount,tokestring);
          break;
      case 19UL:                                            // reject
          done = 1;                                         // so end processing buffer[]
          break;
      default:                                              // this is not a final state or error state so
          tokestring[tokepos++] = buffer[bufpos++];         // add current byte to tokestring[]
          if ((tokepos > MAX_INPUT_BYTES) ||
              (bufpos > buflen)) {                          // but if tokestring[] is too long
            curstate = 19UL;                                // reject
            done = 1;                                       // and end processing buffer[]
          }
          break;
    }
  }
#ifdef TROUBLE
  fprintf(stderr, "%s\n", informat);
#endif
  return (14UL == curstate);                                // return true if everything is OK and last token was an end-of-line
                                                            // otherwise return false
}

// Line input routine (get one line of input from STDIN)
// This had to be one one byte at a time in order to work with redirection in the
// shell.  We MUST stop when a newline is encountered.
// buffer is a pointer to the INPUT line buffer
// buflen is the length of buffer
// returns number of bytes in this line of input on succes, -1 on error
static signed long int INPUT(
    char *buffer,
    unsigned long int buflen) {
  char *tbuffer = buffer,                                   // pointer to the start of the actual input buffer
       *bufmax = buffer + buflen;                           // pointer to end of input buffer
  signed long int ret = 0;

  // read one byte at a time so we don't read too far
  do {                                                      // repeat
                                                            // read one byte
    asm volatile (
        "syscall"
        : "=a" (ret)
        : "0"(__NR_read), "D"(STDIN), "S"(tbuffer), "d"(1UL)
        : "cc", "rcx", "r11", "memory"
    );
    if (ret < 1L) {
      outputbuffer(OBUF, &obuf_next, &curzone);
      appendbuffer(EBUF, &ebuf_next, &curezone,
                   "EOF ON INPUT - PROGRAM TERMINATED IN AN ERROR STATE");
      outputbuffer(EBUF, &ebuf_next, &curezone);
                                                            // exit program with an error code
      asm volatile (
        "syscall"
        :
        : "a"(__NR_exit), "D"(EXIT_FAILURE)
        : "rcx", "r11"
      );
    }
    if ('\n' == *tbuffer) break;                            // if this byte was a newline, break out of loop
    tbuffer++;
  } while (tbuffer < bufmax);                               // while more bytes of input exist
  *tbuffer = 0;                                             // terminate the input buffer
  if (!ISTERMINAL) {                                        // if not a tty then we need to echo here ....
    unsigned long int rez, start;
    unsigned long int wmax, wleft;
    start = obuf_next - 1;
    wmax = wleft = OUTPUT_WIDTH - obuf_next + 2;
    appendbuffer(OBUF, &obuf_next, &curzone, buffer);
    OBUF[OUTPUT_WIDTH] = '\n';
    OBUF[OUTPUT_WIDTH + 1] = 0;
    do {
      WRITE(STDOUT,(OBUF+start+wmax-wleft),wleft,ret);
      wleft -= ret;
    } while ((wleft > 0L) && (ret > 0L));
  }
  initbuffer(OBUF, &obuf_next, &curzone);
  return (unsigned long int)(tbuffer - buffer);               // return the number of bytes in this line of input
}

static void process_stack(
    char *fmt) {
  unsigned long int lhave = mystrlen(informat);      // get number of items in format string (1 type byte/item)

  for (unsigned long int i = 0UL; i < lhave; ++i) {  // for each item
    if (('S' == fmt[i]) || ('U' == fmt[i])) {        // if we need a string
      if ('N' == informat[i]) {                      // and we have a number then
        if (mystrlen(rt_nput_stack[i].toketext) > MAX_STRING_BYTES) {    // if the token was too long then
           appendbuffer(EBUF, &ebuf_next, &curezone, "INVALID INPUT: STRING EXCEEDS ");
           appendbuffer(EBUF, &ebuf_next, &curezone, uitoa(MAX_STRING_BYTES));
           appendbuffer(EBUF, &ebuf_next, &curezone, " BYTES");       // output error message
           outputbuffer(EBUF, &ebuf_next, &curezone);
           continue;                                 // and keep going, since we need all types in informat to compare against fmt
        }                                            // and we want to test later entries that might be OK
        informat[i] = fmt[i];                        // OK, change found type to string
        if ('S' == fmt[i])
          rt_nput_stack[i].tokeid = T_QSTRING;       // and change type of item on stack to string
        else
          rt_nput_stack[i].tokeid = T_UQSTRING;      // and change type of item on stack to string
      }
    }
    if (('U' == fmt[i]) && ('S' == informat[i])) {   // if we want an unquoted string and got a quoted string
      informat[i] = 'U';                             // change type of item to unquoted string
      rt_nput_stack[i].tokeid = T_UQSTRING;
    }
  }
  return;
}

//
// When this returns you definitely have the right stuff
// in the input queue.  fmt is the format string containg
// 1 type byte per item.  Type bytes can be
// U: unquoted string
// S: quoted string
// N: number (floating point or integer, stored as floating point)
//
static unsigned long int doinput(
    char *fmt) {
  unsigned long int tries = 0UL,                           // number of times the user has input a line of items
                    maxtries = 5UL;                        // maximum number of tries the user can have

  do {                                                     // repeat
    char buffer[MAX_INPUT_BYTES + 1] = { 0 };              // INPUT line buffer (+1 for terminator)
    signed long int bytesread,                             // number of bytes returned in buffer after the call to INPUT()
                    ret = 0;                               // write return value
    unsigned long int wmax, wleft,                         // total bytecount to write, bytecount remaining to write
                      needcount;                           // number of items user needs to INPUT

    ++tries;                                               // increment try count
    appendbuffer(OBUF, &obuf_next, &curzone, "? ");        // print prompt
    wmax = wleft = obuf_next - 1UL;                        // we want to write all bytes in the buffer
    do {
      WRITE(STDOUT,(OBUF+wmax-wleft),wleft,ret);
      wleft -= ret;
    } while ((wleft > 0L) && (ret > 0L));
    bytesread = INPUT(buffer, MAX_INPUT_BYTES);            // call INPUT() function to get a line of input and store it in buffer
    if (bytesread < 0L) {                                  // if there was no input available
      appendbuffer(EBUF, &ebuf_next, &curezone, "EOF ON INPUT");
      outputbuffer(EBUF, &ebuf_next, &curezone);
      return 0UL;                                          // and we give up
    }
    buffer[bytesread++] = '\n';                            // add trailing EOL required by parseinput()
    buffer[bytesread] = 0;                                 // and terminate
    if (parseinput(buffer, bytesread)) {                   // scan buffer into tokens using parseinput() function
      unsigned long int lhave;
      if (mystrcmp(fmt, informat) == 0)                    // if parse was OK and types match desired types and number of items is correct
        return 1UL;                                        // we are done
      lhave = mystrlen(informat);                          // get number of items in format string (1 type byte/item)
      if (rt_nput_stack_top == lhave) {                    // if the number of items is correct then
        process_stack(fmt);
        if (mystrcmp(fmt, informat) == 0)                  // after all checks, if the input format and output
          return 1UL;                                      // format are compatible we are done
      }
    }
    initbuffer(OBUF, &obuf_next, &curzone);
    appendbuffer(EBUF, &ebuf_next, &curezone,
                 "INVALID INPUT: EXPECTED ");              // begin display of error message
    needcount = mystrlen(fmt);                             // record number of INPUT items that were required
    for (unsigned long int k = 0UL; k < needcount; ++k) {  // for each required INPUT item
      if (k > 0UL)                                         // if it is not the first item,
        appendbuffer(EBUF, &ebuf_next, &curezone, ",");    // output a comma separator
      switch(fmt[k]) {
        case 'S':
          appendbuffer(EBUF, &ebuf_next, &curezone, "QUOTED STRING");
          break;
        case 'N':
          appendbuffer(EBUF, &ebuf_next, &curezone, "NUMBER");
          break;
        case 'U':
          appendbuffer(EBUF, &ebuf_next, &curezone, "UNQUOTED STRING");
          break;
        default:
          appendbuffer(EBUF, &ebuf_next, &curezone, "UNKNOWN FORMAT!");
          break;
      }
    }
    outputbuffer(EBUF, &ebuf_next, &curezone);
  } while (tries < maxtries);                            // until number of tries exceeds maxtries
  return 0UL;                                            // and then return failure indicator
}

// Self-test code
#ifdef UNIT_TEST
int main(void) {
  char buffer[MAX_INPUT_VARS + 1U] = { 0 };
  signed long int ret = 0;                               // write return value
  unsigned long int wmax, wleft;                         // total bytecount to write, bytecount remaining to write

  initbuffer(OBUF, &obuf_next, &curzone);
  initbuffer(EBUF, &ebuf_next, &curezone);
  ISTERMINAL = isterminal(STDIN);
  appendbuffer(OBUF, &obuf_next, &curzone, "Enter the format string of N, S and U:");
  wmax = wleft = obuf_next - 1UL;                        // we want to write all bytes in the buffer
  do {
    WRITE(STDOUT,(OBUF+wmax-wleft),wleft,ret);
    wleft -= ret;
  } while ((wleft > 0L) && (ret > 0L));
  INPUT(buffer, MAX_INPUT_VARS);
  fprintf(stderr, "expected format string buffer is '%s'\n", buffer);
  appendbuffer(OBUF, &obuf_next, &curzone, "PROMPT STRING GOES HERE");
  if (doinput(buffer)) {
    unsigned long int i;                 // loop index to iterate over stack contents

    fprintf(stderr, "item count=%lu\n", rt_nput_stack_top);
    for (i = 0UL; i < rt_nput_stack_top; ++i) {
      switch(rt_nput_stack[i].tokeid) {
        case T_REAL:
          fprintf(stderr, "Token #%lu: T_REAL, \"%s\"\n", i, rt_nput_stack[i].toketext);
          break;
        case T_QSTRING:
          fprintf(stderr, "Token #%lu: T_QSTRING, \"%s\"\n", i, rt_nput_stack[i].toketext);
          break;
        case T_UQSTRING:
          fprintf(stderr, "Token #%lu: T_UQSTRING, \"%s\"\n", i, rt_nput_stack[i].toketext);
          break;
        default:
          fprintf(stderr, "Token #%lu: %u, \"%s\"\n", i, rt_nput_stack[i].tokeid, rt_nput_stack[i].toketext);
          break;
      }
    }
    return EXIT_SUCCESS;
  }
  fprintf(stderr, "doinput(\"%s\") failed\n", buffer);
  return EXIT_FAILURE;
}
#endif
