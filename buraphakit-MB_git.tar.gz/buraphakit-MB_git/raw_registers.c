//
// raw_registers.c - This is the file containing the register management code
//                   for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include "globals.h"
#include "error_messages.h"
#include "raw_registers.h"

#define XMM_REGCOUNT 16                    // number of xmm registers available
#define XMM_REGISTER_NAME_WIDTH 7          // '%xmm??' + 1 byte terminator
static struct floatreg_record {
  char name[XMM_REGISTER_NAME_WIDTH];      // xmm register name (like xmm0, xmm1, etc.)
  bool busy;                               // true if register is allocated, false otherwise
} floatreg_master[XMM_REGCOUNT];           // array of xmm (floating point) register information
static unsigned int floatregs_stack[XMM_REGCOUNT - 1U];// the actual register allocation stack, which
                                                       // just holds integers (xmm4 is stored as 4, etc.)
                                                       // and xmm0 is NOT in this stack....
static unsigned int floatregs_stack_tos = XMM_REGCOUNT - 1U;  // top of stack pointer for floatregs_stack[]
                                                       // points to next slot on stack `above' topmost item
static unsigned int floatregs_max_used = 0U; // highest register number used so far IN THE ENTIRE PROGRAM
                                             // so this is not reset in init_floatregs()

//
// This function will return the register slot number (index into
// floatreg_master[]) for the xmm register whose text name is regname.  Returns
// the index number on success, otherwise the compiler halts.
//
static unsigned int reg2slotno(
    const char *regname) {                 // pointer to text name of xmm register
  char *endptr = NULL;                     // pointer to first unconverted byte in input string
  unsigned long int tuival;                // temporary to hold return value of strtoul()
  char *s = (char *)regname + 4;           // register number for the register specified by regname
                                           // by skipping over leading '%xmm'

  errno = 0;                               // reset error flag to OK
  tuival = strtoul(s, &endptr, 10);        // attempt the conversion
  if (errno != 0)
    ICE(__FILE__, __func__, __LINE__, emsg[17], __func__, s, errno, tuival);
  if (endptr != s + strnlen(s, 3))         // if there was junk in the string
                                           // after the converted part then
    ICE(__FILE__, __func__, __LINE__, emsg[18], __func__, s, errno, tuival);
  return (unsigned int)tuival;
}

//
// Procedure to initialize xmm register stacks for register allocation
//
void init_floatregs(void) {
  unsigned int i;                          // loop index to loop over all xmm registers

  for (i = 0U; i < XMM_REGCOUNT; ++i) {
    snprintf(floatreg_master[i].name, XMM_REGISTER_NAME_WIDTH, "%%xmm%u", i);  // 0, 1, 2, 3, ..., 15
    floatreg_master[i].name[XMM_REGISTER_NAME_WIDTH - 1U] = 0;
    floatreg_master[i].busy = false;
  }
  // register zero is reserved for function calls, etc.
  floatreg_master[0].busy = true;
  for (i = 0U; i < XMM_REGCOUNT - 1U; ++i) {
    floatregs_stack[i] = XMM_REGCOUNT - i - 1;   // 15, 13, 12, 11, ..., 1
  }
  floatregs_stack_tos = XMM_REGCOUNT - 1U;
  return;
}

//
// Procedure to dump the xmm register stacks used for register allocation for
// diagnostic purposes.
//
void dump_floatregs(void) {
  unsigned int i;                          // loop index variable to iterate over register slots
                                           // (indices) in floatreg_master

  fprintf(stderr,
          "XMM_REGCOUNT=%u, floatregs_stack_tos=%u\n",
          XMM_REGCOUNT,
          floatregs_stack_tos);
  fprintf(stderr, "\n         actual stack\n");
  for (i = 0U; i < XMM_REGCOUNT - 1U; ++i) {
    unsigned int regno = XMM_REGCOUNT - i - 2U;
    if (regno < floatregs_stack_tos) {
      fprintf(stderr,
              "%2u: %%xmm%u %s\n",
              regno,
              floatregs_stack[regno],
              ((regno + 1U) == floatregs_stack_tos) ? "Top of stack" : "");
    } else {
      fprintf(stderr,
              "%2u:       %s\n",
              regno,
              ((regno + 1U) == floatregs_stack_tos) ? "Top of stack" : "");
    }
  }
  if (0U == floatregs_stack_tos)
    fprintf(stderr, "Stack is empty, no free registers are available!\n");
  fprintf(stderr,
          "\n"
          "  slot data\n"
          "regname busy?\n"
          "------- -----\n");
  for (i = 0U; i < XMM_REGCOUNT; ++i)
    fprintf(stderr,
            "%-7s %5s\n",
            floatreg_master[i].name,
            floatreg_master[i].busy ? "true": "false");
  fprintf(stderr, "Highest numbered register used is %u\n", floatregs_max_used);
  return;
}

//
// This function will allocate a free register and return the name to the
// caller.  If it cannot, the compiler halts with an error message.
//
const char *allocate_register(void) {
  unsigned int slotno;                     // integer slot number in floatreg_master[]

  debug_printf("allocate_register() ");
  if (0U == floatregs_stack_tos)
    ICE(__FILE__, __func__, __LINE__, emsg[20], __func__);
  slotno = floatregs_stack[--floatregs_stack_tos];
  floatreg_master[slotno].busy = true;
  if (slotno > floatregs_max_used)
    floatregs_max_used = slotno;
  debug_printf("returns '%s' with max as '%s'\n", floatreg_master[slotno].name, floatreg_master[floatregs_max_used].name);
  return floatreg_master[slotno].name;
}

//
// This procedure will deallocate the register whose name was passed in the
// regname parameter.  If it cannot, the compiler halts with an error message.
//
void deallocate_register(
    const char *regname) {                 // pointer to ASCIIZ string with name
                                           // of register to deallocate
  unsigned int slotno;                     // integer slot number in floatreg_master[]

  debug_printf("deallocate_register('%s')\n", regname);
  if (floatregs_stack_tos > XMM_REGCOUNT - 1U)
    ICE(__FILE__, __func__, __LINE__, emsg[21], __func__, floatregs_stack_tos, XMM_REGCOUNT);
  slotno = reg2slotno(regname);
  if (!floatreg_master[slotno].busy)
    ICE(__FILE__, __func__, __LINE__, emsg[209], regname);
  floatreg_master[slotno].busy = false;
  floatregs_stack[floatregs_stack_tos++] = slotno;
  return;
}

#ifdef UNIT_TEST
int main(void) {
  char *regname1 = NULL,
       *regname2 = NULL,
       *regname3 = NULL,
       *regname[XMM_REGCOUNT - 1U];
  unsigned int i;

  printf("Initialize register system, %%xmm0 always reserved\n");
  fflush(stdout);
  init_floatregs();
  dump_floatregs();
  printf("\n*******************************\n\n");
  fflush(stdout);

  printf("Allocate three registers ");
  fflush(stdout);
  regname1 = (char *)allocate_register();
  regname2 = (char *)allocate_register();
  regname3 = (char *)allocate_register();
  printf("'%s,%s, and %s': success!\n", regname1, regname2, regname3);
  fflush(stdout);
  dump_floatregs();
  printf("\n*******************************\n\n");
  fflush(stdout);

  printf("Deallocate the second allocated register, '%s': ", regname2);
  fflush(stdout);
  deallocate_register(regname2);
  printf("success!\n");
  fflush(stdout);
  dump_floatregs();
  printf("\n*******************************\n\n");
  fflush(stdout);

  printf("Deallocate the remaining two registers, '%s' and '%s': ", regname1, regname3);
  fflush(stdout);
  deallocate_register(regname1);
  deallocate_register(regname3);
  printf("success!\n");
  fflush(stdout);
  dump_floatregs();
  printf("\n*******************************\n\n");
  fflush(stdout);

  printf("Allocate all registers: ");
  fflush(stdout);
  for (i = 0U; i < XMM_REGCOUNT - 1U; ++i)
    regname[i] = (char *)allocate_register();
  printf("success!\n");
  fflush(stdout);
  dump_floatregs();
  printf("\n*******************************\n\n");
  fflush(stdout);

  printf("Deallocate all registers: ");
  fflush(stdout);
  for (i = 0U; i < XMM_REGCOUNT - 1U; ++i)
    deallocate_register(regname[i]);
  printf("success!\n");
  fflush(stdout);
  dump_floatregs();

  return EXIT_SUCCESS;
}
#endif
