#ifndef OPTIMIZER_H
#define OPTIMIZER_H
//
// optimizer.h - This is the file with the header for optimizer.c
//               for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <inttypes.h>
#include <stdbool.h>
#include "tree.h"

void fold_numeric_expression(
    treenode *node);                 // Pointer to the root AST node for this numeric expression
#endif
