#ifndef SHA256_H
#define SHA256_H
int get_sha256sum(unsigned char *data, unsigned long int datacount, unsigned char *sumbuf);
#endif
