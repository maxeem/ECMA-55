//
// globals.c - This is the file containing global variables
//             for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <termios.h>
#include <unistd.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <ctype.h>
#include "globals.h"
#include "error_messages.h"
#include "hexdump2.h"

const char version[] = "2.40";    // version number for this compiler
// NOTE: In the code, normally 1 is subtracted from the SIGNIFICANCE value since
// David M. Gay's g_fmt() expects the number of digits after the decimal point
// for normalized output.
const uint32_t
  // number of significant digits to output for display with narrow output mode
  SIGNIFICANCE_WIDTH_NARROW_OUTPUT = 7U,
  // number of significant digits to output for display with wide output mode
  SIGNIFICANCE_WIDTH_WIDE_OUTPUT = 18U,
  // number of significant digits to use with g_fmt() internally when processing
  // floating point constants.  It turns out there are very bad effects on 32
  // bit results if this is too small.
  SIGNIFICANCE_WIDTH_INTERNAL = 22U,
  // maximum permitted subscript value for array indexing
  MAX_SUBSCRIPT_VALUE = 10000000U,
  // depth of runtime operand stack for string expression evaluation
  MAX_STRING_OPERANDS = 4U,
  // maximum permitted Minimal BASIC line number
  MAXLINENO = 9999U,
  // maximum permitted column width for input Minimal BASIC source code
  MAXCOLUMN = INPUT_WIDTH + 1U,
  // maximum number of line number jump targets for an ON .. GOTO statement
  MAXONJUMPTARGETS = 50U,
  // length of buffer for g_fmt() conversions
  FLOAT_BUFFER_LEN = 41U,
  // Maximum possible number of digits in line number
  MAX_LINENO_DIGITS = 4U;
const char
  // width of exponent field for display with narrow output mode
  EXRAD_NARROW_OUTPUT = 2,
  // width of exponent field for display with wide output mode
  EXRAD_WIDE_OUTPUT = 3,
  // maximum optimization level is -O3
  MAX_OPTIMIZATION_LEVEL = 3;
unsigned long int
  // length of error message buffers + 1 byte terminator
  ERROR_BUFFER_LEN = 81UL;
const unsigned long int
  // Maximum number of letters in a built-in function name
  MAX_BIFNAME_LEN = 20UL;
const unsigned int
  // maximum number of active nested FOR loops
  FORSTACK_DEPTH = 100U,
  // maximum number of active nested GOSUBs permitted
  MAX_GOSUB_DEPTH = 50U,
  // maximum number of bytes in a string (without terminator)
  MAX_STRING_BYTES = 18U,
  // maximum width of a generated label
  // .LLINE???? where ???? are the MAX_LINENO_DIGITS digits right justified zero padded on the left
  MAX_LABELWIDTH = 10U, // 6U + MAX_LINENO_DIGITS(4)
  // 2 bytes + 1 byte terminator
  MAX_VARNAME_LEN = 3U;
bool
  // if true, SSE4.1 instructions can be used
  use_SSE4_1             = false,
  // if true, array indexes begin at 1, otherwise they begin at 0
  base_is_one            = false,
  // if true, eXtensions such as AND, OR, NOT, EXIT FOR are allowed
  extensions             = false,
  // if true, runtime library code for the ACOS() function must be emitted
  need_ACOS               = false,
  // if true, we must include code for add operator
  need_ADD               = false,
  // if true, we must library code for the ANGLE function must be emitted
  need_ANGLE             = false,
  // if true, runtime library code for the ASIN() function must be emitted
  need_ASIN               = false,
  // if true, runtime library code for the ATN() function must be emitted
  need_ATN               = false,
  // if true, we must output a .bss section for floating point variables
  need_BSS_numeric       = false,
  // if true, we must output a .bss section for string variables
  need_BSS_string        = false,
  // if true, runtime library code for the CEIL() function must be emitted
  need_CEIL              = false,
  // if true, runtime library code for the COS() function must be emitted
  need_COS               = false,
  // if true, runtime library code for the COSH() function must be emitted
  need_COSH              = false,
  // if true, we must include code for divide operator
  need_DIVIDE            = false,
  // if true, runtime library code for the DATE numeric function must be emitted
  need_DATE              = false,
  // if true, runtime library code for the DATE$ string function must be emitted
  need_DATES             = false,
  // if true, runtime library code for the EXP() function must be emitted
  need_EXP               = false,
  // if true, we must include code for FOR/NEXT support
  need_FORNEXT           = false,
  // if true, runtime library code for the INPUT statement must be emitted
  need_INPUT             = false,
  // if true, code for the INPUT statement for array numeric 1D variables
  // must be emitted
  need_INPUT_NAVAR_1D    = false,
  // if true, code for the INPUT statement for array numeric 2D variables
  // must be emitted
  need_INPUT_NAVAR_2D    = false,
  // if true, code for the INPUT statement for scalar numeric variables
  // must be emitted
  need_INPUT_NVAR        = false,
  // if true, runtime library code for the INT() function must be emitted
  need_INT               = false,
  // if true, runtime library code for the IP() function must be emitted
  need_IP                = false,
  // if true, runtime library code for the FP() function must be emitted
  need_FP                = false,
  // if true, runtime library code for the MOD() function must be emitted
  need_MOD                = false,
  // if true, runtime library code for the REMAINDER() function must be emitted
  need_REMAINDER                = false,
  // if true, we must include code to load real numbers
  need_LOADREAL          = false,
  // if true, runtime library code for the LOG() function must be emitted
  need_LOG               = false,
  // if true, runtime library code for the LOG10() function must be emitted
  need_LOG10             = false,
  // if true, runtime library code for the LOG2() function must be emitted
  need_LOG2              = false,
  // if true, we must include code for multiply operator
  need_MULTIPLY          = false,
  // if true, we must include ON..GOTO support
  need_ONGOTO            = false,
  // if true, we must include code for power operator
  need_POWER             = false,
  // if true, runtime library code for the PRINT statement must be emitted
  need_PRINT             = false,
  // if true, runtime library code for the PRINT statement must be emitted
  need_PRINT_NUMERIC     = false,
  // if true, runtime library code for the READ statement must be emitted
  need_READSTMT          = false,
  // if true, runtime library code for the READ statement for numeric 1D arrays
  // must be emitted
  need_READSTMT_NAVAR_1D = false,
  // if true, runtime library code for the READ statement for numeric 2D arrays
  // must be emitted
  need_READSTMT_NAVAR_2D = false,
  // if true, runtime library code for the READ statement for numeric scalars
  // must be emitted
  need_READSTMT_NVAR     = false,
  // if true, runtime library code for the READ statement for strings must be
  // emitted
  need_READSTMT_SVAR     = false,
  // if true, we must include code for 1D array read
  need_READ_1D           = false,
  // if true, we must include code for 2D array read
  need_READ_2D           = false,
  // if true, runtime library code for the RND function must be emitted
  need_RND               = false,
  // if true, runtime library code for the ROUND function must be emitted
  need_ROUND             = false,
  // if true, runtime library code for the SIN() function must be emitted
  need_SIN               = false,
  // if true, runtime library code for the SINH() function must be emitted
  need_SINH              = false,
  // if true, runtime library code for the SQR() function must be emitted
  need_SQR               = false,
  // if true, we must include code for strings and the string stack
  need_STRINGS           = false,
  // if true, we must include code for GOSUB/RETURN support
  need_SUBROUTINE        = false,
  // if true, we must include code for subtract operator
  need_SUBTRACT          = false,
  // if true, runtime library code for the TAB() function must be emitted
  need_TAB               = false,
  // if true, runtime library code for the TAN() function must be emitted
  need_TAN               = false,
  // if true, runtime library code for the TANH() function must be emitted
  need_TANH              = false,
  // if true, runtime library code for the TIME numeric function must be emitted
  need_TIME              = false,
  // if true, runtime library code for the TIME$ string function must be emitted
  need_TIMES             = false,
  // if true, runtime library code for user-defined functions must be emitted
  need_UDF               = false,
  // if true, we must include code for 1D array write
  need_WRITE_1D          = false,
  // if true, we must include code for 2D array write
  need_WRITE_2D          = false,
  // if true, runtime library code for the strcmp() function must be emitted
  need_strcmp            = false,
  // if true, runtime library code for the strcpy() function must be emitted
  need_strcpy            = false,
  // if true, after parse pretty print the code using the AST
  pretty_print           = false,
  // if true and pretty_print is true, renumber the code as part of pretty print
  renumber               = false,
  // if true, use 64 bit floating point math, otherwise use 32 bit floating
  //  point math
  use_double             = true,
  // if true, output in full precision in 132 columns, (-w switch)
  // otherwise use lower precision output in 80 columns
  // false matches the original standard and is the default
  use_double_output      = false,
  // if true, runtime library code for SEC() function must be emitted
  need_SEC               = false,
  // if true, runtime library code for CSC() function must be emitted
  need_CSC               = false,
  // if true, runtime library code for COT() function must be emitted
  need_COT               = false,
  // if true, verbose diagnostics should be displayed
  verbose                = false;
// optimization level, 0 indicates no optimization (not used at this time)
uint8_t optimization_level = 0U;
// high-level file handle for debug message output file
FILE *diagnostic_stream = NULL;
// low-level file handle for debug message output file
static int diagnostic_stream_fileno = -1;

//
// This procedure will display an Internal Compiler Error (ICE) message and
// then abort() the program.  It acts very much like printf, but its output
// is hard-wired to go to stderr, and it does not return at all.
//
noreturn void ICE(
    const char *filename,       // name of source code file
    const char *funcname,       // name of function
    const unsigned int lineno,  // line number in source code file filename
    const char *format,         // printf() style format string
    ...) {                      // zero or more arguments used by format
  va_list arg;

  fflush(stdout);
  tcdrain(STDERR_FILENO); // ensure all normal output is done
  fprintf(stderr, "ICE: %s:%u %s() ->", filename, lineno, funcname);
  va_start(arg, format);
  vfprintf(stderr, format, arg);
  va_end(arg);
  fflush(stderr);
  tcdrain(STDOUT_FILENO); // ensure all error output is done
  abort();
}

//
// This procedure will display a fatal message and
// then exit() the program.  It acts very much like printf, but its output
// is hard-wired to go to stderr, and it does not return at all.
//
noreturn void FATAL(
    const char *filename,       // name of source code file
    const char *funcname,       // name of function
    const unsigned int lineno,  // line number in source code file filename
    const char *format,         // printf() style format string
    ...) {                      // zero or more arguments used by format
  va_list arg;

  fflush(stdout);
  tcdrain(STDOUT_FILENO); // ensure all normal output is done
  fprintf(stderr, "FATAL ");
  if (verbose)
    fprintf(stderr, "%s:%u %s() ->", filename, lineno, funcname);
  va_start(arg, format);
  vfprintf(stderr, format, arg);
  va_end(arg);
  fflush(stderr);
  tcdrain(STDERR_FILENO); // ensure all error output is done
  exit(EXIT_FAILURE);
}

//
// This procedure will initialize the file handle data for the debug message
// output file.
//
void init_debug_printf(
    FILE *f) {                  // handle of open file for debug message output
  diagnostic_stream = f;
  diagnostic_stream_fileno = fileno(f);
  return;
}

//
// This procedure will output a message to the debug message output file.  The
// init_debug_printf() function must be called before ever using this function.
// This function mimics the printf() function and has the same API, but sends
// all of its output to the debug message output file.
//
void debug_printf(
    const char *format,         // printf() style format string
    ...) {                      // zero or more arguments used by format
  if (verbose) {
    va_list arg;

    if (!diagnostic_stream) {
      fputs("You failed to call init_debug_printf before debug_printf.\n", stderr);
      abort();
    }
    va_start(arg, format);
    vfprintf(diagnostic_stream, format, arg);
    va_end(arg);
    if (diagnostic_stream != stderr) {
      fflush(diagnostic_stream);
      fsync(diagnostic_stream_fileno);
    }
  }
  return;
}

//
// This function is used to escape backslash characters in the string s
// using a backslash, so every single backslash in the input results in a
// double backslash in the output.  All other bytes are copied verbatim, up
// to the terminator.  It returns a pointer to the buffer which contains
// the escaped version of s, and that buffer should be free()'d after use.
//
char *fixbackslashes(
    const char *instring) {     // pointer to ASCIIZ string
  unsigned int sndex,           // index of position in s[]
               ondex;           // index of position in buffer[]
  char *outstring = NULL;       // buffer for generated ASCIIZ string
  bool keeplooping = true;      // flag to exit loop when NULL occurs in s[]

  outstring = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*LITVAL_MAX_BYTES);
  for (sndex = 0U, ondex = 0U;
       keeplooping && (sndex < LITVAL_MAX_BYTES);
       ++sndex) {
    outstring[ondex++] = instring[sndex];  // copy input byte to output string
    switch(instring[sndex]) {          // if input character is
      case '\\':                       // backslash
        // output an extra backslash to output string
        outstring[ondex++] = instring[sndex];
        break;
      case 0:                          // string terminator in input
                                       // (was already copied to output)
        keeplooping = false;           // exit loop
        break;
      default:                         // anything else
        break;                         // just keep going
    }
  }
  return outstring;
}

//
// This function returns the appropriate suffix to use for a number in error
// messages.  It is best explained by examples:
//
// 1 - st, for 1st
// 2 - nd, for 2nd
// 3 - rd, for 3rd
// 4 - th, for 4th
// 11 - th, for 11th
// 12 - th, for 12th
// 13 - th, for 13th
// 21 - st, for 21st
// 22 - nd, for 22nd
// 23 - rd, for 23rd
//
const char *suffix(
    const uint32_t number) {   // number for which we need the suffix
  static const char *nth[] =
    { "th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th" };
  uint32_t it;                 // computed index into nth[] array

  if (((number % 100U) >= 11U) &&
      ((number % 100U) <= 13U))
    it = 0U;
  else
    it = number % 10U;
  return nth[it];
}

//
// in-place function which removes leading and trailing
// spaces from an ASCIIZ string
//
char *trim(
    char *instring) {          // pointer to input string buffer
  unsigned int leftshift = 0,  // number of character to shift left
               len = 0;        // number of characters in result
                               // not including terminator

  while (' ' == instring[leftshift])
    ++leftshift;
  while (instring[leftshift+len])
    ++len;
  while ((len>0) && (' ' == instring[leftshift+len-1]))
    --len;
  if (leftshift)
    for (unsigned int i=0; i<len; ++i)
      instring[i]=instring[i+leftshift];
  instring[len]=0;
  return instring;
}

//
// This function returns true if it can convert the non-empty, non-NULL
// ASCIIZ string passed in parameter s to a valid Minimal BASIC line number,
// otherwise it returns false.  If the conversion is successful, the result
// is stored in the parameter lineno, otherwise an ASCIIZ string containing
// the reason for failure is stored in the parameter why.
//
bool convert_line_number(
    const char *s,     // pointer to buffer containing the ASCIIZ
                       // string of a line number
    uint32_t *lineno,  // pointer to unsigned integer variable to hold the
                       // numeric value of the string passed in parameter s
    char *why) {       // pointer to buffer to contain an error message if the
                       // conversion fails
  char *endptr = NULL; // pointer to first non-converted byte of s
                       // which should be a 0
  uint64_t incoming;   // temporary 64 bit unsigned integer storage location
                       // to hold result of initial conversion of s

  errno = 0;           // clear any existing error
  if ((!s) || ('-' == s[0])) {   // if the first byte is a minus then fail with an error
    snprintf(why, ERROR_BUFFER_LEN, emsg[0], s?s:"null string");
    why[ERROR_BUFFER_LEN - 1U] = 0;
    return false;
  }
  incoming = strtoul(s, &endptr, 10);    // attempt the conversion
  switch (errno) {
    case 0:         // OK
      break;
    case ERANGE:    // range error
      snprintf(why, ERROR_BUFFER_LEN, emsg[1], s, MAXLINENO);
      why[ERROR_BUFFER_LEN - 1U] = 0;
      return false;
    default:        // some other problem with the conversion
      snprintf(why, ERROR_BUFFER_LEN, emsg[2], s);
      why[ERROR_BUFFER_LEN - 1U] = 0;
      return false;
  }
  if (endptr != s + strlen(s)) {  // s parameter had trailing junk
    snprintf(why, ERROR_BUFFER_LEN, emsg[3], s, endptr);
    why[ERROR_BUFFER_LEN - 1U] = 0;
    return false;
  }
  if ((incoming > UINT32_MAX) ||
      (incoming > MAXLINENO)) {   // line number was too big
    snprintf(why, ERROR_BUFFER_LEN, emsg[4], s, MAXLINENO);
    why[ERROR_BUFFER_LEN - 1U] = 0;
    return false;
  }
  *lineno = (uint32_t)incoming;   // convert type to 32 bit unsigned integer
  return true;
}

//
// Procedure to show current CPU flag values tracked by the compiler.
//
void dumpflags(void) {
  fprintf(stderr, "use_SSE4_1         is set to %s\n",
          (use_SSE4_1 ? "true" : "false"));
  fprintf(stderr, "verbose            is set to %s\n",
          (verbose ? "true" : "false"));
  fprintf(stderr, "base_is_one        is set to %s\n",
          (base_is_one ? "true" : "false"));
  fprintf(stderr, "pretty_print       is set to %s\n",
          (pretty_print ? "true" : "false"));
  fprintf(stderr, "extensions         is set to %s\n",
          (extensions ? "true" : "false"));
  fprintf(stderr, "need_RND           is set to %s\n",
          (need_RND ? "true" : "false"));
  fprintf(stderr, "need_ROUND         is set to %s\n",
          (need_ROUND ? "true" : "false"));
  fprintf(stderr, "need_DATE          is set to %s\n",
          (need_DATE ? "true" : "false"));
  fprintf(stderr, "need_DATES         is set to %s\n",
          (need_DATES ? "true" : "false"));
  fprintf(stderr, "need_TIME          is set to %s\n",
          (need_TIME ? "true" : "false"));
  fprintf(stderr, "need_TIMES         is set to %s\n",
          (need_TIMES ? "true" : "false"));
  fprintf(stderr, "need_SIN           is set to %s\n",
          (need_SIN ? "true" : "false"));
  fprintf(stderr, "need_SINH          is set to %s\n",
          (need_SINH ? "true" : "false"));
  fprintf(stderr, "need_ASIN          is set to %s\n",
          (need_ASIN ? "true" : "false"));
  fprintf(stderr, "need_CEIL          is set to %s\n",
          (need_CEIL ? "true" : "false"));
  fprintf(stderr, "need_COS           is set to %s\n",
          (need_COS ? "true" : "false"));
  fprintf(stderr, "need_COSH          is set to %s\n",
          (need_COSH ? "true" : "false"));
  fprintf(stderr, "need_ACOS          is set to %s\n",
          (need_ACOS ? "true" : "false"));
  fprintf(stderr, "need_TAN           is set to %s\n",
          (need_TAN ? "true" : "false"));
  fprintf(stderr, "need_TANH          is set to %s\n",
          (need_TANH ? "true" : "false"));
  fprintf(stderr, "need_ATN           is set to %s\n",
          (need_ATN ? "true" : "false"));
  fprintf(stderr, "need_LOG           is set to %s\n",
          (need_LOG ? "true" : "false"));
  fprintf(stderr, "need_LOG10         is set to %s\n",
          (need_LOG10 ? "true" : "false"));
  fprintf(stderr, "need_LOG2          is set to %s\n",
          (need_LOG2 ? "true" : "false"));
  fprintf(stderr, "need_EXP           is set to %s\n",
          (need_EXP ? "true" : "false"));
  fprintf(stderr, "need_SQR           is set to %s\n",
          (need_SQR ? "true" : "false"));
  fprintf(stderr, "need_INT           is set to %s\n",
          (need_INT ? "true" : "false"));
  fprintf(stderr, "need_IP            is set to %s\n",
          (need_IP ? "true" : "false"));
  fprintf(stderr, "need_FP            is set to %s\n",
          (need_FP ? "true" : "false"));
  fprintf(stderr, "need_MOD           is set to %s\n",
          (need_MOD ? "true" : "false"));
  fprintf(stderr, "need_REMAINDER     is set to %s\n",
          (need_REMAINDER ? "true" : "false"));
  fprintf(stderr, "need_UDF           is set to %s\n",
          (need_UDF ? "true" : "false"));
  fprintf(stderr, "need_strcpy        is set to %s\n",
          (need_strcpy ? "true" : "false"));
  fprintf(stderr, "need_strcmp        is set to %s\n",
          (need_strcmp ? "true" : "false"));
  fprintf(stderr, "need_INPUT         is set to %s\n",
          (need_INPUT ? "true" : "false"));
  fprintf(stderr, "need_PRINT         is set to %s\n",
          (need_PRINT ? "true" : "false"));
  fprintf(stderr, "need_PRINT_NUMERIC is set to %s\n",
          (need_PRINT_NUMERIC ? "true" : "false"));
  fprintf(stderr, "need_READSTMT      is set to %s\n",
          (need_READSTMT ? "true" : "false"));
  fprintf(stderr, "need_READSTMT_SVAR is set to %s\n",
          (need_READSTMT_SVAR ? "true" : "false"));
  fprintf(stderr, "need_READSTMT_NVAR is set to %s\n",
          (need_READSTMT_NVAR ? "true" : "false"));
  fprintf(stderr, "need_READSTMT_NAVAR_1D is set to %s\n",
          (need_READSTMT_NAVAR_1D ? "true" : "false"));
  fprintf(stderr, "need_READSTMT_NAVAR_2D is set to %s\n",
          (need_READSTMT_NAVAR_2D ? "true" : "false"));
  fprintf(stderr, "need_TAB           is set to %s\n",
          (need_TAB ? "true" : "false"));
  fprintf(stderr, "need_BSS_numeric   is set to %s\n",
          (need_BSS_numeric ? "true" : "false"));
  fprintf(stderr, "need_BSS_string    is set to %s\n",
          (need_BSS_string ? "true" : "false"));
  fprintf(stderr, "need_SUBROUTINE    is set to %s\n",
          (need_SUBROUTINE ? "true" : "false"));
  fprintf(stderr, "need_FORNEXT       is set to %s\n",
          (need_FORNEXT ? "true" : "false"));
  fprintf(stderr, "need_ADD           is set to %s\n",
          (need_ADD ? "true" : "false"));
  fprintf(stderr, "need_ANGLE         is set to %s\n",
          (need_ANGLE ? "true" : "false"));
  fprintf(stderr, "need_SUBTRACT      is set to %s\n",
          (need_SUBTRACT ? "true" : "false"));
  fprintf(stderr, "need_DIVIDE        is set to %s\n",
          (need_DIVIDE ? "true" : "false"));
  fprintf(stderr, "need_MULTIPLY      is set to %s\n",
          (need_MULTIPLY ? "true" : "false"));
  fprintf(stderr, "need_POWER         is set to %s\n",
          (need_POWER ? "true" : "false"));
  fprintf(stderr, "need_READ_1D       is set to %s\n",
          (need_READ_1D ? "true" : "false"));
  fprintf(stderr, "need_READ_2D       is set to %s\n",
          (need_READ_2D ? "true" : "false"));
  fprintf(stderr, "need_WRITE_1D      is set to %s\n",
          (need_WRITE_1D ? "true" : "false"));
  fprintf(stderr, "need_WRITE_2D      is set to %s\n",
          (need_WRITE_2D ? "true" : "false"));
  fprintf(stderr, "need_STRINGS       is set to %s\n",
          (need_STRINGS ? "true" : "false"));
  fprintf(stderr, "need_ONGOTO        is set to %s\n",
          (need_ONGOTO ? "true" : "false"));
  fprintf(stderr, "need_LOADREAL      is set to %s\n",
          (need_LOADREAL ? "true" : "false"));
  fprintf(stderr, "use_double         is set to %s\n",
          (use_double ? "true" : "false"));
  fprintf(stderr, "need_SEC           is set to %s\n",
          (need_SEC ? "true" : "false"));
  fprintf(stderr, "need_CSC           is set to %s\n",
          (need_CSC ? "true" : "false"));
  fprintf(stderr, "need_COT           is set to %s\n",
          (need_COT ? "true" : "false"));
  fprintf(stderr, "use_double_output  is set to %s\n",
          (use_double_output ? "true" : "false"));
  return;
}

// memory debug routines

//
// The function xmalloc() is a wrapper around the system malloc().  If the
// system malloc() successfully returns memory, this function behaves
// identically.  If the system malloc() fails and returns NULL, this function
// will halt the compiler with a fatal error message.  This means the rest of
// the compiler does not ever need to check the return from xmalloc() for a
// NULL, and simplifies using dynamic memory since this program chooses to
// abort rather than attempt to recover from the situation where dynamic memory
// is exhausted.
//
void *xmalloc(
    const char *filename,       // name of source code file where xmalloc()
                                // was invoked
    const char *funcname,       // name of function that called xmalloc()
    const unsigned int lineno,  // line number in source code file filename
                                // where xmalloc() was invoked
    size_t size) {              // number of bytes to allocate
                                // pointer to system malloc() we are
                                // intercepting
  void *(*real_malloc)(size_t) = malloc;
  void *value;    // pointer to dynamic memory system malloc() returns

  value = real_malloc(size);
  if (!value)
    FATAL(filename, funcname, lineno, emsg[30], __func__);
  return value;
}

#ifdef MJOLNIR

// one less than the maximum number of allocations we can track
#define MAXTRACKED 999999
static struct ramtastic {  // array of tracking data for memory allocations,
                           // with one slot for each chunk of dynamically
                           // allocated memory
  bool allocated;
  void *ptr;               // address of dynamically allocated memory
  size_t size;             // number of bytes allocated
} tracktheram[MAXTRACKED];
// next available slot in the tracktheram[] array
unsigned long int nextslot = 0UL;

//
// This procedure will dump the information in the tracktheram[] array to help
// diagnose memory allocation problems (normally leaks, which are memory
// allocations that were never deallocated).
//
void myshowleakdata(void) {
  unsigned long int i;   // loop index variable to iterate over all used slots
  size_t total = 0U;     // counter holding total number of bytes leaked

  for (i = 0UL; i < nextslot; ++i) {
    if (tracktheram[i].allocated) {
      fprintf(stderr, "%p with %lu bytes still allocated\n",
              tracktheram[i].ptr, tracktheram[i].size);
      hexdump(tracktheram[i].ptr, 0, tracktheram[i].size, 1, 8, stderr);
      total += tracktheram[i].size;
    }
  }
  if (total > 0U) {
    fprintf(stderr, "%lu bytes leaked\n", total);
    abort();    // force a coredump so the memory can be examined
  } else {
    fputs("No bytes leaked\n", stderr);
  }
  return;
}

void *mymalloc(
    const char *filename,        // name of source code file where xmalloc()
                                 // was invoked
    const char *funcname,        // name of function that called xmalloc()
    const unsigned int lineno,   // line number in source code file filename
                                 // where xmalloc() was invoked
    size_t size) {               // number of bytes to allocate
  unsigned long int i;           // loop index to iterate over all slots
  void *temp;                    // pointer to dynamic memory xmalloc() returns
  bool found = false;            // if true re-use existing slot,
                                 // otherwise allocate a new slot

  temp = xmalloc(filename, funcname, lineno, size);
  fprintf(stderr, "%s:%u %s() calls mymalloc(%lu) returns %p\n",
          filename, lineno, funcname, (unsigned long int)size, temp);
  // maybe an old freed slot is used?
  for (i = 0UL; i < nextslot; ++i) {
    if (tracktheram[i].ptr == temp) {
      found = true;
      break;
    }
  }
  if (found) {
    if (tracktheram[i].allocated == true)
      ICE(filename, funcname, lineno, "%s", emsg[5]);
    tracktheram[i].allocated = true;
    tracktheram[i].size = size;
  } else {
    if (nextslot == MAXTRACKED)
      ICE(filename, funcname, lineno, "%s", emsg[6]);
    tracktheram[nextslot].allocated = true;
    tracktheram[nextslot].ptr = temp;
    tracktheram[nextslot].size = size;
    nextslot++;
  }
  return temp;
}

void myfree(
    const char *filename,       // name of source code file where xmalloc()
                                // was invoked
    const char *funcname,       // name of function that called xmalloc()
    const unsigned int lineno,  // line number in source code file filename
                                // where xmalloc() was invoked
    void *ptr) {                // pointer to memory block to deallocate
  unsigned long int i;          // loop index to iterate over all slots
  // pointer to system free() we are intercepting
  void (*real_free)(void *) = free;
  bool found = false;           // if true we found the ptr, otherwise
                                // we ICE

  fprintf(stderr, "%s:%u %s() calls myfree() of %p\n",
          filename, lineno, funcname, ptr);
  if (!ptr)
    return;
  for (i = 0UL; i < nextslot; ++i) {
    if (tracktheram[i].ptr == ptr) {
      found = true;
      fprintf(stderr, "want to free %lu bytes\n",
              (unsigned long int)tracktheram[i].size);
      if (tracktheram[i].allocated == true) {
        tracktheram[i].allocated = false;
      } else {
        ICE(filename, funcname, lineno, emsg[7], __func__);
      }
      break;
    }
  }
  if (!found)
    ICE(filename, funcname, lineno, emsg[8], __func__);
  real_free(ptr);
  ptr = NULL;
  return;
}

void *myrealloc(
    const char *filename,        // name of source code file where xmalloc()
                                 // was invoked
    const char *funcname,        // name of function that called xmalloc()
    const unsigned int lineno,   // line number in source code file filename
                                 // where xmalloc() was invoked
    void *ptr,                   // pointer to memory block to deallocate
    size_t size) {               // number of bytes to allocate
  unsigned long int i;  // loop index variable to iterate over all slots
  bool found = false;   // flag to indicate ptr is a known allocated address
  void *temp;           // pointer to dynamic memory mymalloc() returns

  fprintf(stderr, "%s:%u %s() calls myrealloc() of %p with size %lu\n",
          filename, lineno, funcname, ptr, (unsigned long int)size);
  // If ptr is NULL, then the call is equivalent to xmalloc(size), for all
  // values of size
  if (!ptr)
    return mymalloc(filename, funcname, lineno, size);
  // if size is equal to zero, and ptr is not NULL, then the call is equivalent
  // to free(ptr)
  if ((0U == size) && ptr) {
    myfree(filename, funcname, lineno, ptr);
    return NULL;
  }
  // If ptr is a known, tracked memory location, found is set to true
  for (i = 0UL; i < nextslot; ++i) {
    if (tracktheram[i].ptr == ptr) {
      found = true;
      break;
    }
  }
  if (!found)
    ICE(filename, funcname, lineno, emsg[9], __func__);
  temp = mymalloc(filename, funcname, lineno, size);
  memset(temp, 0, size);
  if (size > tracktheram[i].size)
    size = tracktheram[i].size;
  memcpy(temp, ptr, size);
  myfree(filename, funcname, lineno, ptr);
  debug_printf("myrealloc(%p,%lu) returns %p\n",
               ptr, (unsigned long int)size, temp);
  return temp;
}

char *mystrdup(
    const char *filename,       // name of source code file where xmalloc()
                                // was invoked
    const char *funcname,       // name of function that called xmalloc()
    const unsigned int lineno,  // line number in source code file filename
                                // where xmalloc() was invoked
    const char *s) {   // pointer to source ASCIIZ string to be duplicated
  char *temp = NULL;   // pointer to generated copy of string s

  fprintf(stderr, "%s:%u %s() calls mystrdup of '%s'\n",
          filename, lineno, funcname, s);
  if (!s)
    ICE(filename, funcname, lineno, emsg[10], __func__);
  temp = (char *)mymalloc(filename, funcname, lineno,
                          sizeof(char) * (1U + strlen(s)));
  strcpy(temp, s);
  return temp;
}

#else

void *xrealloc(
    const char *filename,       // name of source code file where xmalloc()
                                // was invoked
    const char *funcname,       // name of function that called xmalloc()
    const unsigned int lineno,  // line number in source code file filename
                                // where xmalloc() was invoked
    void *ptr,                  // pointer to memory block to deallocate
    size_t size) {              // number of bytes to allocate
  // pointer to real system realloc()
  void *(*real_realloc)(void *,size_t) = realloc;
  void *temp;        // pointer to dynamic memory real_realloc() returns

  temp = real_realloc(ptr, size);
  if (!temp)
    FATAL(filename, funcname, lineno,emsg[30], __func__);
  return temp;
}

char *xstrdup(
    const char *filename,      // name of source code file where xmalloc()
                               // was invoked
    const char *funcname,      // name of function that called xmalloc()
    const unsigned int lineno, // line number in source code file filename
                               // where xmalloc() was invoked
    const char *s) {   // pointer to source ASCIIZ string to be duplicated
  char *temp;          // pointer to generated copy of string s

  if (!s)
    ICE(filename, funcname, lineno, emsg[10], __func__);
  temp = (char *)xmalloc(filename, funcname, lineno,
                         sizeof(char) * (1U + strlen(s)));
  strcpy(temp, s);
  return temp;
}

#endif

uint32_t mybsearch(
    const void *key,                      // pointer to key value
    const void *base,                     // pointer to base of array
    const uint32_t nmemb,                 // number of elements in the array
    const uint32_t size,                  // size of one element in the array
                                          // pointer to comparison function
    int (*compar)(const void *, const void *)) {
  uint32_t low = 0U;             // index of start of partition
  uint32_t high = nmemb - 1U;    // index of end of partition
  uint32_t middle = 0U;          // index of midway point in partition

  // while the partition still contains elements keep looking
  while (low <= high) {
    int32_t comparison_result;   // 0 is equal, <1 is left less than right,
                                 // >1 is left greater than right

    middle = low + (high - low) / 2U;     // compute the midway point
    comparison_result = (*compar)((void *)((char *)base + size * middle), key);
    if (0 == comparison_result)      // if we found key
      return middle;                 // return the index of the record
    if (comparison_result < 0) {     // if the value in the midway point
                                     // is too low then
      low = middle + 1U;             // look in the partition to the right of
                                     // the midpoint
    } else {                         // otherwise the value was too high so
      if (0U == middle)              // if the midpoint was the first element
        break;                       // then the value is not in the list
      high = middle - 1U;            // otherwise look in the partition to
                                     // the left of the midway point
    }
  }
  return UINT32_MAX;  // key not found, so return the error indicator value
}

//
// This procedure will print a simple usage message explaining the
// parameters, which are explained in more detail in the man page.
//
void usage(
    const char *progname,
    const bool has_V) {

  printf("Usage: %s [-4] [-v] [-s] [-O opt] [-X] ", progname);
  if (has_V)
    printf(" [-V]");
  printf("\n"
         "              or\n"
         "       %s -h\n", progname);
  printf("    -4 allows code generator to emit SSE4.1 instructions\n"
         "    -h Show this usage information\n"
         "    -O sets optimization level, and must be followed "
         "by an integer between\n"
         "       0 and %u inclusive, with higher numbers "
         "requesting more optimization\n",
         MAX_OPTIMIZATION_LEVEL);
  printf("    -s uses single precision float math for arithmetic expressions\n"
         "    -v generates verbose diagnostics\n");
  if (has_V)
    printf("    -V generates verbose diagnostics, "
           "and quits on first failure\n");
  printf("    -X allows extensions beyond strict ECMA-55\n");
  return;
}

#ifdef UNIT_TEST
#include <stdio.h>

static const char * const test_strings[] = {
"  3  ",
"  3 ",
"  3",
"3  ",
"3 ",
"3",
"",
"                        ",
"dogfood",
"daily double"
};
static const size_t test_strings_count = sizeof(test_strings) / sizeof(char *);

int main(int argc, char **argv) {
  int32_t opt; // variable used by getopt() function
  int retval;

  // process command-line arguments
  while ((opt = getopt(argc, argv, "hv")) != -1) {
    switch (opt) {
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'h': // show help (usage) information and exit
        printf("Usage: %s [-v]\n"
               "              or\n"
               "       %s -h\n"
               "  -h Show this usage information\n"
               "  -v generates verbose diagnostics\n", argv[0], argv[0]);
        return EXIT_SUCCESS;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        retval = EXIT_FAILURE;
        goto xit;
    }
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  init_debug_printf(stderr);
  for (size_t i=0;i<test_strings_count;++i) {
    char *s=trim(strdup(test_strings[i]));
    printf("trim('%s')='%s'\n", test_strings[i], s);
    free(s);s=NULL;
  }
  retval = EXIT_SUCCESS;
xit:
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return retval;
}
#endif
