#ifndef PARSER_H
#define PARSER_H
//
// parser2.c - This is the file containing the parser
//             for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdio.h>
#include <stdbool.h>
#include <inttypes.h>

//
// Returns true if the parse was successful, false it not and we can gracefully fail,
// and will force a halt of the compiler if we cannot gracefully fail (ICE, etc.)
//
bool parseit(
    const char * const buffer,
    const uint64_t buflen,
    uint64_t *pos,
    const uint32_t linecount,        // number of lines in the input BASIC source file
    const char *inname,              // pointer to text name of input BASIC source file
    const char *outname);            // pointer to text name of output assembly language file
#endif
