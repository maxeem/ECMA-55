//
// symbol_table.c - This is the module implementing the symbol table
//                  for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>
#include "codegen.h"
#include "globals.h"
#include "error_messages.h"
#include "symbol_table.h"
#include "g_fmt_BASIC_normal.h"

#define SMALL_BUFFER_MAX 81     // specify size for small ASCIIZ buffers (80 bytes + terminator)
// specify maximum length of an ASCIIZ symbol name (20 bytes + terminator)
#define SYMNAME_MAX_BYTES 21
#define DISYMNAME_MAX_BYTES SYMNAME_MAX_BYTES
#define LISYMNAME_MAX_BYTES SYMNAME_MAX_BYTES
#define FLSYMNAME_MAX_BYTES SYMNAME_MAX_BYTES
#define MSYMNAME_MAX_BYTES SYMNAME_MAX_BYTES

// union used for containing a floating point number
union realnumber {
  uint64_t l;      // 64 bit unsigned integer, for use with hex values
  uint32_t w;      // 32 bit unsigned integer, for use with hex values
  float f;         // 32 bit float
  double d;        // 64 bit float
};

// union used to convert between a 32bit integer bit pattern and a 32bit floating point bit pattern
static union fconvert {
  uint32_t i;
  float f;
} nanny = {.i = 0x7fa00000};               // 32 bit SNaN (signaling Not-a-Number)

// union used to convert between a 64bit integer bit pattern and a 64bit floating point bit pattern
static union fconvert64 {
  uint64_t i;
  double d;
} nanny64 = {.i = 0x7ff0000000000001L};    // 64 bit SNaN (signaling Not-a-Number)

// array used to convert type numbers to type names
static const char *data_item_type_names[] __attribute__ ((unused)) = {
  "QSTR",          // quoted string
  "NUM",           // floating point value
  "UQSTR",         // unquoted string (used in READ and INPUT)
  "PIVAL",         // PI numeric constant
  "MAXNUMVAL",     // MAXNUM numeric constant
};

//
// Table of records for all possible user-defined-functions.
// Initially all 26 rows are marked as having no argument and as
// not having been used by the program.
// WARNING: this array must be sorted by fname
//
static struct udf_item {
  const char *const fname;     // name of function is FN? where ? is one of 'A'..'Z'
  char argname;                // argument name if there is an argument, one of 'A'..'Z'
                               // 0 means this UDF has no argument
  bool exists;                 // true if UDF has been defined in the program
} udf_items[] = {
{"FNA", 0, false}, {"FNB", 0, false}, {"FNC", 0, false}, {"FND", 0, false},
{"FNE", 0, false}, {"FNF", 0, false}, {"FNG", 0, false}, {"FNH", 0, false},
{"FNI", 0, false}, {"FNJ", 0, false}, {"FNK", 0, false}, {"FNL", 0, false},
{"FNM", 0, false}, {"FNN", 0, false}, {"FNO", 0, false}, {"FNP", 0, false},
{"FNQ", 0, false}, {"FNR", 0, false}, {"FNS", 0, false}, {"FNT", 0, false},
{"FNU", 0, false}, {"FNV", 0, false}, {"FNW", 0, false}, {"FNX", 0, false},
{"FNY", 0, false}, {"FNZ", 0, false}
};

//
// Table of records for all possible floating point arrays.
// Initially all 26 rows are marked as having 0 dimensions, which means they
// have not been used by the BASIC program.
// WARNING: must be sorted by namestring
//
static arraydata thealist[] = {
// name, # of dims, max dim1, max dim2
  {"A", 0U, 0U, 0U},
  {"B", 0U, 0U, 0U},
  {"C", 0U, 0U, 0U},
  {"D", 0U, 0U, 0U},
  {"E", 0U, 0U, 0U},
  {"F", 0U, 0U, 0U},
  {"G", 0U, 0U, 0U},
  {"H", 0U, 0U, 0U},
  {"I", 0U, 0U, 0U},
  {"J", 0U, 0U, 0U},
  {"K", 0U, 0U, 0U},
  {"L", 0U, 0U, 0U},
  {"M", 0U, 0U, 0U},
  {"N", 0U, 0U, 0U},
  {"O", 0U, 0U, 0U},
  {"P", 0U, 0U, 0U},
  {"Q", 0U, 0U, 0U},
  {"R", 0U, 0U, 0U},
  {"S", 0U, 0U, 0U},
  {"T", 0U, 0U, 0U},
  {"U", 0U, 0U, 0U},
  {"V", 0U, 0U, 0U},
  {"W", 0U, 0U, 0U},
  {"X", 0U, 0U, 0U},
  {"Y", 0U, 0U, 0U},
  {"Z", 0U, 0U, 0U},
};

// thealist_count is the number of elements in thealist
static const uint32_t thealist_count = sizeof(thealist) / sizeof(arraydata);

//
// DATA statements contain lists of values used by the READ statement.  The
// READ and RESTORE maintain a pointer to the next data item to read.  Each
// READ will advance the pointer, but a RESTORE can reset the pointer to the
// first value.  Since DATA statements often have duplicates, an array of
// pointers to data blocks is used.  If a value is used more than once in
// DATA statements in a program, there will be only one data block with
// the information, but each time it is used a pointer to it will exist.
// The head of the list of the pointer names is data_list_head, and data_list
// is the record type used to hold the list of pointer names.  The actual
// data blocks are in the list of data_item records whose head is specified
// by data_items.
//
static struct data_list {
  char *symbol_name;                   // ASCIIZ string with name of symbol
  struct data_list *next;              // pointer to next node
} *data_list_head = NULL,              // head of singly-linked list of data blocks
  *data_list_tail = NULL;              // tail of singly-linked list of data blocks
// data_list_count is the number of elements in the list pointed to by data_list_head
static uint32_t data_list_count = 0U;

//
// DATA statements are lists of values that can be quoted strings, unquoted strings, or
// floating point numbers.  The values of all DATA statements are stored in a singly
// linked list, in order of appearance in the source program.  That list is composed
// of nodes specified by the data_item record type.  Each unique value in the list
// gets a data block, and this structure is used to hold the information necessary
// to create that data block.
//
static struct data_item {
  enum data_item_type t;               // data type number
  union realnumber numba;              // floating point value (if it exists)
  char *s;                             // pointer to ASCIIZ string containing the value
  char *disymname;                     // ASCIIZ name of the value
  struct data_item *next;              // pointer to next node
} *data_items = NULL,                  // head of singly-linked list of DATA statement items
  *last_data_item = NULL;              // tail of singly-linked list of DATA statement items
// data_item_count is the number of nodes in the list pointed to by data_items
static uint32_t data_item_count = 0U;

//
// string literal values have names generated by the symbol table module.
// The names are stored in a linked list of nodes defined by the literal_item
// record type.
//
static struct literal_item {
  char *lisymname;                     // ASCIIZ string with name of literal value
  char *litval;                        // ASCIIZ string with the actual literal value
  struct literal_item *next;           // pointer to next node
} *literals = NULL,                    // head of singly-linked list of string literal values
  *last_literal = NULL;                // tail of singly-linked list of string literal values

//
// Floating point literal values have names generated by the symbol table module.
// The names are stored in a linked list of nodes defined by the fliteral_item
// record type.
//
static struct fliteral_item {
  char *flsymname;                     // ASCIIZ string with name of symbol
  char *litval;                        // ASCIIZ string with the actual literal value
  struct fliteral_item *next;          // pointer to next node
} *fliterals = NULL,                   // head of singly-linked list of floating point literal values
  *last_fliteral = NULL;               // tail of singly-linked list of floating point literal values

//
// FOR statements need hidden variables to contain the terminating bound and the increment value
// and a singly-linked list of those generated hidden variable names is created using nodes
// defined by the magicvar_item record type
//
static struct magicvar_item {
  char *msymname;                      // ASCIIZ string with name of symbol
  struct magicvar_item *next;          // pointer to next node
} *magicvars = NULL;                   // head of singly-linked list of magic variables used by FOR statements

//
// This is a list of type codes for Minimal BASIC variable types
//   NVAR  - floating point scalar variable
//   NAVAR - floating point array variable
//   SVAR  - string scalar variable
//
enum vartype {
  NVAR = 0,       // floating point scalar variable
  NAVAR = 1,      // floating point array variable
  SVAR = 2,       // string scalar variable
  UNDEFINED = 3,  // anything else
};
//
// This is a map to convert the vartype enum values to string names for display
//
static const char *vartype_names[] = {
  "NVAR",       // floating point scalar variable
  "NAVAR",      // floating point array variable
  "SVAR",       // string scalar variable
  "UNDEFINED",  // anything else
};

//
// floating point scalar values can use variables names A..Z, A1..Z1, ... A9..Z9
// so an array of records is created with all of those possible names.  The
// records are of type stdata.  Initially all variables are marked as unused.
// Note that the names A..Z can be either scalar or numeric.  Their first use
// in the program determines the type, which cannot be changed after the variable
// is used.  The type can be set with a LET, an INPUT, a READ, with a DIM, etc.
//
// WARNING: must be sorted by namestring
//
static struct stdata {
  const char * const namestring;// pointer to ASCIIZ string specifying the scalar variable name
  enum vartype tipe;            // type of the variable (normally NVAR, but A..Z can be NAVAR)
  bool exists;                  // true if the variable has been used, false otherwise
} thelist[] = {
{"A", UNDEFINED, false}, {"A$", SVAR, false}, {"A0", NVAR, false}, {"A1", NVAR, false},
{"A2", NVAR, false}, {"A3", NVAR, false}, {"A4", NVAR, false}, {"A5", NVAR, false},
{"A6", NVAR, false}, {"A7", NVAR, false}, {"A8", NVAR, false}, {"A9", NVAR, false},
{"B", UNDEFINED, false}, {"B$", SVAR, false}, {"B0", NVAR, false}, {"B1", NVAR, false},
{"B2", NVAR, false}, {"B3", NVAR, false}, {"B4", NVAR, false}, {"B5", NVAR, false},
{"B6", NVAR, false}, {"B7", NVAR, false}, {"B8", NVAR, false}, {"B9", NVAR, false},
{"C", UNDEFINED, false}, {"C$", SVAR, false}, {"C0", NVAR, false}, {"C1", NVAR, false},
{"C2", NVAR, false}, {"C3", NVAR, false}, {"C4", NVAR, false}, {"C5", NVAR, false},
{"C6", NVAR, false}, {"C7", NVAR, false}, {"C8", NVAR, false}, {"C9", NVAR, false},
{"D", UNDEFINED, false}, {"D$", SVAR, false}, {"D0", NVAR, false}, {"D1", NVAR, false},
{"D2", NVAR, false}, {"D3", NVAR, false}, {"D4", NVAR, false}, {"D5", NVAR, false},
{"D6", NVAR, false}, {"D7", NVAR, false}, {"D8", NVAR, false}, {"D9", NVAR, false},
{"E", UNDEFINED, false}, {"E$", SVAR, false}, {"E0", NVAR, false}, {"E1", NVAR, false},
{"E2", NVAR, false}, {"E3", NVAR, false}, {"E4", NVAR, false}, {"E5", NVAR, false},
{"E6", NVAR, false}, {"E7", NVAR, false}, {"E8", NVAR, false}, {"E9", NVAR, false},
{"F", UNDEFINED, false}, {"F$", SVAR, false}, {"F0", NVAR, false}, {"F1", NVAR, false},
{"F2", NVAR, false}, {"F3", NVAR, false}, {"F4", NVAR, false}, {"F5", NVAR, false},
{"F6", NVAR, false}, {"F7", NVAR, false}, {"F8", NVAR, false}, {"F9", NVAR, false},
{"G", UNDEFINED, false}, {"G$", SVAR, false}, {"G0", NVAR, false}, {"G1", NVAR, false},
{"G2", NVAR, false}, {"G3", NVAR, false}, {"G4", NVAR, false}, {"G5", NVAR, false},
{"G6", NVAR, false}, {"G7", NVAR, false}, {"G8", NVAR, false}, {"G9", NVAR, false},
{"H", UNDEFINED, false}, {"H$", SVAR, false}, {"H0", NVAR, false}, {"H1", NVAR, false},
{"H2", NVAR, false}, {"H3", NVAR, false}, {"H4", NVAR, false}, {"H5", NVAR, false},
{"H6", NVAR, false}, {"H7", NVAR, false}, {"H8", NVAR, false}, {"H9", NVAR, false},
{"I", UNDEFINED, false}, {"I$", SVAR, false}, {"I0", NVAR, false}, {"I1", NVAR, false},
{"I2", NVAR, false}, {"I3", NVAR, false}, {"I4", NVAR, false}, {"I5", NVAR, false},
{"I6", NVAR, false}, {"I7", NVAR, false}, {"I8", NVAR, false}, {"I9", NVAR, false},
{"J", UNDEFINED, false}, {"J$", SVAR, false}, {"J0", NVAR, false}, {"J1", NVAR, false},
{"J2", NVAR, false}, {"J3", NVAR, false}, {"J4", NVAR, false}, {"J5", NVAR, false},
{"J6", NVAR, false}, {"J7", NVAR, false}, {"J8", NVAR, false}, {"J9", NVAR, false},
{"K", UNDEFINED, false}, {"K$", SVAR, false}, {"K0", NVAR, false}, {"K1", NVAR, false},
{"K2", NVAR, false}, {"K3", NVAR, false}, {"K4", NVAR, false}, {"K5", NVAR, false},
{"K6", NVAR, false}, {"K7", NVAR, false}, {"K8", NVAR, false}, {"K9", NVAR, false},
{"L", UNDEFINED, false}, {"L$", SVAR, false}, {"L0", NVAR, false}, {"L1", NVAR, false},
{"L2", NVAR, false}, {"L3", NVAR, false}, {"L4", NVAR, false}, {"L5", NVAR, false},
{"L6", NVAR, false}, {"L7", NVAR, false}, {"L8", NVAR, false}, {"L9", NVAR, false},
{"M", UNDEFINED, false}, {"M$", SVAR, false}, {"M0", NVAR, false}, {"M1", NVAR, false},
{"M2", NVAR, false}, {"M3", NVAR, false}, {"M4", NVAR, false}, {"M5", NVAR, false},
{"M6", NVAR, false}, {"M7", NVAR, false}, {"M8", NVAR, false}, {"M9", NVAR, false},
{"N", UNDEFINED, false}, {"N$", SVAR, false}, {"N0", NVAR, false}, {"N1", NVAR, false},
{"N2", NVAR, false}, {"N3", NVAR, false}, {"N4", NVAR, false}, {"N5", NVAR, false},
{"N6", NVAR, false}, {"N7", NVAR, false}, {"N8", NVAR, false}, {"N9", NVAR, false},
{"O", UNDEFINED, false}, {"O$", SVAR, false}, {"O0", NVAR, false}, {"O1", NVAR, false},
{"O2", NVAR, false}, {"O3", NVAR, false}, {"O4", NVAR, false}, {"O5", NVAR, false},
{"O6", NVAR, false}, {"O7", NVAR, false}, {"O8", NVAR, false}, {"O9", NVAR, false},
{"P", UNDEFINED, false}, {"P$", SVAR, false}, {"P0", NVAR, false}, {"P1", NVAR, false},
{"P2", NVAR, false}, {"P3", NVAR, false}, {"P4", NVAR, false}, {"P5", NVAR, false},
{"P6", NVAR, false}, {"P7", NVAR, false}, {"P8", NVAR, false}, {"P9", NVAR, false},
{"Q", UNDEFINED, false}, {"Q$", SVAR, false}, {"Q0", NVAR, false}, {"Q1", NVAR, false},
{"Q2", NVAR, false}, {"Q3", NVAR, false}, {"Q4", NVAR, false}, {"Q5", NVAR, false},
{"Q6", NVAR, false}, {"Q7", NVAR, false}, {"Q8", NVAR, false}, {"Q9", NVAR, false},
{"R", UNDEFINED, false}, {"R$", SVAR, false}, {"R0", NVAR, false}, {"R1", NVAR, false},
{"R2", NVAR, false}, {"R3", NVAR, false}, {"R4", NVAR, false}, {"R5", NVAR, false},
{"R6", NVAR, false}, {"R7", NVAR, false}, {"R8", NVAR, false}, {"R9", NVAR, false},
{"S", UNDEFINED, false}, {"S$", SVAR, false}, {"S0", NVAR, false}, {"S1", NVAR, false},
{"S2", NVAR, false}, {"S3", NVAR, false}, {"S4", NVAR, false}, {"S5", NVAR, false},
{"S6", NVAR, false}, {"S7", NVAR, false}, {"S8", NVAR, false}, {"S9", NVAR, false},
{"T", UNDEFINED, false}, {"T$", SVAR, false}, {"T0", NVAR, false}, {"T1", NVAR, false},
{"T2", NVAR, false}, {"T3", NVAR, false}, {"T4", NVAR, false}, {"T5", NVAR, false},
{"T6", NVAR, false}, {"T7", NVAR, false}, {"T8", NVAR, false}, {"T9", NVAR, false},
{"U", UNDEFINED, false}, {"U$", SVAR, false}, {"U0", NVAR, false}, {"U1", NVAR, false},
{"U2", NVAR, false}, {"U3", NVAR, false}, {"U4", NVAR, false}, {"U5", NVAR, false},
{"U6", NVAR, false}, {"U7", NVAR, false}, {"U8", NVAR, false}, {"U9", NVAR, false},
{"V", UNDEFINED, false}, {"V$", SVAR, false}, {"V0", NVAR, false}, {"V1", NVAR, false},
{"V2", NVAR, false}, {"V3", NVAR, false}, {"V4", NVAR, false}, {"V5", NVAR, false},
{"V6", NVAR, false}, {"V7", NVAR, false}, {"V8", NVAR, false}, {"V9", NVAR, false},
{"W", UNDEFINED, false}, {"W$", SVAR, false}, {"W0", NVAR, false}, {"W1", NVAR, false},
{"W2", NVAR, false}, {"W3", NVAR, false}, {"W4", NVAR, false}, {"W5", NVAR, false},
{"W6", NVAR, false}, {"W7", NVAR, false}, {"W8", NVAR, false}, {"W9", NVAR, false},
{"X", UNDEFINED, false}, {"X$", SVAR, false}, {"X0", NVAR, false}, {"X1", NVAR, false},
{"X2", NVAR, false}, {"X3", NVAR, false}, {"X4", NVAR, false}, {"X5", NVAR, false},
{"X6", NVAR, false}, {"X7", NVAR, false}, {"X8", NVAR, false}, {"X9", NVAR, false},
{"Y", UNDEFINED, false}, {"Y$", SVAR, false}, {"Y0", NVAR, false}, {"Y1", NVAR, false},
{"Y2", NVAR, false}, {"Y3", NVAR, false}, {"Y4", NVAR, false}, {"Y5", NVAR, false},
{"Y6", NVAR, false}, {"Y7", NVAR, false}, {"Y8", NVAR, false}, {"Y9", NVAR, false},
{"Z", UNDEFINED, false}, {"Z$", SVAR, false}, {"Z0", NVAR, false}, {"Z1", NVAR, false},
{"Z2", NVAR, false}, {"Z3", NVAR, false}, {"Z4", NVAR, false}, {"Z5", NVAR, false},
{"Z6", NVAR, false}, {"Z7", NVAR, false}, {"Z8", NVAR, false}, {"Z9", NVAR, false},
};
// thelist_count is the number of elements in the thelist table
static const uint32_t thelist_count = sizeof(thelist) / sizeof(struct stdata);

static void bss_numeric(FILE *asmoutputfile);
static void bss_string(FILE *asmoutputfile);
static void ds_read_data(FILE *asmoutputfile);
static void ds_literals(FILE *asmoutputfile);
static void dump_symbol_table_read(void);
static unsigned int get_var_index(const char c);

static unsigned int get_var_index(
    const char c) {
  // c-'A' works in ASCII to map a char in A..Z to 0..25
  // but if we are not ASCII it breaks, so use this map instead,
  // where -1 means invalid
  static const signed char letter2index[256] = {
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1,  0,  1,  2,  3,  4,
     5,  6,  7,  8,  9, 10, 11, 12, 13, 14,
    15, 16, 17, 18, 19, 20, 21, 22, 23, 24,
    25, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
    -1, -1, -1, -1, -1, -1
  };
  signed char ndex=letter2index[(unsigned int)c];

  if (ndex<0)
    FATAL(__FILE__, __func__, __LINE__, "Invalid variable name\n");
  return (unsigned int)ndex;
}

//
// This function will be used in a binary search to look for the variable
// specified by the s parameter in the list specified by the alist
// parameter.  The number of elements in the alist is specified by
// the element_count parameter.  The alist must be sorted in ascending
// order.  Since the variable tables are not dynamic, they are sorted.
// If the variable name is found, the function will return the index of
// the row containing that variable.  If the variable is not found,
// UINT32_MAX is returned to indicate failure.  The alist must not
// contain duplicate variable names (the key).
//
static int kompare(const void *left, const void *right) {
  return strcmp(((const struct stdata *)left)->namestring, right);
}
#define binary_search(alist,element_count,s) mybsearch(s,alist,element_count,sizeof(alist[0]),kompare)

//
// This function will emit the symbol table information for the bss segment for numeric variables
//
static void bss_numeric(
    FILE *asmoutputfile) {               // file handle of already open assembly language output file
  struct magicvar_item *mvi = magicvars; // pointer to current item in magicvars list
  unsigned char extra = (unsigned char)(base_is_one ? 0U : 1U);

  // emit the .bss assembly section header
  do_begin_nvars(asmoutputfile);

  // emit the definitions for scalar numeric variables
  for (unsigned int i = 0U; i < thelist_count; ++i) { // for each possible floating point scalar variable
    if (thelist[i].exists) {         // if this variable was used
      switch(thelist[i].tipe) {
        case NVAR:                   // and it was a scalar numeric variable
          do_define_nvar(asmoutputfile, thelist[i].namestring);
          break;
        case NAVAR:                  // and it was a numeric array variable
        case SVAR:                   // or it was a string variable then
          break;                     // skip it
        default:                     // if it was of an unknown type (only possible with an ICE)
          ICE(__FILE__, __func__, __LINE__, "%s", emsg[135]);
      }
    }
  }
  // emit the definitions for array numeric variables
  for (unsigned int i = 0U; i < thelist_count; ++i) { // for each possible floating point array variable
    if (thelist[i].exists) {                      // if it was used
      if (NAVAR == thelist[i].tipe) {             // and it was a numeric array variable
        uint32_t thecount1;                       // number of elements in first dimension
        unsigned int j;                           // index in thealist table computed from variable name

        j = get_var_index(thelist[i].namestring[0]);
        if (1U == thealist[j].dims) {    // if it has one dimension (vector)
          // emit definition for one-dimensional array, taking into account whether 32 or 64 bit floats are used
          thecount1 = thealist[j].dim1 + extra;
          do_define_1D_navar(asmoutputfile, thelist[i].namestring, thecount1);
        } else {                        // it has two dimensions (matrix)
          uint32_t thecount2;           // number of elements in second dimension

          // emit definition for two-dimensional array, taking into account whether 32 or 64 bit floats are used
          thecount1 = thealist[j].dim1 + extra;
          thecount2 = thealist[j].dim2 + extra;
          do_define_2D_navar(asmoutputfile, thelist[i].namestring, thecount1, thecount2);
        }
      }
    }
  }
  // emit the definitions for hidden internal magic variables
  while (mvi) {                        // while there are any magic variables left in the list
                                       // emit the definition, taking into account whether 32
                                       // or 64 bit floats are used
    mvi->msymname[MSYMNAME_MAX_BYTES - 1] = 0;       // terminate ASCIIZ symbol name
    do_define_nvar(asmoutputfile, mvi->msymname);
    mvi = mvi->next;
  }
  do_end_nvars(asmoutputfile);
  return;
}

//
// This will emit the assembly code for string variable definitions
//
static void bss_string(
    FILE *asmoutputfile) {               // file handle of already open assembly language output file

  do_begin_svars(asmoutputfile);
  for (unsigned int i = 0U; i < thelist_count; ++i) {  // for each possible string variable
    if (thelist[i].exists) {                           // if it was used
      if (SVAR == thelist[i].tipe) {                   // and it was a string then
                                                       // emit the definition
        do_define_svar(asmoutputfile, thelist[i].namestring);
      }
    }
  }
  do_end_svars(asmoutputfile);
  return;
}

//
// This will emit the assembly code for definitions of data used in DATA statements used by READ
//
static void ds_read_data(
    FILE *asmoutputfile) {                  // file handle of already open assembly language output file
  struct data_list *dli = data_list_head;   // pointer to current data block
  struct data_item *dti = data_items;       // pointer to current data item
  char *fptype = (use_double ? (char *)"double" : (char *)"float");

  do_begin_data(asmoutputfile, data_list_count);
  if (data_item_count > 0U) { // if there were any items in DATA statements
    // first we emit the unique data blocks
    do_unique_data_blocks(asmoutputfile);
    while (dti) {                    // while more data blocks need to be written
      char tbuf[FLOAT_BUFFER_LEN];   // temporary buffer used by g_fmt() ASCIIZ to float converter

      // emit the data block
      switch(dti->t) {               // choose definition depending on the type of the data item
        case QSTR:                   // quoted string
          do_data_item_string(asmoutputfile, dti->disymname, dti->s);
          break;
        case PIVAL:
          do_data_item_numeric(asmoutputfile, dti->disymname, dti->s, ".LPI", "quad");
          break;
        case MAXNUMVAL:
          do_data_item_numeric(asmoutputfile, dti->disymname, dti->s, ".LMAXNORMAL", "quad");
          break;
        case NUM:                    // floating point value or
        case UQSTR:                  // unquoted string
          if (use_double) {          // if we are doing 64bit math
            g_fmt(tbuf, dti->numba.d, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
          } else {                   // else we are doing 32bit math
            g_fmt(tbuf, dti->numba.f, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
          }
          do_data_item_numeric(asmoutputfile, dti->disymname, dti->s, tbuf, fptype);
          break;
        default:                     // unknown type (only possible with an ICE)
          ICE(__FILE__, __func__, __LINE__, "%s", emsg[44]);
      }
      dti = dti->next;
    }

    // then we emit the array of pointers to those blocks
    do_read_data_array_start(asmoutputfile);
    while (dli) {                    // while more data item pointers need to be written
      // emit the data item pointer
      do_emit_data_item_pointer(asmoutputfile, dli->symbol_name);
      dli = dli->next;
    }
    do_end_data(asmoutputfile);
  }
  return;
}

//
// This will emit assembly code for literal values used in the program
//
static void ds_literals(
    FILE *asmoutputfile) {               // file handle of already open assembly language output file
  struct literal_item *si = literals;    // pointer to current item in string literals list
  struct fliteral_item *fi = fliterals;  // pointer to current item in floating point literals list

  // emit header for .rodata section
  do_begin_ds_literals(asmoutputfile);
  // string literals
  while (si) {                           // while we still have some string literals in the list
                                         // emit definition for string literal
    char *tstring = NULL;
    si->lisymname[LISYMNAME_MAX_BYTES - 1] = 0;
    tstring = fixbackslashes(si->litval);
    do_define_slit(asmoutputfile, si->lisymname, tstring);
    free(tstring); tstring = NULL;
    si = si->next;
  }
  // numeric literals
  if (fi) {
    do_balign(asmoutputfile);
    while (fi) {                         // while we still have some numeric literals in the list
                                         // emit definition for numeric (floating point) literal,
                                         // taking into account whether 32 or 64 bit floats are used
      fi->flsymname[FLSYMNAME_MAX_BYTES - 1] = 0; // paranoia, ensure string is terminated
      do_define_nlit(asmoutputfile, fi->flsymname, fi->litval);
      fi = fi->next;
    }
  }
  return;
}

//
// This function will emit the required variable and constant definitions
// for all variables in the symbol tables that are needed.  It will return
// true if it is successful, and false if an error occurs.  The f parameter
// is the handle for the output assembly language file to which the
// output must be appended.
// It could be argued that logically this belongs in codegen.c, but that
// would require sharing too much state, so it is done directly here.
//
bool generate_symbol_table(
    FILE *asmoutputfile) {               // file handle of already open assembly language output file

  if (!asmoutputfile)                    // if the file handle is invalid then
    return false;                        // return failure
  if (0U == thelist_count)               // if no variables were used then
    return true;                         // return success
  if (need_BSS_numeric)                  // if we need to emit floating point variable definitions
    bss_numeric(asmoutputfile);
  if (need_BSS_string)                   // if we need to emit string variable definitions
    bss_string(asmoutputfile);
  if (literals || fliterals)             // if we have any literal values
    ds_literals(asmoutputfile);
  if (need_READSTMT)                     // if a READ statement was used in the Minimal BASIC program
    ds_read_data(asmoutputfile);
  return true;
}

//
// This procedure deallocates the dynamic memory used by the symbol table module
//
void clear_symbol_table(void) {
  struct literal_item *si = literals;     // pointer to current string literal item
  struct fliteral_item *fi = fliterals;   // pointer to current floating point literal item
  struct data_item *dti = data_items;     // pointer to current unique data block item
  struct magicvar_item *mvi = magicvars;  // pointer to current magic variable item
  struct data_list *dli = data_list_head; // pointer to current data statement item pointer

  deep_debug_printf("%s", "clear_symbol_table()\n");
  // deallocate string literal items
  while (si) {
    struct literal_item *temp = si;
    si = si->next;
    free(temp->lisymname); temp->lisymname = NULL;
    free(temp->litval); temp->litval = NULL;
    free(temp); temp = NULL;
  }
  literals = last_literal = NULL;
  // deallocate floating point literal items
  while (fi) {
    struct fliteral_item *temp = fi;
    fi = fi->next;
    free(temp->flsymname); temp->flsymname = NULL;
    free(temp->litval); temp->litval = NULL;
    free(temp); temp = NULL;
  }
  fliterals = last_fliteral = NULL;
  // deallocate unique data block items
  while (dti) {
    struct data_item *temp = dti;
    dti = dti->next;
    free(temp->s); temp->s = NULL;
    free(temp->disymname); temp->disymname = NULL;
    free(temp); temp = NULL;
  }
  data_items = last_data_item = NULL;
  // deallocate magic variable items
  while (mvi) {
    struct magicvar_item *temp = mvi;
    mvi = mvi->next;
    temp->next = NULL;
    free(temp->msymname); temp->msymname = NULL;
    free(temp); temp = NULL;
  }
  magicvars = NULL;
  // delete data statement item pointers
  while (dli) {
    struct data_list *temp = dli;
    dli = dli->next;
    temp->next = NULL;
    free(temp->symbol_name); temp->symbol_name = NULL;
    free(temp); temp = NULL;
  }
  data_list_head = data_list_tail = NULL;
  // clear static table values
  for (size_t i = 0U; i < thelist_count; ++i) {  // for each possible numeric variable name
     if (thelist[i].namestring[1] == 0)      // for single-letter names which could be arrays
       thelist[i].tipe = UNDEFINED;  // set them to undefined
                                     // but leave A0..A9, A$, etc. alone
     thelist[i].exists = false;
  }
  for (size_t i = 0U; i < thealist_count; ++i) { // for each possible numeric array variable name
     thealist[i].dims = 0;
     thealist[i].dim1 = 0;
     thealist[i].dim2 = 0;
  }
  for (size_t i = 0U; i < 26U; ++i) {  // for each possible UDF
     udf_items[i].exists = false;
     udf_items[i].argname = 0;
  }
  return;
}

static void dump_symbol_table_read(void) {
  struct data_item *dti = data_items;     // pointer to current data block
  struct data_list *dli = data_list_head; // pointer to current pointer name in list of data pointers

  printf("%u DATA ITEM COUNT\n", data_item_count);
  if (data_item_count > 0U) {             // if any data blocks exist
    puts("DATA BLOCKS");
    while (dti) {                         // while there are more data blocks
      char tbuf[FLOAT_BUFFER_LEN];        // temporary buffer used by g_fmt() ASCIIZ to float function

      // display what we know about the data block
      printf("%sS is \"%s\"\n"
             "%s is marked as a ", dti->disymname, dti->s, dti->disymname);
      switch (dti->t) {
        case QSTR:                        // quoted string
          puts("quoted string");
          break;
        case PIVAL:
        case MAXNUMVAL:
        case NUM:                         // numeric value (floating point)
        case UQSTR:                       // unquoted string
          if (use_double) {               // if we are using 64bit math
            g_fmt(tbuf, dti->numba.d, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
          } else {                        // if we are using 32bit math
            g_fmt(tbuf, dti->numba.f, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
          }
          printf("an unquoted string with numeric type %s with stored value %s\n", (use_double ? "double" : "float"), tbuf);
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, "%s", emsg[44]);
      }
      dti = dti->next;
    }

    puts("DATA POINTER LIST");
    while (dli) {                         // while we have more data item pointers
                                          // display the data item pointer
      printf("%s\n", dli->symbol_name);
      dli = dli->next;
    }
  }
  return;
}

//
// This procedure will dump the data stored in the symbol table module.
// If onlyused is true, then only variables that have been used in the
// Minimal BASIC input program will be shown.  Otherwise, everything is
// shown.
//
void dump_symbol_table(
    bool onlyused) {                     // flag to indicate we want to dump only used variables (true)
                                         // or all possible variables (false)
  unsigned int i;                        // loop index variable
  struct literal_item *si = literals;    // pointer to current string literal item
  struct fliteral_item *fi = fliterals;  // pointer to current floating point literal item
  struct magicvar_item *mvi = magicvars; // pointer to current magic variable item
  bool saw_one = false;                  // flag used to avoid showing title if no items are present

  puts("\nSymbol Table Information");
  if (onlyused) {                            // if only used symbols should be displayed
    for (i = 0U; i < thelist_count; ++i) {   // for each possible numeric variable name
      if (thelist[i].exists) {               // if the variable was used
                                             // display what we know about it
        if (!saw_one) {
          puts("\nVariables");
          saw_one = true;
        }
        printf("name = '%s', tipe = '%s'\n",
               thelist[i].namestring, vartype_names[thelist[i].tipe]);
        if (NAVAR == thelist[i].tipe) { // if it was a numeric array variable
          unsigned int j;

          // show the dimension information
          j = get_var_index(thelist[i].namestring[0]);
          printf("name = '%s', dims = %" PRIu32 ", dim1 = %" PRIu32 ", dim2 = %" PRIu32 "\n",
                 thealist[j].namestring, thealist[j].dims, thealist[j].dim1, thealist[j].dim2);
        }
      }
    }
  } else {                                  // show all symbols
    puts("\nVariables");
    for (i = 0U; i < thelist_count; ++i) {  // for each possible numeric variable name
                                            // display what we know about it
      printf("name = '%s', tipe = %s, exists = %s\n",
             thelist[i].namestring, vartype_names[thelist[i].tipe], (thelist[i].exists ? "true" : "false"));
    }
    for (i = 0U; i < thealist_count; ++i) { // for each possible numeric array variable name
                                            // display what we know about it
      printf("name = '%s', dims = %" PRIu32 ", dim1 = %" PRIu32 ", dim2 = %" PRIu32 "\n",
             thealist[i].namestring, thealist[i].dims, thealist[i].dim1, thealist[i].dim2);
    }
  }
  saw_one = false;
  while (mvi) {                             // while more magic variable names are in the list
                                            // display the name
    if (!saw_one) {
       puts("\nMagic Variables");
       saw_one = true;
    }
    printf("magic variable name = '%s'\n", mvi->msymname);
    mvi = mvi->next;
  }
  saw_one = false;
  while (si) {                              // while more string literal values are in the list
                                            // display the name and value
    if (!saw_one) {
       puts("\nString Literals");
       saw_one = true;
    }
    printf("string literal name = '%s', value = '%s'\n", si->lisymname, si->litval);
    si = si->next;
  }
  saw_one = false;
  while (fi) {                              // while more numeric values are in the list
                                            // display the name and value
    if (!saw_one) {
       puts("\nFloat Literals");
       saw_one = true;
    }
    printf("float literal name = '%s', value = '%s'\n", fi->flsymname, fi->litval);
    fi = fi->next;
  }
  saw_one = false;

  if (need_READSTMT)                        // if any READ statement exists in the Minimal BASIC program
    dump_symbol_table_read();

  for (i = 0U; i < 26U; ++i) {               // for each possible UDF
    if (udf_items[i].exists) {               // if it was defined then
                                             // display what we know about it
      if (!saw_one) {
        puts("\nUser-Defined Functions");
        saw_one = true;
      }
      printf("'%s' has been defined and has ", udf_items[i].fname);
      if (udf_items[i].argname) {            // if the UDF has an argument show the name
        printf("one argument named '%c'\n", udf_items[i].argname);
      } else {                               // otherwise indicate it has no argument
        puts("no arguments");
      }
    }
  }
  if (saw_one) puts("");

  return;
}

//
// This function is used to add a numeric literal (floating point) value to the
// symbol table.  The litval parameter has the ASCIIZ string containing the literal
// value.  If the value is added successfully, true is returned and the ASCIIZ symbol
// name generated is returned in the symbol parameter.  Otherwise false is returned.
//
bool add_float_literal(
    const char *litval,                // pointer to ASCIIZ string containing numeric literal value
    char **symbol) {                   // pointer to pointer to ASCIIZ string which is used to
                                       // return the generated symbol name
  static uint32_t last_symbol = 0U;    // number of next numeric literal
                                       // (used to generate literal names)
  struct fliteral_item *fi = NULL;     // pointer to current floating point literal item

  if (!litval || !litval[0])
    ICE(__FILE__, __func__, __LINE__, "%s", emsg[45]);
  if (!symbol)
    ICE(__FILE__, __func__, __LINE__, "%s", emsg[46]);
  // first lookup the literal value to see if we already have it, and if we do,
  // the symbol name of the existing literal value is returned.
  if (fliterals) {                               // if there are any floating point literals
    fi = fliterals;
    while (fi) {                                 // while more floating point literals exist to consider
      if (strcmp(fi->litval, litval) == 0) {     // if the current floating point literal
                                                 // is the same as litval
        *symbol = fi->flsymname;                 // copy the symbol name into symbol
        return true;                             // and return true
      }
      fi = fi->next;
    }
  }

  // The literal value was not found, so add it
  fi = (struct fliteral_item *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct fliteral_item));
  fi->flsymname = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLSYMNAME_MAX_BYTES);
  fi->litval = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*LITVAL_MAX_BYTES);
  fi->next = NULL;
                                                 // generate the ASCIIZ symbol name
  snprintf(fi->flsymname, FLSYMNAME_MAX_BYTES, ".LFLIT%04" PRIu32, last_symbol++);
  fi->flsymname[FLSYMNAME_MAX_BYTES - 1] = 0;    // ensure termination
  *symbol = fi->flsymname;                       // copy the symbol name into symbol
  strncpy(fi->litval, litval, LITVAL_MAX_BYTES-1); // save the literal value
  fi->litval[LITVAL_MAX_BYTES - 1] = 0;          // ensure termination
  if (!fliterals) {                              // if this is the very first floating point literal
    fliterals = last_fliteral = fi;              // point head and tail to this node
  } else { // otherwise
    last_fliteral->next = fi;                    // append the node to the end of the list
                                                 // of floating point literals
    last_fliteral = fi;
  }
  return true;
}

//
// This function is used to add UDF (user-defined function) information to the
// symbol table.  The fname parameter contains the UDF name, argname contains the
// name of the parameter if the UDF has a parameter, or NULL if the UDF has no
// parameter.  The lno parameter contains the Minimal BASIC program line number
// that is used in error messages if a problem occurs add the UDF information.
// If the UDF has already been defined or has an invalid name, false is returned.
// If everything was OK, true is returned.
//
bool add_udf(
    const char *udfname,               // pointer to ASCIIZ string containing UDF name
    const char *argname,               // pointer to ASCIIZ string containing UDF argument name
    uint32_t lno) {                    // BASIC source line number
  bool retval = false;                 // return value for function
  uint32_t recno;                      // index of row in udf_items where the record
                                       // for the fname UDF is stored

  if (!udfname)
    ICE(__FILE__, __func__, __LINE__, emsg[48], lno);
  if (!udfname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[49], lno);
  // ensure length is 3 bytes
  if (strlen(udfname) != 3) {          // invalid udf name (not 3 bytes) only possible with an ICE
    fprintf(stderr, emsg[136], udfname);
    goto xit;
  }
  // ensure first two letters are 'FN'
  if ((udfname[0] != 'F') || (udfname[1] != 'N')) { // invalid udf name, does not start with FN
    fprintf(stderr, emsg[137], udfname);
    goto xit;
  }
  // ensure incoming ASCIIZ string variable name's third letter is valid
  if (!isupper(udfname[2])) { // invalid variable name only possible with an ICE
    fprintf(stderr, emsg[138], udfname);
    goto xit;
  }
  // compute index of record in udf_items for the UDF specified by udfname
  recno = get_var_index(udfname[2]);
  if (recno > 25U) {      // if the record is out-of-bounds (on possible if we have ICE)
                                   // report error and return indicating error
    ICE(__FILE__, __func__, __LINE__, emsg[50], udfname);
  } else { // otherwise
    if (udf_items[recno].exists) { // if the UDF is already defined
      // report the error and return indicating error
      fprintf(stderr, emsg[139], udfname, lno);
      retval = false;
    } else { // otherwise
      // add UDF information
      udf_items[recno].exists = true; // mark UDF as defined
      udf_items[recno].argname = (!argname ? 0 : argname[0]); // store number of arguments
      retval = true;
    }
  }
xit:
  deep_debug_printf("%s(%s) returns %s\n", __func__, udfname, (retval ? "true" : "false"));
  return retval;
}

//
// This function is used to add a string literal value to the
// symbol table.  The litval parameter has the ASCIIZ string containing the literal
// value.  If the value is added successfully, true is returned and the ASCIIZ symbol
// name generated is returned in the symbol parameter.  Otherwise false is returned.
//
bool add_string_literal(
    const char *litval,                // pointer to ASCIIZ string containing literal value
    char **symbol) {                   // pointer to pointer to ASCIIZ string which is used to
                                       // return the generated symbol name
  static uint32_t last_symbol = 0U;    // number of next string literal
                                       // (used to generate literal names)
  struct literal_item *si = NULL;      // pointer to current string literal item

  if (!litval)
    ICE(__FILE__, __func__, __LINE__, "%s", emsg[51]);
  if (!symbol)
    ICE(__FILE__, __func__, __LINE__, "%s", emsg[52]);
  // first lookup the literal value to see if we already have it.  If we do,
  // the symbol name of the existing literal value is returned.
  if (literals) {                                  // if there are any string literals
    si = literals;
    while (si) {                                   // while there are more string literals to consider
      if (strcmp(si->litval, litval) == 0) {       // if the current string literal is the same as litval
        *symbol = si->lisymname;                   // copy the symbol name into symbol
        return true;                               // and return true
      }
      si = si->next;
    }
  }

  // The literal value was not found, so add it
  // allocate a new literal item node
  si = (struct literal_item *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct literal_item));
  // populate the new literal item node
  si->lisymname = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*LISYMNAME_MAX_BYTES);
  si->litval = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*LITVAL_MAX_BYTES);
  si->next = NULL;
                                                   // generate the ASCIIZ symbol name
  snprintf(si->lisymname, LISYMNAME_MAX_BYTES, ".LSLIT%04" PRIu32, last_symbol++);
  si->lisymname[LISYMNAME_MAX_BYTES - 1] = 0;      // ensure termination
  *symbol = si->lisymname;                         // copy the symbol name into symbol
  strncpy(si->litval, litval, LITVAL_MAX_BYTES-1); // save the literal value
  si->litval[LITVAL_MAX_BYTES - 1] = 0;            // ensure termination
  if (!literals) {                                 // if this is the very first string literal
    literals = last_literal = si;                  // point the head to this node
  } else {                                         // otherwise
    last_literal->next = si;                       // append the node to end of list of string literals
    last_literal = si;
  }
  return true;
}

//
// This function is used to lookup information about a numeric array variable.
// The ASCIIZ string variable named is passed in the s argument.  If the
// information is found, a pointer to the associated record in the thelist
// table is returned.  If the information is not found, NULL is returned.
// The caller of this function must NOT attempt to free the record...
//
arraydata *get_array_data(
    const char *navarname) {           // pointer to ASCIIZ string containing numeric array variable name
  arraydata *retval = NULL;            // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()

  // ensure incoming ASCIIZ string variable name is non-NULL
  if (!navarname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ string variable name is non-empty
  if (!navarname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  // ensure incoming ASCIIZ string variable name's first letter is valid
  if (!isupper(navarname[0])) //invalid variable name only possible with an ICE
    ICE(__FILE__, __func__, __LINE__, emsg[56], __func__);
  if (navarname[1])      // invalid variable name (more than 1 byte) only possible with an ICE
    ICE(__FILE__, __func__, __LINE__, emsg[57], __func__);
  recno = binary_search(thelist, thelist_count, navarname);  // search for s in thelist
  if (UINT32_MAX == recno) {                       // s not found
    deep_debug_printf("%s(): variable '%s' not found in primary symbol table\n", __func__, navarname);
  } else {                                         // s is found
    deep_debug_printf("%s(): variable '%s' found in primary symbol table\n", __func__, navarname);
    if (thelist[recno].tipe != NAVAR) {            // if navarname is not a numeric array variable (type check)
      deep_debug_printf("%s(): variable '%s' has invalid type %s instead of %s\n",
        __func__, navarname, vartype_names[thelist[recno].tipe], vartype_names[NAVAR]);
    } else {
      deep_debug_printf("%s(): variable '%s' has valid type %s\n", __func__, navarname, vartype_names[NAVAR]);
      if (thelist[recno].exists == false) {        // if s has not been used
        deep_debug_printf("%s(): variables '%s' does not yet exist in primary symbol table\n", __func__, navarname);
      } else {                                     // FOUND IT!, s has been used
        deep_debug_printf("%s(): variables '%s' exists in primary symbol table\n", __func__, navarname);
        retval = &thealist[get_var_index(navarname[0])]; // get pointer to record for return value
      }
    }
  }
  return retval;
}

//
// This function will lookup a scalar numeric variable name.  If the
// name is found and has been used then true is returned, otherwise
// false is returned.
//
bool nvar_exists(
    const char *nvarname) {            // pointer to ASCIIZ string containing numeric scalar variable name
  bool retval = false;                 // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()

  // ensure incoming ASCIIZ variable name is non-NULL
  if (!nvarname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ variable name is non-empty
  if (!nvarname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  // ensure incoming ASCIIZ string variable name's first letter is valid
  if (!isupper(nvarname[0])) { // invalid variable name only possible with an ICE
    fprintf(stderr, emsg[140], nvarname);
    goto xit;
  }
  if (nvarname[1])      {              // multi-byte variable name (possible values are [A-Z][0-9])
    if (!isdigit(nvarname[1])) {  // invalid variable name (more than one byte and second byte
                                       // is not a digit) only possible with an ICE
      fprintf(stderr, emsg[141], nvarname);
      goto xit;
    }
    if (nvarname[2])      {            // invalid variable name (more than 2 bytes)
                                       // only possible with an ICE
      fprintf(stderr, emsg[142], nvarname);
      goto xit;
    }
  }
  if ((recno = binary_search(thelist, thelist_count, nvarname)) != UINT32_MAX) // if the name nvarname is found
    if (NVAR == thelist[recno].tipe)   // and it is a numeric scalar value (type check)
      retval = thelist[recno].exists;  // and it has been used then set retval to true, otherwise false
xit:
  deep_debug_printf("%s(%s) returns %s\n", __func__, nvarname, (retval ? "true" : "false"));
  return retval;
}

//
// This function will lookup a numeric array variable name.  If the
// name is found and has been used or defined (DIM) then true is returned,
// otherwise false is returned.
//
bool navar_exists(
    const char *navarname) {           // pointer to ASCIIZ string containing numeric array variable name
  bool retval = false;                 // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()

  // ensure incoming ASCIIZ variable name is non-NULL
  if (!navarname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ variable name is non-empty
  if (!navarname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  // ensure incoming ASCIIZ variable name's first letter is valid
  if (!isupper(navarname[0])) { // invalid variable name only possible with an ICE
    fprintf(stderr, emsg[143], navarname);
    goto xit;
  }
  // ensure incoming ASCIIZ string variable name is a lone byte
  if (navarname[1]) {
    fprintf(stderr, emsg[144], navarname);
    goto xit;
  }
                                       // if the name s is found
  if ((recno = binary_search(thelist, thelist_count, navarname)) != UINT32_MAX)
    if (NAVAR == thelist[recno].tipe)  // and it is a numeric array variable (type check)
      retval = thelist[recno].exists;  // and it has been used or defined then set reval to true,
                                       // otherwise false
xit:
  deep_debug_printf("%s(%s) returns %s\n", __func__, navarname, (retval ? "true" : "false"));
  return retval;
}

//
// This function will lookup a user-defined function name.  If the
// name is found and has defined (DEF) then true is returned,
// otherwise false is returned.  If it is true then argname will
// have the name of the argument if there is an argument to the UDF,
// or an empty string if the UDF does not take an argument.
//
bool udf_exists(
    const char *udfname,               // pointer to ASCIIZ string containing UDF name
    char *argname) {                   // pointer to ASCIIZ string containing UDF argument name
  bool retval = false;                 // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()

  // ensure incoming ASCIIZ variable name is non-NULL
  if (!udfname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ variable name is non-empty
  if (!udfname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  // ensure length is 3 bytes
  if (strlen(udfname) != 3) {          // invalid udf name (not 3 bytes) only possible with an ICE
    fprintf(stderr, emsg[145], udfname);
    goto xit;
  }
  // ensure first two letters are 'FN'
  if ((udfname[0] != 'F') || (udfname[1] != 'N')) { // invalid udf name, does not start with FN
    fprintf(stderr, emsg[146], udfname);
    goto xit;
  }
  // ensure incoming ASCIIZ string variable name's third letter is valid
  if (!isupper(udfname[2])) { // invalid variable name only possible with an ICE
    fprintf(stderr, emsg[147], udfname);
    goto xit;
  }
  recno = get_var_index(udfname[2]);   // compute index in udf_items table from variable name
  if (recno > 25U)                     // range check
    ICE(__FILE__, __func__, __LINE__, emsg[50], udfname);
  retval = udf_items[recno].exists;    // set return value to true if UDF has been defined, otherwise false
  argname[0] = 0;                      // set argname name to empty string
  if (retval) {
    if (udf_items[recno].argname) {               // if there is an argument to the functions
      argname[0] = udf_items[recno].argname;      // copy argument name to argname
      argname[1] = 0;
    }
  }
xit:
  deep_debug_printf("%s(%s) returns %s with %" PRIu8 " arguments\n",
                    __func__, udfname, (retval ? "true" : "false"), (argname[0] ? 1 : 0));
  return retval;
}

//
// This function will lookup a scalar string variable name.  If the
// name is found and has been used then true is returned,
// otherwise false is returned.
//
bool svar_exists(
    const char *svarname) {            // pointer to ASCIIZ string containing scalar string variable name
  bool retval = false;                 // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()

  // ensure incoming ASCIIZ variable name is non-NULL
  if (!svarname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ variable name is non-empty
  if (!svarname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  // ensure incoming ASCIIZ string variable name's first letter is valid
  if (!isupper(svarname[0])) { // invalid variable name only possible with an ICE
    fprintf(stderr, emsg[148], svarname);
    goto xit;
  }
  if (svarname[1] != '$') {            // invalid variable name (second byte not a dollar)
                                       // only possible with an ICE
    fprintf(stderr, emsg[149], svarname);
    goto xit;
  }
  if (svarname[2]) {                   // invalid variable name (more than 2 bytes)
                                       // only possible with an ICE
    fprintf(stderr, emsg[150], svarname);
    goto xit;
  }
                                       // if the name s is found
  if ((recno = binary_search(thelist, thelist_count, svarname)) != UINT32_MAX)
    if (SVAR == thelist[recno].tipe)   // and it is a string scalar value (type check)
      retval = thelist[recno].exists;  // and it has been used then set retval to true, otherwise false
xit:
  deep_debug_printf("%s(%s) returns %s\n", __func__, svarname, (retval ? "true" : "false"));
  return retval;
}

//
// This function will attempt to add the magic variable name specified by the parameter magic_varname
// to the list of magic variable names.  It will return true on success, false otherwise.
//
bool assign_magicvar(
    const char *magic_varname) {       // pointer to ASCIIZ string containing magic variable name
  struct magicvar_item *temp = NULL;   // temporary node for creating magic item record

  if (!magic_varname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  if (!magic_varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  deep_debug_printf("%s(%s)\n", __func__, magic_varname);
                                       // allocate a new node for a magic variable
  temp = (struct magicvar_item *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct magicvar_item));
                                       // copy magic variable name into new node
  temp->msymname = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*MSYMNAME_MAX_BYTES);
  memcpy(temp->msymname, magic_varname, MSYMNAME_MAX_BYTES-1);
  temp->msymname[MSYMNAME_MAX_BYTES - 1] = 0; // ensure termination
                                       // prepend new node to linked list of magic variables
  temp->next = magicvars;
  magicvars = temp;

  need_BSS_numeric = true;             // set flag to true to indicate that a .bss section
                                       // for numeric variables will be needed
  deep_debug_printf("%s(%s) returns true\n", __func__, magic_varname);
  return true;
}

//
// This function will attempt to add the scalar numeric variable name specified by the parameter nvarname
// to the symbol table.  It will return true on success, false otherwise.  The lno parameter is the
// line number of the Minimal BASIC line number where the variable is accessed and is used in
// error messages.  If the variable is already defined and of the correct type, true is returned.
//
bool assign_nvar(
    const char *nvarname,              // pointer to ASCIIZ string containing scalar numeric variable name
    const uint32_t lno) {              // BASIC source line number
  bool retval = false;                 // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()

  deep_debug_printf("%s(%s)\n", __func__, nvarname);
  // ensure incoming ASCIIZ variable name is non-NULL
  if (!nvarname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ variable name is non-empty
  if (!nvarname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  recno = binary_search(thelist, thelist_count, nvarname); // search for nvarname in thelist
  if (UINT32_MAX == recno)                                 // nvarname not found
    ICE(__FILE__, __func__, __LINE__, emsg[59], nvarname, lno);
  if (thelist[recno].exists) {                             // if nvarname is already defined then
    if (NVAR == thelist[recno].tipe) {                     // if it is already defined correctly as a
                                                           // numeric scalar variable (type check)
      retval = true;
      goto xit;
    }
    fprintf(stderr, emsg[151], nvarname, lno);             // otherwise display error
    goto xit;                                              // and return
  }

  retval = true;
  thelist[recno].tipe = NVAR;          // mark this variable as being a numeric scalar variable
  thelist[recno].exists = true;        // mark this variable as used
  need_BSS_numeric = true;             // set flag to true to indicate that a .bss section
                                       // for numeric variables will be needed
xit:
  deep_debug_printf("%s(%s) returns %s\n", __func__, nvarname, (retval ? "true" : "false"));
  return retval;
}

//
// This function will attempt to add the array numeric variable name specified by the parameter navarname
// to the symbol table.  It will return true on success, false otherwise.  The lno parameter is the
// line number of the Minimal BASIC line number where the variable is accessed and is used in
// error messages.  If the variable is already defined and of the correct type, true is returned.
//
bool assign_navar(
    const char *navarname,             // pointer to ASCIIZ string continuing scalar numeric variable name
    const uint32_t lno) {              // BASIC source line number
  bool retval = false;                 // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()

  deep_debug_printf("%s(%s)\n", __func__, navarname);
  // ensure incoming ASCIIZ variable name is non-NULL
  if (!navarname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ variable name is non-empty
  if (!navarname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  recno = binary_search(thelist, thelist_count, navarname); // search for navarname in thelist
  if (UINT32_MAX == recno)                                  // navarname not found
    ICE(__FILE__, __func__, __LINE__, emsg[59], navarname, lno);

  if (thelist[recno].exists) {              // if navarname is already defined
    if (NAVAR == thelist[recno].tipe) {     // already defined correctly as a scalar array variable (type check)
      retval = true;
      goto xit;
    }
    fprintf(stderr, emsg[152], navarname, lno);
    goto xit;
  }
  // everything OK
  retval = true;
  thelist[recno].tipe = NAVAR;         // mark this variable as being a numeric array variable
  thelist[recno].exists = true;        // mark this variable as used
  need_BSS_numeric = true;             // set flag to true to indicate that a .bss section
                                       // for numeric variables will be needed
xit:
  deep_debug_printf("%s(%s) returns %s\n", __func__, navarname, (retval ? "true" : "false"));
  return retval;
}

//
// This function will attempt to add the scalar string variable name specified by the parameter svarname
// to the symbol table.  It will return true on success, false otherwise.  If the variable is already
// defined and of the correct type, true is returned.
//
bool assign_svar(
    const char *svarname) {            // pointer to ASCIIZ string containing scalar string variable name
  bool retval = true;                  // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()

  deep_debug_printf("%s(%s)\n", __func__, svarname);
  // ensure incoming ASCIIZ variable name is non-NULL
  if (!svarname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ variable name is non-empty
  if (!svarname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  // search for scalar string variable name s in thelist
  if (((recno = binary_search(thelist, thelist_count, svarname)) == UINT32_MAX) || // if not found
      (thelist[recno].tipe != SVAR)) {                                             // or not the correct type
    retval = false;                              // return false
  } else {                                       // otherwise
    thelist[recno].exists = true;                // mark this scalar string variable as in-use
    need_BSS_string = true;                      // set flag to true to indicate that a .bss section
                                                 // for string variables will be needed
  }

  deep_debug_printf("%s(%s) returns %s\n", __func__, svarname, (retval ? "true" : "false"));
  return retval;
}

//
// This function updates the thealist table with information about a numeric array variable.
// navarname specifies the numeric array variable name
// dims specifies the number of dimensions (1 or 2)
// dim1 is the maximum subscript permitted for the first dimension
// dim2 is the maximum subscript permitted for the second dimensions (0 if dims is 1)
// The function returns true on success, false on failure
//
bool put_array_data(
    const char *navarname,             // pointer to ASCIIZ string containing numeric array variable name
    uint32_t dims,                     // number of dimensions (1 or 2 ONLY)
    uint32_t dim1,                     // maximum permitted index for first dimension
    uint32_t dim2) {                   // maximum permitted index for second dimension
  bool retval = true;                  // variable to store this function's return value
  uint32_t recno;                      // variable to hold index value returned from binary_search()
  unsigned int varindex;

  deep_debug_printf("%s(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ")\n", __func__, navarname, dims, dim1, dim2);
  // ensure incoming ASCIIZ variable name is non-NULL
  if (!navarname)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ variable name is non-empty
  if (!navarname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  if ((dims < 1U) || (dims > 2U)) {           // if dims parameter value is invalid
                                              // report the error and return false
    fprintf(stderr, "%s", emsg[153]);
    retval = false;
    goto xit;
  }
  if (!isupper(navarname[0])) {
    fprintf(stderr, emsg[154], navarname);
    retval = false;
    goto xit;
  }
  if ((1U == dims) && dim2) {                     // specified a non-zero maximum for 2nd dimension in vector
                                                  // report error and return false
    fprintf(stderr, emsg[155], dim2, navarname);
    retval = false;
    goto xit;
  }
  recno = binary_search(thelist, thelist_count, navarname);  // search for navarname in thelist
  if (recno >= thelist_count) {                              // if not found report error and return false
    deep_debug_printf("%s(): variable '%s' not found in primary symbol table\n", __func__, navarname);
    retval = false;
    goto xit;
  }
  deep_debug_printf("%s(): variable '%s' was found in primary symbol table\n", __func__, navarname);
  if ((thelist[recno].tipe != UNDEFINED) && (thelist[recno].tipe != NAVAR)) { // if type is not correct
                                                                              // report error and return false
    deep_debug_printf("%s(): variable '%s' found, but invalid type '%s' is not UNDEFINED or NAVAR\n",
                      __func__, navarname, vartype_names[thelist[recno].tipe]);
    retval = false;
    goto xit;
  }
  deep_debug_printf("%s(): variable '%s' found and valid type is '%s'\n", __func__, navarname, vartype_names[thelist[recno].tipe]);
  varindex = get_var_index(navarname[0]);
  if (thealist[varindex].dims) {     // if number of dimensions has already been set
                                     // report error and return false
    deep_debug_printf("%s(): variable '%s' found but already has been dimensioned\n", __func__, navarname);
    retval = false;
    goto xit;
  }
  deep_debug_printf("%s(): updating primary symbol table\n", __func__);
  thelist[recno].tipe = NAVAR;     // set type to numeric array variable
  thelist[recno].exists = true;    // mark variable as used by this program
  deep_debug_printf("%s(): updating secondary array symbol table\n", __func__);
  thealist[varindex].dims = dims;  // set the number of dimensions
  thealist[varindex].dim1 = dim1;  // set the maximum permitted subscript for the first dimension
  thealist[varindex].dim2 = dim2;  // set the maximum permitted subscript for the second dimension if dims is 2
xit:
  if (!retval)
    deep_debug_printf("%s(): not updating either primary symbol table or secondary array symbol table\n", __func__);
  deep_debug_printf("%s(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") returns %s\n",
                    __func__, navarname, dims, dim1, dim2, (retval ? "true" : "false"));
  return retval;
}

//
// Add a literal data item from a DATA statement
// The literal value is passed as an ASCIIZ string in litvalstr, and the type to use
// is passed in parameter litvaltype.  If successful, true is returned, otherwise
// false is returned.  This can update two lists:
//   1) data block list (if this is not a duplicate of an existing block)
//   2) data pointer list (always, and point to the unique data block for this value
//      that was either found or created in step 1)
//
bool add_data_literal(
    const char *litvalstr,             // pointer to ASCIIZ string containing literal value
    enum data_item_type litvaltype) {  // type of literal value
  struct data_item *temp = data_items; // pointer to data block information
  struct data_list *temp2 = NULL;      // pointer to data pointer information
  char *end = NULL;                    // need by strto[df]()

  debug_printf("%s(\"%s\",%" PRIu32 ")\n", __func__, litvalstr, litvaltype);
  // do we have a data block for this literal value already?
  while (temp) {
    if ((temp->t == litvaltype) && (strcmp(temp->s, litvalstr) == 0))
      break;                           // found it!
    temp = temp->next;
  }

  if (!temp) {                         // if no data block exists for this yet,
                                       // then we must add data block information

    temp = (struct data_item *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct data_item));
    temp->t = litvaltype;              // save type
    temp->next = NULL;                 // initialize next pointer
    temp->s = strdup(litvalstr);       // copy in the actual literal value
    switch(temp->t) {                  // depending on type...
      case QSTR:                       // quoted string
        break;
      case UQSTR:                                // unquoted string
        if (use_double)
          temp->numba.d = strtod(litvalstr, &end);          // store 64bit numeric value
        else
          temp->numba.f = strtof(litvalstr, &end);          // store 32bit numeric value
        if ((end == litvalstr) || (*end)) {
          debug_printf("Hey you, '%s' cannot be a float\n", temp->s);
          if (use_double)                        // store 64bit NaN
            temp->numba.d = nanny64.d;
          else                                   // store 32bit NaN
            temp->numba.f = nanny.f;
          temp->t = QSTR;                        // change the type to QSTR
        } else {
          debug_printf("end points to %" PRIu32 "\n", (unsigned char)*end);
          if (use_double)
            debug_printf("Hey you, '%s' is a float like %1.8E\n", temp->s, temp->numba.d);
          else
            debug_printf("Hey you, '%s' is a float like %1.8E\n", temp->s, temp->numba.f);
          // do not change the type of UQSTR
        }
        break;
      case NUM:                                     // numeric scalar
        if (use_double)                             // if using 64 bit math
          temp->numba.d = strtod(litvalstr, &end);  // store 64bit numeric value
        else                                        // else 32 bit math
          temp->numba.f = strtof(litvalstr, &end);  // store 32bit numeric value
        break;
      case PIVAL:
        if (use_double)
          temp->numba.l = 0x400921fb54442d18;
        else
          temp->numba.w = 0x40490fdb;
        break;
      case MAXNUMVAL:
        if (use_double)
          temp->numba.l = 0x7FEFFFFFFFFFFFFF;
        else
          temp->numba.w = 0x7F7FFFFF;
        break;
      default:                                      // unknown type (ICE)
        ICE(__FILE__, __func__, __LINE__, emsg[61], __func__);
    }
    temp->disymname = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*DISYMNAME_MAX_BYTES);
    // generate symbol name
    snprintf(temp->disymname, SYMNAME_MAX_BYTES, ".LDATA%04" PRIu32, data_item_count++);
    temp->disymname[DISYMNAME_MAX_BYTES - 1] = 0;    // ensure termination
    debug_printf("OK, finally type of '%s' is %s\n", temp->s, data_item_type_names[temp->t]);
    if (!data_items) {                     // if this is the very first data item
      last_data_item = data_items = temp;  // point head and tail to this node
    } else {                               // otherwise
      last_data_item->next = temp;         // append the node to the end of the list of data items
      last_data_item = temp;
    }
  }
  temp2 = (struct data_list *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct data_list));
  temp2->symbol_name = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*SYMNAME_MAX_BYTES);
  memcpy(temp2->symbol_name, temp->disymname, DISYMNAME_MAX_BYTES);       // store generated symbol name
  temp2->symbol_name[SYMNAME_MAX_BYTES - 1] = 0;   // terminate
  temp2->next = NULL;
  if (!data_list_tail) {                           // if this is the very first data pointer
    data_list_head = data_list_tail = temp2;       // point head and tail to this node
  } else { // otherwise
    data_list_tail->next = temp2;                  // append node to end of list of data pointers
    data_list_tail = temp2;
  }
  data_list_count++;
  return true;
}

//
// This function is used to add an input ASCIIZ format string specified by the
// fmt parameter.  Such a string is required to implement the INPUT statement.
// It contains up to 30 bytes of data followed by a NULL.  Each byte of data
// is either an 'S' or a 'N'.  An 'S' signals that a string value should be
// input, and an 'N' signals that a numeric value should be input.
// The lno parameter is the used to pass the Minimal BASIC source
// file line number for use in generating the literal data item symbol name.
// The symbol parameter is used to pass back the generated identifier for that
// format string.
//
bool add_input_format(
    const char *fmt,                   // pointer to ASCIIZ format string
    char **symbol,                     // pointer to pointer to ASCIIZ generated literal data
                                       // item symbol name
    uint32_t lno) {                    // BASIC source line number
  struct literal_item *si = NULL;      // pointer used to create and insert new literal item

  // ensure incoming ASCIIZ format string is non-NULL
  if (!fmt)
    ICE(__FILE__, __func__, __LINE__, emsg[54], __func__);
  // ensure incoming ASCIIZ format string is non-empty
  if (!fmt[0])
    ICE(__FILE__, __func__, __LINE__, emsg[55], __func__);
  // allocate a new literal item node
  si = (struct literal_item *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct literal_item));
  // populate the new literal item node
  si->lisymname = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*LISYMNAME_MAX_BYTES);
  si->litval = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*LITVAL_MAX_BYTES);
  si->next = NULL;                       // this node will be the last node in the list
  snprintf(si->lisymname, LISYMNAME_MAX_BYTES, ".LNFMT%04" PRIu32, lno); // generate symbol name
  si->lisymname[LISYMNAME_MAX_BYTES - 1] = 0;// terminate
  *symbol = si->lisymname;               // fill in symbol parameter to pass the generated symbol
                                         // name back to the caller
  strncpy(si->litval, fmt, LITVAL_MAX_BYTES - 1);    // copy the actual format data into the node
  si->litval[LITVAL_MAX_BYTES - 1] = 0;  // terminate
  if (!literals) {                       // if this is the very first data item
    literals = last_literal = si;        // point head and tail to this node
  } else {                               // otherwise
    last_literal->next = si;             // append the node to the end of the list of literal data items
    last_literal = si;
  }
  return true;
}

//
// This is code to test the module and is not normally used.
// If you compile with UNIT_TEST defined, then this module will
// be a stand-alone program with its own main() that runs some
// self-tests.
//
#ifdef UNIT_TEST
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <getopt.h>
static bool test_empty_symbol_table(const bool qof);
static bool test_user_defined_functions(const bool qof);
static bool test_scalars(const bool qof);
static bool test_vector_arrays(const bool qof);
static bool test_matrix_arrays(const bool qof);
static bool test_string_literals(const bool qof);
static bool test_data_statement(const bool qof);
#define PASS 0
#define FAIL 1
static const char *answers[] = { "PASS", "FAIL" };

static bool test_empty_symbol_table(const bool qof) {
  bool passed = true;
  uint32_t i, j;
  char s[MAX_VARNAME_LEN];

  // first test with empty symbol table
  for (i = 0U; i < 26U; ++i) {
    s[0] = (char)(65U + i);
    s[1] = 0;
    passed = nvar_exists(s)?false:true;
    printf("nvar_exists(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = (char)(65U + i);
    s[1] = '$';
    s[2] = 0;
    passed = nvar_exists(s)?false:true;
    printf("nvar_exists(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    for (j = 0U; j < 10U; j++) {
      s[1] = (char)('0' + j);
      passed = nvar_exists(s)?false:true;
      printf("nvar_exists(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
      fflush(stdout);
      if ((!passed) && qof)
        break;
    }
    if ((!passed) && qof)
      break;
    fflush(stdout);
  }
  clear_symbol_table();
  fflush(stdout);
  fprintf(stderr, "%s: %s\n",__func__,passed?"true":"false");
  return passed;
}

// ASCII-specific
static bool test_user_defined_functions(const bool qof) {
  bool passed = true;
  uint32_t i;

  while (true) {
    char s[4] = "FN",  // room for FN, a letter, and a newline
         a[2] = { 0 }; // room for a letter and a newline

    s[3] = 0; // terminate
    for (i = 0U; i < 26U; ++i) {
      s[2] = (char)(i + 'A');
      passed = !udf_exists(s, a);
      printf("udf_exists(%2s) returns false when not defined: %s\n", s, answers[passed?PASS:FAIL]);
      fflush(stdout);
      if ((!passed) && qof)
        break;
    }
    if ((!passed) && qof)
      break;
    passed = add_udf("FNX", NULL, 10);
    printf("add_udf(\"FNX\",NULL) returns true when not defined: %s\n", answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = add_udf("FNY", "X", 20);
    printf("add_udf(\"FNY\",\"X\") returns true when not defined: %s\n", answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = !add_udf("FNX", NULL, 10);
    printf("add_udf(\"FNX\",NULL) returns false when already defined: %s\n", answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = !add_udf("BOB", NULL, 10);
    printf("add_udf(\"BOB\",NULL) returns false when not defined: %s\n", answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = (udf_exists("FNX", a) && (!a[0]));
    printf("udf_exists(\"FNX\") with no arguments returns true with empty argument when defined: %s\n",
           answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = (udf_exists("FNY", a) && ('X' == a[0]));
    printf("udf_exists(\"FNY\") with one argument \"X\" returns true with correct argument when defined: %s\n",
           answers[passed?PASS:FAIL]);
    fflush(stdout);
    break;
  }
  clear_symbol_table();
  fflush(stdout);
  fprintf(stderr, "%s: %s\n",__func__,passed?"true":"false");
  return passed;
}

static bool test_scalars(const bool qof) {
  bool passed = true;
  char s[MAX_VARNAME_LEN];

  while (true) {
    s[0] = 'A';
    s[1] = 0;
    passed = assign_nvar(s, 1);
    printf("assign_nvar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'K';
    s[1] = '9';
    s[2] = 0;
    passed = assign_nvar(s, 1);
    printf("assign_nvar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'G';
    s[1] = '$';
    s[2] = 0;
    passed = assign_svar(s);
    printf("assign_svar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = '0';
    s[2] = 0;
    passed = assign_nvar(s, 1);
    printf("assign_nvar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = '$';
    s[2] = 0;
    passed = assign_svar(s);
    printf("assign_svar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = 0;
    passed = nvar_exists(s);
    printf("nvar_exists(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'K';
    s[1] = '9';
    s[2] = 0;
    passed = nvar_exists(s);
    printf("nvar_exists(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'G';
    s[1] = '$';
    s[2] = 0;
    passed = svar_exists(s);
    printf("svar_exists(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = '0';
    s[2] = 0;
    passed = nvar_exists(s);
    printf("nvar_exists(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = '$';
    s[2] = 0;
    passed = svar_exists(s);
    printf("svar_exists(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    // redefine?
    s[0] = 'A';
    s[1] = 0;
    passed = assign_nvar(s, 1);
    printf("assign_nvar(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'K';
    s[1] = '9';
    s[2] = 0;
    passed = assign_nvar(s, 1);
    printf("assign_nvar(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'G';
    s[1] = '$';
    s[2] = 0;
    passed = assign_svar(s);
    printf("assign_svar(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = '0';
    s[2] = 0;
    passed = assign_nvar(s, 1);
    printf("assign_nvar(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = '$';
    s[2] = 0;
    passed = assign_svar(s);
    printf("assign_svar(%2s) when defined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    break;
  }
  clear_symbol_table();
  fflush(stdout);
  fprintf(stderr, "%s: %s\n",__func__,passed?"true":"false");
  return passed;
}

static bool test_vector_arrays(const bool qof) {
  bool passed = true;
  arraydata *ad = NULL;
  char s[MAX_VARNAME_LEN];

  while (true) {
    s[0] = 'B';
    s[1] = 0;
    passed = assign_navar(s, 1);
    printf("assign_navar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = put_array_data(s, 1U, 10U, 0U);
    printf("put_array_data(%2s,1,10,0) when defined as NAVAR: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = 0;
    passed = assign_nvar(s, 1);
    printf("assign_nvar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = assign_navar(s, 1);
    printf("assign_navar(%2s) when defined as NVAR: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = !put_array_data(s, 1U, 10U, 0U);
    printf("put_array_data(%2s,1,10,0) when defined as NVAR: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'B';
    s[1] = 0;
    if ((ad = get_array_data(s)) == NULL) {
      passed = false;
    } else {
      if ((ad->dims != 1U) ||
          (ad->dim1 != 10U) ||
          ad->dim2) {
        passed = false;
      } else {
        passed = true;
      }
    }
    printf("get_array_data(%s) when defined as NAVAR: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    break;
  }
  clear_symbol_table();
  fflush(stdout);
  fprintf(stderr, "%s: %s\n",__func__,passed?"true":"false");
  return passed;
}

static bool test_matrix_arrays(const bool qof) {
  bool passed = true;
  arraydata *ad = NULL;
  char s[MAX_VARNAME_LEN];

  while (true) {
    s[0] = 'Z';
    s[1] = 0;
    passed = assign_navar(s, 1);
    printf("assign_navar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = put_array_data(s, 2U, 10U, 20U);
    printf("put_array_data(%2s,2,10,20) when defined as NAVAR: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'A';
    s[1] = 0;
    passed = assign_nvar(s, 1);
    printf("assign_nvar(%2s) when undefined: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = !assign_navar(s, 1);
    printf("assign_navar(%2s) when defined as NVAR: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    passed = !put_array_data(s, 2U, 10U, 20U);
    printf("put_array_data(%2s,2,10,20) when defined as NVAR: %s\n", s, answers[passed?PASS:FAIL]);
    fflush(stdout);
    if ((!passed) && qof)
      break;
    s[0] = 'Z';
    s[1] = 0;
    if ((ad = get_array_data(s)) == NULL) {
      passed = false;
    } else {
      if ((ad->dims != 2U) ||
          (ad->dim1 != 10U) ||
          (ad->dim2 != 20U)) {
        passed = false;
      } else {
        passed = true;
      }
    }
    printf("get_array_data(%s) when defined as NAVAR: %s\n", s, answers[passed?PASS:FAIL]);
    break;
  }
  /* free(s); s = NULL; */
  clear_symbol_table();
  fflush(stdout);
  fprintf(stderr, "%s: %s\n",__func__,passed?"true":"false");
  return passed;
}

static bool test_string_literals(const bool qof) {
  bool passed = true;

  while (true) {
    char *s = NULL;
    char ugly[] = "\\-/";

    if (!add_string_literal("Hello, World!", &s)) {
      passed = false;
    } else {
      if (strcmp(".LSLIT0000", s) != 0)
        passed = false;
    }
    printf("add string literal 'Hello, World!': %s\n", answers[passed?PASS:FAIL]);
    fflush(stdout);
    s = NULL;
    if ((!passed) && qof)
      break;
    if (!add_string_literal("craptastic", &s)) {
      passed = false;
    } else {
      if (strcmp(".LSLIT0001", s) != 0)
        passed = false;
    }
    printf("add string literal 'craptastic': %s\n", answers[passed?PASS:FAIL]);
    fflush(stdout);
    s = NULL;
    if ((!passed) && qof)
      break;
    if (!add_string_literal("1234567890123456789012345678901234567890123456789012345678901234567890", &s)) {
      passed = false;
    } else {
      if (strcmp(".LSLIT0002", s) != 0)
        passed = false;
    }
    printf("add string literal '1234567890123456789012345678901234567890123456789012345678901234567890': %s\n",
           answers[passed?PASS:FAIL]);
    fflush(stdout);
    s = NULL;
    if ((!passed) && qof)
      break;
/*
    ugly[0] = '\\';
    ugly[1] = '-';
    ugly[2] = '/';
    ugly[3] = 0;
 */
    if (!add_string_literal(ugly, &s)) {
      passed = false;
    } else {
      if (strcmp(".LSLIT0003", s) != 0)
        passed = false;
    }
    printf("add string literal '%s': %s\n", ugly, answers[passed?PASS:FAIL]);
    fflush(stdout);
    s = NULL;
    if ((!passed) && qof)
      break;

    break;
  }
  clear_symbol_table();
  fflush(stdout);
  fprintf(stderr, "%s: %s\n",__func__,passed?"true":"false");
  return passed;
}

static bool test_data_statement(const bool qof) {
  bool passed = true;

  printf("Enable DATA statement handling\n");
  need_READSTMT = true;
  while (true) {
    printf("Add DATA item '12345' as unquoted string\n");
    passed = add_data_literal("12345", UQSTR);
    if ((!passed) && qof)
      break;
    printf("Add DATA item 'MONKEY' as quoted string\n");
    passed = add_data_literal("MONKEY", QSTR);
    if ((!passed) && qof)
      break;
    printf("Add DATA item '123' as number\n");
    passed = add_data_literal("123", NUM);
    if ((!passed) && qof)
      break;
    printf("Add DATA item 'MONKEY' as quoted string (duplicate)\n");
    passed = add_data_literal("MONKEY", QSTR);
    if ((!passed) && qof)
      break;
    printf("Add DATA item '123' as number (duplicte)\n");
    passed = add_data_literal("123", NUM);
    if ((!passed) && qof)
      break;
    printf("Add DATA item '3.1415926535' as number\n");
    passed = add_data_literal("3.1415926535", NUM);
    if ((!passed) && qof)
      break;
    printf("Add DATA item '12345' as unquoted string (duplicate)\n");
    passed = add_data_literal("12345", UQSTR);
    if ((!passed) && qof)
      break;
    printf("Add DATA item '3.1415926535' as number (duplicate)\n");
    passed = add_data_literal("3.1415926535", NUM);
    break;
  }
  clear_symbol_table();
  fflush(stdout);
  fprintf(stderr, "%s: %s\n",__func__,passed?"true":"false");
  return passed;
}

int main(int argc, char **argv) {
  bool quit_on_fail = false,
       passed = true;
  char outfile_name[] = "junk.s";
  FILE *outfile = NULL;
  int32_t opt; // variable used by getopt() function

  optimization_level=0U;
  extensions=use_SSE4_1=use_double=verbose=false;
  use_double=true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:XV")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'V':
        quit_on_fail = true;
        // FALLS THROUGH
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer\n");
          passed = false;
          goto xit;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          passed = false;
          goto xit;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          passed = false;
          goto xit;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          passed = false;
          goto xit;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0],true);
        passed = true;
        goto xit;
      default: // unknown option encountered
        fprintf(stderr, "Unknown option\n");
        passed = false;
        goto xit;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fprintf(stderr, "Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
            "you must also specify -X if you want to use those optimization levels\n");
    passed = false;
    goto xit;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fprintf(stderr, "Garbage after last option\n");
    passed = false;
    goto xit;
  }
  init_debug_printf(stderr);
  deep_debug_printf("verbose=%s,quit_on_fail=%s\n", (verbose ? "true" : "false"), (quit_on_fail ? "true" : "false"));
  deep_debug_printf("thealist_count=%" PRIu32 ",thelist_count=%" PRIu32 ",UINT32_MAX=%" PRIu32 "\n",
                    thealist_count, thelist_count, UINT32_MAX);
  deep_debug_printf("%s", "Begin self-test\n");
  passed=(test_empty_symbol_table(quit_on_fail) &&
          test_user_defined_functions(quit_on_fail) &&
          test_scalars(quit_on_fail) &&
          test_vector_arrays(quit_on_fail) &&
          test_matrix_arrays(quit_on_fail) &&
          test_string_literals(quit_on_fail) &&
          test_data_statement(quit_on_fail));
  // test string literals
  if ((outfile = fopen(outfile_name, "w")) == NULL) {
    fprintf(stderr, emsg[157], outfile_name);
    passed = false;
  } else {
    if (!generate_symbol_table(outfile)) {
      fprintf(stderr, emsg[156], outfile_name);
      passed = false;
    }
    fclose(outfile);
  }
  if (verbose)
    dump_symbol_table(false);
  clear_symbol_table();
  fflush(stdout);
  deep_debug_printf("%s", "End self-test\n");
  if (passed)
    unlink(outfile_name);
xit:
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return (passed ? EXIT_SUCCESS : EXIT_FAILURE);
}
#endif
