//
// load_textdata.h - This file contains the header file for load_textdata.c
//
// Copyright (C) 2017,2018,2019,2020,2021,2023  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#ifndef LOAD_TEXTDATA_H
#define LOAD_TEXTDATA_H
#include <inttypes.h>
#include <stdio.h>

// Warning: This depends on each of the 4 fields being 8 bytes and 
//          ilist must be aligned on a 32 byte boundary.
struct ilist {
  const char *fname;                       // name of text file with assembly code
  const unsigned char *data;               // pointer to buffer that contains that code
  const uint64_t datalength;               // number of bytes in data[] buffer
  const uint64_t junk;                     // filler to ensure alignment
};
void WRITEWITHNEWLINE(FILE *f, int k);
void initialize_item_list(void);           // number of elements in item_list[] vector
#endif
