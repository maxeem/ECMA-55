//
// scanner3.c - This is the file containing the scanner
//              for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#ifndef VERBOSE
#define VERBOSE 0
#endif
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <stdlib.h>
#include <stdarg.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stddef.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <inttypes.h>
#include "scanner3.h"
#include "globals.h"
#include "error_messages.h"

// map to convert token identifiers to text string for display
// MUST be in same order (sorted, ascending) as enum token_ids!
const char * const token_names[] = {
  "T_ABS",
  "T_ACOS",
  "T_ADD",
  "T_AND",
  "T_ANGLE",
  "T_ASIN",
  "T_ATN",
  "T_BASE",
  "T_COMMA",
  "T_CEIL",
  "T_COS",
  "T_COSH",
  "T_COT",
  "T_CSC",
  "T_DATA",
  "T_DATE",
  "T_DATE$",
  "T_DEF",
  "T_DEG",
  "T_DIM",
  "T_DIV",
  "T_END",
  "T_EOF",
  "T_EOL",
  "T_EQ",
  "T_EXIT",
  "T_EXP",
  "T_FNID",
  "T_FOR",
  "T_FP",
  "T_GE",
  "T_GO",
  "T_GOSUB",
  "T_GOTO",
  "T_GT",
  "T_IF",
  "T_IP",
  "T_INPUT",
  "T_INT",
  "T_INTEGER",
  "T_LE",
  "T_LEN",
  "T_LET",
  "T_LINE",
  "T_LOG",
  "T_LOG10",
  "T_LOG2",
  "T_LPAREN",
  "T_LT",
  "T_MAX",
  "T_MAXNUM",
  "T_MIN",
  "T_MOD",
  "T_MUL",
  "T_NAVAR",
  "T_NE",
  "T_NEXT",
  "T_NOT",
  "T_NVAR",
  "T_ON",
  "T_OPTION",
  "T_OR",
  "T_PI",
  "T_POW",
  "T_PRINT",
  "T_PROGRAM",
  "T_QSTRING",
  "T_RAD",
  "T_RANDOMIZE",
  "T_READ",
  "T_REAL",
  "T_REM",
  "T_REMAINDER",
  "T_RESTORE",
  "T_RETURN",
  "T_RND",
  "T_ROUND",
  "T_RPAREN",
  "T_SEC",
  "T_SEMI",
  "T_SGN",
  "T_SIN",
  "T_SINH",
  "T_SQR",
  "T_STEP",
  "T_STOP",
  "T_SUB",
  "T_SUBTRACT",
  "T_SVAR",
  "T_TAB",
  "T_TAN",
  "T_TANH",
  "T_THEN",
  "T_TIME",
  "T_TIME$",
  "T_TO",
  "T_TRUNCATE",
  "T_UQSTRING",
  "T_UNKNOWN",        // not a real token
};
#define T_UNKNOWN (T_UQSTRING+1)
// numtokens does not include T_UNKNOWN (-1)
// but otherwise is the number of tokens in the token_names map
const unsigned int numtokens = (unsigned int)(sizeof(token_names)/sizeof(char *)-1);

struct keyword {
 const char * const kwtext;
 const enum token_ids kwtok;
 const bool need_spaces;
};
// normal keywords always used
// MUST be in sorted, ascending order
static const struct keyword keywords[] = {
 { "ABS", T_ABS, false },
 { "ANGLE", T_ANGLE, false },
 { "ATN", T_ATN, false },
 { "BASE", T_BASE, true },
 { "COS", T_COS, false },
 { "DATA", T_DATA, true },
 { "DEF", T_DEF, true },
 { "DIM", T_DIM, true },
 { "END", T_END, true },
 { "EXP", T_EXP, false },
 { "FOR", T_FOR, true },
 { "GO", T_GO, true },
 { "GOSUB", T_GOSUB, true },
 { "GOTO", T_GOTO, true },
 { "IF", T_IF, true },
 { "INPUT", T_INPUT, true },
 { "INT", T_INT, false },
 { "LET", T_LET, true },
 { "LOG", T_LOG, false },
 { "NEXT", T_NEXT, true },
 { "ON", T_ON, true },
 { "OPTION", T_OPTION, true },
 { "PRINT", T_PRINT, true },
 { "RANDOMIZE", T_RANDOMIZE, true },
 { "READ", T_READ, true },
 { "REM", T_REM, true },
 { "RESTORE", T_RESTORE, true },
 { "RETURN", T_RETURN, true },
 { "RND", T_RND, false },
 { "SGN", T_SGN, false },
 { "SIN", T_SIN, false },
 { "SQR", T_SQR, false },
 { "STEP", T_STEP, true },
 { "STOP", T_STOP, true },
 { "SUB", T_SUB, true },
 { "TAB", T_TAB, false },
 { "TAN", T_TAN, false },
 { "THEN", T_THEN, true },
 { "TO", T_TO, true },
};
static const unsigned int numkeywords = (unsigned int)(sizeof(keywords)/sizeof(struct keyword));

// extended keywords when using -X option
// MUST be in sorted, ascending order
static const struct keyword ekeywords[] = {
 { "ACOS", T_ACOS, false },
 { "AND", T_AND, true },
 { "ASIN", T_ASIN, false },
 { "CEIL", T_CEIL, false },
 { "COSH", T_COSH, false },
 { "COT", T_COT, false },
 { "CSC", T_CSC, false },
 { "DATE", T_DATE, false },
 { "DATE$", T_DATES, false },
 { "DEG", T_DEG, false },
 { "EXIT", T_EXIT, true },
 { "FP", T_FP, false },
 { "IP", T_IP, false },
 { "LEN", T_LEN, false },
 { "LOG10", T_LOG10, false },
 { "LOG2", T_LOG2, false },
 { "MAX", T_MAX, false },
 { "MAXNUM", T_MAXNUM, false },
 { "MIN", T_MIN, false },
 { "MOD", T_MOD, false },
 { "NOT", T_NOT, true },
 { "OR", T_OR, true },
 { "PI", T_PI, false },
 { "RAD", T_RAD, false },
 { "REMAINDER", T_REMAINDER, false },
 { "ROUND", T_ROUND, false },
 { "SEC", T_SEC, false },
 { "SINH", T_SINH, false },
 { "TANH", T_TANH, false },
 { "TIME", T_TIME, false },
 { "TIME$", T_TIMES, false },
 { "TRUNCATE", T_TRUNCATE, false },
};
static unsigned int const numekeywords = (unsigned int)(sizeof(ekeywords)/sizeof(struct keyword));

static int kompare(const void *key, const void *member) {
  const char *l = key;
  const struct keyword *r = member;
  return strcmp(l, r->kwtext);
}

static const bool valid_nbschar[128] = {
// NUL SOH STX ETX EOT ENQ ACK BEL BS HT
false, false, false, false, false, false, false, false, false, false,
// LF (newline)
true,
// VT FF CR SO SI DLE DC1 DC2 DC3 DC4
false, false, false, false, false, false, false, false, false, false,
// NAK SYN ETB CAN EN SUB ESC FS GS RS US
false, false, false, false, false, false, false, false, false, false, false,
// SPACE '!' '"' '#' '$' '%' '&' ''' '(' ')'
true, true, true, true, true, true, true, true, true, true,
// '*' '+' ',' '-' '.' '/'
true, true, true, true, true, true,
// '0'..'9'
true, true, true, true, true, true, true, true, true, true,
// ':' ';' '<' '-' '>' '?' '@'
true, true, true, true, true, true, false,
// 'A'..'Z'
true, true, true, true, true, true, true, true, true, true,
true, true, true, true, true, true, true, true, true, true,
true, true, true, true, true, true,
// '[' '\' ']' '^' '_' '`'
false, false, false, true, true, false,
// 'a'..'z'
false, false, false, false, false, false, false, false, false, false,
false, false, false, false, false, false, false, false, false, false,
false, false, false, false, false, false,
// '{' '|' '}' '~' DEL
false, false, false, false, false,
}; // 0..127 for 7-bit ASCII

static const bool valid_echar[128] __attribute__((unused)) = {
// NUL SOH STX ETX EOT ENQ ACK BEL BS HT
false, false, false, false, false, false, false, false, false, false,
// LF (newline)
true,
// VT FF CR SO SI DLE DC1 DC2 DC3 DC4
false, false, false, false, false, false, false, false, false, false,
// NAK SYN ETB CAN EN SUB ESC FS GS RS US
false, false, false, false, false, false, false, false, false, false, false,
// SPACE '!' '"' '#' '$' '%' '&' ''' '(' ')'
true, true, true, true, true, true, true, true, true, true,
// '*' '+' ',' '-' '.' '/'
true, true, true, true, true, true,
// '0'..'9'
true, true, true, true, true, true, true, true, true, true,
// ':' ';' '<' '-' '>' '?' '@'
true, true, true, true, true, true, true,
// 'A'..'Z'
true, true, true, true, true, true, true, true, true, true,
true, true, true, true, true, true, true, true, true, true,
true, true, true, true, true, true,
// '[' '\' ']' '^' '_' '`'
true, true, true, true, true, true,
// 'a'..'z'
true, true, true, true, true, true, true, true, true, true,
true, true, true, true, true, true, true, true, true, true,
true, true, true, true, true, true,
// '{' '|' '}' '~' DEL
true, true, true, true, false,
}; // 0..127 for 7-bit ASCII

static const char * const nicelines[] = {
  NULL, "first", "second", "third", "fourth", "fifth", "sixth", "seventh", "eighth", "ninth",
};

//
// This function will return a pointer to the next token to the caller (normally the parser).
// On errors, the compiler halts.
//
token *peek_next_token(scanner_state *ss) {
  scanner_state temp_ss = *ss;
  token *t = get_next_token(&temp_ss);
  return t;
}

//
// This function will return a pointer to the next token to the caller (normally the parser).
// On errors, the compiler halts.
//
enum token_ids peek_next_tid(scanner_state *ss) {
  enum token_ids thetid = T_UNKNOWN;
  token *t = peek_next_token(ss);
  if (t) {
    thetid = t->tid;
    free(t->toketext); t->toketext = NULL; free(t); t = NULL;
  }
  return thetid;
}

static const char *charname[] = {
  "NUL",              //  0
  "SOH",              //  1
  "STX",              //  2
  "ETX",              //  3
  "EOT",              //  4
  "ENQ",              //  5
  "ACK",              //  6
  "BELL",             //  7
  "BACKSPACE",        //  8
  "HORIZONTAL TAB",   //  9
  "LINEFEED",         // 10
  "VERTICAL TAB",     // 11
  "FORMFEED",         // 12
  "CR",               // 13
  "SO",               // 14
  "SI",               // 15
  "DLE",              // 16
  "DC1",              // 17
  "DC2",              // 18
  "DC3",              // 19
  "DC4",              // 20
  "NAK",              // 21
  "SYN",              // 22
  "ETB",              // 23
  "CAN",              // 24
  "EM",               // 25
  "SUB",              // 26
  "ESCAPE",           // 27
  "FS",               // 28
  "GS",               // 29
  "RS",               // 30
  "US",               // 31
};

//
// Output an error block like this:
//
//   ERROR: reject on 37th column of 30th line
//   ERROR: This error is on or near the BASIC input program line number 280
//   character is '?' (63)
//   FATAL ERROR: Scanner failed on 30th line of input
//
// In scanner2, this was done by the process_one_byte_reject() function.
//
noreturn static void badcharmsg(scanner_state *ss, bool nolc, unsigned long int lno) {
  fprintf(stderr, emsg[128],
          ss->current_column_number, suffix(ss->current_column_number),
          ss->current_source_line_number, suffix(ss->current_source_line_number));
  // what location?
  if (ss->current_nbs_line_number > 0U)
    fprintf(stderr, emsg[131], ss->current_nbs_line_number);
  else
    fprintf(stderr, "%s", emsg[132]);
  // which character?
  switch ((unsigned char)ss->buffer[ss->pos]) {
    case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10:
    case 11: case 12: case 14: case 15: case 16: case 17: case 18: case 19: case 20:
    case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30:
    case 31:
      fprintf(stderr, emsg[125], charname[(unsigned char)ss->buffer[ss->pos]], (unsigned char)ss->buffer[ss->pos]);
      break;
    case 127:
      fprintf(stderr, emsg[125], "DEL", (unsigned char)ss->buffer[ss->pos]);
      break;
    case 13:
      fprintf(stderr, emsg[133], ss->buffer[ss->pos]);
      break;
    default:
      fprintf(stderr, emsg[134], ss->buffer[ss->pos], (unsigned char)ss->buffer[ss->pos]);
      break;
  }
  // why?
  if ((unsigned char)ss->buffer[ss->pos] > 127)
    fprintf(stderr, "%s", emsg[215]);
  if (nolc) {
    if ( ((unsigned char)ss->buffer[ss->pos] > 96U) &&
         ((unsigned char)ss->buffer[ss->pos] < 123U) ) // WARNING: ASCII-specific!!!!!
                                                       // islower() was not working well [sigh]
      fprintf(stderr, "%s", emsg[129]);
  } else {
     switch ((unsigned char)ss->buffer[ss->pos]) {
       case 0: case 1: case 2: case 3: case 4: case 5: case 6: case 7: case 8: case 9: case 10:
       case 11: case 12: case 14: case 15: case 16: case 17: case 18: case 19: case 20:
       case 21: case 22: case 23: case 24: case 25: case 26: case 27: case 28: case 29: case 30:
       case 31: // special character
         fprintf(stderr, emsg[126], charname[(unsigned char)ss->buffer[ss->pos]], (unsigned char)ss->buffer[ss->pos]);
         break;
       case 97: case 98: case 99: case 100: case 101: case 102: case 103: case 104: case 105:
       case 106: case 107: case 108: case 109: case 110: case 111: case 112: case 113: case 114:
       case 115: case 116: case 117: case 118: case 119: case 120: case 121: case 122: // lower-case
         if (!ss->extensions) // -X is not in effeect (no extensions, be strict)
           fprintf(stderr, "%s", emsg[129]);
         break;
       case 127: // special character
         fprintf(stderr, emsg[126], "DEL", (unsigned char)ss->buffer[ss->pos]);
         break;
       default:
         if ((unsigned char)ss->buffer[ss->pos] < 128) {
           if (islower((unsigned char)ss->buffer[ss->pos]))
             fprintf(stderr, "%s", emsg[129]);
           else
             fprintf(stderr, emsg[127], ss->buffer[ss->pos], (unsigned int)(ss->buffer[ss->pos]));
         }
         break;
     }
  }
  if (ss->indatastatement && (' ' == ss->buffer[ss->pos-1]) &&
      ((',' == ss->buffer[ss->pos]) || ('\n' == ss->buffer[ss->pos])))
    fprintf(stderr, "%s", emsg[130]);
  if (verbose)
    FATAL(__FILE__, __func__, __LINE__, emsg[93],
          ss->current_source_line_number, suffix(ss->current_source_line_number), lno);
  FATAL(__FILE__, __func__, __LINE__, emsg[92],
        ss->current_source_line_number, suffix(ss->current_source_line_number));
}

//
// Get rest of line for REM statement
//
static token *rem(token *t, scanner_state *ss,
    char *tbuffer, uint64_t tbuffer_pos) {
  while ((ss->pos < ss->buflen) && ('\n' != ss->buffer[ss->pos])) {
    if (!(*(ss->valid_char))[(unsigned int)ss->buffer[ss->pos]])
      badcharmsg(ss, false, __LINE__);
    tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
    ss->current_column_number++;
  }
  if ((ss->pos == ss->buflen) || ('\n' != ss->buffer[ss->pos]))
    FATAL(__FILE__, __func__, __LINE__,
          "On line %" PRIu32 " missing newline after REM in input.\n",
          ss->current_nbs_line_number);
  tbuffer[tbuffer_pos] = 0; // terminate string (again)
  t->toketext = strdup(tbuffer); // copy string into token
  return t;
}

//
// Attempts to read next DATA item as a T_UQSTRING, T_INTEGER, and T_REAL.
// If that fails, does not update pos or current_column_number
// and returns NULL
//
static token *get_uqs(
    scanner_state *ss,
    char *why) {                  // why b.d, why?
  char junkbuffer[128] = { 0 };   // scratch buffer to hold toketext
  unsigned long int junkbuffer_pos = 0,   // length of string in junkbuffer
                    untrimmed_length = 0; // length of string in junkbuffer (before trim())
  int (*charok)(int) = ss->extensions?isalpha:isupper; // checks for valid alphabetic characters
  uint64_t tpos = ss->pos;           // temporary writable copy of *pos
  token *t = NULL;                // pointer to token that is returned

  // first get everything up to next comma or the end-of-line and put it in junkbuffer
  while ((tpos < ss->buflen) &&
         (junkbuffer_pos < MAXCOLUMN) &&
         (',' != ss->buffer[tpos]) &&
         ('\n' != ss->buffer[tpos]))
    junkbuffer[junkbuffer_pos++] = ss->buffer[tpos++];
  junkbuffer[junkbuffer_pos] = 0;
  untrimmed_length = junkbuffer_pos;
  trim(junkbuffer);
  junkbuffer_pos = strlen(junkbuffer);
  // Now verify it is a valid unquoted string
  if (junkbuffer_pos > 0) {
    unsigned long int ival __attribute__((unused)) = 0;
    char *endptr = NULL;

    // + - . space letter digit
    for (unsigned int i = 0; i < junkbuffer_pos; ++i) {
      if (!(('+' == junkbuffer[i]) ||
            ('-' == junkbuffer[i]) ||
            ('.' == junkbuffer[i]) ||
            (' ' == junkbuffer[i]) ||
            charok(junkbuffer[i]) || // letter
            isdigit(junkbuffer[i]))) { // digit
        sprintf(why, "near column %" PRIu32 ", invalid character '%c' in unquoted string",
                ss->current_column_number + i, (unsigned char)junkbuffer[i]);
        return NULL;
      }
    }
    t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
    t->toketext = strdup(junkbuffer);
    t->pos = ss->pos;
    t->cno = ss->current_column_number;
    // update global state to point after this token
    ss->current_column_number += (uint32_t)junkbuffer_pos;
    ss->pos += untrimmed_length;
    // if we got here, it is a valid T_UQSTRING
    t->tid = T_UQSTRING;
    if (ss->extensions) {
      if (strcmp(junkbuffer, "PI")==0) {
        t->tid = T_PI;
        return t;
      }
      if (strcmp(junkbuffer, "MAXNUM")==0) {
        t->tid = T_MAXNUM;
        return t;
      }
    }
    // but is it a valid integer?
    errno = 0;
    ival = strtoul(t->toketext, &endptr, 10);
    if (*endptr == 0) // yes it is
      t->tid = T_INTEGER;
    else { // or is it a valid real?
      double dval __attribute__((unused)) = 0.0;

      errno = 0;
      dval = strtod(t->toketext, &endptr);
      if (*endptr == 0) // yes it is
        t->tid = T_REAL;
    }
  }
  return t;
}

//
// This function takes over when we found the first byte of a token is a letter
// in the range 'A'..'Z' + '$'
//
// We might have a variable (scalar numeric, scalar string, vector numeric, or
// matrix numeric), a built-in function (string or numeric), a user-defined
// function, or an unquoted string.
//
static token *process_letters(scanner_state *ss) {
  token *t = (token *)NULL;       // pointer to new token we will create and return
  char tbuffer[256] = {0};        // temporary buffer to store toketext
  unsigned int tbuffer_pos = 0;   // current position within temporary buffer
  char ebuf[256] = {0};           // error buffer to use with get_uqs
  struct keyword *recptr = NULL;  // pointer for use searching keyword and
                                  // function tables

  if (ss->indatastatement) {      // if we are already in a DATA statement
    t = get_uqs(ss, ebuf);        // this better be an unquoted string
    if (NULL == t) {
      fprintf(stderr, emsg[221], ss->current_nbs_line_number, ebuf);
      if (verbose)
        FATAL(__FILE__, __func__, __LINE__, emsg[93], ss->current_source_line_number,
              suffix(ss->current_source_line_number), __LINE__);
      else
        FATAL(__FILE__, __func__, __LINE__, emsg[92], ss->current_source_line_number,
              suffix(ss->current_source_line_number));
      abort();
    }
    return t;
  }
  // ok, it's not an unquoted string
  // so go ahead and make a new token and consume that first letter
  t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  t->tid = T_UNKNOWN;
  t->pos = ss->pos;
  t->cno = ss->current_column_number;
  tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
  ss->current_column_number++;
  // if the single letter is followed by a digit
  if ( (ss->pos < ss->buflen) && isdigit(ss->buffer[ss->pos])) {
    // then it's a scalar numeric variable
    tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
    ss->current_column_number++;
    tbuffer[tbuffer_pos] = 0; // terminate string
    t->toketext = strdup(tbuffer); // copy string into token
    t->tid = T_NVAR;
    return t;
  }
  // ok, it's not an unquoted string or a scalar numeric variable
  // if the single letter is followed by a dollar sign
  if ((ss->pos < ss->buflen) && ('$' == ss->buffer[ss->pos])) {
    // then it's a scalar string variable
    tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
    ss->current_column_number++;
    tbuffer[tbuffer_pos] = 0; // terminate string
    t->toketext = strdup(tbuffer); // copy string into token
    t->tid = T_SVAR;
    return t;
  }
  // wow, it's not an unquoted string, a scalar numeric variable,
  // or a scalar string variable.  Let's read all the following
  // letters up until we find a non-letter.
  while ((ss->pos < ss->buflen) &&
         isupper(ss->buffer[ss->pos])) {
    tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
    ss->current_column_number++;
  }
  // If the next byte is a '$', apend it since this is a string
  // function (probably)
  if ((ss->pos < ss->buflen) &&
      (ss->buffer[ss->pos]=='$')) {
    tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
    ss->current_column_number++;
  }
  // Ok, turn what we have into a string
  tbuffer[tbuffer_pos] = 0; // add ASCIIZ terminator
  // If the length of our string is exactly 1, we have a lone
  // letter.  That is either a numeric scalar variable or a
  // numeric array variable.  Which one?
  if (1 == tbuffer_pos) {
    t->tid = T_NVAR;                       // assume it's a scalar
    if ((ss->pos < ss->buflen) &&          // But if it is
        ((' ' == ss->buffer[ss->pos]) ||   // followed by space
         ('(' == ss->buffer[ss->pos]))) {  // or left parenthesis
      // then look ahead for a left parenthesis....
      if (T_LPAREN == peek_next_tid(ss))   // and if the next non-whitespace
        t->tid = T_NAVAR;                  // token is '(' then we know this
                                           // is a numeric array variable
    }
    t->toketext = strdup(tbuffer); // we copy the string into token text
    return t;
  }
  // OK, it's not an unquoted string or any kind of variable.
  // It is longer than 1 byte, but starts with a letter.  Is it a keyword?
  if (!valid_nbschar[(unsigned int)ss->buffer[ss->pos]])
    badcharmsg(ss, true, __LINE__);
  tbuffer[tbuffer_pos] = 0; // add ASCIIZ terminator
  // search the keyword table
  recptr = bsearch(tbuffer, keywords, numkeywords, sizeof(struct keyword), kompare);
  if (recptr) { // if we found the string in the keyword table
    //
    // We need to special case LOG2 here ...
    //
    if (T_LOG == recptr->kwtok) {         // if it is T_LOG
      if ((ss->pos < ss->buflen) &&       // and is followed
          ('2' == ss->buffer[ss->pos])) { // by a 2 then
        (ss->pos)++;                      // consume the 2
        (ss->current_column_number)++;
        tbuffer[tbuffer_pos++] = '2';     // and update tbuffer
        tbuffer[tbuffer_pos] = 0;         // add ASCIIZ terminator
        goto ek_lookup;                   // and jump to extended keyword lookup
      }
      // otherwise fall through, it's not T_LOG2.  Maybes it's T_LOG10?
      if ((ss->pos < ss->buflen) &&       // and is followed
          ('1' == ss->buffer[ss->pos])) { // by a 1 then
        if ((ss->pos+1 < ss->buflen) &&   // and that is followed
          ('0' == ss->buffer[ss->pos+1])) { // by a 0 then
          (ss->pos)+=2;                     // consume the 10
          (ss->current_column_number)+=2;
          tbuffer[tbuffer_pos++] = '1';     // and update tbuffer
          tbuffer[tbuffer_pos++] = '0';     //
          tbuffer[tbuffer_pos] = 0;         // add ASCIIZ terminator
          goto ek_lookup;                   // and jump to extended keyword lookup
        }
        // otherwise fall through, it's not T_LOG10.
      }
      // OK, it's not T_LOG2 or T_LOG10, it's just plain T_LOG, so
      // fall through
    }
    if (recptr->need_spaces) { // if it requires adjacent spaces (keywords do)
                               // then make sure they are indeed there
      if (' ' != ss->buffer[t->pos-1]) {
        fprintf(stderr, emsg[219], ss->current_nbs_line_number, tbuffer);
        if (verbose)
          FATAL(__FILE__, __func__, __LINE__, emsg[93],
                ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
        else
          FATAL(__FILE__, __func__, __LINE__, emsg[92],
                ss->current_source_line_number, suffix(ss->current_source_line_number));
      }
      if ((' ' != ss->buffer[ss->pos]) &&
          ('\n' != ss->buffer[ss->pos])) {
        fprintf(stderr, emsg[220], ss->current_nbs_line_number, tbuffer);
        if (verbose)
          FATAL(__FILE__, __func__, __LINE__, emsg[93],
                ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
        else
          FATAL(__FILE__, __func__, __LINE__, emsg[92],
                ss->current_source_line_number, suffix(ss->current_source_line_number));
      }
    }
    // Ok, it's a keyword, and any needed spaces are there
    t->tid = recptr->kwtok;
    if (T_REM == t->tid) { // if it is the start of a REM statement
      t = rem(t, ss, tbuffer, tbuffer_pos); // call rem() to handle that
      return t;
    }
    // OK, it's a keyword but not REM
    // If it is GO, is it followed by TO or SUB that we can merge into it?
    if (T_GO == t->tid) {
      token *t2 = NULL;
      switch(peek_next_tid(ss)) {
        case T_TO:         // next token is TO, merge to make GOTO
          t->tid = T_GOTO;
          t->toketext = strdup("GOTO");
          // consume the TO token
          t2 = get_next_token(ss); // to update scanner position
          free(t2->toketext); t2->toketext = NULL; free(t2); t2 = NULL;
          break;
        case T_SUB:        // next token is SUB, merge to make GOSUB
          t->tid = T_GOSUB;
          t->toketext = strdup("GOSUB");
          // consume the SUB token
          t2 = get_next_token(ss); // to update scanner position
          free(t2->toketext); t2->toketext = NULL; free(t2); t2 = NULL;
          break;
        default:           // it's a freestanding GO, let parser deal with it
          t->toketext = strdup(tbuffer); // copy string into token
          break;
      }
      return t;
    }
    // It's a keyword, but not REM or GO
    t->toketext = strdup(tbuffer); // copy ASCIIZ string into token text
    // If it's DATA, set indatastatement flag
    if (T_DATA == t->tid) // in DATA statement
      ss->indatastatement = true;
    // Ok, no special casing needed, just return it
    return t;
  }
  // It's not an unquoted string, variable, or keyword.
  // Is it a user-defined function?  If so, it will fit the pattern
  // FN?, where ? is in 'A'..'Z'
  if ((3 == tbuffer_pos) &&
      ('F' == tbuffer[0]) &&
      ('N' == tbuffer[1]) &&
      (isupper(tbuffer[2]))) {
    // yes, it's a user-defined function
    t->toketext = strdup(tbuffer); // copy string into token text
    t->tid = T_FNID;               // set token identifier
    return t;                      // and return it
  }
ek_lookup:
  // Wow, it isn't anything in ECMA-55.  Maybe it's an extension?
  // Let's check the ekyewords table for that even if extensions are not
  // on, since we might want to recommend they be anabled if this is an
  // extended keyword and extensions aren't enabled.
  recptr = bsearch(tbuffer, ekeywords, numekeywords, sizeof(struct keyword), kompare);
  if (ss->extensions) {           // if extensions are enabled
    if (NULL == recptr) {         // but this keyword isn't an extensions
                                  // report an error and quit
      fprintf(stderr, emsg[217], ss->current_nbs_line_number, tbuffer);
      if (verbose)
        FATAL(__FILE__, __func__, __LINE__, emsg[93],
              ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
      else
        FATAL(__FILE__, __func__, __LINE__, emsg[92],
              ss->current_source_line_number, suffix(ss->current_source_line_number));
    }
    // OK, it's a known extension keyword and extensions are enabled
    if (recptr->need_spaces) {           // if it requires spaces
                                         // ensure they are there
      // NOT can have a '(' before it instead of a space (special case)
      if (strcmp(tbuffer, "NOT") == 0) {
        if ((' ' != ss->buffer[t->pos-1]) &&
            (ss->last_tid != T_LPAREN)) {
          fprintf(stderr, emsg[218], ss->current_nbs_line_number, tbuffer);
          if (verbose)
            FATAL(__FILE__, __func__, __LINE__, emsg[93],
                  ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
          else
            FATAL(__FILE__, __func__, __LINE__, emsg[92],
                  ss->current_source_line_number, suffix(ss->current_source_line_number));
        }
      } else {
        if (' ' != ss->buffer[t->pos-1]) {
          fprintf(stderr, emsg[219], ss->current_nbs_line_number, tbuffer);
          if (verbose)
            FATAL(__FILE__, __func__, __LINE__, emsg[93],
                  ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
          else
            FATAL(__FILE__, __func__, __LINE__, emsg[92],
                  ss->current_source_line_number, suffix(ss->current_source_line_number));
        }
      }
      if ((' ' != ss->buffer[ss->pos]) &&
          ('\n' != ss->buffer[ss->pos])) {
        fprintf(stderr, emsg[220], ss->current_nbs_line_number, tbuffer);
        if (verbose)
          FATAL(__FILE__, __func__, __LINE__, emsg[93],
                ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
        else
          FATAL(__FILE__, __func__, __LINE__, emsg[92],
                ss->current_source_line_number, suffix(ss->current_source_line_number));
      }
    }
    // Ok, any needed spaces are there, we know which extended keyword this is,
    // and extensions are enabled, so
    t->tid = recptr->kwtok;        // set the token identifier
    t->toketext = strdup(tbuffer); // and copy string into token text
    return t;                      // and return it
  }
  // Bummer dude, we need to error out.
  if (recptr)     // if we know it's an extension but extensions are not enabled
                  // suggest enablging them
    fprintf(stderr, emsg[222], ss->current_nbs_line_number, tbuffer);
  else            // otherwise just report the error
    fprintf(stderr, emsg[217], ss->current_nbs_line_number, tbuffer);
  // either way, halt the compilation now
  if (verbose)
    FATAL(__FILE__, __func__, __LINE__, emsg[93],
          ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
  else
    FATAL(__FILE__, __func__, __LINE__, emsg[92],
          ss->current_source_line_number, suffix(ss->current_source_line_number));
}

//
// This function will return a pointer to the next token to the caller (normally the parser)
// and update the pos to point to the first byte after the end of that token.
// On errors, the scanner halts.
//
token *get_next_token(scanner_state *ss) {
  token *t = (token *)NULL;       // pointer to new token we will create and return
  char tbuffer[256] = {0};        // temporary buffer to store toketext
  unsigned int tbuffer_pos = 0;   // current position within temporary buffer
  char ebuf[256] = {0};           // error buffer to use with get_uqs

  if (0 == ss->pos) {
    ss->current_nbs_line_number = 0;
    ss->current_source_line_number = 1;
    ss->current_column_number = 1;
    ss->last_tid = T_EOL;
    ss->indatastatement = false;
    // enable lower-case letters if extensions enabled
    ss->valid_char = (ss->extensions?(bool (*)[128])&valid_echar:(bool (*)[128])&valid_nbschar);
  }
  if (ss->pos < ss->buflen) {
    restart:
    if ((ss->buffer[ss->pos] & 0x80) ||
        (!valid_nbschar[(unsigned int)ss->buffer[ss->pos]]))
      badcharmsg(ss, true, __LINE__);
    if ((T_EOL == ss->last_tid) &&
        (!isdigit(ss->buffer[ss->pos]))) {
      fputs(emsg[216], stderr);
      if (verbose)
        FATAL(__FILE__, __func__, __LINE__, emsg[93],
              ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
      else
        FATAL(__FILE__, __func__, __LINE__, emsg[92],
              ss->current_source_line_number, suffix(ss->current_source_line_number));
    }
    switch (ss->buffer[ss->pos]) {
       case '\n':
          if (ss->current_column_number > MAXCOLUMN) {
            fprintf(stderr, emsg[124], ss->current_nbs_line_number, MAXCOLUMN);
            if (verbose)
              FATAL(__FILE__, __func__, __LINE__, emsg[93], ss->current_source_line_number,
                    suffix(ss->current_source_line_number), __LINE__);
            else
              FATAL(__FILE__, __func__, __LINE__, emsg[92], ss->current_source_line_number,
                    suffix(ss->current_source_line_number));
          }
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup("\n");
          t->tid = T_EOL;
          t->pos = ss->pos;
          t->cno = ss->current_column_number;
          ss->pos++;
          ss->current_column_number = 1UL;
          ss->indatastatement = false;
          ss->current_source_line_number++;
          break;
       case ' ':
          ss->pos++;
          ss->current_column_number++;
          goto restart;
       case '"':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->tid = T_QSTRING;
          t->pos = ss->pos++; // skip over opening double quote
          t->cno = ss->current_column_number++;
          while ((ss->pos < ss->buflen) &&
                 ('\n' != ss->buffer[ss->pos]) &&
                 ('"' != ss->buffer[ss->pos])) {
            if (!(*(ss->valid_char))[(unsigned int)ss->buffer[ss->pos]])
              badcharmsg(ss, false, __LINE__);
            tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
            ss->current_column_number++;
          }
          if ((ss->pos == ss->buflen) ||
              ('"' != ss->buffer[ss->pos]))
            FATAL(__FILE__, __func__, __LINE__,
                  "On line %" PRIu32 " closing double quote missing in input.\n",
                  ss->current_nbs_line_number);
          ss->pos++; // skip over closing double quote
          ss->current_column_number++;
          tbuffer[tbuffer_pos] = 0; // terminate string
          t->toketext = strdup(tbuffer); // copy string into token
          break;
       case '(':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup("(");
          t->tid = T_LPAREN;
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          break;
       case ')':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup(")");
          t->tid = T_RPAREN;
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          break;
       case '*':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup("*");
          t->tid = T_MUL;
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          break;
       case '+':
          if (ss->indatastatement)
            t = get_uqs(ss, ebuf);
          if (NULL == t) {
            t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
            t->pos = ss->pos++;
            t->cno = ss->current_column_number++;
            t->toketext = NULL;
            t->tid = T_UNKNOWN;
            if (ss->indatastatement) {
              if ((ss->pos < ss->buflen) && (isdigit(ss->buffer[ss->pos]))) {
                token *t2 = peek_next_token(ss);
                switch (t2->tid) {
                  case T_INTEGER:
                    t->tid = T_INTEGER;
                    t->toketext = strdup(t2->toketext);
                    free(t2->toketext); t2->toketext = NULL; free(t2); t2 = NULL;
                    t2 = get_next_token(ss); // update pos
                    break;
                  case T_REAL:
                    t->tid = T_REAL;
                    t->toketext = strdup(t2->toketext);
                    free(t2->toketext); t2->toketext = NULL; free(t2); t2 = NULL;
                    t2 = get_next_token(ss); // update pos
                    break;
                  default:
                    ICE(__FILE__, __func__, __LINE__, "%s", "Impossible Error!\n");
                }
                free(t2->toketext); t2->toketext = NULL; free(t2); t2 = NULL;
              } else {
                ICE(__FILE__, __func__, __LINE__, "%s", "Impossible Error!\n");
              }
            } else {
              t->toketext = strdup("+");
              t->tid = T_ADD;
            }
          }
          break;
       case ',':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup(",");
          t->tid = T_COMMA;
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          break;
       case '-':
          if (ss->indatastatement)
            t = get_uqs(ss, ebuf);
          if (NULL == t) {
            t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
            t->pos = ss->pos++;
            t->cno = ss->current_column_number++;
            if (ss->indatastatement) {
              if (ss->pos < ss->buflen)  {
                token *t2 = peek_next_token(ss);
                switch (t2->tid) {
                  case T_INTEGER:
                    t->tid = T_INTEGER;
                    t->toketext = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(strlen(t2->toketext)+2));
                    strcpy(t->toketext, "-");
                    strcat(t->toketext, t2->toketext);
                    free(t2->toketext); t2->toketext = NULL; free(t2); t2 = NULL;
                    t2 = get_next_token(ss); // update pos
                    break;
                  case T_REAL:
                    t->tid = T_REAL;
                    t->toketext = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(strlen(t2->toketext)+2));
                    strcpy(t->toketext, "-");
                    strcat(t->toketext, t2->toketext);
                    free(t2->toketext); t2->toketext = NULL; free(t2); t2 = NULL;
                    t2 = get_next_token(ss); // update pos
                    break;
                  default:
                    ICE(__FILE__, __func__, __LINE__, "%s", "Impossible Error!\n");
                }
                free(t2->toketext); t2->toketext = NULL; free(t2); t2 = NULL;
              } else {
                ICE(__FILE__, __func__, __LINE__, "%s", "Impossible Error!\n");
              }
            } else {
              t->toketext = strdup("-");
              t->tid = T_SUBTRACT;
            }
          }
          break;
       case '.':
          if (ss->indatastatement)
            t = get_uqs(ss, ebuf);
          if (NULL == t) {
            t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
            t->tid = T_REAL;
            t->pos = ss->pos;
            t->cno = ss->current_column_number++;
            tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
            goto gotareal;
          }
          break;
       case '/':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup("/");
          t->tid = T_DIV;
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          break;
       case '0': case '1': case '2': case '3': case '4':
       case '5': case '6': case '7': case '8': case '9':
          if (ss->indatastatement)
            t = get_uqs(ss, ebuf);
          if (NULL == t) {
            t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
            t->tid = T_INTEGER;
            t->pos = ss->pos;
            t->cno = ss->current_column_number++;
            tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
            while ((ss->pos < ss->buflen) &&
                   isdigit(ss->buffer[ss->pos])) {
              tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
              ss->current_column_number++;
            }
            if ((ss->pos < ss->buflen) && ('.' == ss->buffer[ss->pos])) { // if we see a decimal point
                t->tid = T_REAL;
                tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
                ss->current_column_number++;
            }
            gotareal:
            while ((ss->pos < ss->buflen) &&
                   isdigit(ss->buffer[ss->pos])) {
              tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
              ss->current_column_number++;
            }
            {
              bool saw_an_E = false,       // did we see an 'E' ?
                   gotexponent = false;    // did we get at least 1 digit of exponent?
              if ((ss->pos < ss->buflen) && ('E' == ss->buffer[ss->pos])) { // if we see an E
                saw_an_E = true;
                t->tid = T_REAL; // maybe we see E without decimal point....
                tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
                ss->current_column_number++;
                if ((ss->pos < ss->buflen) &&
                    (('-' == ss->buffer[ss->pos]) || ('+' == ss->buffer[ss->pos]))) { // if we see a '+' or '-'
                  tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
                  ss->current_column_number++;
                }
                while ((ss->pos < ss->buflen) &&
                       isdigit(ss->buffer[ss->pos])) {
                  tbuffer[tbuffer_pos++] = ss->buffer[ss->pos++];
                  ss->current_column_number++;
                  gotexponent = true;
                }
              }
              tbuffer[tbuffer_pos] = 0; // terminate string
              if (saw_an_E && (!gotexponent)) {
                if (!ss->indatastatement)
                  FATAL(__FILE__, __func__, __LINE__,
                        "On line %" PRIu32 " missing exponent in input.\n",
                        ss->current_nbs_line_number);
                // rewind, hunt for T_UQSTRING instead
                ss->pos = t->pos;
                ss->current_column_number = t->cno;
                free(t->toketext); t->toketext = NULL; free(t); t = NULL;
                t = get_uqs(ss, ebuf);
              }
            }
            if (t==NULL)
              FATAL(__FILE__, __func__, __LINE__, "NULL token"); // should not be possible....
            if (t->tid != T_UQSTRING)
              t->toketext = strdup(tbuffer); // copy string into token
            if ((T_EOL == ss->last_tid) &&
                (t->tid == T_INTEGER)) { // this is a line nmber
              char *endptr = NULL;
              uint64_t lno = 0;
              char ebuffer[256] = {0};
              errno = 0;
              lno = (uint64_t)strtoul(tbuffer, &endptr, 10);
              if (*endptr != 0) {
                if (ss->current_source_line_number < 10)
                  sprintf(ebuffer, "On %s line of source, ",
                          nicelines[ss->current_source_line_number]);
                else
                  sprintf(ebuffer, "On %" PRIu32 "%s line of source, ",
                          ss->current_source_line_number,
                          suffix(ss->current_source_line_number));
                switch (errno) {
                  case ERANGE:
                    FATAL(__FILE__, __func__, __LINE__,
                          "%s integer '%s' is out of range.\n",
                          ebuffer, tbuffer);
                  default: // including EINVAL
                    FATAL(__FILE__, __func__, __LINE__,
                          "%s bad integer conversion for '%s'.\n",
                          ebuffer, tbuffer);
                }
              }
              if ((lno < 1U) || (lno > 9999U)) {
                fprintf(stderr, emsg[1], tbuffer, MAXLINENO);
                if (verbose)
                  FATAL(__FILE__, __func__, __LINE__, emsg[93],
                        ss->current_source_line_number, suffix(ss->current_source_line_number), __LINE__);
                else
                  FATAL(__FILE__, __func__, __LINE__, emsg[92],
                        ss->current_source_line_number, suffix(ss->current_source_line_number));
              }
              ss->current_nbs_line_number = (uint32_t)lno; // OK to cast since we checked range already
            }
          }
          break;
       case ';':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup(";");
          t->tid = T_SEMI;
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          break;
       case '<':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          // there must be at least one more byte, even if it is 0
          switch (ss->buffer[ss->pos]) {
            case '=':
              ss->pos++; ss->current_column_number++;
              t->toketext = strdup("<=");
              t->tid = T_LE;
              break;
            case '>':
              ss->pos++; ss->current_column_number++;
              t->toketext = strdup("<>");
              t->tid = T_NE;
              break;
            default:
              t->toketext = strdup("<");
              t->tid = T_LT;
          }
          break;
       case '=':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup("=");
          t->tid = T_EQ;
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          break;
       case '>':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          // there must be at least one more byte, even if it is 0
          switch (ss->buffer[ss->pos]) {
            case '=':
              ss->pos++; ss->current_column_number++;
              t->toketext = strdup(">=");
              t->tid = T_GE;
              break;
            default:
              t->toketext = strdup(">");
              t->tid = T_GT;
              break;
          }
          break;
       case 'A': case 'B': case 'C': case 'D': case 'E': case 'F': // letters A..Z + $
       case 'G': case 'H': case 'I': case 'J': case 'K': case 'L':
       case 'M': case 'N': case 'O': case 'P': case 'Q': case 'R':
       case 'S': case 'T': case 'U': case 'V': case 'W': case 'X':
       case 'Y': case 'Z': case '$':
          t = process_letters(ss);
          break;
       case '^':
          t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
          t->toketext = strdup("^");
          t->tid = T_POW;
          t->pos = ss->pos++;
          t->cno = ss->current_column_number++;
          break;
       default:
          badcharmsg(ss, false, __LINE__);
    }
  } else {
    if (tbuffer_pos > 0)
       printf("oh no, lost token!\n");
    t = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
    t->toketext = strdup("<<end of file>>");
    t->tid = T_EOF;
    t->pos = ss->pos;
    t->cno = ss->current_column_number;
  }
  ss->last_tid = t->tid;
  t->lno = ss->current_nbs_line_number;
  return t;
}

#ifdef UNIT_TEST
#include <getopt.h>

struct tt {
  char const * const s;           // pointer to buffer with ASCIIZ string containing the
                                  // Minimal BASIC source code line
  const uint32_t howmany;         // The number of tokens in the token stream
  const token t[60];              // Array of tokens representing the token stream
};
static char *cookit(char const * const s);
static int positive_lookup_tests(const struct keyword *tbl, const unsigned int num_elements);
static int negative_lookup_tests(const struct keyword *tbl, const unsigned int num_elements);
static int parse_tests(const struct tt *test_array, const unsigned int test_count,
                       const bool have_extensions, const bool qof);

static const struct tt tests[] = {
   {"3000 DATA -0.987654000E+05, 0.999948424E+00\n",
     7U,
     {{T_INTEGER,(char *)"3000",3000,1,0},{T_DATA,(char *)"DATA",3000,6,5},{T_REAL,(char *)"-0.987654000E+05",3000,11,10},
      {T_COMMA,(char *)",",3000,27,26},{T_REAL,(char *)"0.999948424E+00",3000,29,28},
      {T_EOL,(char *)"\n",3000,44,43},{T_EOF,(char *)"EOF",3000,45,44}}
   },
   {"7 DEF FNA(X) = X*X\n",
     12U,
     {{T_INTEGER,(char *)"7",7,1,0},{T_DEF,(char *)"DEF",7,3,2},{T_FNID,(char *)"FNA",7,7,6},
      {T_LPAREN,(char *)"(",7,10,9},{T_NVAR,(char *)"X",7,11,10},{T_RPAREN,(char *)")",7,12,11},
      {T_EQ,(char *)"=",7,14,13},{T_NVAR,(char *)"X",7,16,15},{T_MUL,(char *)"*",7,17,16},{T_NVAR,(char *)"X",7,18,17},
      {T_EOL,(char *)"\n",7,19,18}, {T_EOF,(char *)"EOF",7,20,19}}
   },
   {"8 DATA 1E\n",
     5U,
     {{T_INTEGER,(char *)"8",8,1,0},{T_DATA,(char *)"DATA",8,3,2},{T_UQSTRING,(char *)"1E",8,8,7},{T_EOL,(char *)"\n",8,10,9},
      {T_EOF,(char *)"EOF",8,11,10}}
   },
   {"9 DATA 123ABC\n",
     5U,
     {{T_INTEGER,(char *)"9",9,1,0},{T_DATA,(char *)"DATA",9,3,2},{T_UQSTRING,(char *)"123ABC",9,8,7},{T_EOL,(char *)"\n",9,14,13},
      {T_EOF,(char *)"EOF",9,15,14}}
   },
   {"10 DATA ABC123\n",
     5U,
     {{T_INTEGER,(char *)"10",10,1,0},{T_DATA,(char *)"DATA",10,4,3},{T_UQSTRING,(char *)"ABC123",10,9,8},{T_EOL,(char *)"\n",10,15,14},
      {T_EOF,(char *)"EOF",10,16,15}}
   },
   {"11 PRINT \"_\"\n",
    5U,
    {{T_INTEGER,(char *)"11",11,1,0}, {T_PRINT,(char *)"PRINT",11,4,3}, {T_QSTRING,(char *)"_",11,10,9}, {T_EOL,(char *)"\n",11,13,12},
     {T_EOF,(char *)"EOF",11,14,13}}
    },
   {"12 REM COMMENT_WITH_UNDERSCORE\n",
    4U,
    {{T_INTEGER,(char *)"12",12,1,0}, {T_REM,(char *)"REM COMMENT_WITH_UNDERSCORE",12,4,3}, {T_EOL,(char *)"\n",12,31,30},
     {T_EOF,(char *)"EOF",12,32,31}}
    },
   {"13 LET A=INT(360/0.31415926535E-1+2*4/(1+(-2)-1))+SIN(B2)/TAN(LOG(0^0))\n",
    42U,
    {{T_INTEGER,(char *)"13",13,1,0}, {T_LET,(char *)"LET",13,4,3}, {T_NVAR,(char *)"A",13,8,7}, {T_EQ,(char *)"=",13,9,8}, {T_INT,(char *)"INT",13,10,9},
     {T_LPAREN,(char *)"(",13,13,12}, {T_INTEGER,(char *)"360",13,14,13}, {T_DIV,(char *)"/",13,17,16}, {T_REAL,(char *)"0.31415926535E-1",13,18,17}, {T_ADD,(char *)"+",13,34,33},
     {T_INTEGER,(char *)"2",13,35,34}, {T_MUL,(char *)"*",13,36,35},{T_INTEGER,(char *)"4",13,37,36}, {T_DIV,(char *)"/",13,38,37}, {T_LPAREN,(char *)"(",13,39,38},
     {T_INTEGER,(char *)"1",13,40,39}, {T_ADD,(char *)"+",13,41,40},{T_LPAREN,(char *)"(",13,42,41}, {T_SUBTRACT,(char *)"-",13,43,42}, {T_INTEGER,(char *)"2",13,44,43},
     {T_RPAREN,(char *)")",13,45,44},
     {T_SUBTRACT,(char *)"-",13,46,45}, {T_INTEGER,(char *)"1",13,47,46}, {T_RPAREN,(char *)")",13,48,47}, {T_RPAREN,(char *)")",13,49,48}, {T_ADD,(char *)"+",13,50,49},
     {T_SIN,(char *)"SIN",13,51,50}, {T_LPAREN,(char *)"(",13,54,53}, {T_NVAR,(char *)"B2",13,55,54}, {T_RPAREN,(char *)")",13,57,56}, {T_DIV,(char *)"/",13,58,57},
     {T_TAN,(char *)"TAN",13,59,58}, {T_LPAREN,(char *)"(",13,62,61}, {T_LOG,(char *)"LOG",13,63,62}, {T_LPAREN,(char *)"(",13,66,65}, {T_INTEGER,(char *)"0",13,67,66},
     {T_POW,(char *)"^",13,68,67}, {T_INTEGER,(char *)"0",13,69,68}, {T_RPAREN,(char *)")",13,70,69}, {T_RPAREN,(char *)")",13,71,70}, {T_EOL,(char *)"\n",13,72,71},
     {T_EOF,(char *)"EOF",13,73,72}}
   },
   {"14 LET A=INT(360/0.31415926535E-1+2*4/(1+(-2))-1)+SIN(B2)/TAN(LOG(0^0))\n",
    42U,
    {{T_INTEGER,(char *)"14",14,1,0},  {T_LET,(char *)"LET",14,4,3},       {T_NVAR,(char *)"A",14,8,7},      {T_EQ,(char *)"=",14,9,8}, {T_INT,(char *)"INT",14,10,9},
     {T_LPAREN,(char *)"(",14,13,12},  {T_INTEGER,(char *)"360",14,14,13}, {T_DIV,(char *)"/",14,17,16},     {T_REAL,(char *)"0.31415926535E-1",14,18,17}, {T_ADD,(char *)"+",14,34,33},
     {T_INTEGER,(char *)"2",14,35,34}, {T_MUL,(char *)"*",14,36,35},       {T_INTEGER,(char *)"4",14,37,36}, {T_DIV,(char *)"/",14,38,37}, {T_LPAREN,(char *)"(",14,39,38},
     {T_INTEGER,(char *)"1",14,40,39}, {T_ADD,(char *)"+",14,41,40},       {T_LPAREN,(char *)"(",14,42,41},  {T_SUBTRACT,(char *)"-",14,43,42}, {T_INTEGER,(char *)"2",14,44,43},
     {T_RPAREN,(char *)")",14,45,44},
     {T_RPAREN,(char *)")",14,46,45},  {T_SUBTRACT,(char *)"-",14,47,46},  {T_INTEGER,(char *)"1",14,48,47}, {T_RPAREN,(char *)")",14,49,48}, {T_ADD,(char *)"+",14,50,49},
     {T_SIN,(char *)"SIN",14,51,50},   {T_LPAREN,(char *)"(",14,54,53},    {T_NVAR,(char *)"B2",14,55,54},   {T_RPAREN,(char *)")",14,57,56}, {T_DIV,(char *)"/",14,58,57},
     {T_TAN,(char *)"TAN",14,59,58},   {T_LPAREN,(char *)"(",14,62,61},    {T_LOG,(char *)"LOG",14,63,62},   {T_LPAREN,(char *)"(",14,66,65}, {T_INTEGER,(char *)"0",14,67,66},
     {T_POW,(char *)"^",14,68,67},     {T_INTEGER,(char *)"0",14,69,68},   {T_RPAREN,(char *)")",14,70,69},  {T_RPAREN,(char *)")",14,71,70}, {T_EOL,(char *)"\n",14,72,71},
     {T_EOF,(char *)"EOF",14,73,72}}
   },
   {"15 LET A=A+2\n",
    9U,
    {{T_INTEGER,(char *)"15",15,1,0}, {T_LET,(char *)"LET",15,4,3}, {T_NVAR,(char *)"A",15,8,7}, {T_EQ,(char *)"=",15,9,8},
     {T_NVAR,(char *)"A",15,10,9}, {T_ADD,(char *)"+",15,11,10}, {T_INTEGER,(char *)"2",15,12,11}, {T_EOL,(char *)"\n",15,13,12},
     {T_EOF,(char *)"EOF",15,14,13}}
   },
   {"16 PRINT RND\n",
     5U,
     {{T_INTEGER,(char *)"16",16,1,0}, {T_PRINT,(char *)"PRINT",16,4,3}, {T_RND,(char *)"RND",16,10,9}, {T_EOL,(char *)"\n",16,13,12},
      {T_EOF,(char *)"EOF",16,14,13}}
   },
   {"17 PRINT ABS(-1)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_ABS,(char *)"ABS",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_INTEGER,(char *)"1",17,15,14}, {T_RPAREN,(char *)")",17,16,15}, {T_EOL,(char *)"\n",17,17,16}, {T_EOF,(char *)"EOF",17,18,17}}
   },
   {"18 DATA \"\"\n",
     5U,
     {{T_INTEGER,(char *)"18",18,1,0},{T_DATA,(char *)"DATA",18,4,3},{T_QSTRING,(char *)"",18,9,8},{T_EOL,(char *)"\n",18,11,10},
      {T_EOF,(char *)"EOF",18,12,11}}
   },
   {"19 DATA 123\n",
     5U,
     {{T_INTEGER,(char *)"19",19,1,0},{T_DATA,(char *)"DATA",19,4,3},{T_INTEGER,(char *)"123",19,9,8},{T_EOL,(char *)"\n",19,12,11},
      {T_EOF,(char *)"EOF",19,13,12}}
   },
   {"20 DATA 123, 456,  789\n",
     9U,
     {{T_INTEGER,(char *)"20",20,1,0}, {T_DATA,(char *)"DATA",20,4,3}, {T_INTEGER,(char *)"123",20,9,8}, {T_COMMA,(char *)",",20,12,11},
      {T_INTEGER,(char *)"456",20,14,13}, {T_COMMA,(char *)",",20,17,16}, {T_INTEGER,(char *)"789",20,20,19}, {T_EOL,(char *)"\n",20,23,22},
      {T_EOF,(char *)"EOF",20,24,23}}
   },
   {"21 PRINT -0.31415926535E-1+234\n",
    8U,
    {{T_INTEGER,(char *)"21",21,1,0}, {T_PRINT,(char *)"PRINT",21,4,3}, {T_SUBTRACT,(char *)"-",21,10,9}, {T_REAL,(char *)"0.31415926535E-1",21,11,10},
     {T_ADD,(char *)"+",21,27,26},{T_INTEGER,(char *)"234",21,28,27}, {T_EOL,(char *)"\n",21,31,30},{T_EOF,(char *)"EOF",21,32,31}}
   },
   {"22 DATA 1,0.1,.1,-1,-.1,-0.001E+3\n",
    15U,
    {{T_INTEGER,(char *)"22",22,1,0}, {T_DATA,(char *)"DATA",22,4,3}, {T_INTEGER,(char *)"1",22,9,8}, {T_COMMA,(char *)",",22,10,9},
     {T_REAL,(char *)"0.1",22,11,10}, {T_COMMA,(char *)",",22,14,13}, {T_REAL,(char *)".1",22,15,14}, {T_COMMA,(char *)",",22,17,16},
     {T_INTEGER,(char *)"-1",22,18,17}, {T_COMMA,(char *)",",22,20,19}, {T_REAL,(char *)"-.1",22,21,20}, {T_COMMA,(char *)",",22,24,23},
     {T_REAL,(char *)"-0.001E+3",22,25,24}, {T_EOL,(char *)"\n",22,34,33}, {T_EOF,(char *)"EOF",22,35,34}}
   },
   {"23 PRINT A(1),A(1,2)\n",
    15U,
    {{T_INTEGER,(char *)"23",23,1,0}, {T_PRINT,(char *)"PRINT",23,4,3}, {T_NAVAR,(char *)"A",23,10,9}, {T_LPAREN,(char *)"(",23,11,10},
     {T_INTEGER,(char *)"1",23,12,11}, {T_RPAREN,(char *)")",23,13,12}, {T_COMMA,(char *)",",23,14,13}, {T_NAVAR,(char *)"A",23,15,14},
     {T_LPAREN,(char *)"(",23,16,15}, {T_INTEGER,(char *)"1",23,17,16}, {T_COMMA,(char *)",",23,18,17}, {T_INTEGER,(char *)"2",23,19,18},
     {T_RPAREN,(char *)")",23,20,19}, {T_EOL,(char *)"\n",23,21,20}, {T_EOF,(char *)"EOF",23,22,21}}
   },
   {"24 LET A(1)=1\n",
    10U,
    {{T_INTEGER,(char *)"24",24,1,0}, {T_LET,(char *)"LET",24,4,3}, {T_NAVAR,(char *)"A",24,8,7}, {T_LPAREN,(char *)"(",24,9,8},
     {T_INTEGER,(char *)"1",24,10,9}, {T_RPAREN,(char *)")",24,11,10}, {T_EQ,(char *)"=",24,12,11}, {T_INTEGER,(char *)"1",24,13,12},
     {T_EOL,(char *)"\n",24,14,13}, {T_EOF,(char *)"EOF",24,15,14}}
   },
   {"25 PRINT A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z\n",
     55U,
     {{T_INTEGER,(char *)"25",25,1,0}, {T_PRINT,(char *)"PRINT",25,4,3}, {T_NVAR,(char *)"A",25,10,9}, {T_COMMA,(char *)",",25,11,10},
      {T_NVAR,(char *)"B",25,12,11},  {T_COMMA,(char *)",",25,13,12}, {T_NVAR,(char *)"C",25,14,13},  {T_COMMA,(char *)",",25,15,14}, {T_NVAR,(char *)"D",25,16,15},
      {T_COMMA,(char *)",",25,17,16}, {T_NVAR,(char *)"E",25,18,17},  {T_COMMA,(char *)",",25,19,18}, {T_NVAR,(char *)"F",25,20,19},  {T_COMMA,(char *)",",25,21,20},
      {T_NVAR,(char *)"G",25,22,21},  {T_COMMA,(char *)",",25,23,22}, {T_NVAR,(char *)"H",25,24,23},  {T_COMMA,(char *)",",25,25,24}, {T_NVAR,(char *)"I",25,26,25},
      {T_COMMA,(char *)",",25,27,26}, {T_NVAR,(char *)"J",25,28,27},  {T_COMMA,(char *)",",25,29,28}, {T_NVAR,(char *)"K",25,30,29},  {T_COMMA,(char *)",",25,31,30},
      {T_NVAR,(char *)"L",25,32,31},  {T_COMMA,(char *)",",25,33,32}, {T_NVAR,(char *)"M",25,34,33},  {T_COMMA,(char *)",",25,35,34}, {T_NVAR,(char *)"N",25,36,35},
      {T_COMMA,(char *)",",25,37,36}, {T_NVAR,(char *)"O",25,38,37},  {T_COMMA,(char *)",",25,39,38}, {T_NVAR,(char *)"P",25,40,39},  {T_COMMA,(char *)",",25,41,40},
      {T_NVAR,(char *)"Q",25,42,41},  {T_COMMA,(char *)",",25,43,42}, {T_NVAR,(char *)"R",25,44,43},  {T_COMMA,(char *)",",25,45,44}, {T_NVAR,(char *)"S",25,46,45},
      {T_COMMA,(char *)",",25,47,46}, {T_NVAR,(char *)"T",25,48,47},  {T_COMMA,(char *)",",25,49,48}, {T_NVAR,(char *)"U",25,50,49},  {T_COMMA,(char *)",",25,51,50},
      {T_NVAR,(char *)"V",25,52,51},  {T_COMMA,(char *)",",25,53,52}, {T_NVAR,(char *)"W",25,54,53},  {T_COMMA,(char *)",",25,55,54}, {T_NVAR,(char *)"X",25,56,55},
      {T_COMMA,(char *)",",25,57,56}, {T_NVAR,(char *)"Y",25,58,57},  {T_COMMA,(char *)",",25,59,58}, {T_NVAR,(char *)"Z",25,60,59},  {T_EOL,(char *)"\n",25,61,60},
      {T_EOF,(char *)"EOF",25,62,61}}
    },
   {"26 PRINT A9,B9,C9,D9,E9,F9,G9,H9,I9,J9,K9,L9,M9,N9,O9,P9,Q9,R9,S9,T9,U9\n",
     45U,
     {{T_INTEGER,(char *)"26",26,1,0}, {T_PRINT,(char *)"PRINT",26,4,3}, {T_NVAR,(char *)"A9",26,10,9}, {T_COMMA,(char *)",",26,12,11},
      {T_NVAR,(char *)"B9",26,13,12}, {T_COMMA,(char *)",",26,15,14}, {T_NVAR,(char *)"C9",26,16,15}, {T_COMMA,(char *)",",26,18,17}, {T_NVAR,(char *)"D9",26,19,18},
      {T_COMMA,(char *)",",26,21,20}, {T_NVAR,(char *)"E9",26,22,21}, {T_COMMA,(char *)",",26,24,23}, {T_NVAR,(char *)"F9",26,25,24}, {T_COMMA,(char *)",",26,27,26},
      {T_NVAR,(char *)"G9",26,28,27}, {T_COMMA,(char *)",",26,30,29}, {T_NVAR,(char *)"H9",26,31,30}, {T_COMMA,(char *)",",26,33,32}, {T_NVAR,(char *)"I9",26,34,33},
      {T_COMMA,(char *)",",26,36,35}, {T_NVAR,(char *)"J9",26,37,36}, {T_COMMA,(char *)",",26,39,38}, {T_NVAR,(char *)"K9",26,40,39}, {T_COMMA,(char *)",",26,42,41},
      {T_NVAR,(char *)"L9",26,43,42}, {T_COMMA,(char *)",",26,45,44}, {T_NVAR,(char *)"M9",26,46,45}, {T_COMMA,(char *)",",26,48,47}, {T_NVAR,(char *)"N9",26,49,48},
      {T_COMMA,(char *)",",26,51,50}, {T_NVAR,(char *)"O9",26,52,51}, {T_COMMA,(char *)",",26,54,53}, {T_NVAR,(char *)"P9",26,55,54}, {T_COMMA,(char *)",",26,57,56},
      {T_NVAR,(char *)"Q9",26,58,57}, {T_COMMA,(char *)",",26,60,59}, {T_NVAR,(char *)"R9",26,61,60}, {T_COMMA,(char *)",",26,63,62}, {T_NVAR,(char *)"S9",26,64,63},
      {T_COMMA,(char *)",",26,66,65}, {T_NVAR,(char *)"T9",26,67,66}, {T_COMMA,(char *)",",26,69,68}, {T_NVAR,(char *)"U9",26,70,69}, {T_EOL,(char *)"\n",26,72,71},
      {T_EOF,(char *)"EOF",26,73,72}}
    },
   {"27 PRINT A$,B$,C$,D$,E$,F$,G$,H$,I$,J$,K$,L$,M$,N$,O$,P$,Q$,R$,S$,T$,U$\n",
     45U,
     {{T_INTEGER,(char *)"27",27,1,0}, {T_PRINT,(char *)"PRINT",27,4,3}, {T_SVAR,(char *)"A$",27,10,9}, {T_COMMA,(char *)",",27,12,11},
      {T_SVAR,(char *)"B$",27,13,12}, {T_COMMA,(char *)",",27,15,14}, {T_SVAR,(char *)"C$",27,16,15}, {T_COMMA,(char *)",",27,18,17}, {T_SVAR,(char *)"D$",27,19,18},
      {T_COMMA,(char *)",",27,21,20}, {T_SVAR,(char *)"E$",27,22,21}, {T_COMMA,(char *)",",27,24,23}, {T_SVAR,(char *)"F$",27,25,24}, {T_COMMA,(char *)",",27,27,26},
      {T_SVAR,(char *)"G$",27,28,27}, {T_COMMA,(char *)",",27,30,29}, {T_SVAR,(char *)"H$",27,31,30}, {T_COMMA,(char *)",",27,33,32}, {T_SVAR,(char *)"I$",27,34,33},
      {T_COMMA,(char *)",",27,36,35}, {T_SVAR,(char *)"J$",27,37,36}, {T_COMMA,(char *)",",27,39,38}, {T_SVAR,(char *)"K$",27,40,39}, {T_COMMA,(char *)",",27,42,41},
      {T_SVAR,(char *)"L$",27,43,42}, {T_COMMA,(char *)",",27,45,44}, {T_SVAR,(char *)"M$",27,46,45}, {T_COMMA,(char *)",",27,48,47}, {T_SVAR,(char *)"N$",27,49,48},
      {T_COMMA,(char *)",",27,51,50}, {T_SVAR,(char *)"O$",27,52,51}, {T_COMMA,(char *)",",27,54,53}, {T_SVAR,(char *)"P$",27,55,54}, {T_COMMA,(char *)",",27,57,56},
      {T_SVAR,(char *)"Q$",27,58,57}, {T_COMMA,(char *)",",27,60,59}, {T_SVAR,(char *)"R$",27,61,60}, {T_COMMA,(char *)",",27,63,62}, {T_SVAR,(char *)"S$",27,64,63},
      {T_COMMA,(char *)",",27,66,65}, {T_SVAR,(char *)"T$",27,67,66}, {T_COMMA,(char *)",",27,69,68}, {T_SVAR,(char *)"U$",27,70,69}, {T_EOL,(char *)"\n",27,72,71},
      {T_EOF,(char *)"EOF",27,73,72}}
    },
   {"28 OPTION BASE 1\n",
     6U,
     {{T_INTEGER,(char *)"28",28,1,0},{T_OPTION,(char *)"OPTION",28,4,3},{T_BASE,(char *)"BASE",28,11,10},{T_INTEGER,(char *)"1",28,16,15},
      {T_EOL,(char *)"\n",28,17,16}, {T_EOF,(char *)"EOF",28,18,17}}
    },
   {"29 PRINT (*/<>)+=12.34+12.34-12-12.34-+*-1.,\n",
     24U,
     {{T_INTEGER,(char *)"29",29,1,0}, {T_PRINT,(char *)"PRINT",29,4,3}, {T_LPAREN,(char *)"(",29,10,9}, {T_MUL,(char *)"*",29,11,10}, {T_DIV,(char *)"/",29,12,11},
      {T_NE,(char *)"<>",29,13,12}, {T_RPAREN,(char *)")",29,15,14}, {T_ADD,(char *)"+",29,16,15}, {T_EQ,(char *)"=",29,17,16}, {T_REAL,(char *)"12.34",29,18,17},
      {T_ADD,(char *)"+",29,23,22}, {T_REAL,(char *)"12.34",29,24,23}, {T_SUBTRACT,(char *)"-",29,29,28}, {T_INTEGER,(char *)"12",29,30,29},
      {T_SUBTRACT,(char *)"-",29,32,31}, {T_REAL,(char *)"12.34",29,33,32}, {T_SUBTRACT,(char *)"-",29,38,37}, {T_ADD,(char *)"+",29,39,38}, {T_MUL,(char *)"*",29,40,39},
      {T_SUBTRACT,(char *)"-",29,41,40}, {T_REAL,(char *)"1.",29,42,41}, {T_COMMA,(char *)",",29,44,43}, {T_EOL,(char *)"\n",29,45,44}, {T_EOF,(char *)"EOF",29,46,45}}
    },
   {"30 DATA -.123,1E5,1.E5,.1E5,-.1E-5,+1.E+1,-+,-314.15926535E-2\n",
    19U,
    {{T_INTEGER,(char *)"30",30,1,0}, {T_DATA,(char *)"DATA",30,4,3}, {T_REAL,(char *)"-.123",30,9,8}, {T_COMMA,(char *)",",30,14,13}, {T_REAL,(char *)"1E5",30,15,14},
     {T_COMMA,(char *)",",30,18,17}, {T_REAL,(char *)"1.E5",30,19,18}, {T_COMMA,(char *)",",30,23,22}, {T_REAL,(char *)".1E5",30,24,23}, {T_COMMA,(char *)",",30,28,27},
     {T_REAL,(char *)"-.1E-5",30,29,28}, {T_COMMA,(char *)",",30,35,34}, {T_REAL,(char *)"+1.E+1",30,36,35}, {T_COMMA,(char *)",",30,42,41},
     {T_UQSTRING,(char *)"-+",30,43,42}, {T_COMMA,(char *)",",30,45,44}, {T_REAL,(char *)"-314.15926535E-2",30,46,45}, {T_EOL,(char *)"\n",30,62,61},
     {T_EOF,(char *)"EOF",30,63,62}}
    },
   {"999 FOR I=1 TO 10 STEP 3\n",
     11U,
     {{T_INTEGER,(char *)"999",999,1,0}, {T_FOR,(char *)"FOR",999,5,4}, {T_NVAR,(char *)"I",999,9,8}, {T_EQ,(char *)"=",999,10,9}, {T_INTEGER,(char *)"1",999,11,10},
      {T_TO,(char *)"TO",999,13,12}, {T_INTEGER,(char *)"10",999,16,15}, {T_STEP,(char *)"STEP",999,19,18}, {T_INTEGER,(char *)"3",999,24,23},
      {T_EOL,(char *)"\n",999,25,24}, {T_EOF,(char *)"EOF",999,26,25}}
    },
   {"32 LET I1 = +3.4E-3\n",
    8U,
    {{T_INTEGER,(char *)"32",32,1,0}, {T_LET,(char *)"LET",32,4,3}, {T_NVAR,(char *)"I1",32,8,7}, {T_EQ,(char *)"=",32,11,10},
     {T_ADD,(char *)"+",32,13,12}, {T_REAL,(char *)"3.4E-3",32,14,13},
     {T_EOL,(char *)"\n",32,20,19}, {T_EOF,(char *)"EOF",32,21,20}}
    },
   {"33 PRINT \"!;\";\n",
    6U,
    {{T_INTEGER,(char *)"33",33,1,0},{T_PRINT,(char *)"PRINT",33,4,3},{T_QSTRING,(char *)"!;",33,10,9},{T_SEMI,(char *)";",33,14,13},
     {T_EOL,(char *)"\n",33,15,14}, {T_EOF,(char *)"EOF",33,16,15}}
    },
   {"34 GOSUB 123\n",
    5U,
    {{T_INTEGER,(char *)"34",34,1,0}, {T_GOSUB,(char *)"GOSUB",34,4,3}, {T_INTEGER,(char *)"123",34,10,9}, {T_EOL,(char *)"\n",34,13,12}, {T_EOF,(char *)"EOF",10,14,13}}
    },
   {"41 GO SUB 123\n",
    5U,
    {{T_INTEGER,(char *)"41",41,1,0}, {T_GOSUB,(char *)"GOSUB",41,4,3}, {T_INTEGER,(char *)"123",41,11,10}, {T_EOL,(char *)"\n",41,14,13}, {T_EOF,(char *)"EOF",10,15,14}}
    },
   {"42 GOTO 10\n",
    5U,
    {{T_INTEGER,(char *)"42",42,1,0}, {T_GOTO,(char *)"GOTO",42,4,3}, {T_INTEGER,(char *)"10",42,9,8}, {T_EOL,(char *)"\n",42,11,10}, {T_EOF,(char *)"EOF",10,12,11}}
    },
   {"43 GO TO 10\n",
    5U,
    {{T_INTEGER,(char *)"43",43,1,0}, {T_GOTO,(char *)"GOTO",43,4,3}, {T_INTEGER,(char *)"10",43,10,9}, {T_EOL,(char *)"\n",43,12,11}, {T_EOF,(char *)"EOF",43,13,12}}
    },
   {"44 RETURN\n",
    4U,
    {{T_INTEGER,(char *)"44",44,1,0}, {T_RETURN,(char *)"RETURN",44,4,3}, {T_EOL,(char *)"\n",44,10,9}, {T_EOF,(char *)"EOF",44,11,10}}
    },
   {"45 RESTORE\n",
    4U,
    {{T_INTEGER,(char *)"45",45,1,0}, {T_RESTORE,(char *)"RESTORE",45,4,3}, {T_EOL,(char *)"\n",45,11,10}, {T_EOF,(char *)"EOF",45,12,11}}
    },
   {"46 RANDOMIZE\n",
    4U,
    {{T_INTEGER,(char *)"46",46,1,0}, {T_RANDOMIZE,(char *)"RANDOMIZE",46,4,3}, {T_EOL,(char *)"\n",46,13,12}, {T_EOF,(char *)"EOF",46,14,13}}
    },
   {"47 END\n",
    4U,
    {{T_INTEGER,(char *)"47",47,1,0}, {T_END,(char *)"END",47,4,3}, {T_EOL,(char *)"\n",47,7,6}, {T_EOF,(char *)"EOF",47,8,7}}
    },
   {"48 STOP\n",
    4U,
    {{T_INTEGER,(char *)"48",48,1,0}, {T_STOP,(char *)"STOP",48,4,3}, {T_EOL,(char *)"\n",48,8,7}, {T_EOF,(char *)"EOF",48,9,8}}
    },
   {"4 PRINT\n",
    4U,
    {{T_INTEGER,(char *)"4",4,1,0}, {T_PRINT,(char *)"PRINT",4,3,2}, {T_EOL,(char *)"\n",4,8,7}, {T_EOF,(char *)"EOF",4,9,8}}
    },
   {"49 PRINT ,,;\n",
    7U,
    {{T_INTEGER,(char *)"49",49,1,0}, {T_PRINT,(char *)"PRINT",49,4,3}, {T_COMMA, (char *)",",49,10,9}, {T_COMMA, (char *)",",49,11,10},
     {T_SEMI,(char *)";",49,12,11}, {T_EOL,(char *)"\n",49,13,12}, {T_EOF,(char *)"EOF",49,14,13}}
    },
   {"343       IF      A$    <>    \"QUIT\"       THEN          200\n",
    9U,
    {{T_INTEGER,(char *)"343",343,1,0}, {T_IF,(char *)"IF",343,11,10}, {T_SVAR,(char *)"A$",343,19,18}, {T_NE,(char *)"<>",343,25,24},
     {T_QSTRING,(char *)"QUIT",343,31,30}, {T_THEN,(char *)"THEN",343,44,43}, {T_INTEGER,(char *)"200",343,58,57}, {T_EOL,(char *)"\n",343,61,60},
     {T_EOF,(char *)"EOF",343,62,61}}
    },
   {"344 LET I1 = -(-2+1)-3\n",
    15U,
    {{T_INTEGER,(char *)"344",344,1,0}, {T_LET,(char *)"LET",344,5,4}, {T_NVAR,(char *)"I1",344,9,8}, {T_EQ,(char *)"=",344,12,11}, {T_SUBTRACT,(char *)"-",344,14,13},
     {T_LPAREN,(char *)"(",344,15,14}, {T_SUBTRACT,(char *)"-",344,16,15}, {T_INTEGER,(char *)"2",344,17,16}, {T_ADD,(char *)"+",344,18,17},
     {T_INTEGER,(char *)"1",344,19,18}, {T_RPAREN,(char *)")",344,20,19}, {T_SUBTRACT,(char *)"-",344,21,20}, {T_INTEGER,(char *)"3",344,22,21},
     {T_EOL,(char *)"\n",344,23,22}, {T_EOF,(char *)"EOF",344,24,23}}
    },
   {"60 LET A   (   3   ) = 4\n",
    10U,
    {{T_INTEGER,(char *)"60",60,1,0}, {T_LET,(char *)"LET",60,4,3}, {T_NAVAR,(char *)"A",60,8,7}, {T_LPAREN,(char *)"(",60,12,11}, {T_INTEGER,(char *)"3",60,16,15},
     {T_RPAREN,(char *)")",60,20,19}, {T_EQ,(char *)"=",60,22,21}, {T_INTEGER,(char *)"4",60,24,23}, {T_EOL,(char *)"\n",60,25,24}, {T_EOF,(char *)"EOF",60,26,25}}
   },
};
static const unsigned int num_tests = sizeof(tests) / sizeof(struct tt);

//
// Tests which only work without extended mode
//
static const struct tt non_extended_tests[] = {
   {"341 DATA -1,50,PI,-21.,.255,1E10,5E-1,.4E+1,\"XYZ\",\"X - 3B2\",\"1E10\"\n",
    25U,
    {{T_INTEGER,(char *)"341",341,1,0}, {T_DATA,(char *)"DATA",341,5,4}, {T_INTEGER,(char *)"-1",341,10,9}, {T_COMMA,(char *)",",341,12,11},
     {T_INTEGER,(char *)"50",341,13,12}, {T_COMMA,(char *)",",341,15,14}, {T_UQSTRING,(char *)"PI",341,16,15}, {T_COMMA,(char *)",",341,18,17},
     {T_REAL,(char *)"-21.",341,19,18}, {T_COMMA,(char *)",",341,23,22}, {T_REAL,(char *)".255",341,24,23}, {T_COMMA,(char *)",",341,28,27},
     {T_REAL,(char *)"1E10",341,29,28}, {T_COMMA,(char *)",",341,33,32}, {T_REAL,(char *)"5E-1",341,34,33}, {T_COMMA,(char *)",",341,38,37},
     {T_REAL,(char *)".4E+1",341,39,38}, {T_COMMA,(char *)",",341,44,43}, {T_QSTRING,(char *)"XYZ",341,45,44}, {T_COMMA,(char *)",",341,50,49},
     {T_QSTRING,(char *)"X - 3B2",341,51,50}, {T_COMMA,(char *)",",341,60,59}, {T_QSTRING,(char *)"1E10",341,61,60}, {T_EOL,(char *)"\n",341,67,66},
     {T_EOF,(char *)"EOF",341,68,67}}
    },
   {"342 DATA 500,\"DOG\",PI\n",
    9U,
    {{T_INTEGER,(char *)"342",342,1,0}, {T_DATA,(char *)"DATA",342,5,4}, {T_INTEGER,(char *)"500",342,10,9}, {T_COMMA,(char *)",",342,13,12},
     {T_QSTRING,(char *)"DOG",342,14,13}, {T_COMMA,(char *)",",342,19,18}, {T_UQSTRING,(char *)"PI",342,20,19}, {T_EOL,(char *)"\n",342,22,21},
     {T_EOF,(char *)"EOF",342,23,22}}
    },
};
static const unsigned int num_non_extended_tests = sizeof(non_extended_tests) / sizeof(struct tt);

//
// Tests which only work with extended mode (-X)
//
static const struct tt extended_tests[] = {
   {"341 DATA -1,50,PI,-21.,.255,1E10,5E-1,.4E+1,\"XYZ\",\"X - 3B2\",\"1E10\"\n",
    25U,
    {{T_INTEGER,(char *)"341",341,1,0}, {T_DATA,(char *)"DATA",341,5,4}, {T_INTEGER,(char *)"-1",341,10,9}, {T_COMMA,(char *)",",341,12,11},
     {T_INTEGER,(char *)"50",341,13,12}, {T_COMMA,(char *)",",341,15,14}, {T_PI,(char *)"PI",341,16,15}, {T_COMMA,(char *)",",341,18,17},
     {T_REAL,(char *)"-21.",341,19,18}, {T_COMMA,(char *)",",341,23,22}, {T_REAL,(char *)".255",341,24,23}, {T_COMMA,(char *)",",341,28,27},
     {T_REAL,(char *)"1E10",341,29,28}, {T_COMMA,(char *)",",341,33,32}, {T_REAL,(char *)"5E-1",341,34,33}, {T_COMMA,(char *)",",341,38,37},
     {T_REAL,(char *)".4E+1",341,39,38}, {T_COMMA,(char *)",",341,44,43}, {T_QSTRING,(char *)"XYZ",341,45,44}, {T_COMMA,(char *)",",341,50,49},
     {T_QSTRING,(char *)"X - 3B2",341,51,50}, {T_COMMA,(char *)",",341,60,59}, {T_QSTRING,(char *)"1E10",341,61,60}, {T_EOL,(char *)"\n",341,67,66},
     {T_EOF,(char *)"EOF",341,68,67}}
    },
   {"342 DATA 500,\"DOG\",PI\n",
    9U,
    {{T_INTEGER,(char *)"342",342,1,0}, {T_DATA,(char *)"DATA",342,5,4}, {T_INTEGER,(char *)"500",342,10,9}, {T_COMMA,(char *)",",342,13,12},
     {T_QSTRING,(char *)"DOG",342,14,13}, {T_COMMA,(char *)",",342,19,18}, {T_PI,(char *)"PI",342,20,19}, {T_EOL,(char *)"\n",342,22,21},
     {T_EOF,(char *)"EOF",342,23,22}}
    },
   {"61 IF X>0 OR X<5 THEN 200\n",
    13U,
    {{T_INTEGER,(char *)"61",61,1,0}, {T_IF,(char *)"IF",61,4,3}, {T_NVAR,(char *)"X",61,7,6}, {T_GT,(char *)">",61,8,7}, {T_INTEGER,(char *)"0",61,9,8},
     {T_OR,(char *)"OR",61,11,10}, {T_NVAR,(char *)"X",61,14,13}, {T_LT,(char *)"<",61,15,14}, {T_INTEGER,(char *)"5",61,16,15},
     {T_THEN,(char *)"THEN",61,18,17}, {T_INTEGER,(char *)"200",61,23,22}, {T_EOL,(char *)"\n",61,26,25}, {T_EOF,(char *)"EOF",61,27,26}}
   },
   {"62 IF NOT X>0 THEN 200\n",
    10U,
    {{T_INTEGER,(char *)"62",62,1,0}, {T_IF,(char *)"IF",62,4,3}, {T_NOT,(char *)"NOT",62,7,6}, {T_NVAR,(char *)"X",62,11,10}, {T_GT,(char *)">",62,12,11},
     {T_INTEGER,(char *)"0",62,13,12}, {T_THEN,(char *)"THEN",62,15,14}, {T_INTEGER,(char *)"200",62,20,19}, {T_EOL,(char *)"\n",62,23,22}, {T_EOF,(char *)"EOF",62,24,23}}
   },
   {"63 IF X>0 AND X<5 THEN 200\n",
    13U,
    {{T_INTEGER,(char *)"63",63,1,0}, {T_IF,(char *)"IF",63,4,3}, {T_NVAR,(char *)"X",63,7,6}, {T_GT,(char *)">",63,8,7}, {T_INTEGER,(char *)"0",63,9,8},
     {T_AND,(char *)"AND",63,11,10}, {T_NVAR,(char *)"X",63,15,14}, {T_LT,(char *)"<",63,16,15}, {T_INTEGER,(char *)"5",63,17,16},
     {T_THEN,(char *)"THEN",63,19,18}, {T_INTEGER,(char *)"200",63,24,23}, {T_EOL,(char *)"\n",63,27,26}, {T_EOF,(char *)"EOF",63,28,27}}
   },
   {"64 PRINT LEN(S$)\n",
    8U,
    {{T_INTEGER,(char *)"64",64,1,0}, {T_PRINT,(char *)"PRINT",64,4,3}, {T_LEN,(char *)"LEN",64,10,9}, {T_LPAREN,(char *)"(",64,13,12}, {T_SVAR,(char *)"S$",64,14,13},
     {T_RPAREN,(char *)")",64,16,15}, {T_EOL,(char *)"\n",64,17,16}, {T_EOF,(char *)"EOF",64,18,17}}
   },
   {"65 REM Comment with some ugly stuff\n20 STOP\n30 END\n",
    10U,
    {{T_INTEGER,(char *)"65",65,1,0}, {T_REM,(char *)"REM Comment with some ugly stuff",65,4,3}, {T_EOL,(char *)"\n",65,36,35},
     {T_INTEGER,(char *)"20",20,1,36}, {T_STOP,(char *)"STOP",20,4,39}, {T_EOL,(char *)"\n",20,8,43},
     {T_INTEGER,(char *)"30",30,1,44}, {T_END,(char *)"END",30,4,47}, {T_EOL,(char *)"\n",30,7,50}, {T_EOF,(char *)"EOF",10,8,51}}
    },
   {"66 REM Comment with some ugly stuff\n",
    4U,
    {{T_INTEGER,(char *)"66",66,1,0},{T_REM,(char *)"REM Comment with some ugly stuff",66,4,3},{T_EOL,(char *)"\n",66,36,35}, {T_EOF,(char *)"EOF",66,37,36}}
    },
   {"67 PRINT \"this is a !@#$%^&*()_+-=[]{}|\\~`\"\n",
    5U,
    {{T_INTEGER,(char *)"67",67,1,0}, {T_PRINT,(char *)"PRINT",67,4,3}, {T_QSTRING,(char *)"this is a !@#$%^&*()_+-=[]{}|\\~`",67,10,9},
     {T_EOL,(char *)"\n",67,44,43}, {T_EOF,(char *)"EOF",67,45,44}}
    },
   {"68 LET A$ = \"hello\"\n",
    7U,
    {{T_INTEGER,(char *)"68",68,1,0},{T_LET,(char *)"LET",68,4,3},{T_SVAR,(char *)"A$",68,8,7},{T_EQ,(char *)"=",68,11,10},{T_QSTRING,(char *)"hello",68,13,12},
     {T_EOL,(char *)"\n",68,20,19}, {T_EOF,(char *)"EOF",68,21,20}}
    },
   {"69 EXIT FOR\n",
    5U,
    {{T_INTEGER,(char *)"69",69,1,0},{T_EXIT,(char *)"EXIT",69,4,3},{T_FOR,(char *)"FOR",69,9,8}, {T_EOL,(char *)"\n",69,12,11}, {T_EOF,(char *)"EOF",69,13,12}}
    },
   {"17 PRINT CEIL(-1.5)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_CEIL,(char *)"CEIL",17,10,9}, {T_LPAREN,(char *)"(",17,14,13},
      {T_SUBTRACT,(char *)"-",17,15,14}, {T_REAL,(char *)"1.5",17,16,15}, {T_RPAREN,(char *)")",17,19,18}, {T_EOL,(char *)"\n",17,20,19}, {T_EOF,(char *)"EOF",17,21,20}}
   },
   {"96 PRINT PI\n",
     5U,
     {{T_INTEGER,(char *)"96",96,1,0}, {T_PRINT,(char *)"PRINT",96,4,3}, {T_PI,(char *)"PI",96,10,9}, {T_EOL,(char *)"\n",96,12,11},
      {T_EOF,(char *)"EOF",96,13,12}}
   },
   {"17 PRINT DEG(-1.5)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_DEG,(char *)"DEG",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_REAL,(char *)"1.5",17,15,14}, {T_RPAREN,(char *)")",17,18,17}, {T_EOL,(char *)"\n",17,19,18}, {T_EOF,(char *)"EOF",17,20,19}}
   },
   {"17 PRINT RAD(-1.5)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_RAD,(char *)"RAD",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_REAL,(char *)"1.5",17,15,14}, {T_RPAREN,(char *)")",17,18,17}, {T_EOL,(char *)"\n",17,19,18}, {T_EOF,(char *)"EOF",17,20,19}}
   },
   {"17 PRINT MIN(-1,5)\n",
     11U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_MIN,(char *)"MIN",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_INTEGER,(char *)"1",17,15,14}, {T_COMMA,(char *)",",17,16,15},
      {T_INTEGER,(char *)"5", 17,17,16}, {T_RPAREN,(char *)")",17,18,17}, {T_EOL,(char *)"\n",17,19,18}, {T_EOF,(char *)"EOF",17,20,19}}
   },
   {"17 PRINT MAX(-1,5)\n",
     11U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_MAX,(char *)"MAX",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_INTEGER,(char *)"1",17,15,14}, {T_COMMA,(char *)",",17,16,15},
      {T_INTEGER,(char *)"5", 17,17,16}, {T_RPAREN,(char *)")",17,18,17}, {T_EOL,(char *)"\n",17,19,18}, {T_EOF,(char *)"EOF",17,20,19}}
   },
   {"17 PRINT IP(-1.5)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_IP,(char *)"IP",17,10,9}, {T_LPAREN,(char *)"(",17,12,11},
      {T_SUBTRACT,(char *)"-",17,13,12}, {T_REAL,(char *)"1.5",17,14,13}, {T_RPAREN,(char *)")",17,17,16}, {T_EOL,(char *)"\n",17,18,17}, {T_EOF,(char *)"EOF",17,19,18}}
   },
   {"17 PRINT FP(-1.5)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_FP,(char *)"FP",17,10,9}, {T_LPAREN,(char *)"(",17,12,11},
      {T_SUBTRACT,(char *)"-",17,13,12}, {T_REAL,(char *)"1.5",17,14,13}, {T_RPAREN,(char *)")",17,17,16}, {T_EOL,(char *)"\n",17,18,17}, {T_EOF,(char *)"EOF",17,19,18}}
   },
   {"17 PRINT MOD(-1,5)\n",
     11U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_MOD,(char *)"MOD",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_INTEGER,(char *)"1",17,15,14}, {T_COMMA,(char *)",",17,16,15},
      {T_INTEGER,(char *)"5", 17,17,16}, {T_RPAREN,(char *)")",17,18,17}, {T_EOL,(char *)"\n",17,19,18}, {T_EOF,(char *)"EOF",17,20,19}}
   },
   {"17 PRINT REMAINDER(-1,5)\n",
     11U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_REMAINDER,(char *)"REMAINDER",17,10,9}, {T_LPAREN,(char *)"(",17,19,18},
      {T_SUBTRACT,(char *)"-",17,20,19}, {T_INTEGER,(char *)"1",17,21,20}, {T_COMMA,(char *)",",17,22,21},
      {T_INTEGER,(char *)"5", 17,23,22}, {T_RPAREN,(char *)")",17,24,23}, {T_EOL,(char *)"\n",17,25,24}, {T_EOF,(char *)"EOF",17,26,25}}
   },
   {"96 PRINT MAXNUM\n",
     5U,
     {{T_INTEGER,(char *)"96",96,1,0}, {T_PRINT,(char *)"PRINT",96,4,3}, {T_MAXNUM,(char *)"MAXNUM",96,10,9}, {T_EOL,(char *)"\n",96,16,15},
      {T_EOF,(char *)"EOF",96,17,16}}
   },
   {"17 PRINT LOG2(11.5)\n",
     8U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_LOG2,(char *)"LOG2",17,10,9}, {T_LPAREN,(char *)"(",17,14,13},
      {T_REAL,(char *)"11.5",17,15,14}, {T_RPAREN,(char *)")",17,19,18}, {T_EOL,(char *)"\n",17,20,19}, {T_EOF,(char *)"EOF",17,21,20}}
   },
   {"17 PRINT LOG10(1.5)\n",
     8U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_LOG10,(char *)"LOG10",17,10,9}, {T_LPAREN,(char *)"(",17,15,14},
      {T_REAL,(char *)"1.5",17,16,15}, {T_RPAREN,(char *)")",17,19,18}, {T_EOL,(char *)"\n",17,20,19}, {T_EOF,(char *)"EOF",17,21,20}}
   },
   {"17 PRINT ASIN(.7)\n",
     8U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_ASIN,(char *)"ASIN",17,10,9}, {T_LPAREN,(char *)"(",17,14,13},
      {T_REAL,(char *)".7",17,15,14}, {T_RPAREN,(char *)")",17,17,16}, {T_EOL,(char *)"\n",17,18,17}, {T_EOF,(char *)"EOF",17,19,18}}
   },
   {"17 PRINT ACOS(.7)\n",
     8U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_ACOS,(char *)"ACOS",17,10,9}, {T_LPAREN,(char *)"(",17,14,13},
      {T_REAL,(char *)".7",17,15,14}, {T_RPAREN,(char *)")",17,17,16}, {T_EOL,(char *)"\n",17,18,17}, {T_EOF,(char *)"EOF",17,19,18}}
   },
   {"17 PRINT COSH(.7)\n",
     8U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_COSH,(char *)"COSH",17,10,9}, {T_LPAREN,(char *)"(",17,14,13},
      {T_REAL,(char *)".7",17,15,14}, {T_RPAREN,(char *)")",17,17,16}, {T_EOL,(char *)"\n",17,18,17}, {T_EOF,(char *)"EOF",17,19,18}}
   },
   {"17 PRINT SINH(.7)\n",
     8U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_SINH,(char *)"SINH",17,10,9}, {T_LPAREN,(char *)"(",17,14,13},
      {T_REAL,(char *)".7",17,15,14}, {T_RPAREN,(char *)")",17,17,16}, {T_EOL,(char *)"\n",17,18,17}, {T_EOF,(char *)"EOF",17,19,18}}
   },
   {"17 PRINT TANH(.7)\n",
     8U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_TANH,(char *)"TANH",17,10,9}, {T_LPAREN,(char *)"(",17,14,13},
      {T_REAL,(char *)".7",17,15,14}, {T_RPAREN,(char *)")",17,17,16}, {T_EOL,(char *)"\n",17,18,17}, {T_EOF,(char *)"EOF",17,19,18}}
   },
   {"17 PRINT SEC(-1.5)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_SEC,(char *)"SEC",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_REAL,(char *)"1.5",17,15,14}, {T_RPAREN,(char *)")",17,18,17}, {T_EOL,(char *)"\n",17,19,18}, {T_EOF,(char *)"EOF",17,20,19}}
   },
   {"17 PRINT CSC(-1.5)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_CSC,(char *)"CSC",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_REAL,(char *)"1.5",17,15,14}, {T_RPAREN,(char *)")",17,18,17}, {T_EOL,(char *)"\n",17,19,18}, {T_EOF,(char *)"EOF",17,20,19}}
   },
   {"17 PRINT COT(-1.5)\n",
     9U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_COT,(char *)"COT",17,10,9}, {T_LPAREN,(char *)"(",17,13,12},
      {T_SUBTRACT,(char *)"-",17,14,13}, {T_REAL,(char *)"1.5",17,15,14}, {T_RPAREN,(char *)")",17,18,17}, {T_EOL,(char *)"\n",17,19,18}, {T_EOF,(char *)"EOF",17,20,19}}
   },
   {"17 PRINT ROUND(X, N)\n",
     10U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_ROUND,(char *)"ROUND",17,10,9}, {T_LPAREN,(char *)"(",17,15,14},
      {T_NVAR,(char *)"X",17,16,15}, {T_COMMA,(char *)",",17,17,16}, {T_NVAR,(char *)"N", 17,19,18}, {T_RPAREN,(char *)")",17,20,19},
      {T_EOL,(char *)"\n",17,21,20}, {T_EOF,(char *)"EOF",17,22,21}}
   },
   {"17 PRINT TRUNCATE(X, N)\n",
     10U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_TRUNCATE,(char *)"TRUNCATE",17,10,9}, {T_LPAREN,(char *)"(",17,18,17},
      {T_NVAR,(char *)"X",17,19,18}, {T_COMMA,(char *)",",17,20,19}, {T_NVAR,(char *)"N", 17,22,21}, {T_RPAREN,(char *)")",17,23,22},
      {T_EOL,(char *)"\n",17,24,23}, {T_EOF,(char *)"EOF",17,25,24}}
   },
   {"17 PRINT ANGLE(-1,5)\n",
     11U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_ANGLE,(char *)"ANGLE",17,10,9}, {T_LPAREN,(char *)"(",17,15,14},
      {T_SUBTRACT,(char *)"-",17,16,15}, {T_INTEGER,(char *)"1",17,17,16}, {T_COMMA,(char *)",",17,18,17},
      {T_INTEGER,(char *)"5", 17,19,18}, {T_RPAREN,(char *)")",17,20,19}, {T_EOL,(char *)"\n",17,21,20}, {T_EOF,(char *)"EOF",17,22,21}}
   },
   {"17 PRINT DATE\n",
     5U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_DATE,(char *)"DATE",17,10,9}, {T_EOL,(char *)"\n",17,14,13}, {T_EOF,(char *)"EOF",17,15,14}}
   },
   {"17 PRINT TIME\n",
     5U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_TIME,(char *)"TIME",17,10,9}, {T_EOL,(char *)"\n",17,14,13}, {T_EOF,(char *)"EOF",17,15,14}}
   },
   {"17 DATA PI,MAXNUM\n",
     7U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_DATA,(char *)"DATA",17,4,3},  {T_PI,(char *)"PI",17,9,8},
      {T_COMMA,(char *)",",17,11,10}, {T_MAXNUM,(char *)"MAXNUM",17,12,11},
      {T_EOL,(char *)"\n",17,18,17}, {T_EOF,(char *)"EOF",17,19,18}}
   },
   {"17 PRINT DATE$\n",
     5U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_DATES,(char *)"DATE$",17,10,9},
      {T_EOL,(char *)"\n",17,15,14}, {T_EOF,(char *)"EOF",17,16,15}}
   },
   {"17 PRINT TIME$,\"TIME$\"\n",
     7U,
     {{T_INTEGER,(char *)"17",17,1,0}, {T_PRINT,(char *)"PRINT",17,4,3}, {T_TIMES,(char *)"TIME$",17,10,9},
      {T_COMMA,(char *)",",17,15,14}, {T_QSTRING,(char *)"TIME$",17,16,15},
      {T_EOL,(char *)"\n",17,23,22}, {T_EOF,(char *)"EOF",17,24,23}}
   },
};
static const unsigned int num_extended_tests = sizeof(extended_tests) / sizeof(struct tt);

//
// This function will return a string which contains the same data as the
// input string s except newlines are escaped with an extra backslash
//
static char *cookit(
    char const * const s) {         // input buffer
  static char cookit_buffer[120];   // output buffer
  uint32_t i,                       // index of position in input buffer s
           j;                       // index of position in output buffer cookit_buffer

  for (i = j = 0U; s[i]; i++) {
    if ('\n' == s[i]) {
      cookit_buffer[j++] = '\\';
      cookit_buffer[j++] = 'n';
    } else {
      cookit_buffer[j++] = s[i];
    }
  }
  cookit_buffer[j] = 0; // terminate it
  return cookit_buffer;
}

//
// positive lookup self-test
//
static int positive_lookup_tests(const struct keyword *tbl,
                                  const unsigned int num_elements) {
  for (unsigned int ndex = 0U; ndex < num_elements; ndex++) {
    unsigned long int slotno = 0UL;
    struct keyword *recptr = NULL;
    printf("search for %*s'%s': ", (int)(20 - strlen(tbl[ndex].kwtext)), " ",
           tbl[ndex].kwtext?tbl[ndex].kwtext:"CANNOT HAPPEN"); // just to shut up a bogus GCC warning
    // DO NOT FREE recptr
    recptr = bsearch(tbl[ndex].kwtext, tbl, num_elements, sizeof(struct keyword), kompare);
    if (NULL == recptr) {
      fflush(stdout);
      fprintf(stderr, "FAIL Error in binary search routine while searching for '%s'\n", tbl[ndex].kwtext);
      return EXIT_FAILURE;
    }
    slotno = (unsigned long int)((unsigned long int)((char *)recptr - (char *)tbl) / sizeof(struct keyword));
    if (ndex != slotno) {
      fflush(stdout);
      fprintf(stderr, "FAIL, found '%s' in slot %" PRIu32 ", not %lu as expected.\n", tbl[ndex].kwtext, ndex, slotno);
      return EXIT_FAILURE;
    }
    printf("OK, found '%s' in slot %" PRIu32 " as expected.\n", tbl[ndex].kwtext, ndex);
    fflush(stdout);
  }
  return EXIT_SUCCESS;
}

static int parse_tests(
    const struct tt *test_array,    // array of tests
    const unsigned int test_count,  // number of tests
    const bool have_extensions,     // true for -X, false otherwise
    const bool qof) {               // if true, quit on failure, else keep going
  char msg[ERROR_BUFFER_LEN];       // pointer to error message buffer
  bool big_ok = true;

  for (unsigned int ndex = 0U; ndex < test_count; ndex++) {
    uint32_t whichone = 0;
    char *c = NULL; // DO NOT FREE!
    bool ok = true;
    token *curtoken = NULL;
    scanner_state ss = {
       (char *)test_array[ndex].s,      // buffer
       strlen(test_array[ndex].s),      // buflen
       0,                          // pos
       0,                          // current_nbs_line_number
       1,                          // current_source_line_number
       1,                          // current_column_number
       T_EOL,                      // last_tid
       NULL,                       // valid_char
       false,                      // indatastatement
       have_extensions};           // extensions

    c = cookit(ss.buffer);
    printf("Scanning %*s'%s'  :  ", (int)(80 - strlen(c)), " ", c);
    fflush(stdout);
    curtoken = get_next_token(&ss);
    do {
      if (verbose)
        printf("token id is %2" PRId32 ", token name is '%s', text is '%s' on line %" PRIu32 " in column %" PRIu32 "\n",
               curtoken->tid,
               token_names[curtoken->tid],
               (T_EOL == curtoken->tid) ? "\\n" : curtoken->toketext,
               curtoken->lno,
               curtoken->cno);
      if (curtoken->tid != test_array[ndex].t[whichone].tid) {
        ok = false;
        sprintf(msg,
                "1. Token %" PRId32 " : Expected (%" PRIu32 ")%s but got (%" PRId32 ")%s \"%s\"",
                whichone,
                test_array[ndex].t[whichone].tid,
                token_names[test_array[ndex].t[whichone].tid],
                curtoken->tid,
                token_names[curtoken->tid],
                curtoken->toketext);
        goto bail;
      }
      if (strcmp(curtoken->toketext, (char *)test_array[ndex].t[whichone].toketext) != 0) {
        ok = false;
        sprintf(msg, "2. Token %" PRIu32 " (%s): Expected token text '%s', but got '%s'",
                whichone, token_names[test_array[ndex].t[whichone].tid], test_array[ndex].t[whichone].toketext, curtoken->toketext);
        goto bail;
      }
      if (curtoken->lno != test_array[ndex].t[whichone].lno) {
        ok = false;
        sprintf(msg, "3. Token %" PRIu32 " (%s): Expected token lno %" PRIu32 " but got %" PRIu32,
                whichone, token_names[test_array[ndex].t[whichone].tid], test_array[ndex].t[whichone].lno, curtoken->lno);
        goto bail;
      }
      if (curtoken->cno != test_array[ndex].t[whichone].cno) {
        ok = false;
        sprintf(msg,
                "4. Token %" PRIu32 " (%s): Expected token column number %" PRIu32 " but got %" PRIu32,
                whichone, token_names[test_array[ndex].t[whichone].tid], test_array[ndex].t[whichone].cno, curtoken->cno);
        goto bail;
      }
      if (curtoken->pos != test_array[ndex].t[whichone].pos) {
        ok = false;
        sprintf(msg,
                "5. Token %" PRIu32 " (%s): Expected token column number %" PRIu64 " but got %" PRIu64,
                whichone, token_names[test_array[ndex].t[whichone].tid], test_array[ndex].t[whichone].pos, curtoken->pos);
        // goto bail;     just fall through
      }
bail:
      whichone++;
      if (T_EOF != curtoken->tid) {
        if (verbose)
          fprintf(stderr, "%s freeing '%s'\nfreeing token that contained that token text\n",
                  __func__, curtoken->toketext);
        free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
        curtoken = get_next_token(&ss);
      }
    } while (ok && (whichone < test_array[ndex].howmany) && (T_EOF != curtoken->tid));
    if (T_EOF != curtoken->tid) {
      ok = false;
      sprintf(msg, "3. Expected T_EOF, got %s", token_names[curtoken->tid]);
    } else {
      whichone++;
    }
    if (whichone != test_array[ndex].howmany) {
      ok = false;
      sprintf(msg, "4. Expected %u tokens, but got %u tokens", test_array[ndex].howmany, whichone);
    }
    if (ok) {
      puts("OK");
    } else {
      fprintf(stderr, "FAIL\n     %s\n", msg);
      fprintf(stderr, "buffer='%s'\nbuflen=%" PRIu64 "\ncurrent_bufpos=%" PRIu64 "\n",
              ss.buffer, ss.buflen, ss.pos);
      fputs("\nBEGIN EXPECTED TOKEN STREAM\n", stderr);
      for (unsigned int i = 0U; i < test_array[ndex].howmany; i++)
        fprintf(stderr, "token #%2" PRIu32 ":  (%" PRId32 ")%s with text '%s' on line %" PRIu32 " in column %" PRIu32 "\n",
                i,
                test_array[ndex].t[i].tid,
                token_names[test_array[ndex].t[i].tid],
                (T_EOL == test_array[ndex].t[i].tid) ? "\\n" : test_array[ndex].t[i].toketext,
                test_array[ndex].t[i].lno,
                test_array[ndex].t[i].cno);
      fputs("END EXPECTED TOKEN STREAM\n", stderr);
    }
    if (verbose)
      fprintf(stderr, "%s freeing '%s'\nfreeing token that contained that token text\n",
              __func__, curtoken->toketext);
    free(curtoken->toketext); curtoken->toketext = NULL; free(curtoken); curtoken = NULL;
    if (!ok && qof) {
      FATAL(__FILE__, __func__, __LINE__, "\n\nTerminating on first failure as requested.\n");
    }
    if (big_ok)
      big_ok = ok;
  }
  return big_ok?EXIT_SUCCESS:EXIT_FAILURE;
}

//
// negative lookup self-test
//
static int negative_lookup_tests(const struct keyword *tbl,
                                  const unsigned int num_elements) {
  const char *bob = "BOB'S YOUR UNCLE";   // string to search for in negative binary
                                          // search test case
  struct keyword *recptr = NULL;

  printf("search for %*s'%s': ", (int)(20 - strlen(bob)), " ", bob);
  // DO NOT FREE recptr
  recptr = bsearch(bob, tbl, num_elements, sizeof(struct keyword), kompare);
  if (NULL != recptr) {
    puts("FAIL");
    fprintf(stderr, "Error in binary search routine: found '%s'\n", bob);
    return EXIT_FAILURE;
  }
  printf("OK, \"%s\" not found, as expected.\n", bob);
  fflush(stdout);
  return EXIT_SUCCESS;
}

int main(int argc, char **argv) {
  int retcode = EXIT_SUCCESS;
  bool quit_on_fail = false;                 // flag that when true says end program on first error
  int opt;                                 // variable used by getopt() function

  optimization_level = 0U;
  extensions = use_SSE4_1 = verbose = false;
  use_double = true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:XV")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'V':
        quit_on_fail = true;
        // FALLS THROUGH
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          return EXIT_FAILURE;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          return EXIT_FAILURE;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          return EXIT_FAILURE;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          return EXIT_FAILURE;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0], true);
        return EXIT_SUCCESS;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        return EXIT_FAILURE;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    return EXIT_FAILURE;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    retcode = EXIT_FAILURE;
    goto xit;
  }
  printf("Normal Keywords:\n\n");
  retcode = positive_lookup_tests(keywords, numkeywords);
  if (retcode != EXIT_SUCCESS) {
    retcode = EXIT_FAILURE;
    goto xit;
  }
  retcode = negative_lookup_tests(keywords, numkeywords);
  if (retcode != EXIT_SUCCESS) {
    retcode = EXIT_FAILURE;
    goto xit;
  }
  if (extensions) {
    printf("\nExtended Keywords:\n\n");
    retcode = positive_lookup_tests(ekeywords, numekeywords);
    if (retcode != EXIT_SUCCESS) {
      retcode = EXIT_FAILURE;
      goto xit;
    }
    retcode = negative_lookup_tests(ekeywords, numekeywords);
    if (retcode != EXIT_SUCCESS) {
      retcode = EXIT_FAILURE;
      goto xit;
    }
  }
  printf("\nParse Regular Tests:\n\n");
  retcode = parse_tests(tests, num_tests, extensions, quit_on_fail);
  if (retcode != EXIT_SUCCESS) {
    retcode = EXIT_FAILURE;
    goto xit;
  }
  if (extensions) {
    printf("\nParse Extended Tests:\n\n");
    retcode = parse_tests(extended_tests, num_extended_tests, extensions, quit_on_fail);
  } else {
    // run a few tests that have different results in extended vs. non-extended
    retcode = parse_tests(non_extended_tests, num_non_extended_tests, extensions, quit_on_fail);
  }
  if (retcode != EXIT_SUCCESS)
    retcode = EXIT_FAILURE;
xit:
  if (verbose) {
    fflush(stdout);
    fprintf(stderr,
            "\n===================================\n\n"
            "ERROR_BUFFER_LEN=%lu\n"
            "MAX_OPTIMIZATION_LEVEL=%u\n"
            "optimization_level=%u\n"
            "use_double=%s\n"
            "use_SSE4_1=%s\n"
            "extensions=%s\n"
            "quit_on_fail=%s\n",
            ERROR_BUFFER_LEN,
            MAX_OPTIMIZATION_LEVEL,
            optimization_level,
            use_double?"true":"false",
            use_SSE4_1?"true":"false",
            extensions?"true":"false",
            quit_on_fail?"true":"false");
  }
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return retcode;
}
#endif
