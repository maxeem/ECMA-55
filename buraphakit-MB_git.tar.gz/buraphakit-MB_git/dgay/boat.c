#include <stdlib.h>
#include <stdio.h>

extern int errno;
extern char *g_fmt(char *, double, signed long int);
extern double strtod(const char *s00, char **se);
extern char *dtoa(double dd, int mode, int ndigits, int *decpt, int *sign, char **rve);
size_t strlen(char *s);

size_t strlen(char *s) {
  char *e=s;
  while (*e) e++;
  return (e-s);
}

int main(void) {
  char buf[20]="1.0";
  double d;
  int len;
  int mode=4;
  int ndigits=7;
  int decpt,sign;
  char *rve=NULL,*s=NULL;

  printf("Enter buf:");
  fflush(stdout);
  if (fgets(buf,20,stdin)==NULL) {
    printf("trouble\n");
    abort();
  }
  errno=0;
  d=strtod(buf,&s);
  if (*s=='\n')
     *s=0;
  if (*s!=0) {
    printf("bad conversion\n");
  } else {
    len=strlen(buf);
    printf("strtod('%s',NULL) returns %g with errno=%d\n",buf,d,errno);
    s=fcvt(d,7,&decpt,&sign);
    printf("fcvt(%g,7,&decpt,&sign) gives '%s', decpt=%d,sign=%d\n",
       d,s,decpt,sign);
    buf[0]=0;
    s=dtoa(d,mode,ndigits,&decpt,&sign,&rve);
    printf("dtoa(%g,%d,%d,&decpt,&sign,&rve) gives '%s', decpt=%d,sign=%d\n",
       d,mode,ndigits,s,decpt,sign);
    g_fmt(buf,d,ndigits-1);
    printf("g_fmt(buf,%g,%d) gives '%s'\n",d,ndigits-1,buf);
  }
  return EXIT_SUCCESS;
}
