/****************************************************************
 *
 * The author of this software is David M. Gay.
 *
 * Copyright (c) 1991, 1996 by Lucent Technologies.
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose without fee is hereby granted, provided that this entire notice
 * is included in all copies of any software which is or includes a copy
 * or modification of this software and in all copies of the supporting
 * documentation for such software.
 *
 * THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTY.  IN PARTICULAR, NEITHER THE AUTHOR NOR LUCENT MAKES ANY
 * REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
 * OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.
 *
 ***************************************************************/

#include "g_fmt_BASIC_normal.h"
#include "dtoa5_normal.h"

/* g_fmt(buf,x) stores the closest decimal approximation to x in buf;
 * it suffices to declare buf
 *  char buf[32];
 * use 6 for digits_after_decimal for float
 */

char *g_fmt(
    register char *b,
    double x,
    signed long int digits_after_decimal,
    char digits_in_exponent) {
  register int i,
               k;
  register char *s;
  int decpt,
      j,
       sign;
  char *b0,
       *s0,
       *se;

  b0 = b;
#ifdef IGNORE_ZERO_SIGN
  if (x==0.0) {
    *b++ = ' ';
    *b++ = '0';
    *b++ = ' ';
    *b = 0;
    goto done;
  }
#endif
  s = s0 = dgdtoa(x, 4, (int)digits_after_decimal, &decpt, &sign, &se);
  if (sign)
    *b++ = '-';
  else
    *b++ = ' ';
  if (decpt == 9999) { /* Infinity or Nan */
    while((*b = *s++))
      b++;
    *b++ = ' ';
    *b = 0;
    goto done0;
  }
  if ((decpt > digits_after_decimal) || (decpt < (se - s - digits_after_decimal))) {
    *b++ = *s++;
    if (*s) {
      *b++ = '.';
      while ((*b = *s++))
        b++;
    } else {
      *b++ = '.';
    }
    *b++ = 'E';
    /* sprintf(b, "%+.2d", decpt - 1); */
    if (--decpt < 0) {
      *b++ = '-';
      decpt = -decpt;
    } else {
      *b++ = '+';
    }
    switch(digits_in_exponent) {
      case 3:
        k = 100;
        break;
      case 4:
        k = 1000;
        break;
      default:
        k = 10;
        break;
    }
    for (j = digits_in_exponent; 10 * k <= decpt; j++, k *= 10)
      ;
    for (;;) {
      i = decpt / k;
      *b++ = (char)(i + '0');
      if (--j <= 0)
        break;
      decpt -= i * k;
      decpt *= 10;
    }
    *b++ = ' ';
    *b = 0;
  } else if (decpt <= 0) {
    *b++ = '.';
    for (; decpt < 0; decpt++)
      *b++ = '0';
    while((*b = *s++))
      b++;
    *b++ = ' ';
    *b = 0;
  } else {
    while((*b = *s++)) {
      b++;
      if (--decpt == 0 && *s)
        *b++ = '.';
    }
    for (; decpt > 0; decpt--)
      *b++ = '0';
    *b++ = ' ';
    *b = 0;
  }
done0:
  freedtoa(s0);
#ifdef IGNORE_ZERO_SIGN
done:
#endif
  return b0;
}
