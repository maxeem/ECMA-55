//
// codegen.c - This file contains the low-level code generation routines
//             for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <float.h>
#include "globals.h"
#include "error_messages.h"
#include "codegen.h"
#include "load_textdata.h"
#include "textdata.h"
#include "g_fmt_BASIC_normal.h"
#include "dtoa5_normal.h"
#ifndef FLT_TRUE_MIN
#define FLT_TRUE_MIN 1.40129846432481707092e-45F
#endif

#define COMMENT_BUFFER_MAX 256                   // size of comment line buffer used in emit_comment()

static bool is_zero(const char *inbuf),
            is_erange(const char *inbuf, char *tbuf);
static void init_bss(FILE *f),
            prologue1(FILE *f),
            prologue2(FILE *f),
            prologue3(FILE *f),
            startlabel(FILE *f),
            pushsaddr(FILE *f),
            popsaddr(FILE *f, const char *to),
            binary_add(FILE *f, const char *lhs_fpregname,  const char *rhs_fpregname),
            binary_subtract(FILE *f, const char *lhs_fpregname,  const char *rhs_fpregname),
            binary_multiply(FILE *f, const char *lhs_fpregname,  const char *rhs_fpregname),
            binary_power(FILE *f, const char *lhs_fpregname,  const char *rhs_fpregname),
            binary_divide(FILE *f, const char *lhs_fpregname,  const char *rhs_fpregname);

//
// This will examine the inbuf and if it is INF then it returns true,
// otherwise it returns false.  This function requires that inbuf be
// properly NULL terminated (ASCIIZ).  This only handles positive values.
//
static bool is_erange(const char *inbuf, char *tbuf) {
  bool retval = false;
  double d;
  errno = 0;
  d = dgstrtod(inbuf, NULL);
  if (!tbuf)
    ICE(__FILE__, __func__, __LINE__, "NULL tbuf");
  tbuf[0] = 0;
  if (errno) {
    switch (errno) {
      case ERANGE:
        debug_printf("is_erange(\"%s\") got ERANGE\n", inbuf);
        retval = true;
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, "catastrophic conversion failure, errno=%d\n", errno);
    }
  }
  debug_printf("is_erange(\"%s\"/%lg)\n", inbuf, d);
  if (retval) {
    // convert real number ASCIIZ input to David M. Gay's 64bit double format
    g_fmt(tbuf, d, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
    debug_printf("is_erange(\"%s\") g_fmt gave \"%s\"\n", inbuf, tbuf);
    if (strcmp(tbuf," 0 ")==0)
       strcpy(tbuf," -0 "); // negative zero, which cannot happen normally,
                            // signals we should throw an exception
    debug_printf("is_erange(\"%s\") converting to \"%s\"\n", inbuf, tbuf);
  }
  // phase II - if we are using floats, does it fit?
  if ((!retval) && (!use_double)) {
    if (d > FLT_MAX) {   // 3.40282346638528859812e+38F
      debug_printf("is_erange(\"%s\") phase II: too big %lg > %lg\n", inbuf, d, FLT_MAX);
      strcpy(tbuf, " INFINITY ");
      retval = true;
      debug_printf("is_erange(\"%s\") phase II: 2big g_fmt gave \"%s\"\n", inbuf, tbuf);
    } else {
      debug_printf("is_erange(\"%s\") phase II: no problem\n", inbuf);
    }
  }
  debug_printf("is_erange(\"%s\") returning %s\n", inbuf, retval?"true":"false");
  return retval;
}

//
// This will examine the inbuf and if it is [+-]0E### for any
// exponent ### then it returns true, otherwise it returns
// false.  It skips any leading spaces.  This function
// requires that inbuf be properly NULL terminated (ASCIIZ).
//
static bool is_zero(const char *inbuf) {
  char *c = NULL,
       *c2 = (char *)inbuf;
  bool allzeros = false,
       have_exponent = false,
       retval;
  debug_printf("is_zero(\"%s\")\n", inbuf);
  while ((0!=*c2) && (' '==*c2)) {
     debug_printf("skipping a leading blank\n");
     c2++; // skip over any leading blanks
  }
  if ((0!=*c2) &&
      (('-'==*c2)||('+'==*c2))) {
     debug_printf("skipping a leading sing\n");
     c2++;  // skip any sign too
  }
  if (NULL == c2)
    ICE(__FILE__, __func__, __LINE__, "%s", "empty float literal?\n");
  c = strchr(c2, 'E');
  if (NULL!=c) { // if we have an exponent
    debug_printf("found exponent\n");
    have_exponent = true;
    while (c2 < c) {
      debug_printf("c2 is less than c\n");
      if ('0' != *c2) {
         debug_printf("got something non-zero, so breaking out\n");
         break;
      } else {
         debug_printf("got a '0', so moving to next byte\n");
         c2++;
      }
    }
    if (c2 == c)
      allzeros = true;
  } else {
    debug_printf("no exponent\n");
  }
  retval = (have_exponent && allzeros);
  debug_printf("%s returning %s\n", __func__, retval?"true":"false");
  return retval;
}

// load a scalar numeric floating point value (by label) into an xmm register
static void do_floatmem_to_floatreg(
    FILE *f,                   // file handle of output assembly file
    const char *varname,       // pointer to buffer with ASCIIZ string containing the
                               // name of the scalar numeric variable
    const char *fpregname,     // pointer to buffer with ASCIIZ string containing the
                               // destination register
    char first_letter,         // first letter of logical numeric scalar variable name
    char second_letter) {      // second letter of logical numeric scalar variable name,
                               // or 0 if there is no second letter
  static uint32_t instance_number = 0;
  fprintf(f, "        # %s=%s\n"
             "        movabsq $%s,%%r15\n"
             "        pushq %%rax\n"
             "        pushq %%rbx\n"
             "        mov%c (%%r15), %%%cbx\n"
             "        mov%s $.LSNaN,%%%cax\n"
             "        cmp%c    %%%cax,%%%cbx\n"
             "        je      .LFMTOFRM%" PRIu32 "_0\n"
             "        {disp8} jmp .LFMTOFRM%" PRIu32 "_2\n"
             ".LFMTOFRM%" PRIu32 "_0:\n"
             "        popq %%rbx\n"
             "        popq %%rax\n"
             "        # referenced scalar %s was uninitialized\n"
             "        movabsq $.Luninitialized_msg, %%rcx # arg 4 input string address\n"
             ".LFMTOFRM%" PRIu32 "_1:\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer, %%r15\n"
             "        callq   *%%r15\n"
             "        # must create string in reverse order for little-endian\n"
             "        xorl    %%edi,%%edi\n",
          fpregname, varname, varname, (use_double?'q':'l'), (use_double?'r':'e'),
          (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'q':'l'),
          (use_double?'r':'e'), (use_double?'r':'e'), instance_number, instance_number,
          instance_number, varname, instance_number);
  if (second_letter!=0)
    fprintf(f, "# if this is a 2-byte numeric variable like A0 or Z9...\n"
               "        movb    $'%c',%%dil\n"
               "        shlq    $8,%%rdi\n",
            second_letter);
  fprintf(f, "        movb    $'%c',%%dil\n"
             "        shlq    $8,%%rdi\n"
             "        movb    $32,%%dil\n"
             "        subq    $16,%%rsp\n"
             "        movq    %%rdi,(%%rsp)\n"
             "        movq    %%rsp,%%rcx            # arg 4 input string address\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        addq    $16,%%rsp\n"
             "        movabsq $.Lbadxit,%%rax\n"
             "        jmpq    *%%rax                # does not return\n"
             ".LFMTOFRM%" PRIu32 "_2:\n"
             "        popq %%rbx\n"
             "        popq %%rax\n"
             "        movs%c   (%%r15),%s\n"
             "        comis%c  %s,%s\n"
             "        jnp     .LFMTOFRM%" PRIu32 "_3\n"
             "        # It's a generated NaN\n"
             "        movabsq $.LNANDETECTED_msg, %%rcx # arg 4 input string address\n"
             "        {disp8} jmp     .LFMTOFRM%" PRIu32 "_1\n"
             ".LFMTOFRM%" PRIu32 "_3:\n"
             "        movs%c   (%%r15), %s\n",
          first_letter, instance_number, (use_double?'d':'s'), fpregname, (use_double?'d':'s'),
          fpregname, fpregname, instance_number, instance_number, instance_number,
          (use_double?'d':'s'), fpregname);
  instance_number++;
  return;
}

//
// This function emits code to do a conditional jump to a label on a true condition.
// The label parameter contains a string with the name of the jump destination
// label to use if al is 1.
//
void jump_if_true(
    FILE *f,                // File handle for assembly language output file
    char const * const label) {    // pointer to buffer with ASCIIZ string containing jump
                            // destination label
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!label || !label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "label");
  fprintf(f, "        cmpb    $1,%%al                   # if al==1 then\n"
             "        je      %s                        # GOTO label\n", label);
  return;
}

//
// This function emits code to do a conditional jump to a label on a false condition.
// The label parameter contains a string with the name of the jump destination
// label to use if al is 1.
//
void jump_if_false(
    FILE *f,                // File handle for assembly language output file
    char const * const label) {    // pointer to buffer with ASCIIZ string containing jump
                            // destination label
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!label || !label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "label");
  fprintf(f, "        cmpb    $1,%%al                   # if al==0 then\n"
             "        jne     %s                        # GOTO label\n", label);
  return;
}

void do_begin_data(FILE *f,                        // File handle for assembly language output file
                   const uint32_t item_count) {    // number of elements in the list pointed to by data_list_head
  fprintf(f, "        .section .data,\"aw\",@progbits\n\n"
             "        # runtime data item pointer\n"
             "        .type .Ldata_item_ptr, @object\n"
             ".Ldata_item_ptr:\n"
             "        .quad 0\n"
             "        .size .Ldata_item_ptr, .-.Ldata_item_ptr\n\n"
             "        .section .rodata,\"a\",@progbits\n\n"
             "        # the number of data items in the list\n"
             "        .type .Ldata_item_count, @object\n"
             ".Ldata_item_count:\n"
             "        .quad %" PRIu32 "\n"
             "        .size .Ldata_item_count, .-.Ldata_item_count\n", item_count);
  return;
}

void do_unique_data_blocks(FILE *f) {  // File handle for assembly language output file
  fputs("\n# DATA statement unique data blocks\n", f);
  return;
}

void do_data_item_string(FILE *f,                  // File handle for assembly language output file
                         const char *symname,      // Symbol name
                         const char *sval) {       // Symbol string value
  fprintf(f, "        .type %sS, @object\n"
             "%sS:\n"
             "        .asciz \"%s\"           # the ASCIIZ string itself\n"
             "        .size %sS, .-%sS\n"
             "        .equiv %sS_length, .-%sS\n"
             "        .type %s, @object\n"
             "%s:\n"
             "        .byte .LQSTR\n"
             "        .byte %sS_length        # length of ASCIIZ string\n"
             "        .quad %sS               # pointer to ASCIIZ string\n"
             "        .size %s, .-%s\n\n",
          symname, symname, sval, symname, symname, symname, symname, symname, symname, symname,
          symname, symname, symname);
  return;
}

void do_data_item_numeric(FILE *f,                 // File handle for assembly language output file
                          const char *symname,     // Symbol name
                          const char *sval,        // Symbol string value
                          const char *nval,        // ASCIIZ formatted numeric value
                          const char *fptype) {    // Floating-point type (double or float)
  fprintf(f, "%sS:       # string representation\n"
             "        .asciz \"%s\"\n"
             "        .size %sS, .-%sS\n"
             "        .type %sS, @object\n"
             "        .equiv %sS_length, .-%sS\n"
             "%s:\n"
             "        .byte .LUQSTR    # Type\n"
             "        .%s  %s  # numeric representation\n"
             "        .byte %sS_length    # length of ASCIIZ string pointed to by %sS including NULL byte\n"
             "        .quad %sS   # pointer to string representation\n"
             "        .size %s, .-%s\n"
             "        .type %s, @object\n",
          symname, sval, symname, symname, symname, symname, symname,
          symname, fptype, nval, symname, symname, symname, symname, symname, symname);
  return;
}

void do_read_data_array_start(FILE *f) {  // File handle for assembly language output file
    fputs("        # List of pointers to all DATA statement items' data blocks\n"
          "        .align 16\n"
          "        .type .Ldata_items, @object\n"
          ".Ldata_items:\n", f);
  return;
}

void do_emit_data_item_pointer(FILE *f,                 // File handle for assembly language output file
                               const char *symname) {   // Symbol name
  fprintf(f, "        .quad %s\n", symname);
  return;
}

void do_end_data(FILE *f) {  // File handle for assembly language output file
  fputs("        .size .Ldata_items, .-.Ldata_items\n\n", f);
  return;
}

void do_begin_ds_literals(FILE *f) {  // File handle for assembly language output file
  fputs("        .section .rodata,\"a\",@progbits\n\n", f);
  return;
}

void do_define_slit(FILE *f,                // File handle for assembly language output file
                    const char *symname,    // Symbol name
                    const char *litval) {   // String literal value
  fprintf(f, "%s:\n"
             "        .asciz \"%s\"\n"
             "        .size %s, .-%s\n", symname, litval, symname, symname);
  return;
}

void do_define_nlit(FILE *f,  // File handle for assembly language output file
    const char *symname,     // pointer to buffer with ASCIIZ string containing label
    const char *litval) {    // pointer to buffer with ASCIIZ string containing value
  bool isinf = false;
  char tipe[16];
  char *tbuf = NULL;         // buffer used to hold the result of g_fmt() conversion
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!symname || !symname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "symname");
  if (!litval || !litval[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "litval");
  debug_printf("dodefine_nlit(fh,\"%s\",\"%s\")\n",symname,litval);
  tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
  // check for some special cases first
  if (strstr(litval,"-INF")!=NULL) {
    strcpy(tipe,"quad");
    strcpy(tbuf,use_double?"0xfff0000000000000":"0xff800000");
    isinf = true;
  } else if (strstr(litval,"INF")!=NULL) {
    strcpy(tipe,"quad");
    strcpy(tbuf,use_double?"0x7ff0000000000000":"0x7f800000");
    isinf = true;
  } else if (is_zero(litval)) { // 0E22 becomes 22 with GNU as from binutils 2.34
    strcpy(tipe, use_double?"double":"float");
    strcpy(tbuf," 0 ");
    isinf = true;
  } else {
    strcpy(tipe, use_double?"double":"float");
    isinf = is_erange(litval,tbuf); // GNU as from binutils 2.34 pukes on range errors
                                    // instead of just returning INF
    if (strstr(tbuf,"-INF")!=NULL) {
      strcpy(tipe,"quad");
      strcpy(tbuf,use_double?"0xfff0000000000000":"0xff800000");
    } else if (strstr(tbuf,"INF")!=NULL) {
      strcpy(tipe,"quad");
      strcpy(tbuf,use_double?"0x7ff0000000000000":"0x7f800000");
    }
  }
  debug_printf("dodefine_nlit(fh,\"%s\",\"%s\") uses type='%s' and value='%s'\n",
               symname,litval,tipe,isinf?tbuf:litval);
  fprintf(f, "%s:\n"
             "        .%s %s\n"
             "        .size %s, .-%s\n",
          symname, tipe, isinf?tbuf:litval, symname, symname);
  free(tbuf); tbuf = NULL;
  return;
}

void do_define_nvar(FILE *f,                // File handle for assembly language output file
                    const char *varname) {  // Name of numeric scalar variable
  fprintf(f, "%s:\n"
             "        .skip .LBYTES_IN_NUMBER\n"
             "        .size %s, .-%s\n", varname, varname, varname);
  return;
}

void do_define_1D_navar(FILE *f,                    // File handle for assembly language output file
                        const char *varname,        // Name of 1D numeric array variable
                        uint32_t element_count) {   // Number of elements in the array
  fprintf(f, "%s:\n"
             "        .skip (.LBYTES_IN_NUMBER * %" PRIu32 ")\n"
             "        .size %s, .-%s\n", varname, element_count, varname, varname);
  return;
}

void do_define_2D_navar(FILE *f,                           // File handle for assembly language output file
                        const char *varname,               // Name of 2D numeric array variable
                        uint32_t row_element_count,        // Number of rows in the array
                        uint32_t column_element_count) {   // Number of columns in the array
  fprintf(f, "%s:\n"
             "        .skip (.LBYTES_IN_NUMBER * %" PRIu32 " * %" PRIu32 ")\n"
             "        .size %s, .-%s\n", varname, row_element_count, column_element_count, varname, varname);
  return;
}

void do_begin_nvars(FILE *f) {  // File handle for assembly language output file
  fputs("        .section .bss,\"aw\",@nobits\n\n"
        "        .balign .LBALIGN\n"
        ".LSTART_BSS:\n", f);
  return;
}

void do_end_nvars(FILE *f) {  // File handle for assembly language output file
  fputs("        .equiv .LBSS_SIZE, .-.LSTART_BSS\n", f);
  return;
}

void do_begin_svars(FILE *f) {  // File handle for assembly language output file
  fputs("        .section .data,\"aw\",@progbits\n\n"
        "        .balign 1\n"
        ".LSTART2_BSS:\n", f);
  return;
}

void do_define_svar(FILE *f,                // File handle for assembly language output file
                    const char *varname) {  // Scalar string variable name
  fprintf(f, "%s:\n"
             "        .skip 19\n"
             "        .size %s, .-%s\n", varname, varname, varname);
  return;
}

void do_end_svars(FILE *f) {  // File handle for assembly language output file
  fputs("        .equiv .LBSS_SIZE2, .-.LSTART2_BSS\n", f);
  return;
}

void do_balign(FILE *f) {  // File handle for assembly language output file
  fputs("        .balign .LBALIGN,0\n", f);
  return;
}

//
// This function emits a label which can be used as a jump target.
// The label parameter contains a string with the name of the jump destination.
//
void emit_label(
    FILE *f,                // File handle for assembly language output file
    char const * const label) {    // pointer to buffer with ASCIIZ string containing jump
                            // destination label
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!label || !label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "label");
  fprintf(f, "%s:\n", label);
  return;
}

//
// This function will generate a unique file-local label.  It uses
// a static variable, so the caller must copy that to some other place
// before the next call to the function which will overwrite that
// static variable.  The label is 7 characters and a 1 byte terminator (NULL,
// with the first two characters as ".L" and the next 5 characters as an
// unsigned integer zero-padded on the left to 5 digits.
//
const char *generate_label(void) {
  static uint32_t label_number = 0U;    // label counter used to create unique labels
  static char the_label[8];             // buffer containing ASCIIZ string with new label

  snprintf(the_label, 8, ".L%05" PRIu32, label_number++);
  the_label[7] = 0;
  return the_label;
}

//
// This function is used by the main driver to emit the assembly prologue.
// The ASCIIZ file name for the file f is passed
// in the inname parameter.  The code emitted is adjusted depending on many
// of the flags in globals.c, the most significant of which is the use_double
// variable that when true specifies normal 64 bit math will be used, but when
// false specifies 32 bit math will be used instead.  Other flags used are
// need_ATN, need_BSS_numeric, need_BSS_string, need_COS, need_EXP, need_INPUT,
// need_LOG, need_POWER, need_READSTMT, need_RND, need_PI, need_SIN, need_SQR,
// need_strcmp, need_strcpy, and need_TAN.
//
void write_prologue(
    FILE *f,                // File handle for assembly language output file
    const char *inname) {   // pointer to buffer with ASCIIZ string containing
                            // name of Minimal BASIC source code file that the
                            // compiler is translating
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!inname || !inname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "inname");
  // setup access to assembly text blobs
  fprintf(f, "        .file \"%s\"\n"
             "        .equiv .LSSE4_1, %u\n"
             "        # .LWIDE=0 selects 80 column output (not including newline)\n"
             "        # .LWIDE=1 selects 132 column output (not including newline)\n"
             "        .equiv .LWIDE, %u\n"
             "        .equiv .LMAX_STRING_BYTES, %u\n"
             "        .equiv .LBITS64, %u\n"
             "        .equiv .LEXTENSIONS, %u\n",
          inname, (use_SSE4_1?1:0), (use_double_output?1:0), MAX_STRING_BYTES, (use_double?1U:0U),
          (extensions?1U:0U));
  WRITEWITHNEWLINE(f, definitions_asmcode);
  if (need_ADD || need_SUBTRACT || need_MULTIPLY || need_DIVIDE)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .LNaN_msg, @object\n"
          ".LNaN_msg:\n"
          "        .asciz \"NAN GENERATED\"\n"
          "        .size .LNaN_msg, .-.LNaN_msg\n\n", f);
  if (need_DIVIDE)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Ldividebyzero_msg, @object\n"
          ".Ldividebyzero_msg:\n"
          "        .asciz \"DIVIDE BY ZERO\"\n"
          "        .size .Ldividebyzero_msg, .-.Ldividebyzero_msg\n\n", f);
  if (need_POWER)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lbadpower_msg, @object\n"
          ".Lbadpower_msg:\n"
          "        .asciz \"BAD POWER\"\n"
          "        .size .Lbadpower_msg, .-.Lbadpower_msg\n\n"
          "        .type .Lzero_to_negative_power_msg, @object\n"
          ".Lzero_to_negative_power_msg:\n"
          "        .asciz \"ZERO RAISED TO A NEGATIVE POWER\"\n"
          "        .size .Lzero_to_negative_power_msg, .-.Lzero_to_negative_power_msg\n\n"
          "        .type .Lnegraisednonint_msg, @object\n"
          ".Lnegraisednonint_msg:\n"
          "        .asciz \"NEGATIVE QUANTITY RAISED TO A NON-INTEGRAL POWER\"\n"
          "        .size .Lnegraisednonint_msg, .-.Lnegraisednonint_msg\n\n", f);
  if (need_STRINGS || need_PRINT)
    fputs("        # maximum number of string stack entries permitted\n"
          "        .equiv .LMAX_SADDR_DEPTH, 4\n\n"
          "        .section .data,\"aw\",@progbits\n\n"
          "        .type .Lsoperand_stack_ptr, @object\n"
          ".Lsoperand_stack_ptr:\n"
          "        .quad 0\n"
          "        .size .Lsoperand_stack_ptr, .-.Lsoperand_stack_ptr\n\n"
          "        .section .bss,\"aw\",@nobits\n\n"
          "        .type .Lsoperand_stack, @object\n"
          ".Lsoperand_stack:\n"
          "        .rept .LMAX_SADDR_DEPTH\n"
          "        .quad 0      # (8 byte units, string addresses)\n"
          "        .endr\n"
          "        .size .Lsoperand_stack, .-.Lsoperand_stack\n"
          "        .equiv .Lsoperand_stack_size, (.-.Lsoperand_stack)>>3\n\n"
          "        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lsstack_full_msg, @object\n"
          ".Lsstack_full_msg:\n"
          "        .asciz \"STRING STACK OF 4 ENTRIES IS FULL\"\n"
          "        .size .Lsstack_full_msg, .-.Lsstack_full_msg\n\n"
          "        .type .Lsstack_empty_msg, @object\n"
          ".Lsstack_empty_msg:\n"
          "        .asciz \"STRING STACK EMPTY\"\n"
          "        .size .Lsstack_empty_msg, .-.Lsstack_empty_msg\n\n"
          "        .type .Lstring_too_long_msg, @object\n"
          ".Lstring_too_long_msg:\n"
          "        .asciz \"STRING LITERAL IN ASSIGNMENT TOO LONG\"\n"
          "        .size .Lstring_too_long_msg, .-.Lstring_too_long_msg\n\n", f);
  if (need_UDF && extensions)
    WRITEWITHNEWLINE(f, badudfarg_asmcode);
  if (need_IP)
    WRITEWITHNEWLINE(f, IP_asmcode);
  if (need_FP)
    WRITEWITHNEWLINE(f, FP_asmcode);
  if (need_DATE || need_TIME || need_DATES || need_TIMES)
    WRITEWITHNEWLINE(f, localtime_asmcode);
  if (need_DATE)
    WRITEWITHNEWLINE(f, fb_date_n_asmcode);
  if (need_TIME)
    WRITEWITHNEWLINE(f, fb_time_n_asmcode);
  if (need_DATES)
    WRITEWITHNEWLINE(f, fb_date_s_asmcode);
  if (need_TIMES)
    WRITEWITHNEWLINE(f, fb_time_s_asmcode);
  if (need_LOADREAL)
    fputs(".ifndef .LLNANDETECTED\n"
          "        .equ  .LLNANDETECTED, 1\n\n"
          "        .section .rodata.str,\"aS\",@progbits\n"
          "        .type .LNANDETECTED_msg, @object\n"
          ".LNANDETECTED_msg:\n"
          "        .asciz \"NAN DETECTED LOADING\"\n"
          "        .size .LNANDETECTED_msg, .-.LNANDETECTED_msg\n"
          ".endif\n", f);
  if (need_READSTMT_SVAR)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lbad_string_read_msg, @object\n"
          ".Lbad_string_read_msg:\n"
          "        .asciz \"BAD STRING READ\"\n"
          "        .size .Lbad_string_read_msg, .-.Lbad_string_read_msg\n\n", f);
  if (need_READ_1D)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lbogus_read_subscript_msg, @object\n"
          ".Lbogus_read_subscript_msg:\n"
          "        .asciz \"INVALID SUBSCRIPT FOR READ OF ARRAY \"\n"
          "        .equ .Lbogus_read_subscript_msg_len, .-.Lbogus_read_subscript_msg\n"
          "        .size .Lbogus_read_subscript_msg, .-.Lbogus_read_subscript_msg\n\n"
          ".ifndef .Lsubscript_msg_len\n"
          "        .type .Lsubscript_msg, @object\n"
          ".Lsubscript_msg:\n"
          "        .asciz \" WITH SUBSCRIPT \"\n"
          "        .equ .Lsubscript_msg_len, .-.Lsubscript_msg\n"
          "        .size .Lsubscript_msg, .-.Lsubscript_msg\n"
          ".endif\n\n", f);
  if (need_READ_2D)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lbogus_read_first_subscript_msg, @object\n"
          ".Lbogus_read_first_subscript_msg:\n"
          "        .asciz \"INVALID FIRST SUBSCRIPT FOR READ OF ARRAY \"\n"
          "        .equ .Lbogus_read_first_subscript_msg_len, .-.Lbogus_read_first_subscript_msg\n"
          "        .size .Lbogus_read_first_subscript_msg, .-.Lbogus_read_first_subscript_msg\n\n"
          "        .type .Lbogus_read_second_subscript_msg, @object\n"
          ".Lbogus_read_second_subscript_msg:\n"
          "        .asciz \"INVALID SECOND SUBSCRIPT FOR READ OF ARRAY \"\n"
          "        .equ .Lbogus_read_second_subscript_msg_len, .-.Lbogus_read_second_subscript_msg\n"
          "        .size .Lbogus_read_second_subscript_msg, .-.Lbogus_read_second_subscript_msg\n\n"
          ".ifndef .Lsubscript2_msg_len\n"
          "        .type .Lsubscript2_msg, @object\n"
          ".Lsubscript2_msg:\n"
          "        .asciz \" WITH SUBSCRIPTS \"\n"
          "        .equ .Lsubscript2_msg_len, .-.Lsubscript2_msg\n"
          "        .size .Lsubscript2_msg, .-.Lsubscript2_msg\n"
          ".endif\n\n", f);
  if (need_READ_1D || need_READ_2D)
    fputs(".ifndef .Larray_OOB_read_msg_len\n"
          "        .type .Larray_OOB_read_msg, @object\n"
          ".Larray_OOB_read_msg:\n"
          "        .asciz \"INDEX OUT OF BOUNDS READ FOR ARRAY \"\n"
          "        .equ .Larray_OOB_read_msg_len, .-.Larray_OOB_read_msg\n"
          "        .size .Larray_OOB_read_msg, .-.Larray_OOB_read_msg\n\n"
          "        .type .Luninitialized_element_msg, @object\n"
          ".Luninitialized_element_msg:\n"
          "        .asciz \"READ OF UNINITIALIZED ELEMENT IN ARRAY \"\n"
          "        .equ .Luninitialized_element_msg_len, .-.Luninitialized_element_msg\n"
          "        .size .Luninitialized_element_msg, .-.Luninitialized_element_msg\n"
          ".endif\n", f);
  if (need_WRITE_1D || need_WRITE_2D)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          ".Larray_OOB_write_msg:\n"
          "        .asciz \"INDEX OUT OF BOUNDS WRITE FOR ARRAY \"\n"
          "        .equ .Larray_OOB_write_msg_len, .-.Larray_OOB_write_msg\n"
          "        .size .Larray_OOB_write_msg, .-.Larray_OOB_write_msg\n\n", f);
  if (need_WRITE_1D) // already in rodata.str
    fputs("        .type .Lbogus_write_subscript_msg, @object\n"
          ".Lbogus_write_subscript_msg:\n"
          "        .asciz \"INVALID SUBSCRIPT FOR WRITE OF ARRAY \"\n"
          "        .equ .Lbogus_write_subscript_msg_len, .-.Lbogus_write_subscript_msg\n"
          "        .size .Lbogus_write_subscript_msg, .-.Lbogus_write_subscript_msg\n\n"
          ".ifndef .Lsubscript_msg_len\n"
          "        .type .Lsubscript_msg, @object\n"
          ".Lsubscript_msg:\n"
          "        .asciz \" WITH SUBSCRIPT \"\n"
          "        .equ .Lsubscript_msg_len, .-.Lsubscript_msg\n"
          "        .size .Lsubscript_msg, .-.Lsubscript_msg\n"
          ".endif\n", f);
  if (need_WRITE_2D) // already in rodata.str
    fputs("        .type .Lbogus_write_first_subscript_msg, @object\n"
          ".Lbogus_write_first_subscript_msg:\n"
          "        .asciz \"INVALID FIRST SUBSCRIPT FOR WRITE OF ARRAY \"\n"
          "        .equ .Lbogus_write_first_subscript_msg_len, .-.Lbogus_write_first_subscript_msg\n"
          "        .size .Lbogus_write_first_subscript_msg, .-.Lbogus_write_first_subscript_msg\n\n"
          "        .type .Lbogus_write_second_subscript_msg, @object\n"
          ".Lbogus_write_second_subscript_msg:\n"
          "        .asciz \"INVALID SECOND SUBSCRIPT FOR WRITE OF ARRAY \"\n"
          "        .equ .Lbogus_write_second_subscript_msg_len, .-.Lbogus_write_second_subscript_msg\n"
          "        .size .Lbogus_write_second_subscript_msg, .-.Lbogus_write_second_subscript_msg\n\n"
          ".ifndef .Lsubscript2_msg_len\n"
          "        .type .Lsubscript2_msg, @object\n"
          ".Lsubscript2_msg:\n"
          "        .asciz \" WITH SUBSCRIPTS \"\n"
          "        .equ .Lsubscript2_msg_len, .-.Lsubscript2_msg\n"
          "        .size .Lsubscript2_msg, .-.Lsubscript2_msg\n"
          ".endif\n", f);
  if (need_FORNEXT)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Luninitialized_forindex_msg, @object\n"
          ".Luninitialized_forindex_msg:\n"
          "        .asciz \"ICE:READ OF UNINITIALIZED FOR LOOP INDEX \"\n"
          "        .size .Luninitialized_forindex_msg, .-.Luninitialized_forindex_msg\n\n"
          "        .type .Luninitialized_forinc_msg, @object\n"
          ".Luninitialized_forinc_msg:\n"
          "        .asciz \"ICE:READ OF UNINITIALIZED FOR LOOP INCREMENT\"\n"
          "        .size .Luninitialized_forinc_msg, .-.Luninitialized_forinc_msg\n\n"
          "        .type .Luninitialized_forlimit_msg, @object\n"
          ".Luninitialized_forlimit_msg:\n"
          "        .asciz \"ICE:READ OF UNINITIALIZED FOR LOOP LIMIT\"\n"
          "        .size .Luninitialized_forlimit_msg, .-.Luninitialized_forlimit_msg\n\n", f);
  if (need_SUBROUTINE)
    fprintf(f, "        # maximum number of active nested GOSUBs permitted\n"
               "        .equiv .LMAX_GOSUB_DEPTH, %u\n\n"
               "        .section .rodata,\"a\",@progbits\n\n"
               "        .type .Lreturn_stack_full_msg, @object\n"
               ".Lreturn_stack_full_msg:\n"
               "        .asciz \"RETURN STACK OF %u ENTRIES IS FULL\"\n"
               "        .size .Lreturn_stack_full_msg, .-.Lreturn_stack_full_msg\n\n"
               "        .type .Lreturn_stack_empty_msg, @object\n"
               ".Lreturn_stack_empty_msg:\n"
               "        .asciz \"RETURN WITHOUT GOSUB\"\n"
               "        .size .Lreturn_stack_empty_msg, .-.Lreturn_stack_empty_msg\n\n"
               "        .section .data,\"aw\",@progbits\n\n"
               "        # gosub/return stack pointer\n"
               "        # initialized to 0 (next available slot), so a value of 0\n"
               "        # means the stack is empty.  The need to initialize this\n"
               "        # is why it is in the .data segment and not the .bss segment.\n"
               "        .type .Lretaddr_stack_ptr, @object\n"
               ".Lretaddr_stack_ptr:\n"
               "        .long 0                  # 4 byte integer value, 0..MAX_GOSUB_DEPTH-1\n"
               "        .size .Lretaddr_stack_ptr, .-.Lretaddr_stack_ptr\n\n"
               "        .section .bss,\"aw\",@nobits\n\n"
               "        # gosub/return stack of return addresses\n"
               "        # with room for MAX_GOSUB_DEPTH addresses\n"
               "        .type .Lretaddr_stack, @object\n"
               ".Lretaddr_stack:\n"
               "        .rept .LMAX_GOSUB_DEPTH  # supported levels of nesting....\n"
               "        .skip 8                  # (8 byte units, return addresses)\n"
               "        .endr\n"
               "        .size .Lretaddr_stack, .-.Lretaddr_stack\n"
               "        # number of addresses stack can hold\n"
               "        .set .Lretaddr_stack_size, (.-.Lretaddr_stack)>>3\n\n",
            MAX_GOSUB_DEPTH, MAX_GOSUB_DEPTH);
  if (need_TAB)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .LTAB_msg, @object\n"
          ".LTAB_msg:\n"
          "        .asciz \"TAB(\"\n"
          "        .size .LTAB_msg, .-.LTAB_msg\n\n"
          ".ifndef .LBADARG\n"
          "        .equ .LBADARG, 1\n"
          "        .type .Lbadarg_msg, @object\n"
          ".Lbadarg_msg:\n"
          "        .asciz \"INVALID ARGUMENT TO \"\n"
          "        .size .Lbadarg_msg, .-.Lbadarg_msg\n\n"
          "        .type .Lfunction_msg, @object\n"
          ".Lfunction_msg:\n"
          "        .asciz \") FUNCTION\"\n"
          "        .size .Lfunction_msg, .-.Lfunction_msg\n"
          ".endif\n\n"
          "        .section .text,\"ax\",@progbits\n\n"
          ".Lbadtabarg: # xmm0 contains invalid argument value\n"
          "        # Ok, invalid argument to TAB(), so flush any pending normal output\n"
          "        movabsq $.LOBUF,%rdi         # output buffer variable address\n"
          "        movabsq $.Lobuf_next,%rsi    # output bufpos variable address\n"
          "        movabsq $.Lcurzone,%rdx      # output zonepos variable address\n"
          "        movabsq $.Lflushoutputln,%rax # flushoutputln\n"
          "        callq   *%rax\n"
          "        # initialize output error buffer with \"INVALID ARGUMENT TO \"\n"
          "        movabsq $.Lbadarg_msg,%rcx   # rcx = address of badarg_msg\n"
          "        movabsq $.LEBUF,%rdi         # output error buffer variable address\n"
          "        movabsq $.Lebuf_next,%rsi    # output error bufpos variable address\n"
          "        movabsq $.Lcurezone,%rdx     # output error zonepos variable address\n"
          "        movabsq $.Lappendbuffer,%rax # call appendbuffer\n"
          "        # append \"TAB(\" to output error buffer\n"
          "        callq   *%rax\n"
          "        movabsq $.LTAB_msg,%rcx      # rcx = address of TAB_msg\n"
          "        movabsq $.LEBUF,%rdi         # output error buffer variable address\n"
          "        movabsq $.Lebuf_next,%rsi    # output error bufpos variable address\n"
          "        movabsq $.Lcurezone,%rdx     # output error zonepos variable address\n"
          "        movabsq $.Lappendbuffer,%rax # call appendbuffer\n"
          "        callq   *%rax\n"
          "        movabsq $.LEBUF,%rdi         # output error buffer variable address\n"
          "        movabsq $.Lebuf_next,%rsi    # output error bufpos variable address\n"
          "        movabsq $.Lcurezone,%rdx     # output error zonepos variable address\n"
          "        movabsq $.Lappendfloat,%rax  # call appendfloat\n"
          "        callq   *%rax\n"
          "        # append \") FUNCTION\" to output error buffer\n"
          "        movabsq $.Lfunction_msg,%rcx # rcx = address of function_msg\n"
          "        movabsq $.LEBUF,%rdi         # output error buffer variable address\n"
          "        movabsq $.Lebuf_next,%rsi    # output error bufpos variable address\n"
          "        movabsq $.Lcurezone,%rdx     # output error zonepos variable address\n"
          "        movabsq $.Lappendbuffer,%rax # call appendbuffer\n"
          "        callq   *%rax\n"
          "        # append \", USING TAB(1) INSTEAD\" to output error buffer\n"
          "        movabsq $.LTABERRMSG2, %rsi            # rsi = address of TABERRMSG2\n"
          "        movabsq $.Lexception_non_fatal,%r15    # call exception_non_fatal\n"
          "        callq   *%r15                # which prints the output error buffer\n"
          "        retq\n"
          "        .size .Lbadtabarg, .-.Lbadtabarg\n\n", f);
  if (need_EXP)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Loverflow_exp_msg, @object\n"
          ".Loverflow_exp_msg:\n"
          "        .asciz \"OVERFLOW IN EXP FUNCTION\"\n"
          "        .size .Loverflow_exp_msg, .-.Loverflow_exp_msg\n\n"
          "        .type .Lunderflow_exp_msg, @object\n"
          ".Lunderflow_exp_msg:\n"
          "        .asciz \"UNDERFLOW IN EXP FUNCTION\"\n"
          "        .size .Lunderflow_exp_msg, .-.Lunderflow_exp_msg\n\n", f);
  if (need_READSTMT_NVAR || need_READSTMT_NAVAR_1D || need_READSTMT_NAVAR_2D)
    fputs(".ifndef .LBNRM\n"
          "        .equ .LBNRM, 1\n"
          "        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lbad_number_read_msg, @object\n"
          ".Lbad_number_read_msg:\n"
          "        .asciz \"BAD NUMBER READ\"\n"
          "        .size .Lbad_number_read_msg, .-.Lbad_number_read_msg\n\n"
          ".endif\n", f);
  if (need_READSTMT_SVAR || need_READSTMT_NVAR || need_READSTMT_NAVAR_1D || need_READSTMT_NAVAR_2D)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lout_of_data_msg, @object\n"
          ".Lout_of_data_msg:\n"
          "        .asciz \"OUT OF DATA\"\n"
          "        .size .Lout_of_data_msg, .-.Lout_of_data_msg\n\n", f);
  if (need_REMAINDER)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lremainderfail_msg, @object\n"
          ".Lremainderfail_msg:\n"
          "        .asciz \"SECOND ARGUMENT OF REMAINDER() FUNCTION IS ZERO\"\n\n", f);
  if (need_ANGLE)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Lbadangle_msg, @object\n"
          ".Lbadangle_msg:\n"
          "        .asciz \"BOTH ARGUMENTS TO ANGLE FUNCTION ARE ZERO\"\n"
          "        .size .Lbadangle_msg, .-.Lbadangle_msg\n\n"
          "        .section .text,\"ax\",@progbits\n\n", f);
  if (need_ONGOTO)
    fputs("        .section .rodata.str,\"aS\",@progbits\n\n"
          "        .type .Longotofail_msg, @object\n"
          ".Longotofail_msg:\n"
          "        .asciz \"ON .. GOTO EXPRESSION VALUE OUT OF RANGE\"\n"
          "        .size .Longotofail_msg, .-.Longotofail_msg\n\n", f);
  // read only data for runtime (constants)
  prologue1(f);
  if (need_RND || need_DATE || need_TIME || need_DATES || need_TIMES)
    WRITEWITHNEWLINE(f, vDSO_support_asmcode);
  startlabel(f);
  if (need_RND || need_DATE || need_TIME || need_DATES || need_TIMES)
    WRITEWITHNEWLINE(f, vDSO_startup_asmcode);
  prologue2(f);
  if (need_RND) // need to include support for RND function
    fputs("        xorl   %edi, %edi           # select repeatable sequence\n"
          "        movabsq $.Lrealinit, %rax   # initialize random number generator\n"
          "        callq   *%rax\n", f);
  // always need to include support for PRINT statement
  prologue3(f);
  return;
}

static void prologue1(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        .section .rodata.str,\"aS\",@progbits\n"
        "\n"
        "        .type .Lspace, @object\n"
        ".Lspace:\n"
        "        .asciz \" \"\n"
        "        .size .Lspace, .-.Lspace\n"
        "\n"
        "        .type .Lon_line_number_msg, @object\n"
        ".Lon_line_number_msg:\n"
        "        .asciz \" ON LINE NUMBER \"\n"
        "        .size .Lon_line_number_msg, .-.Lon_line_number_msg\n"
        "\n"
        "        .type .Loverflow_msg, @object\n"
        ".Loverflow_msg:\n"
        "        .asciz \"ARITHMETIC OVERFLOW\"\n"
        "        .size .Loverflow_msg, .-.Loverflow_msg\n"
        "\n"
        "        .type .Lunderflow_msg, @object\n"
        ".Lunderflow_msg:\n"
        "        .asciz \"ARITHMETIC UNDERFLOW\"\n"
        "        .size .Lunderflow_msg, .-.Lunderflow_msg\n"
        "\n"
        "        .type .Luninitialized_msg, @object\n"
        ".Luninitialized_msg:\n"
        "        .asciz \"READ OF UNINITIALIZED VARIABLE\"\n"
        "        .size .Luninitialized_msg, .-.Luninitialized_msg\n"
        "\n"
        "        .type .Luninitializedparm_msg, @object\n"
        ".Luninitializedparm_msg:\n"
        "        .asciz \"READ OF UNINITIALIZED FUNCTION PARAMETER\"\n"
        "        .size .Luninitializedparm_msg, .-.Luninitializedparm_msg\n"
        "\n"
        "        .type .Luninitializedparm2_msg, @object\n"
        ".Luninitializedparm2_msg:\n"
        "        .asciz \" OF FUNCTION FN\"\n"
        "        .size .Luninitializedparm2_msg, .-.Luninitializedparm2_msg\n"
        "\n"
        "        .section .bss,\"aw\",@nobits\n"
        "\n"
        "#\n"
        "# This is the line output buffer used by the PRINT statement.\n"
        "#\n"
        "        .align  1,0\n"
        "        .type .LOUTBUFFER,@object\n"
        ".LOUTBUFFER:\n"
        "        .skip 32\n"
        "        .size .LOUTBUFFER,.-.LOUTBUFFER\n"
        "\n"
        "#\n"
        "# This variable is used to hold the current Minimal BASIC\n"
        "# statement line number, which is used for display in some\n"
        "# error and exception messages.\n"
        "#\n"
        "        .align  8,0\n"
        "        .type .LCURLINENO,@object\n"
        ".LCURLINENO:\n"
        "        .skip 8\n"
        "        .size .LCURLINENO,.-.LCURLINENO\n"
        "\n"
        "#\n"
        "# This variable is used to hold the original RSP (stack pointer)\n"
        "# register contents so they can be restored on program exit.\n"
        "#\n"
        "        .type   .Loldrsp,@object\n"
        ".Loldrsp:\n"
        "        .skip 8\n"
        "        .size   .Loldrsp, .-.Loldrsp\n"
        "\n"
        "#\n"
        "# This is used to store the original SIMD floating point unit\n"
        "# MXCSR status register contents so they can be restored on\n"
        "# program exit.\n"
        "#\n"
        "        .type   .Loldmxcsr, @object\n"
        "        .align 4\n"
        ".Loldmxcsr:\n"
        "        .zero   4\n"
        "        .size   .Loldmxcsr, .-.Loldmxcsr\n"
        "\n"
        "#\n"
        "# Variable used by SLEEF routines for storing the\n"
        "# SIMD floating point unit MXCSR status register contents.\n"
        "#\n"
        "        .type   .Lnewmxcsr, @object\n"
        "        .align 4\n"
        ".Lnewmxcsr:\n"
        "        .zero   4\n"
        "        .size   .Lnewmxcsr, .-.Lnewmxcsr\n"
        "\n"
        "#\n"
        "# This is a runtime flag that is used to indicate whether\n"
        "# input on .LSTDIN should be echod on .LSTDOUT or not.  When\n"
        "# reading on a TTY we should not echo (the tty will do that)\n"
        "# but when reading from a file or pipe we need to echo.\n"
        "#\n"
        "        .type   .Lecho_input, @object\n"
        ".Lecho_input:\n"
        "        .zero   8\n"
        "        .size   .Lecho_input, .-.Lecho_input\n", f);
  return;
}

static void prologue2(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        xorl    %ebp, %ebp          # signal this is the outermost frame\n"
        "        movabsq $.Loldrsp, %rax\n"
        "        movq    %rsp, (%rax)        # save stack pointer\n"
        "        # checks for required CPU features\n"
        "        movabsq $.Lhavefeatures,%rax\n"
        "        callq   *%rax\n"
        "        testb   %al,%al\n"
        "        jnz     0f\n"
        "        movabsq $.LEXIT_FAILURE,%rdi  # return code indicates failure\n"
        "        movabsq $.L__NR_exit,%rax\n"
        "        syscall                     # does not return\n"
        "0:\n"
        "        # save original MXCSR\n"
        "        movabsq $.Loldmxcsr, %rbx\n"
        "        stmxcsr (%rbx)\n"
        "        # put MXCSR into eax\n"
        "        movl    (%rbx), %eax\n"
        "        # enable masking, set RC to mode 0, disable FTZ and DAZ,\n"
        "        # and clear any pending exceptions\n"
        "        movw    $0x1F80, %ax\n"
        "        # save new MXCSR (used by SLEEF routines)\n"
        "        movabsq $.Lnewmxcsr, %rbx\n"
        "        movl    %eax, (%rbx)\n"
        "        # load new MXCSR\n"
        "        ldmxcsr (%rbx)\n"
        "        # is .LSTDIN a tty?\n"
        "        movabsq $.Listerminal, %rax\n"
        "        callq   *%rax\n"
        "        movabsq $.Lecho_input, %rbx\n"
        "        movq    %rax, (%rbx)\n", f);
  return;
}

static void prologue3(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        # initialize output buffers\n"
        "        movabsq $.LOBUF,%rdi\n"
        "        movabsq $.Lobuf_next,%rsi\n"
        "        movabsq $.Lcurzone,%rdx\n"
        "        movabsq $.Linitbuffer,%rax\n"
        "        callq   *%rax\n"
        "        movabsq $.LEBUF,%rdi\n"
        "        movabsq $.Lebuf_next,%rsi\n"
        "        movabsq $.Lcurezone,%rdx\n"
        "        movabsq $.Linitbuffer,%rax\n"
        "        callq   *%rax\n"
        "        # make call to initialize .bss section at runtime\n"
        "        # before main program code begins\n"
        "        movabsq $.Linit_bss,%rax\n"
        "        callq   *%rax\n", f);
  return;
}

static void startlabel(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        .section .bss,\"aw\",@nobits\n"
        "        .align 32\n"
        "        .type .Largc, @object\n"
        ".Largc:\n"
        "        .quad 0\n"
        "        .size .Largc, .-.Largc\n"
        "\n"
        "        .align 32\n"
        "        .type .Largv, @object\n"
        ".Largv:\n"
        "        .quad 0\n"
        "        .size .Largv, .-.Largv\n"
        "\n"
        "        .align 32\n"
        "        .type .Lenvironment, @object\n"
        ".Lenvironment:\n"
        "        .quad 0\n"
        "        .size .Lenvironment, .-.Lenvironment\n"
        "\n"
        "        .section .text,\"ax\",@progbits\n"
        "#\n"
        "# The _start label is the actual entry point where program execution\n"
        "# will begin.\n"
        "#\n"
        "        .globl  _start\n"
        "        .type   _start, @function\n"
        "        .align 16, 0x90\n"
        "_start:\n"
        "        movabsq $.Largc, %r15\n"
        "        movq (%rsp), %r14\n"
        "        movq %r14, (%r15)        # populate argc\n"
        "        movq %rsp, %r13\n"
        "        addq $8, %r13\n"
        "        movabsq $.Largv, %r15\n"
        "        movq %r13, (%r15)        # populate **argv\n"
        "        movq %rsp, %r13\n"
        "        leaq 16(%r13,%r14,8), %r13\n"
        "        movabsq $.Lenvironment, %r15\n"
        "        movq %r13, (%r15)        # populate **environment\n", f);
  return;
}

//
// Initialize .bss section's variables so that uninitialized variables can be detected
// at runtime.
//
static void init_bss(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        # subroutine to initialize .bss values\n"
        "        .type .Linit_bss,@function\n"
        ".Linit_bss:\n", f);
  if (need_BSS_numeric)   // we have some numeric variables
    fprintf(f, "        # initialize .bss section numeric variables\n"
               "        movabsq $.LSTART_BSS, %%rdi      # rdi = &START_BSS\n"
               "        movabsq $.LBSS_SIZE/%" PRIu32 ", %%rcx     # rcx = number of uninitialized %ss\n"
               "        mov%s $.LSNaN,%%%cax            # %cax = SNaN %s\n"
               "        cld                             # set forward direction\n"
               "rep     stos%c                           # fill buffer with SNaN values (%s)\n",
            (use_double?8U:4U), (use_double?"double":"float"), (use_double?"absq":"l   "),
            (use_double?'r':'e'), (use_double?'r':'e'), (use_double?"double":"float"), (use_double?'q':'l'),
            (use_double?"doubles":"floats"));
  else
    fputs("        # .bss section has no numeric variables to initialize\n", f);
  if (need_BSS_string) // we have some string scalar variables
    fputs("        # initialize .bss section string variables\n"
          "        #\n"
          "        # fill unintialized strings with NAK in two parts:\n"
          "        # compute number of 8 byte fills and fill them\n"
          "        # then compute remianing bytes (0..7) and fill them too\n"
          "        #\n"
          "        cld                             # set forward direction\n"
          "        movabsq $.LSTART2_BSS, %rdi     # rdi = &START2_BSS\n"
          "        movb    $.LNAK,%al              # al = NAK\n"
          "        movabsq $.LBSS_SIZE2/8, %rcx    # rcx = BSS_SIZE / 8\n"
          "        testq   %rcx,%rcx               # if rcx==0\n"
          "        jz 0f                           # then goto 0\n"
          "rep     stosq                           # else fill buffer with NAK\n"
          "                                        # from START2_BSS to START2_BSS+8*(BSS_SIZE//8)\n"
          "0:      movabsq $.LBSS_SIZE2%8, %rcx    # rcx = BSS_size % 8\n"
          "        testq   %rcx,%rcx               # if rcx==0\n"
          "        jz 1f                           # then goto 1\n"
          "rep     stosb                           # else fill buffer with NAK\n"
          "                                        # from START2_BSS+8*(BSS_SIZE//8) to START2_BSS+BSS_SIZE\n"
          "1:\n", f);
  else
    fputs("        # .bss section has no string variables to initialize\n", f);
  fputs("        retq\n"
        "        .size .Linit_bss, .-.Linit_bss\n\n", f);
  return;
}

//
// This function is used by the main driver to emit the assembly epilogue.
// The code emitted is adjusted depending on many
// of the flags in globals.c, the most significant of which is the use_double
// variable that when true specifies normal 64 bit math will be used, but when
// false specifies 32 bit math will be used instead.  Other flags used are
// need_SQR, need_READSTMT, need_INPUT, need_RND, and need_PRINT.
//
void write_epilogue(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (need_LOG)
    WRITEWITHNEWLINE(f, badlog_asmcode);
  if (need_LOG2)
    WRITEWITHNEWLINE(f, badlog2_asmcode);
  if (need_LOG10)
    WRITEWITHNEWLINE(f, badlog10_asmcode);
  if (need_SIN || need_COS || need_TAN)
    WRITEWITHNEWLINE(f, rempitabdb_asmcode);
  if (need_TAN)
    WRITEWITHNEWLINE(f, badtanarg_asmcode);
  if (need_SIN)
    WRITEWITHNEWLINE(f, badsinarg_asmcode);
  if (need_ASIN)
    WRITEWITHNEWLINE(f, badasinarg_asmcode);
  if (need_COS)
    WRITEWITHNEWLINE(f, badcosarg_asmcode);
  if (need_ACOS)
    WRITEWITHNEWLINE(f, badacosarg_asmcode);
  if (need_SEC)
    WRITEWITHNEWLINE(f, badsecarg_asmcode);
  if (need_CSC)
    WRITEWITHNEWLINE(f, badcscarg_asmcode);
  if (need_COT)
    WRITEWITHNEWLINE(f, badcotarg_asmcode);
  if (need_MOD)
    WRITEWITHNEWLINE(f, badmodarg_asmcode);
  if (need_SQR)
    WRITEWITHNEWLINE(f, badsqrarg_asmcode);
  WRITEWITHNEWLINE(f, good_bad_xit_asmcode);
  if (need_INPUT)   // need to include support for INPUT statement
    fputs("        # drain .LSTDIN (discard any remaining data in buffer of STDIN)\n"
          "        movabsq $.Ldrain_stdin,%rax     # rax = &drain_stdin\n"
          "        callq   *%rax                   # call *rax\n", f);
  fputs("        movabsq $.Loldmxcsr,%rax   # restore original MXCSR\n"
        "        ldmxcsr (%rax)\n"
        "        movabsq $.Loldrsp, %rax    # restore stack pointer\n"
        "        movq    (%rax), %rsp\n"
        "        movl    $.L__NR_exit, %eax # call exit()\n"
        "        syscall                    # does not return\n"
        "        .size _start, .-_start\n", f);
  init_bss(f);
  WRITEWITHNEWLINE(f, exception_non_fatal_asmcode);
  WRITEWITHNEWLINE(f, havefeatures_asmcode);
  WRITEWITHNEWLINE(f, isterminal_asmcode);
  WRITEWITHNEWLINE(f, mystrlen_asmcode);
  WRITEWITHNEWLINE(f, myitoa_asmcode);
  // include support for runtime BASIC functions if it is needed
  if (need_INT)               // need to include support for INT() function
    WRITEWITHNEWLINE(f, floor_asmcode);
  if (need_RND)               // need to include support for RND() function
    WRITEWITHNEWLINE(f, isaac64_asmcode);
  if (need_SIN)               // need to include support for SIN() function
    WRITEWITHNEWLINE(f, xsin_u1_asmcode);
  if (need_SINH)              // need to include support for SINH() function
    WRITEWITHNEWLINE(f, xsinh_u1_asmcode);
  if (need_ASIN)              // need to include support for ASIN() function
    WRITEWITHNEWLINE(f, xasin_u1_asmcode);
  if (need_COS)               // need to include support for COS() function
    WRITEWITHNEWLINE(f, xcos_u1_asmcode);
  if (need_COSH)              // need to include support for COSH() function
    WRITEWITHNEWLINE(f, xcosh_u1_asmcode);
  if (need_ACOS)              // need to include support for ACOS() function
    WRITEWITHNEWLINE(f, xacos_u1_asmcode);
  if (need_TAN)               // need to include support for TAN() function
    WRITEWITHNEWLINE(f, xtan_u1_asmcode);
  if (need_TANH)              // need to include support for TANH() function
    WRITEWITHNEWLINE(f, xtanh_u1_asmcode);
  if (need_ATN)               // need to include support for ATN() function
    WRITEWITHNEWLINE(f, xatan_u1_asmcode);
  if (need_LOG)               // need to include support for LOG() function
    WRITEWITHNEWLINE(f, xlog_u1_asmcode);
  if (need_LOG10)             // need to include support for LOG10() function
    WRITEWITHNEWLINE(f, xlog10_u1_asmcode);
  if (need_LOG2)             // need to include support for LOG2() function
    WRITEWITHNEWLINE(f, xlog2_u1_asmcode);
  if (need_EXP)               // need to include support for EXP() function
    WRITEWITHNEWLINE(f, xexp_u1_asmcode);
  if (need_POWER)             // need to include support for POW() function
    WRITEWITHNEWLINE(f, xpow_u1_asmcode);
  if (need_ANGLE)             // need to include support for ANGLE() function
    WRITEWITHNEWLINE(f, xatan2_u1_asmcode);
  if (need_CEIL)              // need to include support for ceil() function
    WRITEWITHNEWLINE(f, ceil_asmcode);
  if (need_strcpy)            // need to include support for strcpy() function
    WRITEWITHNEWLINE(f, mystrcpy_asmcode);
  if (need_strcmp)            // need to include support for strcmp() function
    WRITEWITHNEWLINE(f, mystrcmp_asmcode);
  if (need_INPUT)             // need to include support for INPUT statement
    WRITEWITHNEWLINE(f, doinput_asmcode);
  WRITEWITHNEWLINE(f, buffer_asmcode);
  // only need this if we had a TAB() function call
  if (need_TAB)
    WRITEWITHNEWLINE(f, tab_asmcode);
  // only need this if we had a PRINT statement with numeric output
  if (need_PRINT_NUMERIC)
    WRITEWITHNEWLINE(f, appendfloat_asmcode);
  fputs("        # end PRINT ZONE code\n"
        "\n", f);
  WRITEWITHNEWLINE(f, memcpy_asmcode); // always need it, dgay_code() depends on it
  WRITEWITHNEWLINE(f, dmgay_asmcode);  // always need it, used to convert float<-->ASCIIZ
  return;
}

//
// Function to emit code to push a string literal value onto the dedicated string
// address stack.
//
void push_string_literal(
    FILE *f,                // File handle for assembly language output file
    const char *label,      // ASCIIZ string containing the label of the string literal
    const char *txt) {      // ASCIIZ string containing the actual literal value for
                            // including in the generated comments
  char *tstring = NULL;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!label || !label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "label");
  tstring = fixbackslashes(txt);
  fprintf(f, "        movabsq $%s, %%rdi    # %%rdi=pointer to '%s'\n",
          label, tstring);
  free(tstring); tstring = NULL;
  pushsaddr(f);
  return;
}

//
// Function to emit code to move a numeric value from memory to a register.
//
void load_nparm(
    FILE *f,                // File handle for assembly language output file
    const char *varname,    // pointer to buffer with ASCIIZ string containing the
                            // label for the source scalar numeric variable
    const char *fpregname) {// pointer to buffer with ASCIIZ string containing the
                            // destination register
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  do_floatmem_to_floatreg(f, varname, fpregname, varname[6], varname[7]);
  return;
}

//
// Function to emit code to push a string variable's address onto the dedicated string
// address stack.
//
void push_svar(
    FILE *f,                // File handle for assembly language output file
    const char *varname) {  // pointer to buffer with ASCIIZ string containing the
                            // label for the string variable
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  fprintf(f, "        # varname does not include the trailing $, it is a single letter\n"
             "        # byte0 is the same, but must have single quotes\n"
             "        movabsq $%c$, %%rdi\n"
             "        cmpb    $.LNAK, (%%rdi)\n"
             "        je      .LPUSHSVARM%" PRIu32 "_0\n"
             "        {disp8} jmp .LPUSHSVARM%" PRIu32 "_1\n"
             ".LPUSHSVARM%" PRIu32 "_0:\n"
             "        # flush any pending output\n"
             "        movabsq $.LOBUF, %%rdi\n"
             "        movabsq $.Lobuf_next, %%rsi\n"
             "        movabsq $.Lcurzone, %%rdx\n"
             "        movabsq $.Lflushoutputln, %%rax\n"
             "        callq   *%%rax\n"
             "        # referenced scalar was uninitialized\n"
             "        movabsq $.Luninitialized_msg, %%rcx\n"
             "        movabsq $.LEBUF, %%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next, %%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone, %%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer, %%rax\n"
             "        callq   *%%rax\n"
             "        # must create string in reverse order\n"
             "        xorl    %%edi, %%edi\n"
             "        movb    $'$', %%dil\n"
             "        shlq    $8, %%rdi\n"
             "        movb    $'%c', %%dil\n"
             "        shlq    $8, %%rdi\n"
             "        movb    $32, %%dil\n"
             "        subq    $16, %%rsp\n"
             "        movq    %%rdi, (%%rsp)\n"
             "        movq    %%rsp, %%rcx            # arg 4 input string address\n"
             "        movabsq $.LEBUF, %%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next, %%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone, %%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer, %%rax\n"
             "        callq   *%%rax\n"
             "        addq    $16, %%rsp\n"
             "        movabsq $.Lbadxit, %%rax\n"
             "        jmpq    *%%rax\n"
             ".LPUSHSVARM%" PRIu32 "_1:\n",
          varname[0], instance_number, instance_number, instance_number, varname[0], instance_number);
  pushsaddr(f);
  instance_number++;
  return;
}

//
// Function to emit code to load an array numeric variable's value into the the
// floating point register specified by the fpregname parameter.  This compiler
// generates code that stores arrays in row-major order.  The global base_is_one
// flag is used to adjust the bounds checking.  If base_is_one is true, the
// minimum index is one, otherwise the minimum index is zero.
//
void load_1D_navar(
    FILE *f,                  // File handle for assembly language output file
    const char *varname,      // pointer to buffer with ASCIIZ string containing the
                              // name of the array
    const uint32_t maxindex,  // the highest permitted value for the subscript
                              // which is used to implement array bounds checking
    const char *fpregname) {  // pointer to buffer with ASCIIZ string containing the
                              // name of a floating point register that contains the
                              // array index value on input, and contains the value
                              // loaded from the array on output
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  // one dimensional array reference
  // fpregname should have index expression as a floating point value
  fprintf(f, "        # if subscript gave a NaN, do not try to convert\n"
             "        movq    %s, %%rax                 # copy loaded float value to rax\n"
             "        movabsq $0x7FFFFFFF00000000, %%rdx\n"
             "        andq    %%rax, %%rdx\n"
             "        movabsq $.LPInf64, %%rsi\n"
             "        cmpq    %%rsi, %%rdx\n"
             "        jne     .LA1DTOF%" PRIu32 "_0\n"
             "        movabsq $.Lbogus_read_subscript_msg, %%rcx # arg 4 input string address\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        # NaN subscript\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $'%c',(%%rcx)    # and put array name there\n"
             "        movb    $0,1(%%rcx)\n"
             "        {disp8} jmp .LA1DTOF%" PRIu32 "_3\n"
             ".LA1DTOF%" PRIu32 "_0:\n"
             "        subq    $16,%%rsp\n"
             "        movq    $0,(%%rsp)\n"
             "        mov%s $.LFLOATHALF,%%r15%s\n"
             "        mov%s $.LFLOATNEGHALF,%%r8%s\n"
             "        comis%c  (%%rsp),%s\n"
             "        cmovb%c  %%r8%s,%%r15%s\n"
             "        mov%c    %%r15%s,(%%rsp)\n"
             "        movq    %s,-8(%%rsp)\n"
             "        adds%c   (%%rsp),%s\n"
             "        cvtts%c2si %s,%%r8\n"
             "        movq    -8(%%rsp),%s\n"
             "        addq    $16,%%rsp\n"
             "        # bounds check for vector array read\n"
             "        # r8 must be <= %" PRIu32 " and >= %u\n"
             "        # technique using just one compare is from \"Hacker's Delight, 2nd Ed.\", Henry S. Warren, Jr. p.67\n",
          fpregname, instance_number, varname[0], instance_number, instance_number, (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?'d':'s'), fpregname,
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"), (use_double?'q':'l'), (use_double?"":"d"),
          fpregname, (use_double?'d':'s'), fpregname, (use_double?'d':'s'), fpregname, fpregname, maxindex,
          (base_is_one?1U:0U));
  if (base_is_one)
    fputs("        decq    %r8\n", f);
  fprintf(f, "        cmpq    $%" PRIu32 "-%u,%%r8\n"
             "        jbe     .LA1DTOF%" PRIu32 "_1\n"
             "        movabsq $.Larray_OOB_read_msg, %%rcx\n"
             "        {disp8} jmp .LA1DTOF%" PRIu32 "_2\n"
             ".LA1DTOF%" PRIu32 "_1:\n"
             "        movabsq $%s,%%r15\n"
             "        movss   0(%%r15,%%r8,4),%s\n"
             "        movs%c   0(%%r15,%%r8,%" PRIu32 "),%s\n"
             "        comis%c  %s,%s\n"
             "        jnp     .LA1DTOF%" PRIu32 "_4\n"
             "        # referenced element of array %c was NaN, uninitialized\n"
             "        movabsq $.Luninitialized_element_msg, %%rcx # arg 4 input string address\n"
             ".LA1DTOF%" PRIu32 "_2:\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $'%c',(%%rcx)    # and put array name there\n"
             "        movb    $0,1(%%rcx)\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.Lsubscript_msg, %%rcx # arg 4 input string address\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n",
          maxindex, (base_is_one?1U:0U), instance_number, instance_number, instance_number, varname,
          fpregname, (use_double?'d':'s'), (use_double?8U:4U), fpregname, (use_double?'d':'s'),
          fpregname, fpregname, instance_number, varname[0], instance_number, varname[0]);
  if (base_is_one)
    fputs("        incq    %r8\n", f);
  fprintf(f, "        movq    %%r8,%%rdi\n"
             "        movabsq $.LOUTBUFFER, %%rsi   # buffer\n"
             "        movabsq $.Lmyitoa, %%rax\n"
             "        callq   *%%rax                # call itoa(i,b)\n"
             "        movabsq $.LOUTBUFFER, %%rcx   # buffer\n"
             ".LA1DTOF%" PRIu32 "_3:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                # DOES NOT RETURN\n"
             ".LA1DTOF%" PRIu32 "_4:\n",
          instance_number, instance_number);
  instance_number++;
  return;
}

//
// Function to emit code to copy a 2 dimensional array numeric variable's value
// into the floating point register specified by the row_fpregname parameter.
// This compiler generates code that stores arrays in row-major order.  The
// global base_is_one global flag is used to adjust the bounds checking.  If
// base_is_one is true, the minimum index is one, otherwise the minimum index
// is zero.
//
void load_2D_navar(
    FILE *f,                         // File handle for assembly language output file
    const char *varname,             // pointer to buffer with ASCIIZ string containing the
                                     // name of the array
    const uint32_t maxrows,          // the highest permitted value for the first subscript
                                     // which is used to implement array bounds checking
    const uint32_t maxcolumns,       // the highest permitted value for the second subscript
                                     // which is used to implement array bounds checking
    const char *row_fpregname,       // pointer to buffer with ASCIIZ string containing the
                                     // name of a floating point register that contains the
                                     // first array index value on input, and contains the
                                     // value loaded from the array on output
    const char *column_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                     // name of a floating point register that contains the
                                     // second array index value
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!row_fpregname || !row_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "row_fpregname");
  if (!column_fpregname || !column_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "column_fpregname");
  fprintf(f, "        # two dimensional array read\n"
             "        # if first subscript gave a NaN, do not try to convert\n"
             "        movq    %s, %%rax                 # copy loaded float value to rax\n"
             "        movabsq $0x7FFFFFFF00000000, %%rdx\n"
             "        andq    %%rax, %%rdx\n"
             "        movabsq $.LPInf64, %%rsi\n"
             "        cmpq    %%rsi, %%rdx\n"
             "        jne     .LA2DTOF%" PRIu32 "_0\n"
             "        movabsq $.Lbogus_read_first_subscript_msg,%%rcx # arg 4 input string address\n"
             "        {disp8} jmp .LA2DTOF%" PRIu32 "_1\n"
             ".LA2DTOF%" PRIu32 "_0:\n"
             "        # if second subscript gave a NaN, do not try to convert\n"
             "        movq    %s, %%rax                 # copy loaded float value to rax\n"
             "        movabsq $0x7FFFFFFF00000000, %%rdx\n"
             "        andq    %%rax, %%rdx\n"
             "        movabsq $.LPInf64, %%rsi\n"
             "        cmpq    %%rsi, %%rdx\n"
             "        jne     .LA2DTOF%" PRIu32 "_2\n"
             "        movabsq $.Lbogus_read_second_subscript_msg, %%rcx\n"
             ".LA2DTOF%" PRIu32 "_1:\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        # NaN subscript\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $'%c',(%%rcx)    # and put array name there\n"
             "        movb    $0,1(%%rcx)\n"
             "        {disp8} jmp .LA2DTOF%" PRIu32 "_6\n"
             ".LA2DTOF%" PRIu32 "_2:\n"
             "        subq    $16,%%rsp\n",
          row_fpregname, instance_number, instance_number, instance_number,
          column_fpregname, instance_number, instance_number,
          varname[0], instance_number, instance_number);
  if (use_double)
    fprintf(f, "        movq    $0,(%%rsp)\n"
               "        movabsq $.LFLOATHALF,%%r15\n"
               "        movabsq $.LFLOATNEGHALF,%%r8\n"
               "        comisd  (%%rsp),%s\n"
               "        cmovbq  %%r8,%%r15\n"
               "        movq    %%r15,(%%rsp)\n"
               "        movq    %s,-8(%%rsp)\n"
               "        addsd   (%%rsp),%s\n"
               "        cvttsd2si %s,%%r8\n"
               "        movq    -8(%%rsp),%s\n"
               "        movq    $0,(%%rsp)\n"
               "        movabsq $.LFLOATHALF,%%r15\n"
               "        movabsq $.LFLOATNEGHALF,%%r9\n"
               "        comisd  (%%rsp),%s\n"
               "        cmovbq  %%r9,%%r15\n"
               "        movq    %%r15,(%%rsp)\n"
               "        movq    %s,-8(%%rsp)\n"
               "        addsd   (%%rsp),%s\n"
               "        cvttsd2si %s,%%r9\n"
               "        movq    -8(%%rsp),%s\n",
             column_fpregname, column_fpregname, column_fpregname,
             column_fpregname, column_fpregname, row_fpregname,
             row_fpregname, row_fpregname, row_fpregname, row_fpregname);
  else
    fprintf(f, "        movq    $0,(%%rsp)\n"
               "        movl    $.LFLOATHALF,%%r15d\n"
               "        movl    $.LFLOATNEGHALF,%%r8d\n"
               "        comiss  (%%rsp),%s\n"
               "        cmovbl  %%r8d,%%r15d\n"
               "        movl    %%r15d,(%%rsp)\n"
               "        movq    %s,-8(%%rsp)\n"
               "        addss   (%%rsp),%s\n"
               "        cvttss2si %s,%%r8\n"
               "        movq    -8(%%rsp),%s\n"
               "        movq    $0,(%%rsp)\n"
               "        movl    $.LFLOATHALF,%%r15d\n"
               "        movl    $.LFLOATNEGHALF,%%r9d\n"
               "        comiss  (%%rsp),%s\n"
               "        cmovbl  %%r9d,%%r15d\n"
               "        movl    %%r15d,(%%rsp)\n"
               "        movq    %s,-8(%%rsp)\n"
               "        addss   (%%rsp),%s\n"
               "        cvttss2si %s,%%r9\n"
               "        movq    -8(%%rsp),%s\n",
             column_fpregname, column_fpregname, column_fpregname,
             column_fpregname, column_fpregname, row_fpregname,
             row_fpregname, row_fpregname, row_fpregname, row_fpregname);
  fprintf(f, "        addq    $16,%%rsp\n"
             "        pushq   %%r8\n"
             "        pushq   %%r9\n"
             "        # bounds check for matrix array read\n"
             "        # row r9 must be <= %" PRIu32 " and >= %u\n"
             "        # column r8 must be <= %" PRIu32 " and >= %u\n"
             "        # technique using just one compare is from \"Hacker's Delight, 2nd Ed.\", Henry S. Warren, Jr. p.67\n",
          maxrows, (base_is_one?1U:0U), maxcolumns, (base_is_one?1U:0U));
  if (base_is_one)
    fputs("        decq    %r9\n", f);
  fprintf(f, "        cmpq    $%" PRIu32 "-%u,%%r9 # if row index is out of bounds then goto 3\n"
             "        ja      .LA2DTOF%" PRIu32 "_3\n",
          maxrows, (base_is_one?1U:0U), instance_number);
  if (base_is_one)
    fputs("        decq    %r8\n", f);
  fprintf(f, "        cmpq    $%" PRIu32 "-%u,%%r8 # if column index is OK then goto 4\n"
             "        jbe     .LA2DTOF%" PRIu32 "_4\n"
             ".LA2DTOF%" PRIu32 "_3:\n"
             "        movabsq $.Larray_OOB_read_msg, %%rcx\n"
             "        {disp8} jmp .LA2DTOF%" PRIu32 "_5\n"
             ".LA2DTOF%" PRIu32 "_4:\n"
             "        movq    %%r9,%%rax\n"
             "        movabsq $%" PRIu32 "+1-%u,%%r15 # number of elements in one row\n"
             "        mulq    %%r15    # rdx:rax=rax*r15\n"
             "        addq    %%rax,%%r8\n"
             "        movabsq $%s,%%r15\n"
             "        movq    %s,%%r9\n"
             "        movsd   0(%%r15,%%r8,%" PRIu32 "),%s\n"
             "        comis%c  %s,%s\n"
             "        jnp     .LA2DTOF%" PRIu32 "_7\n"
             "        # referenced element of array A was NaN, uninitialized\n"
             "        movabsq $.Luninitialized_element_msg, %%rcx\n"
             ".LA2DTOF%" PRIu32 "_5:\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $'%c',(%%rcx)    # and put array name there\n"
             "        movb    $0,1(%%rcx)\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.Lsubscript2_msg,%%rcx # arg 4 input string address\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        popq    %%rdi\n"
             "        movabsq $.LOUTBUFFER, %%rsi   # buffer\n"
             "        movabsq $.Lmyitoa, %%rax\n"
             "        callq   *%%rax                # call itoa(i,b)\n"
             "        movabsq $.LOUTBUFFER, %%rcx   # buffer\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $.LCOMMA,(%%rcx)      # and put comma there\n"
             "        movb    $0,1(%%rcx)\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        popq    %%rdi\n"
             "        movabsq $.LOUTBUFFER, %%rsi   # buffer\n"
             "        movabsq $.Lmyitoa, %%rax\n"
             "        callq   *%%rax                # call itoa(i,b)\n"
             "        movabsq $.LOUTBUFFER, %%rcx   # buffer\n"
             ".LA2DTOF%" PRIu32 "_6:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                # DOES NOT RETURN\n"
             ".LA2DTOF%" PRIu32 "_7:\n"
             "        addq    $16,%%rsp\n",
          maxcolumns, (base_is_one?1U:0U), instance_number, instance_number, instance_number,
          instance_number, maxcolumns, (base_is_one?1U:0U), varname, row_fpregname, (use_double?8U:4U),
          row_fpregname, (use_double?'d':'s'), row_fpregname, row_fpregname, instance_number,
          instance_number, varname[0], instance_number, instance_number);
  instance_number++;
  return;
}

//
// This function is used to implement assignment to a scalar numeric variable.
//
void dostore_nvar(
    FILE *f,                // File handle for assembly language output file
    const char *varname,    // pointer to buffer with ASCIIZ string containing the
                            // destination numeric scalar variable name
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // name of the source floating pointer register
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=%s\n"
             "        movabsq $%s, %%r15\n"
             "        movs%c  %s, (%%r15)\n",
          varname, regname, varname, (use_double?'d':'s'), regname);
  return;
}

//
// This function is used to implement assignment to a scalar string variable.
// The address of the source string value to be stored must be on the top of
// the dedicated string address stack.  The strings are ASCIIZ strings, and
// mystrcpy() is called to actually copy the data.
//
void dostore_svar(
    FILE *f,                // File handle for assembly language output file
    const char *varname) {  // pointer to buffer with ASCIIZ string containing the
                            // label for the source string variable
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  popsaddr(f, "%rsi");
  fprintf(f, "        movq    %%rsi, %%rdi\n"
             "        movabsq $.Lmystrlen, %%rax\n"
             "        callq   *%%rax\n"
             "        cmpq    $.LMAX_STRING_BYTES, %%rax\n"
             "        jbe     0f\n"
             "        movabsq $.Lstring_too_long_msg, %%rcx\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             "0:\n"
             "        movabsq $%s, %%rdi\n"
             "        movabsq $.Lmystrcpy, %%rax\n"
             "        callq   *%%rax\n",
          varname);
  return;
}

//
// This function is used to implement assignment to a numeric one-dimensional
// array variable.  The base_is_one flag is used to adjust the bounds checking.
// If base_is_one is true, the minimum index is one, otherwise the minimum
// index is zero.
//
void dostore_1D_navar(
    FILE *f,                     // File handle for assembly language output file
    const char *varname,         // pointer to buffer with ASCIIZ string containing the
                                 // name of the array
    const uint32_t maxindex,     // the highest permitted index value for the subscript
                                 // which is used to implement array bounds checking
    const char *index_fpregname, // pointer to buffer with ASCIIZ string containing the
                                 // name of the floating point register containing the
                                 // array index value
    const char *fpregname) {     // pointer to buffer with ASCIIZ string containing the
                                 // name of the floating point register containing the
                                 // value to be stored in the array
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!index_fpregname || !index_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "index_fpregname");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        # if subscript gave a NaN, do not try to convert\n"
             "        movq    %s, %%rax                 # copy loaded float value to rax\n"
             "        movabsq $0x7FFFFFFF00000000, %%rdx\n"
             "        andq    %%rax, %%rdx\n"
             "        movabsq $.LPInf64, %%rsi\n"
             "        cmpq    %%rsi, %%rdx\n"
             "        jne     .LFRTOA1DM%" PRIu32 "_0\n"
             "        movabsq $.Lbogus_write_subscript_msg, %%rcx # arg 4 input string address\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        # NaN subscript\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $'%c',(%%rcx)    # and put array name there\n"
             "        movb    $0,1(%%rcx)\n"
             "        {disp8} jmp .LFRTOA1DM%" PRIu32 "_1\n"
             ".LFRTOA1DM%" PRIu32 "_0:\n"
             "        subq    $16,%%rsp\n"
             "        movq    $0,(%%rsp)\n"
             "        mov%s $.LFLOATHALF,%%r15%s\n"
             "        mov%s $.LFLOATNEGHALF,%%r8%s\n"
             "        comis%c  (%%rsp),%s\n"
             "        cmovb%c  %%r8%s,%%r15%s\n"
             "        mov%c    %%r15%s,(%%rsp)\n"
             "        movq    %s,-8(%%rsp)\n"
             "        adds%c   (%%rsp),%s\n"
             "        cvtts%c2si %s,%%r8\n"
             "        movq    -8(%%rsp),%s\n"
             "        addq    $16,%%rsp\n"
             "        # bounds check for vector array write\n"
             "        # r8 must be <= %" PRIu32 " and >= %u\n"
             "        # technique using just one compare is from \"Hacker's Delight, 2nd Ed.\", Henry S. Warren, Jr. p.67\n",
          index_fpregname, instance_number, varname[0], instance_number, instance_number, (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?'d':'s'), index_fpregname,
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"), (use_double?'q':'l'), (use_double?"":"d"),
          index_fpregname, (use_double?'d':'s'), index_fpregname, (use_double?'d':'s'), index_fpregname, index_fpregname,
          maxindex, (base_is_one?1U:0U));
  if (base_is_one)
    fputs("        decq    %r8\n", f);
  fprintf(f, "        cmpq    $%" PRIu32 "-%u,%%r8\n"
             "        jbe     .LFRTOA1DM%" PRIu32 "_2\n"
             "        movabsq $.Larray_OOB_write_msg, %%rcx # arg 4 input string address\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $'%c',(%%rcx)    # and put array name there\n"
             "        movb    $0,1(%%rcx)\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.Lsubscript_msg, %%rcx # arg 4 input string address\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n",
          maxindex, (base_is_one?1U:0U), instance_number, varname[0]);
  if (base_is_one)
    fputs("        incq    %r8\n", f);
  fprintf(f, "        movq    %%r8,%%rdi\n"
             "        movabsq $.LOUTBUFFER, %%rsi   # buffer\n"
             "        movabsq $.Lmyitoa, %%rax\n"
             "        callq   *%%rax                # call itoa(i,b)\n"
             "        movabsq $.LOUTBUFFER, %%rcx   # buffer\n"
             ".LFRTOA1DM%" PRIu32 "_1:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                # DOES NOT RETURN\n"
             ".LFRTOA1DM%" PRIu32 "_2:\n"
             "        movabsq $%s,%%r15\n"
             "        movs%c   %s,0(%%r15,%%r8,%" PRIu32 ")\n",
          instance_number, instance_number, varname, (use_double?'d':'s'), fpregname,
          (use_double?8U:4U));
  instance_number++;
  return;
}

//
// This function is used copy a value in a floating point register to a numeric
// two-dimensional array variable.  The base_is_one flag is used to adjust the
// bounds checking.  If base_is_one is true, the minimum index is one, otherwise
// the minimum index is zero.
//
void dostore_2D_navar(
    FILE *f,                        // File handle for assembly language output file
    const char *varname,            // pointer to buffer with ASCIIZ string containing the
                                    // name of the array
    const uint32_t maxrows,         // the highest permitted value for the first subscript
                                    // which is used to implement array bounds checking
    const uint32_t maxcolumns,      // the highest permitted value for the second subscript
                                    // which is used to implement array bounds checking
    const char *row_fpregname,      // pointer to buffer with ASCIIZ string containing the
                                    // name of a floating point register that contains the
                                    // first array index value
    const char *column_fpregname,   // pointer to buffer with ASCIIZ string containing the
                                    // name of a floating point register that contains the
                                    // second array index value
    const char *destreg) {          // pointer to buffer with ASCIIZ string containing the
                                    // name of a floating point register that contains the
                                    // expression to store in the array
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!row_fpregname || !row_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "row_fpregname");
  if (!column_fpregname || !column_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "column_fpregname");
  if (!destreg || !destreg[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "destreg");
  fprintf(f, "        # if first subscript gave a NaN, do not try to convert\n"
             "        movq    %s, %%rax                 # copy loaded float value to rax\n"
             "        movabsq $0x7FFFFFFF00000000, %%rdx\n"
             "        andq    %%rax, %%rdx\n"
             "        movabsq $.LPInf64, %%rsi\n"
             "        cmpq    %%rsi, %%rdx\n"
             "        jne     .LFRTOA2DM%" PRIu32 "_0\n"
             "        movabsq $.Lbogus_write_first_subscript_msg, %%rcx\n"
             "        {disp8} jmp .LFRTOA2DM%" PRIu32 "_1\n"
             ".LFRTOA2DM%" PRIu32 "_0:\n"
             "        # if second subscript gave a NaN, do not try to convert\n"
             "        movq    %s, %%rax                 # copy loaded float value to rax\n"
             "        movabsq $0x7FFFFFFF00000000, %%rdx\n"
             "        andq    %%rax, %%rdx\n"
             "        movabsq $.LPInf64, %%rsi\n"
             "        cmpq    %%rsi, %%rdx\n"
             "        jne     .LFRTOA2DM%" PRIu32 "_2\n"
             "        movabsq $.Lbogus_write_second_subscript_msg, %%rcx\n"
             ".LFRTOA2DM%" PRIu32 "_1:\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        # NaN subscript\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $'%c',(%%rcx)    # and put array name there\n"
             "        movb    $0,1(%%rcx)\n"
             "        {disp8} jmp .LFRTOA2DM%" PRIu32 "_4\n"
             ".LFRTOA2DM%" PRIu32 "_2:\n"
             "        subq    $16,%%rsp\n"
             "        movq    $0,(%%rsp)\n",
          row_fpregname, instance_number, instance_number, instance_number, column_fpregname,
          instance_number, instance_number, varname[0], instance_number, instance_number);
  if (use_double)
    fprintf(f, "        movabsq $.LFLOATHALF,%%r15\n"
               "        movabsq $.LFLOATNEGHALF,%%r8\n"
               "        comisd  (%%rsp),%s\n"
               "        cmovbq  %%r8,%%r15\n"
               "        movq    %%r15,(%%rsp)\n"
               "        movq    %s,-8(%%rsp)\n"
               "        addsd   (%%rsp),%s\n"
               "        cvttsd2si %s,%%r8\n"
               "        movq    -8(%%rsp),%s\n"
               "        movq    $0,(%%rsp)\n"
               "        movabsq $.LFLOATHALF,%%r15\n"
               "        movabsq $.LFLOATNEGHALF,%%r9\n"
               "        comisd  (%%rsp),%s\n"
               "        cmovbq  %%r9,%%r15\n"
               "        movq    %%r15,(%%rsp)\n"
               "        movq    %s,-8(%%rsp)\n"
               "        addsd   (%%rsp),%s\n"
               "        cvttsd2si %s,%%r9\n"
               "        movq    -8(%%rsp),%s\n",
            column_fpregname, column_fpregname, column_fpregname, column_fpregname, column_fpregname,
            row_fpregname, row_fpregname, row_fpregname, row_fpregname, row_fpregname);
  else
    fprintf(f, "        movl    $.LFLOATHALF,%%r15d\n"
               "        movl    $.LFLOATNEGHALF,%%r8d\n"
               "        comiss  (%%rsp),%s\n"
               "        cmovbl  %%r8d,%%r15d\n"
               "        movl    %%r15d,(%%rsp)\n"
               "        movq    %s,-8(%%rsp)\n"
               "        addss   (%%rsp),%s\n"
               "        cvttss2si %s,%%r8\n"
               "        movq    -8(%%rsp),%s\n"
               "        movq    $0,(%%rsp)\n"
               "        movl    $.LFLOATHALF,%%r15d\n"
               "        movl    $.LFLOATNEGHALF,%%r9d\n"
               "        comiss  (%%rsp),%s\n"
               "        cmovbl  %%r9d,%%r15d\n"
               "        movl    %%r15d,(%%rsp)\n"
               "        movq    %s,-8(%%rsp)\n"
               "        addss   (%%rsp),%s\n"
               "        cvttss2si %s,%%r9\n"
               "        movq    -8(%%rsp),%s\n",
            column_fpregname, column_fpregname, column_fpregname, column_fpregname, column_fpregname,
            row_fpregname, row_fpregname, row_fpregname, row_fpregname, row_fpregname);
  fprintf(f, "        addq    $16,%%rsp\n"
             "        pushq   %%r8\n"
             "        pushq   %%r9\n"
             "        # bounds check for matrix array write\n"
             "        # r9 must be <= %" PRIu32 " and >= %u\n"
             "        # r8 must be <= %" PRIu32 " and >= %u\n"
             "        # bounds check for vector array write\n"
             "        # technique using just one compare is from \"Hacker's Delight, 2nd Ed.\", Henry S. Warren, Jr. p.67\n",
          maxrows, (base_is_one?1U:0U), maxcolumns, (base_is_one?1U:0U));
  if (base_is_one)
    fputs("        decq    %r9\n", f);
  fprintf(f, "        cmpq    $%" PRIu32 "-%u,%%r9\n"
             "        ja      .LFRTOA2DM%" PRIu32 "_3\n",
          maxrows, (base_is_one?1U:0U), instance_number);
  if (base_is_one)
    fputs("        decq    %r8\n", f);
  fprintf(f, "        cmpq    $%" PRIu32 "-%u,%%r8\n"
             "        jbe     .LFRTOA2DM%" PRIu32 "_5\n"
             ".LFRTOA2DM%" PRIu32 "_3:\n"
             "        popq    %%r9\n"
             "        popq    %%r8\n"
             "        movabsq $.Larray_OOB_write_msg, %%rcx\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $'%c',(%%rcx)    # and put array name there\n"
             "        movb    $0,1(%%rcx)\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.Lsubscript2_msg,%%rcx # arg 4 input string address\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movq    %%r9,%%rdi\n"
             "        movabsq $.LOUTBUFFER, %%rsi   # buffer\n"
             "        movabsq $.Lmyitoa, %%rax\n"
             "        callq   *%%rax                # call itoa(i,b)\n"
             "        movabsq $.LOUTBUFFER, %%rcx   # buffer\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.LOUTBUFFER,%%rcx\n"
             "        movb    $.LCOMMA,(%%rcx)      # and put comma there\n"
             "        movb    $0,1(%%rcx)\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer,%%rax\n"
             "        callq   *%%rax\n"
             "        movq    %%r8,%%rdi\n"
             "        movabsq $.LOUTBUFFER, %%rsi   # buffer\n"
             "        movabsq $.Lmyitoa, %%rax\n"
             "        callq   *%%rax                # call itoa(i,b)\n"
             "        movabsq $.LOUTBUFFER, %%rcx   # buffer\n"
             ".LFRTOA2DM%" PRIu32 "_4:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                # DOES NOT RETURN\n"
             ".LFRTOA2DM%" PRIu32 "_5:\n"
             "        addq    $16,%%rsp\n"
             "        # we must use %%rax since mul is hard-wired to use %%rdx:%%rax\n"
             "        movq    %%r9,%%rax\n"
             "        movabsq $%" PRIu32 "+1-%u,%%r15\n"
             "        mulq    %%r15   # rdx:rax=rax*%%r15\n"
             "        addq    %%rax,%%r8\n"
             "        movabsq $%s,%%r15\n"
             "        movs%c   %s,0(%%r15,%%r8,%" PRIu32 ")\n",
          maxcolumns, (base_is_one?1U:0U), instance_number, instance_number, varname[0],
          instance_number, instance_number, maxcolumns, (base_is_one?1U:0U), varname,
          (use_double?'d':'s'), destreg, (use_double?8U:4U));
  instance_number++;
  return;
}

//
// This function is called at the start of the sequence for generating code for
// each Minimal BASIC source input line.  The lineno parameter specifies the
// Minimal BASIC line number that code will be emitted for after the call to
// this function.  This function will generate a label from the lineno
// parameter (.LLINE####) and also copy the Minimal BASIC line number to the
// magic internal .LCURLINENO variable which is used for displaying errors and
// exceptions.
//
void doloc(
    FILE *f,                  // File handle for assembly language output file
    const uint32_t lineno) {  // the Minimal BASIC line number
  char *buffer = NULL;        // .LLINEXXXX and a terminator
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (lineno>MAXLINENO)  // ECMA-55 MinimalBASIC rule
    ICE(__FILE__, __func__, __LINE__, emsg[89], __func__, lineno, MAXLINENO);
  // if (lineno > 4294967295U) you would need to do this:
  //  fprintf(f, "        movabsq $%" PRIu32 ", %%rbx\n"
  //             "        movq    %%rbx, (%%rax)\n", lineno);
  buffer = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_LABELWIDTH+1U));
  snprintf(buffer, MAX_LABELWIDTH+1, ".LLINE%0*" PRIu32, MAX_LINENO_DIGITS, lineno);
  buffer[MAX_LABELWIDTH]=0; // ensure buffer is terminated
  emit_label(f, buffer);
  free(buffer); buffer = NULL;
  fprintf(f, "        movabsq $.LCURLINENO, %%rax\n"
             "        movq    $%" PRIu32 ", (%%rax)\n", lineno);
  return;
}

//
// This function will emit code to append the floating point value stored in
// xmm0 to the output buffer.  It is used as part of the implementation of the
// PRINT statement.  Trashes rax.
//
void doprint_number(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        # append floating point value in xmm0 to output buffer\n"
        "                                     # arg 1 (xmm0) contains float to print\n"
        "        movabsq $.LOBUF,%rdi         # arg 2 output buffer variable address\n"
        "        movabsq $.Lobuf_next,%rsi    # arg 3 output bufpos variable address\n"
        "        movabsq $.Lcurzone,%rdx      # arg 4 output zonepos variable address\n"
        "        movabsq $.Lappendfloat, %rax\n"
        "        callq   *%rax\n", f);
  return;
}

//
// This function will emit code to append a string value to the output buffer.
// It is used as part of the implementation of the PRINT statement.  The address
// of the string to append must be pushed on the stack immediately before the
// call of pushsaddr.
//
void doprint_string(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        # append string pointed to by rdi to output buffer\n"
        "        movabsq $.LOBUF,%rdi         # arg 1 output buffer variable address\n"
        "        movabsq $.Lobuf_next,%rsi    # arg 2 output bufpos variable address\n"
        "        movabsq $.Lcurzone,%rdx      # arg 3 output zonepos variable address\n"
        "                                     # arg 4 input string address is in rcx\n", f);
  popsaddr(f, "%rcx");
  fputs("        movabsq $.Lappendbuffer, %rax\n"
        "        callq   *%rax\n", f);
  return;
}

//
// This function will emit code to output the current output buffer to STDOUT.
// It is used as part of the implementation of the PRINT statement.
//
void doprint_newline(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        # emit current output buffer contents and newline, or bare newline if\n"
        "        # buffer is empty\n"
        "        movabsq $.LOBUF,%rdi         # arg 1 output buffer variable address\n"
        "        movabsq $.Lobuf_next,%rsi    # arg 2 output bufpos variable address\n"
        "        movabsq $.Lcurzone,%rdx      # arg 3 output zonepos variable address\n"
        "        movabsq $.Loutputbuffer, %rax\n"
        "        callq   *%rax\n", f);
  return;
}

//
// This function will emit code to advance the next print zone of the current
// output buffer.  It is used as part of the implementation of the PRINT
// statement to support the comma (,) behavior.
//
void doprint_nextfield(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        # advance to the next print zone of the current output buffer.\n"
        "        movabsq $.LOBUF,%rdi         # arg 1 output buffer variable address\n"
        "        movabsq $.Lobuf_next,%rsi    # arg 2 output bufpos variable address\n"
        "        movabsq $.Lcurzone,%rdx      # arg 3 output zonepos variable address\n"
        "        movabsq $.Lnextzone, %rax\n"
        "        callq   *%rax\n", f);
  return;
}

//
// This function will emit code to implement a call to the LEN() function.  The
// register to hold the return value of the function is passed in as regname.
//
void do_len(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for output value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fputs("        pushq   %rax\n"
        "        pushq   %rcx\n"
        "        pushq   %rdi\n", f);
  popsaddr(f, "%rdi");
  fprintf(f, "        xorl    %%ecx, %%ecx      # set rcx to maximum value\n"
             "        notq    %%rcx            # of 0xFFFFFFFFFFFFFFFF, the maximum number of\n"
             "                                # repetitions in repne loop\n"
             "        xorb    %%al, %%al        # set al to 0, the string terminator\n"
             "        cld                     # use a forward scan\n"
             "repne   scasb                   # scan from rdi until character is 0 or rcx reaches zero\n"
             "                                # (rcx is decremented for each character processed)\n"
             "        notq    %%rcx            # flip bits and subtract 1 to get\n"
             "        leaq    -1(%%rcx), %%rax  # string length and store it in rax\n"
             "        cvtsi2s%cq %%rax, %s\n"
             "        popq    %%rdi\n"
             "        popq    %%rcx\n"
             "        popq    %%rax\n",
          (use_double?'d':'s'), regname);
  return;
}

//
// This function will emit code to implement the ABS() function.  The
// register containing the value to take the absolute value of is passed in the
// argument regname.  The return value of the function will be left in that
// same register.
//
void do_abs(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=abs(%s)\n"
             "        movq    %s, %%rax\n"
             "        pushf                    # save flags\n"
             "        btr%c    $%" PRIu32 ",%%%cax         # set bit %" PRIu32 " (sign bit) to zero\n"
             "        popf                     # and restore flags so cf is not modified\n"
             "        movq    %%rax, %s\n",
          regname, regname, regname, (use_double?'q':'l'), (use_double?63U:31U),
          (use_double?'r':'e'), (use_double?63U:31U), regname);
  return;
}

//
// This function will emit code to do the SGN() function as inline code.  The
// register containing the value to take the SGN of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_sgn(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=sgn(%s)\n"
             "        movq    %s, %%rax\n"
             "        test%c   %%%cax,%%%cax\n"
             "jz      0f\n"
             "        mov%s $.LFLOATONE,%%%ccx\n"
             "        mov%c    $.LFLOATNEGONE,%%%cdx\n"
             "        bt%c     $%" PRIu32 ",%%%cax\n"
             "        cmovc%c  %%%cdx,%%%ccx\n"
             "        movq    %%rcx, %s\n"
             "0:\n",
          regname, regname, regname, (use_double?'q':'l'), (use_double?'r':'e'), (use_double?'r':'e'),
          (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'q':'l'), (use_double?'r':'e'),
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?'r':'e'), (use_double?'q':'l'),
          (use_double?'r':'e'), (use_double?'r':'e'), regname);
  return;
}

//
// This function will emit code to implement a call of the SQR() function by
// directly calling the square root instruction on the processor.  The register
// containing the value to take the square root of is passed in the argument
// fpregname.  The return value is left in that same register.
//
void do_sqr(
    FILE *f,                // File handle for assembly language output file
    const char *fpregname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        # %s = SQR(%s)\n"
             "        movq    %s,%%rax   # rax = %s\n"
             "        bt%c     $%u,%%%cax             # cf = sign of %s\n"
             "        jc      .LSQR%" PRIu32 "_0         # if %s < 0 then goto 0\n"
             "        mov%s $.LPInf,%%%cbx         # %cbx = +INF (%s)\n"
             "        cmp%c    %%%cax,%%%cbx            # if %cax != %cbx\n"
             "        jne     .LSQR%" PRIu32 "_1         # then goto 1\n"
             ".LSQR%" PRIu32 "_0:\n"
             "        # appendfloat needs the floating point value in xmm0\n"
             "        movs%c     %s, %%xmm0\n"
             "        movabsq $.Lbadsqrarg, %%rax # and then goto badsqrarg\n"
             "        jmpq    *%%rax              # DOES NOT RETURN\n"
             ".LSQR%" PRIu32 "_1:\n"
             "        sqrts%c  %s,%s   # %s = sqrt(%s)\n",
          fpregname, fpregname, fpregname, fpregname, (use_double?'q':'l'), (use_double?63:31),
          (use_double?'r':'e'), fpregname, instance_number, fpregname, (use_double?"absq":"l   "),
          (use_double?'r':'e'), (use_double?'r':'e'), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?'r':'e'), (use_double?'r':'e'), (use_double?'r':'e'),
          (use_double?'r':'e'), instance_number, instance_number, (use_double?'d':'s'), fpregname,
          instance_number, (use_double?'d':'s'), fpregname, fpregname, fpregname, fpregname);
  instance_number++;
  return;
}

//
// This function will emit code to implement a call of the INT() function.
// INT(X) returns the largest integral value not greater than X.  The register
// containing the value to convert is passed in the argument regname.
// Note the type of result is still a floating point value, and regname holds
// a 32 bit float or 64 bit float depending on the global use_double flag.
//
void do_int(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=INT(%s)\n", regname, regname);
  if (strcmp(regname,"%xmm0")!=0)            // if argument is not in xmm0 then
    fprintf(f, "        movq    %%xmm0, %%rax    # save current value of xmm0\n"
               "        pushq   %%rax            # on the stack and set\n"
               "        movapd  %s, %%xmm0        # xmm0=%s\n",
            regname, regname);
  fputs("        movabsq $.Lfloor, %rax   # %xmm0=floor(%xmm0)\n"
        "        callq   *%rax\n", f);
  if (strcmp(regname,"%xmm0")!=0) {          // if argument is not in xmm0 then
    fprintf(f, "        movapd  %%xmm0, %s       # %s=xmm0\n"
               "        popq    %%rax            # and restore old value of xmm0\n"
               "        movq    %%rax,%%xmm0     # from the stack\n",
            regname, regname);
  }
  return;
}

//
// This function will emit code to implement a call of the RND function.
//
void do_rnd(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used to hold the generated RND value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fputs("        movabsq $.Ldrand, %rax\n"
        "        callq   *%rax\n", f);
  if (!use_double)
    fputs("        cvtsd2ss %xmm0, %xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movap%c  %%xmm0, %s\n",
            (use_double?'d':'s'), regname);
  return;
}

//
// This function will emit code to implement a call of the PI function.
//
void do_pi(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used to hold the generated PI value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        pushq %%rax\n"
             "        mov%s $.LPI, %%%cax          # %cax = pi (%s)\n"
             "        movq %%rax, %s     # %s = rax\n"
             "        popq %%rax\n",
          (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'r':'e'),
          (use_double?"double":"float"), regname, regname);
  return;
}

//
// This function will emit code to implement a call of the MAXNUM function.
//
void do_maxnum(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used to hold the generated MAXNUM value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        pushq %%rax\n"
             "        mov%s $.LMAXNORMAL, %%%cax   # %cax = MAXNORMAL\n"
             "        movq %%rax, %s     # %s = rax\n"
             "        popq %%rax\n",
          (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'r':'e'),
          regname, regname);
  return;
}

//
// This function will emit code to implement a call of the DATE numeric function.
//
void do_date(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used to hold the generated DATE value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # compute %s=DATE\n", regname);
  if (strcmp(regname, "%xmm0")!=0)
    fputs("        movq    %xmm0, %rax          # save a copy of xmm0 on the\n"
          "        pushq   %rax                 # stack and\n"
          "        subq    $8, %rsp             # add 8 bytes padding so we are on a\n"
          "                                     # 16 byte stack boundary to call a subroutine\n", f);
  fputs("        movabsq $.Lfb_date_n, %rax\n"
        "        callq *%rax\n", f);
  if (strcmp(regname, "%xmm0")!=0) {
    fprintf(f, "        movq   %%xmm0, %-6s         # put answer in %s\n"
               "        addq   $8, %%rsp              # and\n"
               "        popq   %%rax                  # restore\n"
               "        movq   %%rax,%%xmm0            # xmm0\n",
            regname, regname);
  }
  if (!use_double)
    fprintf(f, "        cvtsd2ss %-6s, %-6s\n", regname, regname);
  return;
}

//
// This imlements the ECMA-116 TIME built-in math function
// which returns number of seconds since last midnight in %xmm0.
// For example, 54530 for 5:08:50.
//
void do_time(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used to hold the generated TIME value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s = TIME\n", regname);
  if (strcmp(regname, "%xmm0") != 0) {
    fputs("        movq    %xmm0,%rax  # save a copy of xmm0 on the\n"
          "        pushq   %rax        # stack and\n"
          "        subq    $8, %rsp    # add 8 bytes of padding so we are on a\n"
          "                            # 16 byte stack boundary to call a subroutine\n", f);
  }
  fputs("        movabsq $.Lfb_time_n, %rax\n"
        "        callq *%rax\n", f);
  if (strcmp(regname, "%xmm0") != 0)
     fprintf(f, "        movq %%xmm0, %s      # put answer in %s\n"
                "        addq   $8, %%rsp                # and\n"
                "        popq   %%rax                    # restore\n"
                "        movq   %%rax,%%xmm0              # xmm0\n", regname, regname);
  if (use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  return;
}

//
// This function will emit code to implement a call of the DATE$ string function.
//
void do_dates(
    FILE *f) {              // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        pushq   %rax\n"
        "        pushq   %rdi\n"
        "        movl    $0, %edi\n"
        "        movabsq $.Llinux_time, %rax\n"
        "        call    *%rax\n"
        "        movabsq $.Lts, %rdi\n"
        "        movabsq $.Llocaltime, %rax\n"
        "        call    *%rax\n"
        "        movabsq $.Ltm, %rdi\n"
        "        movabsq $.Lfb_date_s, %rax\n"
        "        callq   *%rax\n"
        "        movq    %rax, %rdi\n", f);
  pushsaddr(f);
  fputs("        popq    %rdi\n"
        "        popq    %rax\n", f);
  return;
}

//
// This function will emit code to implement a call of the TIME$ string function.
//
void do_times(
    FILE *f) {              // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        pushq   %rax\n"
        "        pushq   %rdi\n"
        "        movl    $0, %edi\n"
        "        movabsq $.Llinux_time, %rax\n"
        "        call    *%rax\n"
        "        movabsq $.Lts, %rdi\n"
        "        movabsq $.Llocaltime, %rax\n"
        "        call    *%rax\n"
        "        movabsq $.Ltm, %rdi\n"
        "        movabsq $.Lfb_time_s, %rax\n"
        "        callq   *%rax\n"
        "        movq    %rax, %rdi\n", f);
  pushsaddr(f);
  fputs("        popq    %rdi\n"
        "        popq    %rax\n" ,f);
  return;
}

//
// This function will emit code to implement a call of the DEG() function.
//
void do_deg(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used to hold the input/output value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        pushq %%rax                   # save rax\n"
             "        movq %s, %%rax\n"
             "        pushq %%rax                   # push fpregname (angle in raidans)\n"
             "        mov%s $.L180OVERPI, %%%cax   # %cax = 180/pi (%s)\n"
             "        mov%c %%%cax, %s     # %s = 180/pi\n"
             "        muls%c (%%rsp), %s  # %s *= 180/pi\n"
             "                                     # fpregname = angle in degrees\n"
             "        popq %%rax                    # pop stack and throw it away\n"
             "        popq %%rax                    # restore rax\n",
          regname, (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'r':'e'),
          (use_double?"double":"float"), (use_double?'q':'d'), (use_double?'r':'e'), regname,
          regname, (use_double?'d':'s'), regname, regname);
  return;
}

//
// This function will emit code to implement a call of the RAD() function.
//
void do_rad(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used to hold the input/output value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        pushq %%rax                   # save rax\n"
             "        movq %s, %%rax\n"
             "        pushq %%rax                   # push fpregname (angle in degrees)\n"
             "        mov%s $.LPIOVER180, %%%cax   # %cax = pi/180 (%s)\n"
             "        mov%c %%%cax, %s     # %s = pi/180\n"
             "        muls%c (%%rsp), %s   # %s *= 180/pi\n"
             "                                     # fpregname = angle in radians\n"
             "        popq %%rax                    # pop stack and throw it away\n"
             "        popq %%rax                    # restore rax\n",
          regname, (use_double?"absq":"l   "), (use_double?'r':'e'),  (use_double?'r':'e'),
          (use_double?"double":"float"), (use_double?'q':'d'), (use_double?'r':'e'), regname,
          regname, (use_double?'d':'s'), regname, regname);
  return;
}

//
// This function will emit code to implement a call of the MAX() function.
//
void do_max(
    FILE *f,                      // File handle for assembly language output file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting difference on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side subtrahend expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s = max(%s,%s)\n"
             "        maxs%c %s, %s\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname, (use_double?'d':'s'), rhs_fpregname,
          lhs_fpregname);
  return;
}

//
// This function will emit code to implement a call of the MIN() function.
//
void do_min(
    FILE *f,                      // File handle for assembly language output file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting difference on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side subtrahend expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f,
          "        # %s = min(%s,%s)\n"
          "        mins%c %s, %s\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname, (use_double?'d':'s'), rhs_fpregname,
          lhs_fpregname);
  return;
}

//
// This imlements the ECMA-116 MOD(x,y) built-in math function.
// Input is two values x and y, y!=0
// Output is x-y*INT(x/y)
//
void do_mod(
    FILE *f,                      // File handle for assembly language output file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting difference on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side subtrahend expression value
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s = MOD(%s, %s)\n"
             "        pushq %%rax\n"
             "        movq %s,%%rax\n"
             "        pushq %%rax\n"
             "        movq %s,%%rax\n"
             "        test%c   %%%cax,%%%cax            # if %s value is not zero\n"
             "        jnz     .LMODM%" PRIu32 "_0         # then go and evaluate the formula\n"
             "        addq    $16, %%rsp            # reset stack pointer back to\n"
             "                                     # what it was before\n"
             "        movabsq $.Lbadmodarg,%%rax    # goto badmodarg\n"
             "        jmpq    *%%rax                # DOES NOT RETURN\n"
             ".LMODM%" PRIu32 "_0:\n"
             "                            # %s /= %s\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname, lhs_fpregname, rhs_fpregname,
          (use_double?'q':'l'), (use_double?'r':'e'), (use_double?'r':'e'),
          (use_double?"double":"float"), instance_number, instance_number, lhs_fpregname,
          rhs_fpregname);
  binary_divide(f, lhs_fpregname, rhs_fpregname);
  if (strcmp(lhs_fpregname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax                 # save current value of xmm0\n"
               "        pushq   %%rax                       # on the stack and set\n"
               "        movapd  %s, %%xmm0    # xmm0=%s\n",
            lhs_fpregname, lhs_fpregname);
  fputs("        movabsq $.Lfloor,%rax\n"
        "        callq %rax                         # x = INT(x), i.e. INT(x/y)\n", f);
  if (strcmp(lhs_fpregname, "%xmm0")!=0)
    fprintf(f, "        movapd  %%xmm0, %s    # %s=xmm0\n"
               "        popq    %%rax                       # and restore old value of xmm0\n"
               "        movq    %%rax,%%xmm0                 # from the stack\n",
            lhs_fpregname, lhs_fpregname);
  fputs("        # y = y*IP(x/y)\n", f);
  binary_multiply(f, rhs_fpregname, lhs_fpregname);
  fprintf(f, "        popq %%rax\n"
             "        movq %%rax,%s\n",
          lhs_fpregname);
  binary_subtract(f, lhs_fpregname, rhs_fpregname);
  fputs("        popq %rax\n", f);
  instance_number++;
  return;
}

//
// This imlements the ECMA-116 REMAINDER(x,y) built-in math function.
// Input is two values x and y, y!=0
// Output is x-y*IP(x/y)
//
void do_remainder(
    FILE *f,                      // File handle for assembly language output file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting difference on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side subtrahend expression value
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s = REMAINDER(%s, %s)\n"
             "        pushq %%rax\n"
             "        movq %s,%%rax\n"
             "        pushq %%rax\n"
             "        movq %s,%%rax\n"
             "        test%c   %%%cax,%%%cax                  # if %s value is not zero\n"
             "        jnz     .LREMAINDERM%" PRIu32 "_0         # then go and evaluate the formula\n"
             "        # Output any pending line\n"
             "        movabsq $.LOBUF,%%rdi               # output buffer variable address\n"
             "        movabsq $.Lobuf_next,%%rsi          # output bufpos variable address\n"
             "        movabsq $.Lcurzone,%%rdx            # output zonepos variable address\n"
             "        movabsq $.Lflushoutputln,%%rax      # call flushoutputln\n"
             "        callq   *%%rax\n"
             "        # Output error message\n"
             "        movabsq $.Lremainderfail_msg,%%rcx  # error message string address\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        callq   *%%rax                      # DOES NOT RETURN\n"
             ".LREMAINDERM%" PRIu32 "_0:\n"
             "                                           # %s /= %s\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname, lhs_fpregname, rhs_fpregname,
          (use_double?'q':'l'), (use_double?'r':'e'), (use_double?'r':'e'), (use_double?"double":"float"),
          instance_number, instance_number, lhs_fpregname, rhs_fpregname);
  binary_divide(f, lhs_fpregname, rhs_fpregname);
  if (strcmp(lhs_fpregname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax                 # save current value of xmm0\n"
               "        pushq   %%rax                       # on the stack and set\n"
               "        movapd  %s, %%xmm0    # xmm0=%s\n",
            lhs_fpregname, lhs_fpregname);
  fputs("        movabsq $.LIP,%rax\n"
        "        callq %rax                         # x = IP(x), i.e. IP(x/y)\n", f);
  if (strcmp(lhs_fpregname, "%xmm0")!=0)
    fprintf(f, "        movapd  %%xmm0, %s    # %s=xmm0\n"
               "        popq    %%rax                       # and restore old value of xmm0\n"
               "        movq    %%rax,%%xmm0                 # from the stack\n",
            lhs_fpregname, lhs_fpregname);
  fputs("        # y = y*IP(x/y)\n", f);
  binary_multiply(f, rhs_fpregname, lhs_fpregname);
  fprintf(f, "        popq %%rax\n"
             "        movq %%rax,%s\n",
          lhs_fpregname);
  binary_subtract(f, lhs_fpregname, rhs_fpregname);
  fputs("        popq %rax\n", f);
  instance_number++;
  return;
}

//
// This imlements the ECMA-116 ROUND(x,y) built-in math function.
// Input is two values x and y in lhsfpregname and rhsfpregname respectively
// Output is INT((X*(10^N))+.5)/(10^N) in \lhsfpregname, trashes rax
//
void do_round(
    FILE *f,                      // File handle for assembly language output file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting difference on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side subtrahend expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s = ROUND(%s, %s)\n"
             "        pushq %%r14           # backup r14\n"
             "        pushq %%r15           # backup r15\n"
             "        movq %s,%%r14         # r14 = X\n"
             "        movq %s,%%r15         # r15 = N\n"
             "        movq %%xmm0, %%rax                   # backup\n"
             "        pushq %%rax                         # xmm0\n"
             "        movq %%xmm1, %%rax                   # backup\n"
             "        pushq %%rax                         # xmm1\n"
             "        movq %%xmm2, %%rax                   # backup\n"
             "        pushq %%rax                         # xmm2\n"
             "        subq $8, %%rsp                      # keep stack aligned on 16 bytes\n"
             "        mov%s $.LFLOATTEN, %%%cax          # %cax = 10\n"
             "        movq %%rax, %%xmm0                   # xmm0 = 10\n"
             "        movq %%r15,%%xmm1                    # xmm1 = N\n"
             "                                           # xmm0 ^= N\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname, lhs_fpregname, rhs_fpregname,
          (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'r':'e'));
  binary_power(f, "%xmm0", "%xmm1");
  fputs("        movq %r14,%xmm2                    # xmm2 = X\n"
        "        # xmm2 *= (10^N)\n", f);
  binary_multiply(f, "%xmm2", "%xmm0");
  fprintf(f, "        mov%s $.LFLOATHALF, %%%cax         # %cax = 0.5 (%s)\n"
             "        movq %%rax, %%xmm1                   # xmm1 = 0.5\n"
             "                                           # xmm2 += 0.5\n",
          (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'r':'e'),
          (use_double?"double":"float"));
  binary_add(f, "%xmm2", "%xmm1");
  fputs("                                           # xmm2 = INT(X*(10^N)+0.5)\n"
        "        movq    %xmm0,%rax                 # save current value of xmm0\n"
        "        pushq   %rax                       # on the stack and set\n"
        "        movapd  %xmm2, %xmm0               # xmm0=xmm2\n"
        "        movabsq $.Lfloor, %rax             # %xmm0=floor(%xmm0)\n"
        "        callq   *%rax\n"
        "        movapd  %xmm0, %xmm2               # xmm2=xmm0\n"
        "        popq    %rax                       # and restore old value of xmm0\n"
        "        movq    %rax,%xmm0                 # from the stack\n"
        "                                           # xmm2 /= 10^N, yielding INT(X*(10^N)+0.5)/(10^N)\n", f);
  binary_divide(f, "%xmm2", "%xmm0");
  fputs("        addq $8, %rsp                      # keep stack aligned on 16 bytes\n"
        "        popq %rax\n", f);
  if (strcmp(lhs_fpregname, "%xmm2")!=0)
    fprintf(f, "        movq %%xmm2, %s       # lhsfpregname = xmm2\n"
               "        movq %%rax, %%xmm2                   # restore xmm2\n",
            lhs_fpregname);
  fputs("        popq %rax\n", f);
  if (strcmp(lhs_fpregname, "%xmm1")!=0)
    fputs("        movq %rax, %xmm1                   # restore xmm1\n", f);
  fputs("        popq %rax\n", f);
  if (strcmp(lhs_fpregname, "%xmm0")!=0)
    fputs("        movq %rax, %xmm0                   # restore xmm0\n", f);
  fputs("        popq %r15                          # restore r15\n"
        "        popq %r14                          # restore r14\n", f);
  return;
}

//
// This imlements the ECMA-116 TRUNCATE(x,y) built-in math function.
// Input is two values x and y in lhsfpregname and rhsfpregname respectively
// Output is IP(X*10^N)/10^N
//
void do_truncate(
    FILE *f,                      // File handle for assembly language output file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting difference on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side subtrahend expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s = TRUNCATE(%s, %s)\n"
             "        pushq %%r14                         # backup r14\n"
             "        pushq %%r15                         # backup r15\n"
             "        movq %s,%%r14         # r14 = X\n"
             "        movq %s,%%r15         # r15 = N\n"
             "        movq %%xmm0, %%rax                   # backup\n"
             "        pushq %%rax                         # xmm0\n"
             "        movq %%xmm1, %%rax                   # backup\n"
             "        pushq %%rax                         # xmm1\n"
             "        movq %%xmm2, %%rax                   # backup\n"
             "        pushq %%rax                         # xmm2\n"
             "        subq $8, %%rsp                      # keep stack aligned on 16 bytes\n"
             "        mov%s $.LFLOATTEN, %%%cax          # %cax = 10\n"
             "        movq %%rax, %%xmm0                   # xmm0 = 10\n"
             "        movq %%r15,%%xmm1                    # xmm1 = N\n"
             "                                           # xmm0 ^= N\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname, lhs_fpregname, rhs_fpregname,
          (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'r':'e'));
  binary_power(f, "%xmm0", "%xmm1");
  fputs("        movq %r14,%xmm2                    # xmm2 = X\n"
        "        # xmm2 *= (10^N)\n", f);
  binary_multiply(f, "%xmm2", "%xmm0");
  fputs("        movq    %xmm0,%rax                 # save current value of xmm0\n"
        "        pushq   %rax                       # on the stack and set\n"
        "        movapd  %xmm2, %xmm0               # %xmm0=%xmm2\n"
        "        movabsq $.LIP, %rax                # %xmm0=IP(%xmm0)\n"
        "        callq   *%rax\n"
        "        movapd  %xmm0, %xmm2               # %xmm2=%xmm0\n"
        "        popq    %rax                       # and restore old value of xmm0\n"
        "        movq    %rax,%xmm0                 # from the stack\n"
        "                                           # xmm2 /= 10^N, yielding INT(X*(10^N)+0.5)/(10^N)\n", f);
  binary_divide(f, "%xmm2", "%xmm0");
  fputs("        addq $8, %rsp                      # keep stack aligned on 16 bytes\n"
        "        popq %rax\n", f);
  if (strcmp(lhs_fpregname, "%xmm2")!=0)
    fprintf(f, "        movq %%xmm2, %s       # %s = xmm2\n"
               "        movq %%rax, %%xmm2                   # restore xmm2\n",
            lhs_fpregname, lhs_fpregname);
  fputs("        popq %rax\n", f);
  if (strcmp(lhs_fpregname, "%xmm1")!=0)
    fputs("        movq %rax, %xmm1                   # restore xmm1\n", f);
  fputs("        popq %rax\n", f);
  if (strcmp(lhs_fpregname, "%xmm0")!=0)
    fputs("        movq %rax, %xmm0                   # restore xmm0\n", f);
  fputs("        popq %r15                          # restore r15\n"
        "        popq %r14                          # restore r14\n", f);
  return;
}

//
// This function will emit code to implement a call of the ANGLE() function.
//
void do_angle(
    FILE *f,                      // File handle for assembly language output file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting difference on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side subtrahend expression value
  static uint32_t instance_number = 0,
                  stackbytes = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # atan2 expects y, x, but angle gets x, y!\n"
             "        # %s=ANGLE(%s,%s)\n"
             "        movq    %s,%%rax\n"
             "        test%c   %%%cax,%%%cax     # is first argument zero %s?\n"
             "        jnz     .LANGLE%" PRIu32 "_1            # if not, goto 1\n"
             "        movq    %s,%%rax\n"
             "        test%c   %%%cax,%%%cax     # is second argument zero float?\n"
             "        jnz     .LANGLE%" PRIu32 "_1            # if not, goto 1\n"
             "        # if we get here both arguments are zero!\n"
             "        movabsq $.LOBUF,%%rdi              # output buffer variable address\n"
             "        movabsq $.Lobuf_next,%%rsi         # output bubufpos variable address\n"
             "        movabsq $.Lcurzone,%%rdx           # output zonepos variable address\n"
             "        movabsq $.Lflushoutputln,%%r13     # call flushoutputln to\n"
             "        callq   *%%r13                     # flush any normal output\n"
             "        movabsq $.Lbadangle_msg, %%rcx     # address of badpower error message\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                     # DOES NOT RETURN\n"
             ".LANGLE%" PRIu32 "_1:\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname, lhs_fpregname, (use_double?'q':'l'),
          (use_double?'r':'e'), (use_double?'r':'e'), (use_double?"double":"float"), instance_number,
          rhs_fpregname, (use_double?'q':'l'), (use_double?'r':'e'), (use_double?'r':'e'),
          instance_number, instance_number);
  if (strcmp(rhs_fpregname, "%xmm0")!=0) {
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            rhs_fpregname, rhs_fpregname);
    stackbytes += 8U;
  }
  if (strcmp(lhs_fpregname, "%xmm1")!=0) {
    fprintf(f, "        movq    %%xmm1,%%rax  # save a copy of xmm1 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        movq    %s,%%xmm1 # xmm1 = %s\n",
            lhs_fpregname, lhs_fpregname);
    stackbytes += 8U;
  }
  fputs("        # at this point, angle is in xmm0\n", f);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0  # then xmm0 = (double)xmm0\n"
          "        cvtss2sd %xmm1,%xmm1  # then xmm1 = (double)xmm1\n", f);
  if (stackbytes%16 != 0)
    fputs("        subq    $8, %rsp      # pad stack for 16bit alignment\n", f);
  fputs("        movabsq $.Lxatan2_u1,%rax  # call xatan2_u1(xmm0,xmm1)\n"
        "        callq   *%rax              # which leaves answer in xmm0\n", f);
  if (stackbytes%16 != 0)
    fputs("        addq    $8, %rsp      # undo stack padding\n", f);
  fputs("        # at this point, atan2(firstarg,secondarg) is in xmm0\n", f);
  if (strcmp(lhs_fpregname, "%xmm1")!=0) {
    fputs("        popq    %rax          # and then restore the original\n"
          "        movq    %rax,%xmm1    # value of %xmm1\n", f);
  }
  if (strcmp(rhs_fpregname, "%xmm0")!=0) {
    fprintf(f, "        movq    %%xmm0,%s # %s = xmm0 (yes, really)\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            lhs_fpregname, lhs_fpregname);
  }
  fprintf(f, "        # at this point, atan2(%s,%s) is in %s\n",
          rhs_fpregname, lhs_fpregname, lhs_fpregname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            lhs_fpregname, lhs_fpregname, lhs_fpregname, lhs_fpregname);
  instance_number++;
  return;
}

//
// This function will emit code to implement the RANDOMIZE statement.
//
void dorandomize(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        movl    $1, %edi            # select non-repeatable sequence\n"
        "        movabsq $.Lrealinit, %rax   # initialize random number generator\n"
        "        callq   *%rax\n", f);
  return;
}

//
// This function will emit code to call the SIN() function.  The register
// containing the value to take the sine of is passed in the argument fpregname.
// The return value is left in that same register.
//
void do_sin(
    FILE *f,                // File handle for assembly language output file
    const char *fpregname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        # %s=SIN(%s)\n"
             "        # at this point, angle is in %s\n",
          fpregname, fpregname, fpregname);
  if (strcmp(fpregname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # %%xmm0 = %s\n",
            fpregname, fpregname);
  fprintf(f, "        # at this point, angle is in %%xmm0\n"
             "        movq    %%xmm0,%%r14  # r14 = %%xmm0\n"
             "        btr%c    $%" PRIu32 ",%%r14%s      # r14%s = abs(r14%s)  (%s)\n"
             "        mov%s $.LPInf,%%r15%s  # r15%s = +INF      (%s)\n"
             "        cmp%c    %%r14%s,%%r15%s    # if abs(angle) != +INF\n"
             "        jne     .LSINM%" PRIu32 "_0  # then goto 0\n"
             "        addq    $16, %%rsp      # reset stack pointer back to\n"
             "                               # what it was before\n"
             "        movabsq $.Lbadsinarg,%%rax  # and then goto badsinarg\n"
             "        jmpq    *%%rax              # DOES NOT RETURN\n"
             ".LSINM%" PRIu32 "_0:\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"), instance_number,
          instance_number);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0   # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxsin_u1,%rax  # call xsin_u1(xmm0)\n"
        "        callq   *%rax            # which leaves answer in xmm0\n"
        "        # at this point, sin(angle) is in xmm0\n", f);
  if (strcmp(fpregname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            fpregname, fpregname);
  fprintf(f, "        # at this point, sin(angle) is in %s\n", fpregname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            fpregname, fpregname, fpregname, fpregname);
  instance_number++;
  return;
}

//
// This function will emit code to call the SINH() function.  The register
// containing the value to take the sine of is passed in the argument regname.
// The return value is left in that same register.
//
void do_sinh(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=SINH(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fputs("        # at this point, angle is in xmm0\n", f);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0  # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxsinh_u1,%rax # call xsinh_u1(xmm0)\n"
        "        callq   *%rax            # which leaves answer in xmm0\n"
        "        # at this point, sinh(angle) is in xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, sinh(angle) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  return;
}

//
// This function will emit code to call the ASIN() function.  The register
// containing the value to take the sine of is passed in the argument regname.
// The return value is left in that same register.
//
void do_asin(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=ASIN(%s)\n"
             "        # at this point, x is in %s\n"
             "        # if not (-1 <= x <= 1) then fatal error\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fprintf(f, "        # at this point, x is in xmm0\n"
             "        movq    %%xmm1,%%rax\n"
             "        pushq   %%rax\n"
             "        movq    %%xmm2,%%rax\n"
             "        pushq   %%rax\n"
             "        movq    %%xmm0,%%r14          # r14 = xmm0\n"
             "        btr%c    $%" PRIu32 ",%%r14%s           # r14%s = abs(x)  (%s)\n"
             "        movq    %%r14,%%xmm1\n"
             "        mov%s $.LFLOATONE,%%r15%s   # r15%s = 1.0     (%s)\n"
             "        mov%c    %%r15%s,%%xmm2\n"
             "        comis%c  %%xmm2,%%xmm1         # if abs(x) <= 1 then\n"
             "        jbe     .LASINM%" PRIu32 "_0       # then goto 0\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%%xmm2\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%%xmm1\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?"absq":"l   "), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), (use_double?'q':'d'),
          (use_double?"":"d"), (use_double?'d':'s'), instance_number);
  if (strcmp(regname, "%xmm0")!=0)
    fputs("        popq    %rax\n"
          "        movq    %rax,%xmm0\n", f);
  fprintf(f, "                                    # what it was before\n"
             "        movabsq $.Lbadasinarg,%%rax  # and then goto badasinarg\n"
             "        jmpq    *%%rax               # DOES NOT RETURN\n"
             ".LASINM%" PRIu32 "_0:\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%%xmm2\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%%xmm1\n",
          instance_number);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0        # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxasin_u1,%rax    # call xasin_u1(xmm0)\n"
        "        callq   *%rax               # which leaves answer in xmm0\n"
        "        # at this point, asin(x) is in xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, asin(x) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  instance_number++;
  return;
}

//
// This function will emit code to call the COS() function.  The register
// containing the value to take the cosine of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_cos(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=COS(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fprintf(f, "        # at this point, angle is in xmm0\n"
             "        movq    %%xmm0,%%r14  # r14 = xmm0\n"
             "        btr%c    $%" PRIu32 ",%%r14%s      # r14%s = abs(r14%s)  (%s)\n"
             "        mov%s $.LPInf,%%r15%s  # r15%s = +INF      (%s)\n"
             "        cmp%c    %%r14%s,%%r15%s    # if abs(angle) != +INF\n"
             "        jne     .LCOSM%" PRIu32 "_0  # then goto 0\n"
             "        addq    $16, %%rsp      # reset stack pointer back to\n"
             "                               # what it was before\n"
             "        movabsq $.Lbadcosarg,%%rax  # and then goto badcosarg\n"
             "        jmpq    *%%rax              # DOES NOT RETURN\n"
             ".LCOSM%" PRIu32 "_0:\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"), (use_double?'q':'l'),
          (use_double?"":"d"), (use_double?"":"d"), instance_number, instance_number);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0   # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxcos_u1,%rax  # call xcos_u1(xmm0)\n"
        "        callq   *%rax            # which leaves answer in xmm0\n"
        "        # at this point, cos(angle) is in xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, cos(angle) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  instance_number++;
  return;
}

//
// This function will emit code to call the COSH() function.  The register
// containing the value to take the cosine of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_cosh(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=COSH(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax     # save a copy of xmm0 on the\n"
               "        pushq   %%rax           # stack and\n"
               "        subq    $8, %%rsp       # add 8 bytes padding so we are on a\n"
               "                               # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fputs("        # at this point, angle is in xmm0\n", f);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0   # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxcosh_u1,%rax # call xcosh_u1(xmm0)\n"
        "        callq   *%rax            # which leaves answer in xmm0\n"
        "        # at this point, cosh(angle) is in xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp       # remove 8 bytes of stack padding\n"
               "        popq    %%rax           # and then restore the original\n"
               "        movq    %%rax,%%xmm0     # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, cosh(angle) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  return;
}

//
// This function will emit code to call the ACOS() function.  The register
// containing the value to take the cosine of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_acos(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=ACOS(%s)\n"
             "        # at this point, x is in %s\n"
             "        # if not (-1 <= x <= 1) then fatal error\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fprintf(f, "        # at this point, x is in xmm0\n"
             "        movq    %%xmm1,%%rax\n"
             "        pushq   %%rax\n"
             "        movq    %%xmm2,%%rax\n"
             "        pushq   %%rax\n"
             "        movq    %%xmm0,%%r14          # r14 = xmm0\n"
             "        btr%c    $%" PRIu32 ",%%r14%s           # r14%s = abs(x)  (%s)\n"
             "        mov%c    %%r14%s,%%xmm1\n"
             "        mov%s $.LFLOATONE,%%r15%s   # r15%s = 1.0     (%s)\n"
             "        mov%c    %%r15%s,%%xmm2\n"
             "        comis%c  %%xmm2,%%xmm1         # if abs(x) <= 1 then\n"
             "        jbe     .LACOSM%" PRIu32 "_0       # then goto 0\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%%xmm2\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%%xmm1\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?'q':'d'), (use_double?"":"d"),
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'d'), (use_double?"":"d"), (use_double?'d':'s'), instance_number);
  if (strcmp(regname, "%xmm0")!=0)
    fputs("        popq    %rax\n"
          "        movq    %rax,%xmm0\n", f);
  fprintf(f, "                                    # what it was before\n"
             "        movabsq $.Lbadacosarg,%%rax  # and then goto badacosarg\n"
             "        jmpq    *%%rax               # DOES NOT RETURN\n"
             ".LACOSM%" PRIu32 "_0:\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%%xmm2\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%%xmm1\n",
          instance_number);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0        # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxacos_u1,%rax    # call xacos_u1(xmm0)\n"
        "        callq   *%rax               # which leaves answer in xmm0\n"
        "        # at this point, acos(x) is in xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, acos(x) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  instance_number++;
  return;
}

//
// This function will emit code to call the SEC() function.  The register
// containing the value to take the secant of is passed in the argument regname.
// The return value is left in that same register.
//
void do_sec(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # sec(x) calculated as 1/cos(x)\n"
             "        # %s=SEC(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fprintf(f, "        # at this point, angle is in xmm0\n"
             "        movq    %%xmm0,%%r14  # r14 = xmm0\n"
             "        btr%c    $%" PRIu32 ",%%r14%s      # r14%s = abs(r14%s)  (%s)\n"
             "        mov%s $.LPInf,%%r15%s  # r15%s = +INF      (%s)\n"
             "        cmp%c    %%r14%s,%%r15%s    # if abs(angle) != +INF\n"
             "        jne     .LSECM%" PRIu32 "_0  # then goto 0\n"
             "        addq    $16, %%rsp      # reset stack pointer back to\n"
             "                               # what it was before\n"
             "        movabsq $.Lbadsecarg,%%rax  # and then goto badsecarg\n"
             "        jmpq    *%%rax              # DOES NOT RETURN\n"
             ".LSECM%" PRIu32 "_0:\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"), (use_double?'q':'l'),
          (use_double?"":"d"), (use_double?"":"d"), instance_number, instance_number);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0   # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxcos_u1,%rax  # call xcos_u1(xmm0)\n"
        "        callq   *%rax            # which leaves answer in xmm0\n"
        "        # at this point, cos(angle) is in xmm0\n"
        "        movq    %xmm1, %rax     # make backup of\n"
        "        pushq   %rax            # xmm1 on the stack\n"
        "        movabsq $.LFLOATONE64, %rax # rax = 1.0\n"
        "        movq    %xmm0, %xmm1    # xmm1 = xmm0\n"
        "        movq    %rax, %xmm0     # xmm0 = 1.0\n"
        "        divsd   %xmm1, %xmm0    # xmm0 /= xmm1\n"
        "        popq    %rax            # restore backup of\n"
        "        movq    %rax, %xmm1     # xmm1\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, sec(angle) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  instance_number++;
  return;
}

//
// This function will emit code to call the CSC() function.  The register
// containing the value to take the cosecant of is passed in the argument regname.
// The return value is left in that same register.
//
void do_csc(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # csc(x) calculated as 1/sin(x)\n"
             "        # %s=CSC(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax      # save a copy of xmm0 on the\n"
               "        pushq   %%rax            # stack and\n"
               "        subq    $8, %%rsp        # add 8 bytes padding so we are on a\n"
               "                                # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fprintf(f, "        # at this point, angle is in xmm0\n"
             "        movq    %%xmm0,%%r14      # r14 = xmm0\n"
             "        btr%c    $%" PRIu32 ",%%r14%s       # r14%s = abs(r14%s)  (%s)\n"
             "        mov%s $.LPInf,%%r15%s   # r15%s = +INF      (%s)\n"
             "        cmp%c    %%r14%s,%%r15%s     # if abs(angle) != +INF\n"
             "        jne     .LCSCM%" PRIu32 "_0    # then goto 0\n"
             "        addq    $16, %%rsp       # reset stack pointer back to\n"
             "                                # what it was before\n"
             "        movabsq $.Lbadcscarg,%%rax  # and then goto badcscarg\n"
             "        jmpq    *%%rax              # DOES NOT RETURN\n"
             ".LCSCM%" PRIu32 "_0:\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"), instance_number,
          instance_number);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0    # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxsin_u1,%rax # call xsin_u1(xmm0)\n"
        "        callq   *%rax           # which leaves answer in xmm0\n"
        "        # at this point, sin(angle) is in xmm0\n"
        "        movq    %xmm1, %rax     # make backup of\n"
        "        pushq   %rax            # xmm1 on the stack\n"
        "        movabsq $.LFLOATONE64, %rax # rax = 1.0\n"
        "        movq    %xmm0, %xmm1    # xmm1 = xmm0\n"
        "        movq    %rax, %xmm0     # xmm0 = 1.0\n"
        "        divsd   %xmm1, %xmm0    # xmm0 /= xmm1\n"
        "        popq    %rax            # restore backup of\n"
        "        movq    %rax, %xmm1     # xmm1\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp        # remove 8 bytes of stack padding\n"
               "        popq    %%rax            # and then restore the original\n"
               "        movq    %%rax,%%xmm0      # value of xmm0\n"
               "        # at this point, sec(angle) is in %s\n",
            regname, regname, regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  instance_number++;
  return;
}

//
// This function will emit code to call the COT() function.  The register
// containing the value to take the cotangent of is passed in the argument regname.
// The return value is left in that same register.
//
void do_cot(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # cot(x) calculated as 1/tan(x)\n"
             "        # %s=COT(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fprintf(f, "        # at this point, angle is in xmm0\n"
             "        movq    %%xmm0,%%r14  # r14 = xmm0\n"
             "        btr%c    $%" PRIu32 ",%%r14%s      # r14%s = abs(r14%s)  (%s)\n"
             "        mov%s $.LPInf,%%r15%s  # r15%s = +INF      (%s)\n"
             "        cmp%c    %%r14%s,%%r15%s    # if abs(angle) != +INF\n"
             "        jne     .LCOT%" PRIu32 "_0   # then goto 0\n"
             "        addq    $16, %%rsp      # reset stack pointer back to\n"
             "                               # what it was before\n"
             "        movabsq $.Lbadcotarg,%%rax  # and then goto badsecarg\n"
             "        jmpq    *%%rax              # DOES NOT RETURN\n"
             ".LCOT%" PRIu32 "_0:\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"), instance_number,
          instance_number);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0   # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxtan_u1,%rax # call xcos_u1(xmm0)\n"
        "        callq   *%rax           # which leaves answer in xmm0\n"
        "        # at this point, tan(angle) is in xmm0\n"
        "        movq    %xmm1, %rax     # make backup of\n"
        "        pushq   %rax            # xmm1 on the stack\n"
        "        movabsq $.LFLOATONE64, %rax # rax = 1.0\n"
        "        movq    %xmm0, %xmm1    # xmm1 = xmm0\n"
        "        movq    %rax, %xmm0     # xmm0 = 1.0\n"
        "        divsd   %xmm1, %xmm0    # xmm0 /= xmm1\n"
        "        popq    %rax            # restore backup of\n"
        "        movq    %rax, %xmm1     # xmm1\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, cot(angle) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  instance_number++;
  return;
}

//
// This function will emit code to call the CEIL() function.  The register
// containing the value to take the ceiling of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_ceil(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  if (strcmp(regname, "%xxm0")!=0)
    fprintf(f, "      movq    %%xmm0, %%rax      # save current value of xmm0\n"
               "      pushq   %%rax              # on the stack and set\n"
               "      movapd  %s, %%xmm0         # %%xmm0=%s\n",
            regname, regname);
  fputs("        movabsq $.Lceil, %rax               # xmm0=ceil(xmm0)\n"
        "        callq   *%rax\n", f);
  if (strcmp(regname, "%xxm0")!=0) {
    fprintf(f, "      movapd  %%xmm0, %-6s        # %s=%%xmm0\n"
               "      popq    %%rax               # and restore old value of xmm0\n"
               "      movq    %%rax, %%xmm0       # from the stack\n", regname, regname);
  }
  return;
}

//
// This function will emit code to call the IP() function.  The register
// containing the value to find the integer part of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_ip(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  if (strcmp(regname, "%xmm0")!=1)          // if argument is not in xmm0 then
    fprintf(f, "        movq    %%xmm0, %%rax                 # save current value of xmm0\n"
               "        pushq   %%rax                        # on the stack and set\n"
               "        movapd  %s, %%xmm0        # xmm0=%s\n",
            regname, regname);
  fputs("        movabsq $.LIP, %rax                 # xmm0=IP(xmm0)\n"
        "        callq   *%rax\n", f);
  if (strcmp(regname, "%xmm0")!=1)          // if argument is not in xmm0 then
    fprintf(f, "        movapd  %%xmm0, %s        # %s=xmm0\n"
               "        popq    %%rax                        # and restore old value of xmm0\n"
               "        movq    %%rax, %%xmm0                 # from the stack\n",
            regname, regname);
  return;
}

//
// This function will emit code to call the FP() function.  The register
// containing the value to find the factional part of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_fp(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  if (strcmp(regname, "%xxm0")!=1)          // if argument is not in xxm0 then
    fprintf(f, "        movq    %%xmm0, %%rax                 # save current value of xmm0\n"
               "        pushq   %%rax                        # on the stack and set\n"
               "        movapd  %s, %%xmm0        # xmm0=%s\n",
            regname, regname);
  fputs("        movabsq $.LFP, %rax                 # xmm0=IP(xmm0)\n"
        "        callq   *%rax\n", f);
  if (strcmp(regname, "%xxm0")!=1)          // if argument is not in xxm0 then
    fprintf(f, "        movapd  %%xmm0, %s        # %s=xmm0\n"
               "        popq    %%rax                        # and restore old value of xmm0\n"
               "        movq    %%rax, %%xmm0                 # from the stack\n",
            regname, regname);
  return;
}

//
// This function will emit code to implement the STOP statement.
//
void do_stop(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        movabsq $.Lgoodxit, %rax          # rax = &label\n"
        "        jmpq    *%rax                     # GOTO *rax\n\n", f);
  return;
}

//
// This function will emit code to implement the GOTO statement.  The Minimal
// BASIC statement target line number must be passed in the target_lineno
// parameter.
//
void do_goto(
    FILE *f,                         // File handle for assembly language output file
    const uint32_t target_lineno) {  // Minimal BASIC source program GOTO jump target line number
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fprintf(f, "        movabsq $.LLINE%04" PRIu32 ", %%rax          # GOTO line %" PRIu32 "\n"
             "        jmpq    *%%rax\n", target_lineno, target_lineno);
  return;
}

//
// This function will emit code to call the TAN() function.  The register
// containing the value to take the tangent of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_tan(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # compute %s=TAN(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fprintf(f, "        # at this point, angle is in xmm0\n"
             "        movq    %%xmm0,%%r14  # r14 = xmm0\n"
             "        btr%c    $%" PRIu32 ",%%r14%s      # r14%s = abs(r14%s)  (%s)\n"
             "        mov%s $.LPInf,%%r15%s  # r15%s = +INF      (%s)\n"
             "        cmp%c    %%r14%s,%%r15%s    # if abs(angle) != +INF\n"
             "        jne     .LTANM%" PRIu32 "_0  # then goto 0\n"
             "        addq    $16, %%rsp      # reset stack pointer back to\n"
             "                               # what it was before\n"
             "        movabsq $.Lbadtanarg,%%rax  # and then goto badtanarg\n"
             "        jmpq    *%%rax              # DOES NOT RETURN\n"
             ".LTANM%" PRIu32 "_0:\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"), (use_double?'q':'l'),
          (use_double?"":"d"), (use_double?"":"d"), instance_number, instance_number);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0   # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxtan_u1,%rax  # call xtan_u1(xmm0)\n"
        "        callq   *%rax            # which leaves answer in xmm0\n"
        "        # at this point, tan(angle) is in xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, tan(angle) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  instance_number++;
  return;
}

//
// This function will emit code to call the TANH() function.  The register
// containing the value to take the tangent of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_tanh(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=TANH(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax    # save a copy of xmm0 on the\n"
               "        pushq   %%rax          # stack and\n"
               "        subq    $8, %%rsp      # add 8 bytes padding so we are on a\n"
               "                              # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fputs("        # at this point, angle is in xmm0\n", f);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0  # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxtanh_u1,%rax # call xtanh_u1(xmm0)\n"
        "        callq   *%rax            # which leaves answer in xmm0\n"
        "        # at this point, tanh(angle) is in xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
              regname, regname);
  fprintf(f, "        # at this point, tanh(angle) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  return;
}

//
// This function will emit code to call the ATN() function.  The register
// containing the value to take the arctangent of is passed in the argument
// regname.  The return value is left in that same register.
//
void do_atan(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=ATN(%s)\n"
             "        # at this point, angle is in %s\n",
          regname, regname, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            regname, regname);
  fputs("        # at this point, angle is in xmm0\n", f);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0  # then xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxatan_u1,%rax  # call xatan_u1(xmm0)\n"
        "        callq   *%rax             # which leaves answer in xmm0\n"
        "        # at this point, atan(angle) is in xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            regname, regname);
  fprintf(f, "        # at this point, atan(angle) is in %s\n", regname);
  if (!use_double)
    fprintf(f, "        cvtsd2ss %s,%s # %s = (float)%s\n",
            regname, regname, regname, regname);
  return;
}

//
// This function will emit code to call the LOG() function.  The register
// containing the value to take the natural logarithm of is passed in the
// argument regname.  The return value is left in that same register.
//
void do_log(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=LOG(%s)\n"
             "        pushq   %%rbp\n"
             "        movq    %%rsp, %%rbp\n"
             "        andq    $-32, %%rsp      # force align the stack on 16-byte\n"
             "        subq    $32,%%rsp        # reserve 24 bytes + 8 bytes padding of locals\n"
             "                                # -24(rbp)   backup copy of xmm0\n"
             "                                # -16(rbp)   backup copy of rax\n"
             "                                # -8(rbp)    temp\n"
             "        movq    %%rax,-16(%%rbp)         # save rax\n"
             "        xorl    %%eax,%%eax              # rax = 0\n"
             "        movq    %%rax,-8(%%rbp)          # 8 bytes of zero\n"
             "        comis%c  -8(%%rbp),%s # if %s > 0 then\n"
             "        ja      .LLOGEM%" PRIu32 "_0          # goto 0\n"
             "        movq    %%rbp, %%rsp             # else restore stack\n"
             "        popq    %%rbp                   # pointer\n"
             "        movabsq $.Lbadlog,%%rax         # and goto badlog\n"
             "        jmpq    *%%rax                  # DOES NOT RETURN\n"
             ".LLOGEM%" PRIu32 "_0:\n"
             "        #\n"
             "        # if we get here, then %s contents are > 0\n"
             "        #\n",
          regname, regname, (use_double?'d':'s'), regname, regname,
          instance_number, instance_number, regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax             # save a copy of xmm0 on the\n"
               "        movq    %%rax,-24(%%rbp)         # stack and\n"
               "        movq    %s,%%xmm0    # xmm0 = %s\n",
            regname, regname);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0           # xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxlog_u1,%rax        # call log(xmm0)\n"
        "        callq   *%rax                  # which leaves answer in xmm0\n", f);
  if (!use_double)
    fputs("        cvtsd2ss %xmm0,%xmm0           # xmm0 = (float)xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        movq    -24(%%rbp), %%rax\n"
               "        movq    %%rax,%%xmm0             # retore xmm0\n",
            regname, regname);
  fputs("        movq    -16(%rbp),%rax         # restore rax\n"
        "        movq    %rbp, %rsp\n"
        "        popq    %rbp\n", f);
  instance_number++;
  return;
}

//
// This function will emit code to call the LOG2() function.  The register
// containing the value to take the base 2 logarithm of is passed in the
// argument regname.  The return value is left in that same register.
//
void do_log2(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=LOG2(%s)\n"
             "        pushq   %%rbp\n"
             "        movq    %%rsp, %%rbp\n"
             "        andq    $-32, %%rsp      # force align the stack on 16-byte\n"
             "        subq    $32,%%rsp        # reserve 24 bytes + 8 bytes padding of locals\n"
             "                                # -24(%%rbp)   backup copy of xmm0\n"
             "                                # -16(%%rbp)   backup copy of rax\n"
             "                                # -8(%%rbp)    temp\n"
             "        movq    %%rax,-16(%%rbp)         # save rax\n"
             "        xorl    %%eax,%%eax              # rax = 0\n"
             "        movq    %%rax,-8(%%rbp)          # 8 bytes of zero\n"
             "        comis%c  -8(%%rbp),%s # if %s > 0 then\n"
             "        ja      .LLOG2M%" PRIu32 "_0          # goto 0\n"
             "        movq    %%rbp, %%rsp             # else restore stack\n"
             "        popq    %%rbp                   # pointer\n"
             "        movabsq $.Lbadlog2,%%rax        # and goto badlog2\n"
             "        jmpq    *%%rax                  # DOES NOT RETURN\n"
             ".LLOG2M%" PRIu32 "_0:\n"
             "        #\n"
             "        # if we get here, then %s contents are > 0\n"
             "        #\n",
          regname, regname, (use_double?'d':'s'), regname, regname, instance_number, instance_number,
          regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax             # save a copy of xmm0 on the\n"
               "        movq    %%rax,-24(%%rbp)         # stack and\n"
               "        movq    %s,%%xmm0    # xmm0 = %s\n", regname, regname);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0           # xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxlog2_u1,%rax       # call log2(xmm0)\n"
        "        callq   *%rax                  # which leaves answer in xmm0\n", f);
  if (!use_double)
    fputs("        cvtsd2ss %xmm0,%xmm0           # xmm0 = (float)xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        movq    -24(%%rbp), %%rax\n"
               "        movq    %%rax,%%xmm0             # retore xmm0\n",
            regname, regname);
  fputs("        movq    -16(%rbp),%rax         # restore rax\n"
        "        movq    %rbp, %rsp\n"
        "        popq    %rbp\n", f);
  instance_number++;
  return;
}

//
// This function will emit code to call the LOG10() function.  The register
// containing the value to take the base 10 logarithm (natural logarithm)
// of is passed in the argument regname.  The return value is left in that
// same register.
//
void do_log10(
    FILE *f,                // File handle for assembly language output file
    const char *regname) {  // pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!regname || !regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "regname");
  fprintf(f, "        # %s=LOG10(%s)\n"
             "        pushq   %%rbp\n"
             "        movq    %%rsp, %%rbp\n"
             "        andq    $-32, %%rsp      # force align the stack on 16-byte\n"
             "        subq    $32,%%rsp        # reserve 24 bytes + 8 bytes padding of locals\n"
             "                                # -24(%%rbp)   backup copy of xmm0\n"
             "                                # -16(%%rbp)   backup copy of rax\n"
             "                                # -8(%%rbp)    temp\n"
             "        movq    %%rax,-16(%%rbp)         # save rax\n"
             "        xorl    %%eax,%%eax              # rax = 0\n"
             "        movq    %%rax,-8(%%rbp)          # 8 bytes of zero\n"
             "        comis%c  -8(%%rbp),%s # if %s > 0 then\n"
             "        ja      .LLOG10M%" PRIu32 "_0         # goto 0\n"
             "        movq    %%rbp, %%rsp             # else restore stack\n"
             "        popq    %%rbp                   # pointer\n"
             "        movabsq $.Lbadlog10,%%rax       # and goto badlog10\n"
             "        jmpq    *%%rax                  # DOES NOT RETURN\n"
             ".LLOG10M%" PRIu32 "_0:\n"
             "        #\n"
             "        # if we get here, then %s contents are > 0\n"
             "        #\n",
          regname, regname, (use_double?'d':'s'), regname, regname, instance_number, instance_number,
          regname);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax             # save a copy of xmm0 on the\n"
               "        movq    %%rax,-24(%%rbp)         # stack and\n"
               "        movq    %s,%%xmm0    # xmm0 = %s\n",
            regname, regname);
  if (!use_double)
    fputs("        cvtss2sd %xmm0,%xmm0           # xmm0 = (double)xmm0\n", f);
  fputs("        movabsq $.Lxlog10_u1,%rax      # call log10(xmm0)\n"
        "        callq   *%rax                  # which leaves answer in xmm0\n", f);
  if (!use_double)
    fputs("        cvtsd2ss %xmm0,%xmm0           # xmm0 = (float)xmm0\n", f);
  if (strcmp(regname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s    # %s = xmm0\n"
               "        movq    -24(%%rbp), %%rax\n"
               "        movq    %%rax,%%xmm0             # retore xmm0\n",
            regname, regname);
  fputs("        movq    -16(%rbp),%rax         # restore rax\n"
        "        movq    %rbp, %rsp\n"
        "        popq    %rbp\n", f);
  instance_number++;
  return;
}

//
// This function will emit code to call the EXP() function.  The register
// containing the value to take the exponential of is passed in the argument
// regname.  The return value is left in that same register.
//
// WARNING: This FAILS for negative arguments.
//
void do_exp(
    FILE *f,                // File handle for assembly language output file
    const char *fpregname) {// pointer to buffer with ASCIIZ string containing the
                            // register name used for both input and output values
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        # %s=EXP(%s)\n"
             "        # at this point, argument is in %s\n"
             "        pushq   %%r15\n"
             "        pushq   %%r14\n"
             "        # Keep a backup copy of the argument to exp in r15\n"
             "        movq    %s, %%r15\n",
          fpregname, fpregname, fpregname, fpregname);
  if (strcmp(fpregname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%%rax  # save a copy of xmm0 on the\n"
               "        pushq   %%rax        # stack and\n"
               "        subq    $8, %%rsp    # add 8 bytes padding so we are on a\n"
               "                            # 16 byte stack boundary to call a subroutine\n"
               "        movq    %s,%%xmm0 # xmm0 = %s\n",
            fpregname, fpregname);
  if (!use_double)
    fprintf(f, "        # Hideous hard-coded heuristic to work around Intel\n"
               "        # limitations [see page 111 in 325462-sdm-vol-1.2abcd-3abcd-v071.pdf,\n"
               "        # 4.9.1.5 Numeric Underflow Exception #U\n"
               "        # Underflow Exception Masked\n"
               "        # The underflow exception is only reported (the UE flag is set)\n"
               "        # only when the result is both tiny and inexact.\n"
               "        # Developer Summary: underflow detection isn't something you can use\n"
               "        #                    with floating point on INT64/AMD64; you have to\n"
               "        #                    do stuff like this hard-coded nightmare\n"
               "        # if argument < -103.972 then underflow\n"
               "        movl $0xc2cff1aa, %%eax # -103.972 float\n"
               "        movq %%rax, %%xmm1\n"
               "        comiss %%xmm1,%%xmm0\n"
               "        ja      .LEXPM%" PRIu32 "_0\n"
               "        movabsq $.Lunderflow_exp_msg,%%rsi  # rsi = address of error message\n"
               "        movabsq $.Lexception_non_fatal,%%rax  # call exception_non_fatal\n"
               "        callq   *%%rax\n"
               "        pxor    %%xmm0,%%xmm0 # return a zero\n"
               "        {disp8} jmp .LEXPM%" PRIu32 "_7\n"
               ".LEXPM%" PRIu32 "_0:\n"
               "        cvtss2sd %%xmm0,%%xmm0  # then xmm0 = (double)xmm0\n",
            instance_number, instance_number, instance_number);
  fprintf(f, "        # at this point, argument is in xmm0\n"
             "        movabsq $.Lxexp_u1,%%rax   # call xexp(xmm0)\n"
             "        callq   *%%rax          # which leaves answer in xmm0\n"
             "        # Keep a backup copy of the result from exp in r14\n"
             "        movq    %%xmm0, %%r14\n"
             "        xorl    %%eax,%%eax      # rax=0, assume return will be false\n"
             "        movq    %%xmm0, %%rdx    # move xmm0 to rdx\n"
             "        btrq    $63, %%rdx      # rdx = abs(xmms)   clear sign bit\n"
             "        movabsq $.LPInf64,%%rcx # move +INF to rcx   (double)\n"
             "        cmpq    %%rcx, %%rdx     # if rdx == +INF\n"
             "                               # i.e, if exp(argument) returns +/-INF\n"
             "        sete    %%al            # then rax=1, else rax=0\n"
             "        testq   %%rax, %%rax     # if rax==0      (was not INF)\n"
             "        jz      .LEXPM%" PRIu32 "_1   # then goto 1\n"
             "        # Infinity (64 bit overflow)\n"
             "        movabsq $.Loverflow_exp_msg,%%rsi      # rsi = address of error message\n"
             "        movabsq $.Lexception_non_fatal,%%rax  # call exception_non_fatal\n"
             "        callq   *%%rax\n"
             "        {disp8} jmp .LEXPM%" PRIu32 "_5\n"
             ".LEXPM%" PRIu32 "_1:\n"
             "        # if argument was negative and result is 0, we have underflow\n"
             "        movq    %%r15, %%xmm0     # argument\n"
             "        pxor    %%xmm1, %%xmm1    # 0\n"
             "        comisd  %%xmm1, %%xmm0    # if argument >= 0 then\n"
             "        jae     .LEXPM%" PRIu32 "_5    # goto 5\n"
             "        # ok, arg is negative\n"
             "        movq    %%r14, %%xmm0     # return value\n"
             "        comisd  %%xmm1, %%xmm0    # return value != 0 then\n"
             "        jne     .LEXPM%" PRIu32 "_5    # goto 5\n"
             "        # ok, return value is zero\n"
             "        # so, return of 0 and arg is negative, (64 bit underflow)\n"
             "        movabsq $.Lunderflow_exp_msg,%%rsi    # rsi = address of error message\n"
             "        movabsq $.Lexception_non_fatal,%%rax  # call exception_non_fatal\n"
             "        callq   *%%rax\n"
             "        xorl    %%r14d,%%r14d # return a zero\n"
             ".LEXPM%" PRIu32 "_5:\n"
             "        movq    %%r14, %%xmm0\n"
             "        # at this point, exp(argument) is in xmm0\n",
          instance_number, instance_number, instance_number, instance_number, instance_number,
          instance_number);
  if (!use_double)
    fprintf(f, "        stmxcsr (%%rsp)        # save mxcsr status on stack\n"
               "        andl    $0xFFC0,(%%rsp) # clear exception in stack copy of MXCSR\n"
               "        ldmxcsr (%%rsp)        # and reload that into real MXCSR\n"
               "        cvtsd2ss %%xmm0,%%xmm0  # xmm0 = (float)xmm0\n"
               "        # check exceptions from conversion\n"
               "        subq    $16, %%rsp     # allocate 12 bytes of padding and 4 byte temp\n"
               "                              # (padding is to keep 16 byte stack alignment)\n"
               "        stmxcsr (%%rsp)        # temp = mxcsr\n"
               "        testl   $.LFE_OVERFLOW,(%%rsp)   # if !temp.FE_OVERFLOW then\n"
               "        jz      .LEXPM%" PRIu32 "_6\n"
               "        movabsq $.Loverflow_exp_msg,%%rsi      # rsi = address of error message\n"
               "        movabsq $.Lexception_non_fatal,%%rax  # call exception_non_fatal\n"
               "        callq   *%%rax\n"
               "        stmxcsr (%%rsp)        # save mxcsr status on stack\n"
               "        andl    $0xFFC0,(%%rsp) # clear exception in stack copy of MXCSR\n"
               "        ldmxcsr (%%rsp)        # and reload that into real MXCSR\n"
               "        {disp8} jmp .LEXPM%" PRIu32 "_7\n"
               ".LEXPM%" PRIu32 "_6:\n"
               "        testl   $.LFE_UNDERFLOW,(%%rsp)   # if !temp.FE_UNDERFLOW then\n"
               "        jz      .LEXPM%" PRIu32 "_7\n"
               "        # this is really tricky - they signal underflow even when they\n"
               "        # get a value you can use, so only trigger this if we really\n"
               "        # got zero...\n"
               "        pxor    %%xmm1,%%xmm1\n"
               "        ucomiss %%xmm1,%%xmm0\n"
               "        jne     .LEXPM%" PRIu32 "_7\n"
               "        # ok, we really got all zero bits AND the underflow exception now\n"
               "        movabsq $.Lunderflow_exp_msg,%%rsi      # rsi = address of error message\n"
               "        movabsq $.Lexception_non_fatal,%%rax  # call exception_non_fatal\n"
               "        callq   *%%rax\n"
               "        stmxcsr (%%rsp)        # save mxcsr status on stack\n"
               "        andl    $0xFFC0,(%%rsp) # clear exception in stack copy of MXCSR\n"
               "        ldmxcsr (%%rsp)        # and reload that into real MXCSR\n"
               "        pxor    %%xmm0,%%xmm0 # return a zero\n"
               ".LEXPM%" PRIu32 "_7:\n",
            instance_number, instance_number,instance_number, instance_number, instance_number,
            instance_number);
  if (strcmp(fpregname, "%xmm0")!=0)
    fprintf(f, "        movq    %%xmm0,%s  # %s = xmm0\n"
               "        addq    $8, %%rsp      # remove 8 bytes of stack padding\n"
               "        popq    %%rax          # and then restore the original\n"
               "        movq    %%rax,%%xmm0    # value of xmm0\n",
            fpregname, fpregname);
  fputs("        popq    %r14\n"
        "        popq    %r15\n", f);
  instance_number++;
  return;
}

//
// This function will do a logical NOT on the contents of al, which
// must be a signed zero (false) or one (true).  The result will
// be left in al.
//
void do_logical_not(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        # counterintuitive, but notb al=0 gives ff, not 1 like we want\n"
        "        # incoming boolean condition is in al, 0 is false, 1 is true\n"
        "        xorb    $1,%al             # condition = !condition\n", f);
  return;
}

//
// This function will emit code for a string comparison.
// The right-hand-side string address should be on top of the dedicated
// string stack, and the left-hand-side string address should just
// below that.  The type of comparison is specified by the op parameter.
// At runtime, after the comparison, you get rax with either 1
// (true) or 0 (false).
// Only comparison for equality and inequality are permitted in Minimal BASIC.
// With extensions on, you get support for all 6 comparisons.
//
void do_string_comparison2(
    FILE *f,                // File handle for assembly language output file
    const enum relop op) {  // operator type, must be EQ or NE
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  popsaddr(f, "%rsi"); // rhs
  popsaddr(f, "%rdi"); // lhs
  fputs("        movabsq $.Lmystrcmp, %rax\n"
        "        callq   *%rax\n"
        "        movq    %rax, %rbx\n"
        "        xorl    %eax, %eax\n", f);
  if (extensions) {
    fputs("        cmpq    $0, %rbx\n", f);
    switch (op) {
      case LT:
        fputs("        setl    %al\n", f); break;
      case LE:
        fputs("        setle   %al\n", f); break;
      case EQ:
        fputs("        sete    %al\n", f); break;
      case NE:
        fputs("        setne   %al\n", f); break;
      case GE:
        fputs("        setge   %al\n", f); break;
      case GT:
        fputs("        setg    %al\n", f); break;
      default:
        ICE(__FILE__, __func__, __LINE__, "%s", emsg[83]);
    }
    return;
  }
  if ((op != EQ) && (op != NE))
    ICE(__FILE__, __func__, __LINE__, "%s", emsg[83]);
  fprintf(f, "        testq   %%rbx, %%rbx\n"
             "        set%-2s    %%al\n", (op==EQ?"e ":"ne"));
  return;
}

//
// This function will emit code for a numeric comparison.
// The right-hand-side expression value should be in rhs_regname
// and the left-hand-side expression value should be in lhs_regname.
// The type of comparison is specified by the op parameter.
// At runtime, after the comparison, you get rax with either 1
// (true) or 0 (false).
//
void do_numeric_comparison(
    FILE *f,                   // File handle for assembly language output file
    const enum relop op,       // operator type
    const char *lhs_regname,   // pointer buffer with ASCIIZ string containing the
                               // floating point register name containing the value
                               // of the left-hand side numeric expression
    const char *rhs_regname) { // pointer buffer with ASCIIZ string containing the
                               // floating point register name containing the value
                               // of the right-hand side numeric expression
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_regname || !lhs_regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_regname");
  if (!rhs_regname || !rhs_regname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_regname");
  fprintf(f, "        xorl    %%eax,%%eax\n"
             "        comis%c  %s, %s\n"
             "        jnp     .LNC%" PRIu32 "_0\n"
             "        # LHS and/or RHS was NaN\n"
             "        movabsq $.Luninitialized_msg, %%rcx\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             ".LNC%" PRIu32 "_0:\n",
          (use_double?'d':'s'), rhs_regname, lhs_regname, instance_number, instance_number);
  switch(op) {
    case EQ:
      fputs("        sete    %al\n", f); break;
    case NE:
      fputs("        setne   %al\n", f); break;
    case LT:
      fputs("        setb    %al\n", f); break;
    case LE:
      fputs("        setbe   %al\n", f); break;
    case GT:
      fputs("        seta    %al\n", f); break;
    case GE:
      fputs("        setae   %al\n", f); break;
    default:
      ICE(__FILE__, __func__, __LINE__, "%s", emsg[83]);
  }
  instance_number++;
  return;
}

//
// This emits code to do a conditional branch to the line specified
// by the target_lineno.  The branch is taken if al is 1 (true), and is not
// taken otherwise (0, false).
//
void do_conditional_branch(
    FILE *f,                        // File handle for assembly language output file
    const uint32_t target_lineno) { // target Minimal BASIC line number used when the
                                    // condition is true and the branch is taken
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fprintf(f, "        cmpb    $1,%%al             # if condition was false\n"
             "        jne     .LCB%" PRIu32 "_0        # jump to continue\n"
             "        movabsq $.LLINE%04" PRIu32 ",%%rax    # else goto line %" PRIu32 "\n"
             "        jmpq    *%%rax              # DOES NOT RETURN\n"
             ".LCB%" PRIu32 "_0:                       # false, keep going\n",
          instance_number, target_lineno, target_lineno, instance_number);
  instance_number++;
  return;
}

//
// This function will emit code for the GOSUB statement.  The target_lineno
// is the Minimal BASIC statement line number of the subroutine to run.
// If the return stack is not full, then the `from' value is pushed
// and the program does an unconditional jump to the `jumptarget'
// otherwise an error is displayed and the program jumps to badxit
// and terminates with an error.
//
void do_gosub(
    FILE *f,                         // File handle for assembly language output file
    const uint32_t target_lineno) {  // target Minimal BASIC line number used when the
                                     // condition is true and the branch is taken
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fprintf(f, "        movabsq $.Lretaddr_stack_ptr,%%r13   # r13 = &retaddr_stack_ptr\n"
             "        movl    (%%r13),%%r15d                # r15d = *retaddr_stack_ptr (4 byte integer)\n"
             "        movl    $.Lretaddr_stack_size,%%r14d # r14d = retaddr_stack_size\n"
             "        cmpl    %%r14d,%%r15d                 # if *retaddr_stack_ptr < retaddr_stack_size\n"
             "        jb      .LGOSUB%" PRIu32 "_1              # then goto 1\n"
             "        movabsq $.Lreturn_stack_full_msg, %%rcx # address of error message\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                       # DOES NOT RETURN\n"
             ".LGOSUB%" PRIu32 "_1:\n"
             "        movabsq $.Lretaddr_stack, %%r14      # r14 is &retaddr_stack\n"
             "        movq    $.LRETSPOT%" PRIu32 "_0, 0(%%r14,%%r15,8)   # retaddr_stack[r15*8] = from\n"
             "        incl    %%r15d                       # ++r15\n"
             "        movl    %%r15d,(%%r13)                # *retaddr_stack_ptr = r15\n"
             "        movabsq $.LLINE%04" PRIu32 ", %%r15       # goto jumptarget\n"
             "        jmpq    *%%r15                       # DOES NOT RETURN\n"
             ".LRETSPOT%" PRIu32 "_0:\n",
          instance_number, instance_number, instance_number, target_lineno, instance_number);
  instance_number++;
  return;
}

//
// This function will emit code for the RETURN statement.
// If the return stack is empty, then an error is displayed and the
// program jumps to badxit and termintes with an error
// otherwise an address is popped from the stack and the program
// will unconditionally jump to that address.
//
void do_return(
    FILE *f) {                // File handle for assembly language output file
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fprintf(f, "        movabsq $.Lretaddr_stack_ptr, %%r13  # r13 = &retaddr_stack_ptr\n"
             "        movl    (%%r13),%%r15d                # r15d = *retaddr_stack_ptr (4 byte integer)\n"
             "        xorl    %%r14d,%%r14d                 # r14d = 0\n"
             "        cmpl    %%r14d,%%r15d                 # if *retaddr_stack_ptr > 0 then\n"
             "        ja      .LRETURN%" PRIu32 "_1             # goto 1\n"
             "        movabsq $.Lreturn_stack_empty_msg, %%rcx  # input error message buffer variable address\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                       # DOES NOT RETURN\n"
             ".LRETURN%" PRIu32 "_1:\n"
             "        movabsq $.Lretaddr_stack, %%r14      # r14 = &retaddr_stack\n"
             "        decl    %%r15d                       # r15 -= 1 (decrement temp copy of stack ptr)\n"
             "        movq    0(%%r14,%%r15,8), %%r14        # r14 = retaddr_stack[retaddr_stack_ptr]\n"
             "        movl    %%r15d,(%%r13)                # *retaddr_stack_ptr = r15\n"
             "        jmpq    *%%r14                       # jump to *r14 (return from last gosub)\n",
          instance_number, instance_number);
  instance_number++;
  return;
}

//
// maxchoice is the number of comma-separated line numbers following the GOTO keyword
// fpregname is the floating point register that contains the result of
// the numeric expression between the ON and GOTO keywords
//
void do_ongotostart(
    FILE *f,                  // File handle for assembly language output file
    const uint32_t maxchoice, // the number of comma-separated line numbers following
                              // the GOTO keyword (number of jump targets)
    const char *fpregname) {  // pointer to buffer with ASCIIZ string of the name of
                              // the floating point register that contains the
                              // result of the numeric expression between the ON and GOTO
                              // keywords
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        subq    $8,%%rsp                  # save room for 2 copies of mxcsr on stack\n"
             "        stmxcsr -4(%%rsp)                 # current value for later\n"
             "        stmxcsr (%%rsp)                   # current value we will modify\n"
             "        andl    $0xffff9fff, (%%rsp)      # clear rouding bits 13/14\n"
             "        ldmxcsr (%%rsp)                   # load modified value into mxcsr\n"
             "        cvts%c2sil %s, %%eax    # eax = (uint32_t)%s  (%s)\n"
             "        stmxcsr (%%rsp)                   # temp = mxcsr\n"
             "        testl   $.LFE_INVALID,(%%rsp)     # if temp.FE_INVALID\n"
             "        jz      .LONGOTOSTART%" PRIu32 "_0     # then goto 0\n"
             "        {disp8} jmp .LONGOTOSTART%" PRIu32 "_1 # else goto 1\n"
             ".LONGOTOSTART%" PRIu32 "_0:\n"
             "        ldmxcsr -4(%%rsp)                 # reload original mxcsr value\n"
             "        # ensure jump target choice number is valid:\n"
             "        decl    %%eax                     # eax -= 1\n"
             "        cmpl    $(%" PRIu32 " - 1),%%eax # if eax > (maxchoice-1) then\n"
             "        ja      .LONGOTOSTART%" PRIu32 "_1     # goto 1\n"
             "        ldmxcsr -4(%%rsp)                 # reload original mxcsr value\n"
             "        addq    $8,%%rsp                  # free allocated stack\n"
             "        jmpq    *.LJT%" PRIu32 "(,%%rax,8)      # goto address in jump table slot rax\n"
             ".LONGOTOSTART%" PRIu32 "_1:\n"
             "        ldmxcsr -4(%%rsp)                 # reload original mxcsr value\n"
             "        addq    $8,%%rsp                  # free allocated stack\n"
             "        # display out of range error\n"
             "        movabsq $.Longotofail_msg, %%rcx  # input error message address\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             "        #\n"
             "        # Ok, we need to switch to the read-only data segment\n"
             "        # where the jump table is stored\n"
             "        #\n"
             "        .section .rodata,\"a\",@progbits\n"
             "\n"
             "        # jump table starts here\n"
             "        # there is a different one for every ON..GOTO\n"
             "        .balign 8, 0\n",
          (use_double?'d':'s'), fpregname, fpregname, (use_double?"double":"float"), instance_number,
          instance_number, instance_number, maxchoice, instance_number, instance_number, instance_number);
  fprintf(f, ".LJT%" PRIu32 ":\n", instance_number);
  instance_number++;
  return;
}

//
// Add a jump target to the jump table for an ON..GOTO statement.
// Each line number (jump target) will need this invoked
// to create an entry in the jump table
// labelname is the label for that jump target.
//
void do_ongotochoice(
    FILE *f,                         // File handle for assembly language output file
    const uint32_t target_lineno) {  // Minimal BASIC source program ON..GOTO jump target line number
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fprintf(f, "        .quad   .LLINE%04" PRIu32 "\n", target_lineno);
  return;
}

//
// End the jump table for an ON..GOTO statement.
// Once the jump table entries are all created with
// invocations of ongotochoice, we need to switch
// back to the code segment (.text section).
//
void do_ongotoend(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("\n.section .text,\"ax\",@progbits\n\n"
        ".balign 8, 0\n", f);
  return;
}

//
// This function emits the the code for the FOR statement.
// The actual implementation is contained in beginfor.
// tol_label, bol_label, inc_var, limit_var must be allocated
// by caller and exist and be appropriately sized.
//
void do_forloopstart(
    FILE *f,                  // File handle for assembly language output file
    const char *ndex_var,     // pointer to buffer with ASCIIZ string containing the
                              // label for the loop index variable
    const char *inc_var,      // pointer to buffer with ASCIIZ string containing the
                              // label for the variable containing the increment amount
    char *test_label,         // pointer to buffer with ASCIIZ string containing the
                              // top of loop label used to do another iteration
    char *body_label) {       // pointer to buffer with ASCIIZ string containing the
                              // bottom of loop label used to jump out of the loop
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!ndex_var || !ndex_var[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "ndex_var");
  if (!inc_var || !inc_var[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "inc_var");
  if (!test_label || !test_label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "test_label");
  if (!body_label || !body_label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "body_label");
  fprintf(f, "        .section .rodata,\"a\",@progbits\n\n"
             "        .type .Lbeginfor%" PRIu32 "_msg, @object\n"
             ".Lbeginfor%" PRIu32 "_msg:\n"
             "        .asciz \"%s\"\n"
             "        .size .Lbeginfor%" PRIu32 "_msg, .-.Lbeginfor%" PRIu32 "_msg\n\n"
             "        .section .text,\"ax\",@progbits\n\n"
             "        # xmm0=%s (FOR loop index variable)\n"
             "        movabsq $%s, %%rax        # rax = &%s\n"
             "                                           # pf=false, xmm0 is not SNaN\n"
             "                                           # pf=true, xmm0 is SNan\n"
             "        movs%c   (%%rax),%%xmm0               # xmm0 = *rax (float)\n"
             "        comis%c  %%xmm0, %%xmm0               # if xmm0 == SNaN, pf=true\n"
             "        jnp .LBEGINFOR%" PRIu32 "_0              # if pf then goto 0\n"
             "                                           # i.e., if xmm0 == SNaN then goto 0\n"
             "        # referenced scalar %s was SNaN, uninitialized\n"
             "        movabsq $.Luninitialized_forindex_msg, %%rcx  # input error message buffer variable address\n"
             "        movabsq $.LEBUF,%%rdi               # output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi          # output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx           # output zonepos variable address\n"
             "        movabsq $.Lappendbuffer, %%rax      # call appendbuffer\n"
             "        callq   *%%rax\n"
             "        movabsq $.Lbeginfor%" PRIu32 "_msg, %%rcx    # rcx = address of buffer with name of %s\n"
             "        {disp8} jmp .LBEGINFOR%" PRIu32 "_1      # goto 1\n"
             ".LBEGINFOR%" PRIu32 "_0:\n"
             "        # xmm1=%s (FOR loop increment variable)\n"
             "        movabsq $%s, %%rax         # rax = &%s\n"
             "        movs%c   (%%rax),%%xmm1               # xmm1 = *rax (%s)\n"
             "        comis%c  %%xmm1, %%xmm1               # if xmm1 == SNan, pf=true\n"
             "        jnp     .LBEGINFOR%" PRIu32 "_2          # if pf then goto 1\n"
             "                                           # i.e., if xmm1 == SNaN then goto 0\n"
             "        # referenced scalar %s was SNaN, uninitialized\n"
             "        movabsq $.Luninitialized_forinc_msg, %%rcx  # input error message buffer variable address\n"
             ".LBEGINFOR%" PRIu32 "_1:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                      # DOES NOT RETURN\n"
             ".LBEGINFOR%" PRIu32 "_2:\n"
             "        movabsq $%s, %%rax         # goto %s\n"
             "        jmpq    *%%rax\n"
             "%s:\n",
          instance_number, instance_number, ndex_var, instance_number, instance_number, ndex_var, ndex_var, ndex_var,
          (use_double?'d':'s'), (use_double?'d':'s'), instance_number, ndex_var, instance_number, ndex_var, instance_number,
          instance_number, inc_var, inc_var, inc_var, (use_double?'d':'s'), (use_double?"double":"float"),
          (use_double?'d':'s'), instance_number, inc_var, instance_number, instance_number, test_label, test_label, body_label);
  instance_number++;
  return;
}

//
// This functions emits the code for the EXIT FOR statement.  The done_label is
// a string containing the label at the end of the loop where control flow will
// transfer as a result of the EXIT FOR.  It has the format ".FORDONE####" and
// that value is generated by the sc_forstmt() function in the semantic_checks
// module.
//
void do_forloopexit(
    FILE *f,                  // File handle for assembly language output file
    const char *done_label) {  // pointer to buffer with ASCIIZ string containing the
                              // top of loop label used to do another iteration
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!done_label || !done_label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "done_label");
  fprintf(f, "        movabsq $%s,%%rax\n"
             "        jmpq    *%%rax\n", done_label);
  return;
}

//
// This function emits the code for the NEXT statement.  The synthetic variable
// for the increment created in doforloopstart() must be passed in the ndex_var
// parameter (.LFORINCREMENT####).  The label for the jump from next
// (.FORTEST####) to the loop termination test generated by the
// doforloopstart() must be passed in the tol_label parameter.  The label for
// the for loop termination (.LFORDONE####) generated by the doforloopstart()
// must be passed in the done_label parameter.  Finally, the loop index variable
// must be passed in the ndex_var parameter.  The actual implementation is
// contained in endfor.
//
void do_forloopend(
    FILE *f,                 // File handle for assembly language output file
    const char *ndex_var,    // pointer to buffer with ASCIIZ string containing the
                             // label for the loop index variable
    const char *inc_var,     // pointer to buffer with ASCIIZ string containing the
                             // label for the variable containing the increment value
    const char *limit_var,   // pointer to buffer with ASCIIZ string containing the
                             // label for the variable containing the limit value
    const char *test_label,  // pointer to buffer with ASCIIZ string containing the
                             // loop test exit condition label used to do another iteration
    const char *body_label,  // pointer to buffer with ASCIIZ string containing the
                             // loop body label used to do another iteration
    const char *done_label) {// pointer to buffer with ASCIIZ string containing the
                             // bottom of loop label used to jump out of the loop
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!ndex_var || !ndex_var[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "ndex_var");
  if (!inc_var || !inc_var[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "inc_var");
  if (!limit_var || !limit_var[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "limit_var");
  if (!test_label || !test_label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "test_label");
  if (!body_label || !body_label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "body_label");
  if (!done_label || !done_label[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "done_label");
  fprintf(f, "        .section .rodata,\"a\",@progbits\n\n"
             "        .type .Lendfor%" PRIu32 "_msg, @object\n"
             ".Lendfor%" PRIu32 "_msg:\n"
             "        .asciz \"%s\"\n"
             "        .size .Lendfor%" PRIu32 "_msg, .-.Lendfor%" PRIu32 "_msg\n"
             "        .section .text,\"ax\",@progbits\n\n"
             "        # FOR loop with index var %s body ends here\n"
             "        # FOR loop with index var %s increment starts here\n"
             "        # xmm0=%s (FOR loop index variable)\n"
             "        movabsq $%s, %%rax\n"
             "        movs%c   (%%rax),%%xmm0\n"
             "        comis%c  %%xmm0, %%xmm0\n"
             "        jnp     .LENDFOR%" PRIu32 "_0\n"
             "        # referenced scalar %s was NaN, uninitialized\n"
             "        movabsq $.Luninitialized_forindex_msg, %%rcx\n"
             "        movabsq $.LEBUF,%%rdi         # arg 1 output buffer variable address\n"
             "        movabsq $.Lebuf_next,%%rsi    # arg 2 output bufpos variable address\n"
             "        movabsq $.Lcurezone,%%rdx     # arg 3 output zonepos variable address\n"
             "        movabsq $.Lappendbuffer, %%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.Lendfor%" PRIu32 "_msg, %%rcx\n"
             "        {disp8} jmp .LENDFOR%" PRIu32 "_1\n"
             ".LENDFOR%" PRIu32 "_0:\n"
             "        # xmm1=%s (FOR loop increment variable)\n"
             "        movabsq $%s, %%rax\n"
             "        movs%c   (%%rax),%%xmm1\n"
             "        comis%c  %%xmm1, %%xmm1\n"
             "        jnp     .LENDFOR%" PRIu32 "_1\n"
             "        # referenced scalar %s was NaN, uninitialized\n"
             "        movabsq $.Luninitialized_forinc_msg, %%rcx\n"
             "        {disp8} jmp .LENDFOR%" PRIu32 "_2\n"
             ".LENDFOR%" PRIu32 "_1:\n"
             "        # increment FOR loop variable %s\n"
             "        movabsq $%s,%%rax\n",
          instance_number, instance_number, ndex_var, instance_number, instance_number, ndex_var, ndex_var,
          ndex_var, ndex_var, (use_double?'d':'s'), (use_double?'d':'s'), instance_number, ndex_var,
          instance_number, instance_number, instance_number, inc_var, inc_var, (use_double?'d':'s'),
          (use_double?'d':'s'), instance_number, inc_var, instance_number, instance_number, ndex_var, ndex_var);
  binary_add(f, "%xmm0", "%xmm1");
  fprintf(f, "        movs%c   %%xmm0,(%%rax)\n"
             "%s:\n"
             "        movabsq $%s, %%rax\n"
             "        movs%c   (%%rax),%%xmm2\n"
             "        comis%c  %%xmm2, %%xmm2\n"
             "        jnp     .LENDFOR%" PRIu32 "_3\n"
             "        # referenced scalar %s was NaN, uninitialized\n"
             "        movabsq $.Luninitialized_forlimit_msg, %%rcx\n"
             ".LENDFOR%" PRIu32 "_2:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             ".LENDFOR%" PRIu32 "_3:\n"
             "        # xmm0=%s-%s\n",
          (use_double?'d':'s'), test_label, limit_var, (use_double?'d':'s'), (use_double?'d':'s'),
          instance_number, limit_var, instance_number, instance_number, ndex_var, limit_var);
  binary_subtract(f, "%xmm0", "%xmm2");
  fprintf(f, "        # is %s positive?\n"
             "        xorpd   %%xmm3,%%xmm3\n"
             "        comis%c  %%xmm3,%%xmm1\n"
             "        jae     .LENDFOR%" PRIu32 "_4\n"
             "        # no, so multiply xmm0 by -1\n"
             "        xorpd   %%xmm4,%%xmm4\n"
             "        mov%c    $.LFLOATNEGONE,%%%cax\n"
             "        mov%c    %%%cax, %%xmm4\n",
          inc_var, (use_double?'d':'s'), instance_number, (use_double?'q':'l'), (use_double?'r':'e'),
          (use_double?'q':'d'), (use_double?'r':'e'));
  binary_multiply(f, "%xmm0", "%xmm4");
  fprintf(f, ".LENDFOR%" PRIu32 "_4:\n"
             "        # xmm0=(%s-%s)*SGN(%s)\n"
             "        # if xmm0 <= 0 then goto body_label else fall through\n"
             "        comis%c  %%xmm3,%%xmm0\n"
             "        ja      %s\n"
             "        movabsq $%s, %%rax\n"
             "        jmpq    *%%rax\n"
             "%s:\n"
             "        movabsq $%s, %%rax\n"
             "        mov%s    $.LSNaN,%%r15%s\n"
             "        mov%c    %%r15%s,(%%rax)  # %s is now uninitialized again\n"
             "        # illegal jumps into the FOR loop with index var\n"
             "        # %s can be detected by checking if %s is SNaN\n",
          instance_number, ndex_var, limit_var, inc_var, (use_double?'d':'s'), done_label,
          body_label, done_label, inc_var, (use_double?"absq":"l   "), (use_double?"":"d"),
          (use_double?'q':'l'), (use_double?"":"d"), inc_var, ndex_var, inc_var);
  instance_number++;
  return;
}

//
// This function emits the code for the TAB() function call to adjust the
// current column output buffer position.
// Only the integer part of the floating point value will be used.
//
void do_tab(
    FILE *f,                  // File handle for assembly language output file
    const char *fpregname) {  // pointer to buffer with ASCIIZ string containing the
                              // name of the register specifying the column number
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        # tab(%s)\n"
             "        cvts%c2si %s,%%rcx  #   rcx = (int64_t)%s\n"
             "        subq    $4,%%rsp              # allocate 4 byte temp for MXCSR\n"
             "        stmxcsr (%%rsp)               # temp = MXCSR\n"
             "        testl   $.LFE_INVALID,(%%rsp) # if !temp.FE_INVALID then\n"
             "        jz      .LTABM%" PRIu32 "_0         # goto 0, using valid argument in rcx\n"
             "        # append ASCIIZ string version of %s value to output error buffer\n",
          fpregname, (use_double?'d':'s'), fpregname, fpregname, instance_number, fpregname);
  if (strcmp(fpregname, "%xmm0")!=0)
    fprintf(f, "        movq    %s,%%xmm0  # xmm0 = %s\n",
            fpregname, fpregname);
  fprintf(f, "        movabsq $.Lbadtabarg, %%rax\n"
             "        callq   *%%rax\n"
             "        movl    $1,%%ecx              # rcx = 1 (replacing the invalid argument\n"
             "                                     #          value with 1)\n"
             ".LTABM%" PRIu32 "_0:\n"
             "        addq    $4,%%rsp              # dellocate 4 bytes for copy of MXCSR\n"
             "        movabsq $.LOBUF,%%rdi         # output buffer variable address\n"
             "        movabsq $.Lobuf_next,%%rsi    # output bufpos variable address\n"
             "        movabsq $.Lcurzone,%%rdx      # output zonepos variable address\n"
             "        movabsq $.Ltab, %%rax         # call tab(%s)\n"
             "        callq   *%%rax\n",
          instance_number, fpregname);
  instance_number++;
  return;
}

//
// This function will emit code for an INPUT statement.  The nfmt parameter
// will contain the format string that specifies the type and number of
// fields.  Each byte of the ASCIIZ string will contain either an 'N' or
// an 'S'.  An 'N' indicates that a numeric (floating point) value is required.
// An 'S' indicates that a string value is required.  For example, given
// the Minimal BASIC statement:
// INPUT A,B$,C[1]
// the corresponding format string would be "NSN".
// The flushoutput() will flush any partial output from PRINT if there is any.
//
void do_INPUT(
    FILE *f,             // File handle for assembly language output file
    const char *fmt) {   // pointer to buffer with ASCIIZ string containing the
                         // internal compiler-generated format string for the
                         // INPUT statement.  Each byte of the ASCIIZ string will
                         // contain either an 'N' or an 'S'.  'N' indicates that
                         // a numeric (floating point) value is required.  'S'
                         // indicates that a string value is required.  The first
                         // byte has the code for the first item in the INPUT
                         // list, the second for the second item, etc.
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!fmt || !fmt[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fmt");
  fprintf(f, "        movabsq $%s, %%rdi\n"
             "        movabsq $.Ldoinput, %%rax\n"
             "        callq   *%%rax\n", fmt);
  return;
}

//
// This function will emit code for input from STDIN of a scalar numeric
// variable whose ASCIIZ name is passed in the parameter varname.
// The lno parameter is the BASIC source line number
// of the INPUT statement that required this input, and is used in generating
// error messages.  The slotno parameter is the index of the variable in the
// INPUT statement, zero-based.  So for INPUT I,J, the slotno for I is zero,
// and the slotno for J is one.
//
void do_input_nvar(
    FILE *f,                // File handle for assembly language output file
    const char *varname,    // pointer to buffer with ASCIIZ string containing the
                            // numeric scalar variable name
    const uint32_t slotno,  // zero-based index of the variable in the input statement
    const uint32_t lno) {   // Minimal BASIC line number of invoking INPUT statement
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  fprintf(f, "        # target needs to be something like .LLINE0100\n"
             "        # scalar numeric INPUT %s (convert, check for overflow, save in temp slot)\n"
             "        movabsq $.Lrt_nput_stack, %%r15\n"
             "        movabsq $%" PRIu32 ",%%rax                       # slot number %" PRIu32 " on .Lrt_nput_stack\n"
             "        movabsq $((2 * .LMAX_STRING_BYTES) + 2),%%r9    # width of a record on .Lrt_nput_stack\n"
             "        mulq    %%r9\n"
             "        leaq    1(%%r15,%%rax),%%rdi # 1st arg is ASCIZ buffer\n"
             "        xorl    %%esi, %%esi        # 2nd arg is NULL\n"
             "        movabsq $.Lstrtod, %%rax   # call code to do actual conversion from ASCIIZ to floating point\n"
             "        callq   *%%rax\n"
             "        %s %%xmm0, %%xmm1\n"
             "        # if xmm1 is +Infinity then overflow\n"
             "        mov%s $.LPInf,%%r13%s     # move constant +INF into r13\n"
             "        mov%c %%r13%s,%%xmm0\n"
             "        comis%c  %%xmm1,%%xmm0\n"
             "        jne     .LNPUTNVAR%" PRIu32 "_0\n"
             "        # got overflow\n"
             "        movabsq $.Loverflow_msg,%%rsi\n"
             "        movabsq $.Lexception_non_fatal,%%r13\n"
             "        callq   *%%r13\n"
             "        movabsq $.LLINE%04" PRIu32 ",%%rax\n"
             "        jmpq    *%%rax\n"
             ".LNPUTNVAR%" PRIu32 "_0:\n"
             "        movabsq $.Lrt_nput_stack, %%r15\n"
             "        movabsq $%" PRIu32 ",%%rax\n"
             "        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %%r9\n"
             "        mulq    %%r9\n"
             "        movs%c   %%xmm1,1(%%r15,%%rax)\n",
          varname, slotno, slotno, (use_double?"movapd  ":"cvtsd2ss"), (use_double?"absq":"l   "), (use_double?"":"d"),
          (use_double?'q':'d'), (use_double?"":"d"), (use_double?'d':'s'), instance_number, lno, instance_number, slotno,
          (use_double?'d':'s'));
  instance_number++;
  return;
}

//
// This function will emit code for input from STDIN of a scalar string
// variable whose ASCIIZ name is passed in the parameter varname.
//
void do_input_svar(
    FILE *f,                // File handle for assembly language output file
    const char *varname) {  // pointer to buffer with ASCIIZ string containing the
                            // string variable name
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  fprintf(f, "# scalar string INPUT %s (do nothing right now, already in temp slot)\n",
          varname);
  return;
}

//
// This function will emit code for input from STDIN of an array numeric
// variable whose ASCIIZ name is passed in the parameter varname.
// The lno parameter is the BASIC source line number
// of the INPUT statement that required this input, and is used in generating
// error messages.  The slotno parameter is the index of the variable in the
// INPUT statement, zero-based.  So for INPUT I,J, the slotno for I is zero,
// and the slnot for J is one.  Uses xmm0 and xmm1 (hard-coded).
//
void do_input_navar(
    FILE *f,                // File handle for assembly language output file
    const char *varname,    // pointer to buffer with ASCIIZ string containing the
                            // numeric array variable name
    const uint32_t slotno,  // zero-based index of the variable in the input statement
    const uint32_t lno) {   // Minimal BASIC line number of invoking INPUT statement
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  do_input_nvar(f, varname, slotno, lno);
  return;
}

//
// This function is used to copy the temporary value input for a scalar numeric
// variable from the temporary slot specified by slotno to the actual variable
// specified by varname.
//
void do_input_nvar_phase2(
    FILE *f,                  // File handle for assembly language output file
    const char *varname,      // pointer to buffer with ASCIIZ string containing the
                              // label for the destination scalar numeric variable
    const uint32_t slotno) {  // zero-based index of the variable in the input statement
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (slotno==0)
    fputs("        # INPUT ok, copy from temp locations to real locations\n", f);
  fprintf(f, "        # scalar numeric INPUT %s phase 2\n"
             "        movabsq $.Lrt_nput_stack, %%r15\n", varname);
  switch (slotno) {
    case 0:
      fprintf(f, "        movs%c    1(%%r15),%%xmm1\n", (use_double?'d':'s'));
      break;
    case 1:
      fprintf(f, "        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %%rax\n"
                 "        movs%c   1(%%r15,%%rax),%%xmm1\n", (use_double?'d':'s'));
      break;
    default:
      fprintf(f, "        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %%r9\n"
                 "        movabsq $%" PRIu32 ", %%rax\n"
                 "        mulq    %%r9\n"
                 "        movs%c   1(%%r15,%%rax),%%xmm1\n",
              slotno, (use_double?'d':'s'));
      break;
  }
  fprintf(f, "        movabsq $%s, %%r14\n"
             "        movs%c   %%xmm1, (%%r14)\n",
          varname, (use_double?'d':'s'));
  return;
}

//
// This function is used to copy the temporary value input for a scalar string
// variable from the temporary slot specified by slotno to the actual variable
// specified by varname.
//
void do_input_svar_phase2(
    FILE *f,                  // File handle for assembly language output file
    const char *varname,      // pointer to buffer with ASCIIZ string containing the
                              // label for the destination scalar string variable
    const uint32_t slotno) {  // zero-based index of the variable in the input statement
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (slotno==0)
    fputs("        # INPUT ok, copy from temp locations to real locations\n", f);
  fprintf(f, "        # scalar string INPUT %s phase 2\n"
             "        movabsq $.Lrt_nput_stack, %%r15\n"
             "        # second argument to mystrcpy is source in rsi\n",
         varname);
  switch (slotno) {
    case 0:
      fputs("        leaq    1(%r15),%rsi\n", f);
      break;
    case 1:
      fputs("        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %rax\n"
            "        leaq    1(%r15,%rax),%rsi\n", f);
      break;
    default:
      fprintf(f, "        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %%r9\n"
                 "        movabsq $%" PRIu32 ", %%rax\n"
                 "        mulq    %%r9\n"
                 "        leaq    1(%%r15,%%rax),%%rsi\n",
              slotno);
      break;
  }
  fprintf(f, "        # first argument to mystrcpy is destination in rdi\n"
             "        movabsq $%s, %%rdi\n"
             "        movabsq $.Lmystrcpy, %%rax\n"
             "        callq   *%%rax\n",
          varname);
  return;
}

//
// This function is used to copy the temporary value input for an array numeric
// variable from the temporary slot specified by slotno to the actual variable
// specified by varname.  The maximum permitted index for the first dimension
// is passed in the maxrows parameter, and the maximum permitted index for the
// second dimension is passed in the maxcolumns parameter.  If the array is
// one-dimensional (vector) then maxcolumns must be zero.  The maxrows and
// maxcolumns values are used for array index bounds checking.
//
void do_input_1D_navar_phase2(
    FILE *f,                   // File handle for assembly language output file
    const char *varname,       // pointer to buffer with ASCIIZ string containing the
                               // array name
    const uint32_t maxcolumns, // the highest permitted value for the subscript
    const uint32_t slotno,     // zero-based index of the variable in the input statement
    const char *colreg,        // pointer to buffer with ASCIIZ string containing the
                               // name of the floating point register containing the
                               // subscript value
    const char *destreg) {     // pointer to buffer with ASCIIZ string containing the
                               // name of the destination floating point register
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!colreg || !colreg[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "colreg");
  if (!destreg || !destreg[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "destreg");
  fprintf(f, "        # INPUT ok, copy from temp locations to real locations\n"
             "        # array numeric INPUT %s phase 2\n"
             "        movabsq $.Lrt_nput_stack, %%r15\n",
          varname);
  switch(slotno) {
    case 0:
      fprintf(f, "        movs%c   1(%%r15),%s\n", (use_double?'d':'s'), destreg);
      break;
    case 1:
      fprintf(f, "        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %%rax\n"
                 "        movs%c   1(%%r15,%%rax),%s\n", (use_double?'d':'s'), destreg);
      break;
    default:
      fprintf(f, "        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %%r9\n"
                 "        movabsq $%" PRIu32 ", %%rax\n"
                 "        mulq    %%r9\n"
                 "        movs%c   1(%%r15,%%rax),%s\n",
              slotno, (use_double?'d':'s'), destreg);
      break;
  }
  dostore_1D_navar(f, varname, maxcolumns, colreg, destreg);
  return;
}

//
// This function is used to copy the temporary value input for an array numeric
// variable from the temporary slot specified by slotno to the actual variable
// specified by varname.  The maximum permitted index for the first dimension
// is passed in the maxrows parameter, and the maximum permitted index for the
// second dimension is passed in the maxcolumns parameter.  If the array is
// one-dimensional (vector) then maxcolumns must be zero.  The maxrows and
// maxcolumns values are used for array index bounds checking.
//
void do_input_2D_navar_phase2(
    FILE *f,                   // File handle for assembly language output file
    const char *varname,       // pointer to buffer with ASCIIZ string containing the
                               // array name
    const uint32_t maxrows,    // the highest permitted value for the first subscript
    const uint32_t maxcolumns, // the highest permitted value for the second subscript
    const uint32_t slotno,     // zero-based index of the variable in the input statement
    const char *rowreg,        // pointer to buffer with ASCIIZ string containing the
                               // name of the floating point register containing the
                               // first subscript value
    const char *colreg,        // pointer to buffer with ASCIIZ string containing the
                               // name of the floating point register containing the
                               // second subscript value
    const char *destreg) {     // pointer to buffer with ASCIIZ string containing the
                               // name of the destination floating point register
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!rowreg || !rowreg[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rowreg");
  if (!colreg || !colreg[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "colreg");
  if (!destreg || !destreg[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "destreg");
  fprintf(f, "        # INPUT ok, copy from temp locations to real locations\n"
             "        # array numeric INPUT %s phase 2\n"
             "        movabsq $.Lrt_nput_stack, %%r15\n", varname);
  switch (slotno) {
    case 0:
      fprintf(f, "        movs%c   1(%%r15),%s\n", (use_double?'d':'s'), destreg);
      break;

    case 1:
      fprintf(f, "        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %%rax\n"
                 "        movs%c   1(%%r15,%%rax),%s\n",
              (use_double?'d':'s'), destreg);
      break;
    default:
      fprintf(f, "        movabsq $((2 * .LMAX_STRING_BYTES) + 2), %%r9\n"
                 "        movabsq $%" PRIu32 ", %%rax\n"
                 "        mulq    %%r9\n"
                 "        movs%c   1(%%r15,%%rax),%s\n",
              slotno, (use_double?'d':'s'), destreg);
      break;
  }
  dostore_2D_navar(f, varname, maxrows, maxcolumns, rowreg, colreg, destreg);
  return;
}

//
// This function emits code for the READ statement when the destination
// is a numeric scalar variable.  The varname
// parameter is the name of the scalar numeric variable where the
// value read from the DATA list will be stored.
//
void do_read_nvar(
    FILE *f,                // File handle for assembly language output file
    const char *varname) {  // pointer to buffer with ASCIIZ string containing the
                            // name of the destination floating point register
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  fprintf(f, "        # scalar numeric READ %s\n"
             "        movabsq $.Ldata_item_ptr, %%rax\n"
             "        movq    (%%rax), %%rax\n"
             "        movabsq $.Ldata_item_count, %%rbx\n"
             "        movq    (%%rbx), %%rbx\n"
             "        cmpq    %%rbx, %%rax\n"
             "        jb      .LREADNVARM%" PRIu32 "_0\n"
             "        movabsq $.Lout_of_data_msg, %%rcx\n"
             "        {disp8} jmp .LREADNVARM%" PRIu32 "_1\n"
             ".LREADNVARM%" PRIu32 "_0:\n"
             "        movabsq $.Ldata_items, %%rbx     # base of data_items array of struct pointers\n"
             "        movq    (%%rbx,%%rax,8),%%rax      # load pointer value in slot rax\n"
             "        cmpb    $2,(%%rax)               # unquoted string?\n"
             "        je      .LREADNVARM%" PRIu32 "_2\n"
             "        movabsq $.Lbad_number_read_msg, %%rcx\n"
             ".LREADNVARM%" PRIu32 "_1:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             ".LREADNVARM%" PRIu32 "_2:\n"
             "        # ok, load double 2 bytes into that structure into xmm0\n"
             "        movs%c   1(%%rax),%%xmm0\n"
             "        movabsq $%s, %%rax\n"
             "        movs%c   %%xmm0,(%%rax)\n"
             "        movabsq $.Ldata_item_ptr, %%rax\n"
             "        incq    (%%rax)          # increment data_item_ptr in memory but not register\n"
             "        mov%s $.LPInf,%%r15%s\n"
             "        mov%c    %%r15%s,%%xmm1\n"
             "        ucomis%c  %%xmm1,%%xmm0\n"
             "        jne     .LREADNVARM%" PRIu32 "_3\n"
             "        {disp8} jmp .LREADNVARM%" PRIu32 "_4\n"
             ".LREADNVARM%" PRIu32 "_3:\n"
             "        mov%s $.LNInf,%%r15%s\n"
             "        mov%c    %%r15%s,%%xmm1     # temp = -INF\n"
             "        ucomis%c  %%xmm1,%%xmm0\n"
             "        jne     .LREADNVARM%" PRIu32 "_5\n"
             ".LREADNVARM%" PRIu32 "_4:\n"
             "        # overflow message\n"
             "        movabsq $.Loverflow_msg,%%rsi\n"
             "        movabsq $.Lexception_non_fatal,%%r15\n"
             "        callq   *%%r15\n"
             ".LREADNVARM%" PRIu32 "_5:\n",
          varname, instance_number, instance_number, instance_number, instance_number, instance_number,
          instance_number, (use_double?'d':'s'), varname, (use_double?'d':'s'), (use_double?"absq":"l   "),
          (use_double?"":"d"), (use_double?'q':'d'), (use_double?"":"d"), (use_double?'d':'s'), instance_number,
          instance_number, instance_number, (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?'q':'d'),
          (use_double?"":"d"), (use_double?'d':'s'), instance_number, instance_number, instance_number);
  instance_number++;
  return;
}

//
// This function emits code for the READ statement when the destination
// is a scalar string variable.  The varname
// parameter is the name of the scalar string variable where the
// value read from the DATA list will be stored.
//
void do_read_svar(
    FILE *f,                // File handle for assembly language output file
    const char *varname) {  // pointer to buffer with ASCIIZ string containing the
                            // name of the scalar string variable
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  fprintf(f, "        # READ %s\n"
             "        movabsq $.Ldata_item_ptr, %%rax\n"
             "        movq    (%%rax), %%rax\n"
             "        movabsq $.Ldata_item_count, %%rbx\n"
             "        movq    (%%rbx), %%rbx\n"
             "        cmpq    %%rbx, %%rax\n"
             "        jb      .LREADSVARM%" PRIu32 "_0\n"
             "        movabsq $.Lout_of_data_msg, %%rcx\n"
             "        {disp8} jmp .LREADSVARM%" PRIu32 "_2\n"
             ".LREADSVARM%" PRIu32 "_0:\n"
             "        movabsq $.Ldata_items, %%rbx     # base of data_items array of struct pointers\n"
             "        movq    (%%rbx,%%rax,8),%%rsi      # load pointer value in slot rax\n"
             "        cmpb    $2,(%%rsi)               # unquoted string?\n"
             "        jne     .LREADSVARM%" PRIu32 "_1\n"
             "        movq    %u(%%rsi),%%rsi            # load string pointer %u bytes into that structure into rsi\n"
             "        {disp8} jmp .LREADSVARM%" PRIu32 "_4\n"
             ".LREADSVARM%" PRIu32 "_1:\n"
             "        cmpb    $0,(%%rsi)               # quoted string?\n"
             "        je      .LREADSVARM%" PRIu32 "_3\n"
             "        movabsq $.Lbad_string_read_msg, %%rcx\n"
             ".LREADSVARM%" PRIu32 "_2:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                   # DOES NOT RETURN\n"
             ".LREADSVARM%" PRIu32 "_3:\n"
             "        movq    2(%%rsi),%%rsi            # load string pointer 2 bytes into that structure into rsi\n"
             ".LREADSVARM%" PRIu32 "_4:\n"
             "        movabsq $%s, %%rdi\n"
             "        movabsq $.Lmystrcpy, %%rax\n"
             "        callq   *%%rax\n"
             "        movabsq $.Ldata_item_ptr, %%rax\n"
             "        incq    (%%rax)                  # increment data_item_ptr\n",
          varname, instance_number, instance_number, instance_number, instance_number, (use_double?10:6), (use_double?10:6),
          instance_number, instance_number, instance_number, instance_number, instance_number, instance_number, varname);
  instance_number++;
  return;
}

//
// This function emits code for the READ statement when the destination is a
// numeric array variable.  The varname parameter is
// the name of the numeric array variable where the value read from the DATA
// list will be stored.  Note that this function calls dostore_navar() to store the value
// read from the xmm0 register, and that dstore_navar() does the required array
// bounds checking.
//
void do_read_1D_navar(
    FILE *f,                          // File handle for assembly language output file
    const char *varname,              // pointer to buffer with ASCIIZ string containing the
                                      // array name
    const uint32_t maxcolumns,        // the highest permitted value for the subscript
    const char *column_fpregname,     // pointer to buffer with ASCIIZ string containing the
                                      // name of the floating point register containing the
                                      // subscript value
    const char *destreg) {            // pointer to buffer with ASCIIZ string containing the
                                      // name of a floating point register that contains the
                                      // expression to store in the array
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!destreg || !destreg[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "destreg");
  if (!column_fpregname || !column_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "column_fpregname");
  fprintf(f, "        # 1D array numeric READ into %s\n"
             "        movq    %s,%%rax\n"
             "        pushq   %%rax\n"
             "        movabsq $.Ldata_item_ptr, %%rax\n"
             "        movq    (%%rax), %%rax\n"
             "        movabsq $.Ldata_item_count, %%rbx\n"
             "        movq    (%%rbx), %%rbx\n"
             "        cmpq    %%rbx, %%rax\n"
             "        jb      .LRNAV1DM%" PRIu32 "_0\n"
             "        movabsq $.Lout_of_data_msg, %%rcx\n"
             "        {disp8} jmp .LRNAV1DM%" PRIu32 "_1\n"
             ".LRNAV1DM%" PRIu32 "_0:\n"
             "        movabsq $.Ldata_items, %%rbx     # base of data_items array of struct pointers\n"
             "        movq    (%%rbx,%%rax,8),%%rax      # load pointer value in slot rax\n"
             "        cmpb    $2,(%%rax)               # number?\n"
             "        je      .LRNAV1DM%" PRIu32 "_2\n"
             "        movabsq $.Lbad_number_read_msg, %%rcx\n"
             ".LRNAV1DM%" PRIu32 "_1:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             ".LRNAV1DM%" PRIu32 "_2:\n"
             "        # ok, load %s to offset 2 bytes into that structure into %s\n"
             "        movs%c   1(%%rax),%s\n"
             "        movabsq $.Ldata_item_ptr, %%rax\n"
             "        incq    (%%rax)                  # increment data_item_ptr in memory but not register\n"
             "        mov%s $.LPInf,%%r15%s\n"
             "        mov%c    %%r15%s,%s\n"
             "        ucomis%c  %s,%s\n"
             "        jne     .LRNAV1DM%" PRIu32 "_3\n"
             "        {disp8} jmp .LRNAV1DM%" PRIu32 "_4\n"
             ".LRNAV1DM%" PRIu32 "_3:\n"
             "        mov%s $.LNInf,%%r15%s\n"
             "        mov%c    %%r15%s,%s\n"
             "        ucomis%c %s,%s\n"
             "        jne     .LRNAV1DM%" PRIu32 "_5\n"
             ".LRNAV1DM%" PRIu32 "_4:\n"
             "        # overflow message\n"
             "        movabsq $.Loverflow_msg,%%rsi\n"
             "        movabsq $.Lexception_non_fatal,%%r15\n"
             "        callq   *%%r15\n"
             ".LRNAV1DM%" PRIu32 "_5:\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%s\n",
          varname, column_fpregname, instance_number, instance_number, instance_number, instance_number,
          instance_number, instance_number, (use_double?"double":"float"), destreg, (use_double?'d':'s'), destreg,
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?'q':'d'), (use_double?"":"d"), column_fpregname,
          (use_double?'d':'s'), column_fpregname, destreg, instance_number, instance_number, instance_number,
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?'q':'d'), (use_double?"":"d"),
          column_fpregname, (use_double?'d':'s'), column_fpregname, destreg, instance_number, instance_number,
          instance_number, column_fpregname);
  dostore_1D_navar(f, varname, maxcolumns, column_fpregname, destreg);
  instance_number++;
  return;
}

//
// This function emits code for the READ statement when the destination is a
// numeric array variable.  The varname parameter is
// the name of the numeric array variable where the value read from the DATA
// list will be stored.  Note that this function calls dostore_navar() to store the value
// read from the xmm0 register, and that dstore_navar() does the required array
// bounds checking.
//
void do_read_2D_navar(
    FILE *f,                        // File handle for assembly language output file
    const char *varname,            // pointer to buffer with ASCIIZ string containing the
                                    // array name
    const uint32_t maxrows,         // the highest permitted value for the first subscript
    const uint32_t maxcolumns,      // the highest permitted value for the second subscript
    const char *row_fpregname,      // pointer to buffer with ASCIIZ string containing the
                                    // name of the floating point register containing the
                                    // first subscript value
    const char *column_fpregname,   // pointer to buffer with ASCIIZ string containing the
                                    // name of the floating point register containing the
                                    // second subscript value
    const char *destreg) {          // pointer to buffer with ASCIIZ string containing the
                                    // name of a floating point register that contains the
                                    // expression to store in the array
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!destreg || !destreg[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "destreg");
  if (!column_fpregname || !column_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "column_fpregname");
  if (!row_fpregname || !row_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "row_fpregname");
  fprintf(f, "        # 2D array numeric READ into %s\n"
             "        movq    %s,%%rax\n"
             "        pushq   %%rax\n"
             "        movabsq $.Ldata_item_ptr, %%rax\n"
             "        movq    (%%rax), %%rax\n"
             "        movabsq $.Ldata_item_count, %%rbx\n"
             "        movq    (%%rbx), %%rbx\n"
             "        cmpq    %%rbx, %%rax\n"
             "        jb      .LRNAV2DM%" PRIu32 "_0\n"
             "        movabsq $.Lout_of_data_msg, %%rcx\n"
             "        {disp8} jmp .LRNAV2DM%" PRIu32 "_1\n"
             ".LRNAV2DM%" PRIu32 "_0:\n"
             "        movabsq $.Ldata_items, %%rbx     # base of data_items array of struct pointers\n"
             "        movq    (%%rbx,%%rax,8),%%rax      # load pointer value in slot rax\n"
             "        cmpb    $2,(%%rax)               # number?\n"
             "        je      .LRNAV2DM%" PRIu32 "_2\n"
             "        movabsq $.Lbad_number_read_msg, %%rcx\n"
             ".LRNAV2DM%" PRIu32 "_1:\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             ".LRNAV2DM%" PRIu32 "_2:\n"
             "        # ok, load %s 2 bytes into that structure into %s\n"
             "        movs%c   1(%%rax),%s\n"
             "        movabsq $.Ldata_item_ptr, %%rax\n"
             "        incq    (%%rax)                  # increment data_item_ptr in memory but not register\n"
             "        mov%s $.LPInf,%%r15%s\n"
             "        mov%c    %%r15%s,%s\n"
             "        ucomis%c %s,%s\n"
             "        jne     .LRNAV2DM%" PRIu32 "_3\n"
             "        {disp8} jmp .LRNAV2DM%" PRIu32 "_4\n"
             ".LRNAV2DM%" PRIu32 "_3:\n"
             "        mov%s $.LNInf,%%r15%s\n"
             "        mov%c    %%r15%s,%s # %s = -INF\n"
             "        ucomis%c  %s,%s\n"
             "        jne     .LRNAV2DM%" PRIu32 "_5\n"
             ".LRNAV2DM%" PRIu32 "_4:\n"
             "        # overflow message\n"
             "        movabsq $.Loverflow_msg,%%rsi\n"
             "        movabsq $.Lexception_non_fatal,%%r15\n"
             "        callq   *%%r15\n"
             ".LRNAV2DM%" PRIu32 "_5:\n"
             "        popq    %%rax\n"
             "        movq    %%rax,%s\n",
          varname, column_fpregname, instance_number, instance_number, instance_number, instance_number,
          instance_number, instance_number, destreg, (use_double?"double":"float"), (use_double?'d':'s'), destreg,
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?'q':'d'), (use_double?"":"d"), column_fpregname,
          (use_double?'d':'s'), column_fpregname, destreg, instance_number, instance_number, instance_number,
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?'q':'d'), (use_double?"":"d"), column_fpregname,
          column_fpregname, (use_double?'d':'s'),  column_fpregname, destreg, instance_number, instance_number,
          instance_number, column_fpregname);
  dostore_2D_navar(f, varname, maxrows, maxcolumns, row_fpregname, column_fpregname, destreg);
  instance_number++;
  return;
}

//
// This function emits code to implement the Minimal BASIC RESTORE statement.
// This will reset the DATA statement pointer to the very first data item.
//
void do_restore(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fputs("        # RESTORE data pointer\n"
        "        movabsq $.Ldata_item_ptr, %rax     # store a zero into the data_item_ptr\n"
        "        movq    $0, (%rax)                 # so it points to the first data item\n", f);
  return;
}

//
// This function emits code to call a UDF.  If an argument is required, it
// must be in fpregname before calling this function.  After the function returns,
// the return value will be left in fpregname.
//
void do_call_udf(
    FILE *f,                    // File handle for assembly language output file
    const char *udfname,  // pointer to buffer with ASCIIZ string containing the
                                // name of the user-defined function
    const char *fpregname) {    // pointer to buffer with ASCIIZ string containing the
                                // name of the floating point register to use
                                // to hold the input argument value and also the
                                // output result value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!udfname || !udfname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "udfname");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        pushq   %%rbp                       # create stack frame\n"
             "        movq    %%rsp, %%rbp\n"
             "        pushq   %%r11                       # save current value of r11 on the stack\n"
             "        movq    %s,%%r11         # r11 = %s\n"
             "        andq    $-16, %%rsp                 # align the stack on a 16-byte boundary\n"
             "                                           # save total FPU status\n"
             "        subq    $512,%%rsp                  # allocate 512 byte FPU save area\n"
             "        fxsave64 (%%rsp)                    # and save FPU state there\n"
             "        movq    %%r11,%%xmm0                 # xmm0 = r11\n"
             "        movabsq $.L%s,%%rax        # call the UDF which leaves the result in xmm0\n"
             "        callq   *%%rax\n"
             "        movq    %%xmm0,%%r11                 # r11 = xmm0\n"
             "        fxrstor64 (%%rsp)                   # restore FPU state from save area\n"
             "        addq    $512,%%rsp                  # deallocate 512 byte FPU save area\n"
             "        movq    %%r11,%s         # %s = r11\n"
             "        popq    %%r11                       # restore value of r11 from the stack\n"
             "        movq    %%rbp, %%rsp                 # destroy stack frame\n"
             "        popq    %%rbp\n",
          fpregname, fpregname, udfname, fpregname, fpregname);
  return;
}

//
// This function emits code for the beginning of a UDF.
// The fname parameter is the name of the UDF, and the argname
// parameter is the name of the UDF's argument.  If the UDF does not have an
// argument, argname should be NULL.  The UDFs use a register calling convention
// so if there is an argument, it will be passed in xmm0.
//
void do_udf_header(
    FILE *f,                // File handle for assembly language output file
    const char *udfname,    // pointer to buffer with ASCIIZ string containing the
                            // name of the user-defined function
    const char *argname) {  // pointer to buffer with ASCIIZ string containing the
                            // name of the floating point register to use
                            // to hold the input argument value
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!udfname || !udfname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "udfname");
  if (argname && argname[0]) { // if this UDF has an argument
    fprintf(f, "        .section .data,\"aw\",@progbits\n\n"
               "        #\n"
               "        # the argument is a unique local variable only visible to the\n"
               "        # expression in the body of the UDF\n"
               "        #\n"
               ".L%s_%s:\n"
               "        .%s .LSNaN # %u bytes, %s initialized to SNaN\n"
               "        .size .L%s_%s, .-.L%s_%s\n\n",
            udfname, argname, (use_double?"quad":"long"), (use_double?8U:4U),
            (use_double?"double":"float"), udfname, argname, udfname, argname);
    if (extensions)
      fprintf(f, "         #\n"
                 "         # if -X is enabled, the code will generate a warning if the\n"
                 "         # function takes an argument and the value of the argument\n"
                 "         # when the function is called is +/- INF, so we need to have\n"
                 "         # a string with the UDF name in it for displaying the warning\n"
                 "         #\n"
                 "        .type .L%s_msg, @object\n"
                 ".L%s_msg:\n"
                 "        .asciz \"%s(\"\n"
                 "        .size .L%s_msg, .-.L%s_msg\n\n",
              udfname, udfname, udfname, udfname, udfname);
  }
  fprintf(f, "        .section .text,\"ax\",@progbits\n\n"
             "        #\n"
             "        # this is called before the UDF expression code has been emitted\n"
             "        # and if there is an argument to UDF, then that value is in xmm0\n"
             "        #\n"
             "        .type   .L%s, @function\n"
             ".L%s:\n"
             "        pushq   %%rbp                       # create stack frame\n"
             "        movq    %%rsp, %%rbp\n",
           udfname, udfname);
  if (argname && argname[0]) {
    fprintf(f, "        movabsq $.L%s_%s, %%r15  # r15 = address of\n"
               "                                                     # UDF's argument\n"
               "        # store function argument value %s\n"
               "        movs%c    %%xmm0,(%%r15)              #       *r15 = xmm0\n",
            udfname, argname, argname, (use_double?'d':'s'));
    if (extensions)
      fprintf(f, "        movq    %%xmm0,%%r14                 #     r14 = xmm0\n"
                 "        btr%c    $%" PRIu32 ",%%r14%s                  #       r14%s = abs(r14%s)   (%s)\n"
                 "        mov%s $.LPInf,%%r15%s              #       r15%s = +INF       (%s)\n"
                 "        cmp%c    %%r14%s,%%r15%s                #       compare abs(UDF argument value) to +INF\n"
                 "        jne     .LUDFM%" PRIu32 "_0              #     if abs(UDF argument value) != +INF then\n"
                 "                                           #     goto 0\n"
                 "        movabsq $.L%s_msg,%%r15    #     input string address\n"
                 "        movabsq $.Lbadudfarg, %%rax\n"
                 "        callq *%%rax\n"
                 ".LUDFM%" PRIu32 "_0:\n",
              (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"), (use_double?"":"d"),
              (use_double?"double":"float"), (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"),
              (use_double?"double":"float"), (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
              instance_number, udfname, instance_number);
  }
  instance_number++;
  return;
}

//
// This function emits code for the end of a UDF.
// The fname parameter is the name of the UDF.  The body of the UDF is an
// arithmetic expression and the computed value will be left in fpregname.
// This function will move that into the xmm0 register before actually
// returning from the UDF.  The UDFs use a register calling convention, and the
// return value must be in xmm0.
//
void do_udf_footer(
    FILE *f,                  // File handle for assembly language output file
    const char *udfname,      // pointer to buffer with ASCIIZ string containing the
                              // name of the user-defined function, such as FNA
    const char *fpregname) {  // pointer to buffer with ASCIIZ string containing the
                              // name of the floating point register to use
                              // to hold the output result value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!udfname || !udfname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "udfname");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fputs("#\n"
        "# this code is emitted after the UDF expression code has been emitted\n"
        "# and that code leaves the result of evaluating that expression in xmm0\n"
        "#\n"
        "        # return value needs to be in xmm0\n", f);
  if (strcmp(fpregname, "%xmm0")!=0)
    fprintf(f, "        movap%c  %s,%%xmm0        #       them move it's value to xmm0\n",
            (use_double?'d':'s'), fpregname);
  fprintf(f, "        movq    %%rbp,%%rsp                  # destroy stack frame\n"
             "        popq    %%rbp\n"
             "        retq\n"
             "        .size .L%s, .-.L%s\n",
          udfname, udfname);


  return;
}

//
// This procedure will emit code to setup the main runtime stack.
// This is actually the last code emitted to the assembly output.
// This procedure also emits the ELF identification string.
//
void gen_stack(
    FILE *f) {                // File handle for assembly language output file
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fprintf(f, "        # Configure runtime system stack\n"
             "        .section .note.GNU-stack,\"\",@progbits\n"
             "        # Low-level compiler identification information.\n"
             "        .ident \"Mr. Ham's ECMA-55 Minimal BASIC version %s for x86_64 Linux\"\n"
             "        .end\n", version);
  return;
}

//
// This function is used to write a comment line in the generated
// assembly language output.
// The fmt parameter is a format string like fprintf() uses.  The
// API for this function is the same as the well-known C standard
// library function fprintf().
//
void emit_comment(
    FILE *f,           // file handle of output assembly file
    const char *fmt,   // pointer to buffer with ASCIIZ string containing the
                       // fprintf() style format string
    ...) {
  va_list arg;
  char buffer[COMMENT_BUFFER_MAX];

  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!fmt || !fmt[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fmt");
  snprintf(buffer, COMMENT_BUFFER_MAX, "        # %s\n", fmt);
  buffer[COMMENT_BUFFER_MAX - 2U] = '\n'; // chop, and ensure last non-null byte is a newline
  buffer[COMMENT_BUFFER_MAX - 1U] = 0;    // and that last byte is null
  va_start(arg, fmt);
  vfprintf(f, buffer, arg);
  va_end(arg);
  return;
}

//
// This function will emit code to copy the contents of a floating
// point register to another floating point register.  It is essentially
// equal to
//
//   freg2=freg1
//
void freg_to_freg(
    FILE *f,              // file handle of output assembly file
    const char *freg1,    // pointer to buffer with ASCIIZ string containing the
                          // source floating point register name
    const char *freg2) {  // pointer to buffer with ASCIIZ string containing the
                          // destination floating point register name
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!freg1 || !freg1[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "freg1");
  if (!freg2 || !freg2[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "freg2");
  fprintf(f, "        movap%c          %*s, %s # %s=%s\n", (use_double?'d':'s'),
          (int)strlen(freg1), freg1, freg2, freg2, freg1);
  return;
}

//
// This function emits a call that will do floating
// point addition.  It is essentially equal to
//
//    lhs_fpregname+=rhs_fpregname
//
void dofpadd(
    FILE *f,                      // file handle of output assembly file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting sum on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side addend expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  binary_add(f, lhs_fpregname, rhs_fpregname);
  fprintf(f, "                               # %s=%s+%s\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname);
  return;
}

//
// This function will emit code to raise the value specified in the
// lhs_regname to the power specified by the rhs_regname, and the
// result will be left in lhs_regname.
// This effect is semantically like this:
//
//   lhs_regname=lhs_regname^rhs_regname
//
// where '^' is the power operator.
//
void dofppow(
    FILE *f,                      // file handle of output assembly file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting value on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side exponent expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "                                # %s=%s^%s\n",
          lhs_fpregname, rhs_fpregname, lhs_fpregname);
  binary_power(f, lhs_fpregname, rhs_fpregname);
  return;
}

//
// This function emits a call that will do floating
// point multiplication.  It is essentially equal to
//
//    lhs_fpregname*=rhs_fpregname
//
void dofpmul(
    FILE *f,                      // file handle of output assembly file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting product on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side multiplier expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s=%s*%s\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname);
  binary_multiply(f, lhs_fpregname, rhs_fpregname);
  return;
}

//
// This function emits a call that will do floating
// point subtraction.  It is essentially equal to
//
//    lhs_fpregname-=rhs_fpregname
//
void dofpsub(
    FILE *f,                      // file handle of output assembly file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting difference on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side subtrahend expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "                                # %s=%s-%s\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname);
  binary_subtract(f, lhs_fpregname, rhs_fpregname);
  return;
}

//
// This function emits a call that will do floating
// point division.  It is essentially equal to
//
//    lhs_fpregname/=rhs_fpregname
//
void dofpdiv(
    FILE *f,                      // file handle of output assembly file
    const char *lhs_fpregname,    // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // left-hand side expression value on input and
                                  // the resulting quotient on output
    const char *rhs_fpregname) {  // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // right-hand side divisor expression value
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "                                # %s /= %s\n",
          lhs_fpregname, rhs_fpregname);
  binary_divide(f, lhs_fpregname, rhs_fpregname);
  return;
}

//
// This function emits a call that will do floating
// point unary minus.  It is essentially equal to
//
//    fpregname=-fpregname
//
void dofpneg(
    FILE *f,                      // file handle of output assembly file
    const char *fpregname) {      // pointer to buffer with ASCIIZ string containing the
                                  // name of the floating point register that holds the
                                  // value which will have its sign changed on input and
                                  // the resulting value on output
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        # %s=-%s\n"
             "        movq      %s, %%rax\n"
             "        pushf                            # save flags\n"
             "        btc%c      $%" PRIu32 ",%%%cax               # flip msb in %cax (flip sign bit for %s)\n"
             "        popf                             # and restore flags so cf is not modified\n"
             "        movq      %%rax,%s\n",
          fpregname, fpregname, fpregname, (use_double?'q':'l'), (use_double?63U:31U), (use_double?'r':'e'),
          (use_double?'r':'e'), (use_double?"double":"float"), fpregname);
  return;
}

//
// Function to emit code to load a float literal value into the specified xmm
// register.  The flitval is an ASCIIZ string containing the actual
// literal value for including in the generated comments.  The flitname parameter
// is the assembly identifier for the floating point literal value's address.
//
void load_float_literal(
    FILE *f,                   // file handle of output assembly file
    const char *flitname,      // pointer to buffer with ASCIIZ string containing the
                               // label for the literal value
    const char *flitval,       // pointer to buffer with ASCIIZ string containing the
                               // printable actual literal value
    const char *fpregname) {   // pointer to buffer with ASCIIZ string containing the
                               // destination register
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!flitname || !flitname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "flitname");
  if (!flitval || !flitval[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "flitval");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  fprintf(f, "        # %s = %s\n"
             "        movabsq $%s, %%rax       # rax = address of constant\n"
             "        movs%c   (%%rax), %s  # destfloatreg = value of constant\n"
             "        movq    %s,%%rax     # rax = %s\n"
             "        mov%s $.LPInf,%%%csi              # %csi = +INF\n"
             "        cmp%c    %%%csi, %%%cax                # compare %cax and %csi\n"
             "        jne     0f                        # if value is not +INF goto 0\n"
             "                                          # else report overflow exception\n"
             "        movabsq $.Loverflow_msg, %%rsi     # address of exception mesasge\n"
             "        movabsq $.Lexception_non_fatal, %%rax # address of exception function\n"
             "        callq   *%%rax                     # call exception function\n"
             "0:\n",
          fpregname, flitval, flitname, (use_double?'d':'s'), fpregname, fpregname, flitval,
          (use_double?"absq":"l   "), (use_double?'r':'e'), (use_double?'r':'e'),
          (use_double?'q':'l'), (use_double?'r':'e'), (use_double?'r':'e'), (use_double?'r':'e'),
          (use_double?'r':'e'));
  return;
}

//
// Function to emit code to load a scalar numeric variable's value into the specified xmm
// register.  The varname parameter is the assembly identifier for the
// scalar numeric variable.
//
void load_nvar(
    FILE *f,                   // file handle of output assembly file
    const char *varname,       // pointer to buffer with ASCIIZ string containing the
                               // name of the scalar numeric variable
    const char *fpregname) {   // pointer to buffer with ASCIIZ string containing the
                               // destination register
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!varname || !varname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "varname");
  if (!fpregname || !fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "fpregname");
  do_floatmem_to_floatreg(f, varname, fpregname, varname[0], varname[1]);
  return;
}

static void pushsaddr(
    FILE *f) {              // File handle for assembly language output file
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  fprintf(f, "        # push string string address in rdi onto dedicated string address stack\n"
             "        movabsq $.Lsoperand_stack_ptr, %%rdx\n"
             "        movq    (%%rdx), %%rbx\n"
             "        cmpq    $.Lsoperand_stack_size, %%rbx\n"
             "        jb      .LPUSHSADDR%" PRIu32 "_0\n"
             "        movabsq $.Lsstack_full_msg, %%rcx\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             ".LPUSHSADDR%" PRIu32 "_0:\n"
             "        movabsq $.Lsoperand_stack, %%rax\n"
             "        movq    %%rdi, (%%rax,%%rbx,8)\n"
             "        incq    %%rbx\n"
             "        movq    %%rbx, (%%rdx)\n",
          instance_number, instance_number);
  instance_number++;
  return;
}

static void popsaddr(
    FILE *f,                // File handle for assembly language output file
    const char *to) {       // Destination register for pointer to string
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!to || !to[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "to");
  fprintf(f, "        # pop string address from the dedicated string address stack into register %s\n"
             "        pushq   %%rax\n"
             "        pushq   %%rbx\n"
             "        pushq   %%rdx\n"
             "        movabsq $.Lsoperand_stack_ptr, %%rdx\n"
             "        movq    (%%rdx), %%rbx\n"
             "        testq   %%rbx, %%rbx\n"
             "        jnz     .LPOPSADDR%" PRIu32 "_0\n"
             "        movabsq $.Lsstack_empty_msg, %%rcx\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax\n"
             ".LPOPSADDR%" PRIu32 "_0:\n"
             "        decq    %%rbx\n"
             "        movq    %%rbx, (%%rdx)\n"
             "        movabsq $.Lsoperand_stack, %%rax\n"
             "        movq    (%%rax, %%rbx, 8), %s\n"
             "        popq    %%rdx\n"
             "        popq    %%rbx\n"
             "        popq    %%rax\n",
          to, instance_number, instance_number, to);
  instance_number++;
  return;
}

static void binary_subtract(
    FILE *f,                // File handle for assembly language output file
    const char *lhs_fpregname,
    const char *rhs_fpregname) {
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s -= %s\n"
             "        movq    %s,%%r12     # backup copy of augend in r12\n"
             "                             # since a failed add will destroy %s\n"
             "        subs%c   %s,%s   #  %s += %s (%s)\n"
             "        subq    $4,%%rsp               # allocate storage for temp copy of MXCSR\n"
             "        stmxcsr (%%rsp)                # temp = mxcsr\n"
             "        testl   $.LFE_INVALID,(%%rsp)  # if !temp.FE_INVALID\n"
             "        jz      .LBS%" PRIu32 "_2           # then goto 2\n"
             "        # OK, result was invalid - why?\n"
             "        addq    $4,%%rsp               # deallocate storage for temp copy of MXCSR\n"
             "        movq    %s,%%r14     # r14 = lhsfpreg (result of addition at this point)\n"
             "        mov%s $.LQNaN_Indefinite, %%r13%s   # r13%s = QNaN Indefinite (%s)\n"
             "        cmp%c    %%r13%s,%%r14%s           # if result is a NaN\n"
             "        movabsq $.LNaN_msg, %%rcx      # then we output \"NAN GENERATED\"\n"
             "        movabsq $.Luninitialized_msg, %%rdx  # otherwise we output\n"
             "        cmovne  %%rdx,%%rcx             # \"READ OF UNINITIALIZED VARIABLE\"\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                 # DOES NOT RETURN\n"
             ".LBS%" PRIu32 "_2:                          # was result overflow?\n"
             "        testl   $.LFE_OVERFLOW,(%%rsp) # if !temp.LE_OVERFLOW\n"
             "        jz      .LBS%" PRIu32 "_3           # then goto 3\n"
             "        andl    $0xFFC0,(%%rsp)        # clear exception in memory copy of MXCSR\n"
             "        ldmxcsr (%%rsp)                # and reload that into real MXCSR\n"
             "        movabsq $.Loverflow_msg,%%rsi  # rsi = address of overflow error message\n"
             "        movabsq $.Lexception_non_fatal,%%r15 # call exception_non_fatal\n"
             "        callq   *%%r15\n"
             "        # now we need to return +/-INF\n"
             "        mov%s $.LNInf,%%r13%s         # r13%s=-INF (%s)\n"
             "        mov%s $.LPInf,%%r14%s         # r14%s=+INF (%s)\n"
             "        bt%c     $%" PRIu32 ",%%r12%s             # if augend was negative\n"
             "        cmovc%c  %%r13%s,%%r14%s           # then use -INF else use +INF\n"
             "        mov%c    %%r14%s,%s    # %s = r14%s (%s)\n"
             "        # fall through to exit\n"
             ".LBS%" PRIu32 "_3:      addq    $4,%%rsp     # deallocate storage for copy of MXCSR\n",
          lhs_fpregname, rhs_fpregname, lhs_fpregname, lhs_fpregname, (use_double?'d':'s'), rhs_fpregname,
          lhs_fpregname, lhs_fpregname, rhs_fpregname, (use_double?"double":"float"), instance_number,
          lhs_fpregname, (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          instance_number, instance_number,
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?'q':'d'), (use_double?"":"d"), lhs_fpregname, lhs_fpregname, (use_double?"":"d"),
          (use_double?"double":"float"),
          instance_number);
  instance_number++;
  return;
}

static void binary_add(
    FILE *f,                // File handle for assembly language output file
    const char *lhs_fpregname,
    const char *rhs_fpregname) {
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s += %s\n"
             "        movq    %s,%%r12     # backup copy of augend in r12\n"
             "                             # since a failed add will destroy %s\n"
             "        adds%c   %s,%s   #  %s += %s (%s)\n"
             "        subq    $4,%%rsp               # allocate storage for temp copy of MXCSR\n"
             "        stmxcsr (%%rsp)                # temp = mxcsr\n"
             "        testl   $.LFE_INVALID,(%%rsp)  # if !temp.FE_INVALID\n"
             "        jz      .LBA%" PRIu32 "_2           # then goto 2\n"
             "        # OK, result was invalid - why?\n"
             "        addq    $4,%%rsp               # deallocate storage for temp copy of MXCSR\n"
             "        movq    %s,%%r14     # r14 = lhsfpreg (result of addition at this point)\n"
             "        mov%s $.LQNaN_Indefinite, %%r13%s   # r13%s = QNaN Indefinite (%s)\n"
             "        cmp%c    %%r13%s,%%r14%s           # if result is a NaN\n"
             "        movabsq $.LNaN_msg, %%rcx      # then we output \"NAN GENERATED\"\n"
             "        movabsq $.Luninitialized_msg, %%rdx  # otherwise we output\n"
             "        cmovne  %%rdx,%%rcx             # \"READ OF UNINITIALIZED VARIABLE\"\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                 # DOES NOT RETURN\n"
             ".LBA%" PRIu32 "_2:                          # was result overflow?\n"
             "        testl   $.LFE_OVERFLOW,(%%rsp) # if !temp.LE_OVERFLOW\n"
             "        jz      .LBA%" PRIu32 "_3           # then goto 3\n"
             "        andl    $0xFFC0,(%%rsp)        # clear exception in memory copy of MXCSR\n"
             "        ldmxcsr (%%rsp)                # and reload that into real MXCSR\n"
             "        movabsq $.Loverflow_msg,%%rsi  # rsi = address of overflow error message\n"
             "        movabsq $.Lexception_non_fatal,%%r15 # call exception_non_fatal\n"
             "        callq   *%%r15\n"
             "        # now we need to return +/-INF\n"
             "        mov%s $.LNInf,%%r13%s         # r13%s=-INF (%s)\n"
             "        mov%s $.LPInf,%%r14%s         # r14%s=+INF (%s)\n"
             "        bt%c     $%" PRIu32 ",%%r12%s             # if augend was negative\n"
             "        cmovc%c  %%r13%s,%%r14%s           # then use -INF else use +INF\n"
             "        mov%c    %%r14%s,%s    # %s = r14%s (%s)\n"
             "        # fall through to exit\n"
             ".LBA%" PRIu32 "_3:      addq    $4,%%rsp     # deallocate storage for copy of MXCSR\n",
          lhs_fpregname, rhs_fpregname, lhs_fpregname, lhs_fpregname, (use_double?'d':'s'), rhs_fpregname,
          lhs_fpregname, lhs_fpregname, rhs_fpregname, (use_double?"double":"float"), instance_number,
          lhs_fpregname, (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          instance_number, instance_number, (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"), (use_double?'q':'d'), (use_double?"":"d"),
          lhs_fpregname, lhs_fpregname, (use_double?"":"d"), (use_double?"double":"float"), instance_number);
  instance_number++;
  return;
}

static void binary_multiply(
    FILE *f,                // File handle for assembly language output file
    const char *lhs_fpregname,
    const char *rhs_fpregname) {
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s *= %s\n"
             "        movq    %s,%%r12     # backup copy of multiplicand in r12\n"
             "                                      # since a failed multiply will destroy %s\n"
             "        movq    %s,%%r11     # backup copy of multiplier in r11\n"
             "                                      # since a failed multiply will destroy %s\n"
             "                                      # %s*=%s\n"
             "        muls%c   %s,%s   #  %s *= %s (%s)\n"
             "        subq    $16,%%rsp              # allocate storage for temp copy of MXCSR + 12 bytes padding\n"
             "        stmxcsr (%%rsp)                # temp = mxcsr\n"
             "        testl   $.LFE_INVALID,(%%rsp)  # if temp.FE_INVALID\n"
             "        jnz     .LBM%" PRIu32 "_1                    # then goto 1\n"
             "        testl   $.LFE_UNDERFLOW,(%%rsp)  # if temp.FE_UNDERFLOW\n"
             "        jnz     .LBM%" PRIu32 "_2                    # then goto 2\n"
             "        testl   $.LFE_OVERFLOW,(%%rsp) # if temp.FE_OVERFLOW\n"
             "        jnz     .LBM%" PRIu32 "_3                    # then goto 3 (all OK)\n"
             "        # if answer is +/- Infinity, an overflow exception must be generated\n"
             "        mov%c    %s,%%r12%s              # r12%s = %s (%s)\n"
             "        btr%c    $%" PRIu32 ",%%r12%s             # r12%s = abs(r12%s) (%s) mask out sign\n"
             "        mov%s $.LPInf,%%r11%s         # r11%s = +INF (%s)\n"
             "        cmp%c    %%r11%s,%%r12%s           # if abs(%s) != +INF (%s)\n"
             "        je      .LBM%" PRIu32 "_0                    # then goto 6 (answer is OK)\n"
             "        {disp8} jmp .LBM%" PRIu32 "_6\n"
             ".LBM%" PRIu32 "_0:\n"
             "        {disp8} jmp .LBM%" PRIu32 "_4                # else goto 4 (we need an overflow exception)\n"
             ".LBM%" PRIu32 "_1:\n"
             "        # lhsfpreg value is invalid\n"
             "        addq    $16,%%rsp              # deallocate storage for temp copy of MXCSR + 12 bytes padding\n"
             "        movq    %s,%%r14     # r14 = %s\n"
             "        mov%s $.LQNaN_Indefinite, %%r13%s   # r13%s = QNaN Indefinite (%s)\n"
             "        cmp%c    %%r13%s,%%r14%s           # if result is a NaN\n"
             "        movabsq $.LNaN_msg, %%rcx      # then we output \"NAN GENERATED\"\n"
             "        movabsq $.Luninitialized_msg, %%rdx  # otherwise we output\n"
             "        cmovne  %%rdx,%%rcx             # \"READ OF UNINITIALIZED VARIABLE\"\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                 # DOES NOT RETURN\n"
             ".LBM%" PRIu32 "_2:\n"
             "        # underflow, returns 0 and throws underflow exception\n"
             "        andl    $0xFFC0,(%%rsp)        # clear exception in memory copy of MXCSR\n"
             "        ldmxcsr (%%rsp)                # and reload that into real MXCSR\n"
             "        # substitute a zero value\n"
             "        xorp%c   %s,%s # %s = 0 (%s)\n"
             "        movabsq $.Lunderflow_msg,%%rsi # rsi = address of underflow_msg\n"
             "        {disp8} jmp .LBM%" PRIu32 "_5\n"
             ".LBM%" PRIu32 "_3:\n"
             "        # overflow, returns +/- INF and throws OVERFLOW exception\n"
             "        andl    $0xFFC0,(%%rsp)        # clear exception in memory copy of MXCSR\n"
             "        ldmxcsr (%%rsp)                # and reload that into real MXCSR\n"
             "        mov%c    %%r11%s,%%r15%s           # r15%s = r11%s    (%s)\n",
          lhs_fpregname, rhs_fpregname, lhs_fpregname, lhs_fpregname, rhs_fpregname, rhs_fpregname, lhs_fpregname,
          rhs_fpregname, (use_double?'d':'s'), rhs_fpregname, lhs_fpregname, lhs_fpregname, rhs_fpregname,
          (use_double?"double":"float"), instance_number, instance_number, instance_number,
          (use_double?'q':'d'), lhs_fpregname, (use_double?"":"d"),
          (use_double?"":"d"), lhs_fpregname, (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"), lhs_fpregname,
          (use_double?"double":"float"), instance_number, instance_number, instance_number, instance_number,
          instance_number, lhs_fpregname, lhs_fpregname, (use_double?"absq":"l   "), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), (use_double?'q':'l'), (use_double?"":"d"),
          (use_double?"":"d"), instance_number, (use_double?'d':'s'), lhs_fpregname, lhs_fpregname, lhs_fpregname,
          (use_double?"double":"float"), instance_number, instance_number,
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"));
  // cannot merge this with previous printf since that makes the format string exceed the 4095 byte C standard limit
  fprintf(f, "        shr%c    $%" PRIu32 ",%%r15%s             # r15%s >>= %" PRIu32 "   (%s)\n"
             "        mov%c    %%r12%s,%%r13%s             # r13%s = r12%s    (%s)\n"
             "        shr%c    $%" PRIu32 ",%%r13%s             # r13%s >>= %" PRIu32 "   (%s)\n"
             "        add%c    %%r13%s,%%r15%s             # r15%s += r13%s   (%s)\n"
             "                                      # sum is 0,2 (same signs) or 1 (different signs)\n"
             "                                      # if same sign return +INF else return -INF\n"
             "        mov%s    $.LPInf,%%r13%s         # r13%s=+INF    (%s)\n"
             "        mov%s $.LNInf,%%r14%s         # r14%s=-INF    (%s)\n"
             "        and%c    $1,%%r15%s              # mask out all but the last bit\n"
             "        test%c   %%r15%s,%%r15%s           # if all zeros (same sign)\n"
             "        cmovz%c  %%r13%s,%%r14%s           # then r14%s = +INF, else r14%s = -INF  (%s)\n"
             "        mov%c    %%r14%s,%s    # %s = r14%s   (%s)\n"
             "        # fall through intentionally\n"
             ".LBM%" PRIu32 "_4:\n"
             "        # emit overflow exception\n"
             "        movabsq $.Loverflow_msg,%%rsi  # rsi = address of overflow_msg\n"
             "        # fall through intentionally\n"
             ".LBM%" PRIu32 "_5:\n"
             "        # emit some kind of exception\n"
             "        movabsq $.Lexception_non_fatal,%%r15 # call exception_non_fatal\n"
             "        callq   *%%r15\n"
             "        # fall through intentionally\n"
             ".LBM%" PRIu32 "_6:\n"
             "        addq    $16,%%rsp              # deallocate storage for temp copy of MXCSR + 12 bytes padding\n",
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?63U:31U), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?63U:31U), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?'q':'d'), (use_double?"":"d"), lhs_fpregname, lhs_fpregname,
          (use_double?"":"d"), (use_double?"double":"float"),
          instance_number, instance_number, instance_number);
  instance_number++;
  return;
}

static void binary_power(
    FILE *f,                // File handle for assembly language output file
    const char *lhs_fpregname,
    const char *rhs_fpregname) {
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s=pow(%s,%s)\n"
             "        pushq   %%rbp                      # create stack frame\n"
             "        movq    %%rsp, %%rbp\n"
             "        andq    $-16, %%rsp                # force align the stack on 16-byte boundary\n"
             "        pushq   %%rax                      # save original value of rax\n"
             "        pushq   %%rsi                      # save original value of rsi\n"
             "        pushq   %%r13                      # save original value of r13\n"
             "        subq    $8,%%rsp                   # allocate 8 bytes of padding\n"
             "                                          # to maintain 16-byte stack alignment\n"
             "        # save total FPU status\n"
             "        subq    $512,%%rsp                 # allocate 512 FPU save area\n"
             "        fxsave64 (%%rsp)                   # and save FP state into FPU save area\n"
             "        movq    %s,%%rsi    # move %s base\n"
             "        movq    %%rsi,%%xmm0                # into xmm0\n"
             "        movq    %s,%%r13    # move %s exponent\n"
             "        movq    %%r13,%%xmm1                # into xmm1\n",
          lhs_fpregname, lhs_fpregname, rhs_fpregname, lhs_fpregname, lhs_fpregname, rhs_fpregname,
          rhs_fpregname);
  if (!use_double)
    fputs("        cvtss2sd %xmm1,%xmm1              # convert exponent to float\n"
          "        cvtss2sd %xmm0,%xmm0              # convert base to float\n", f);
  fprintf(f, "        xorpd   %%xmm2,%%xmm2               # xmm2=0.0\n"
             "        comisd  %%xmm2,%%xmm0               # compare base to zero  (double)\n"
             "        jb      .LBP%" PRIu32 "_2               # if base < zero then goto 2\n"
             "        je      .LBP%" PRIu32 "_0               # if base !=0 zero then goto 0\n"
             "        {disp8} jmp .LBP%" PRIu32 "_6\n"
             ".LBP%" PRIu32 "_0:\n"
             "        # we know base is not zero at this point\n"
             "        comisd  %%xmm2,%%xmm1               # compare exponent to zero  (double)\n"
             "        jb      .LBP%" PRIu32 "_1               # if exponent >= zero then goto 1\n"
             "        {disp8} jmp .LBP%" PRIu32 "_6\n"
             ".LBP%" PRIu32 "_1:\n"
             "        # base is zero, and exponent is < zero, so we have\n"
             "        # zero raised to some negative power, so print exception and\n"
             "        # return +INF\n"
             "        movabsq $.Lzero_to_negative_power_msg,%%rsi  # rsi = address of exception message\n"
             "        movabsq $.Lexception_non_fatal,%%r13         # call exception_non_fatal\n"
             "        callq   *%%r13\n"
             "        mov%s $.LPInf,%%r13%s             # r13 = +INF    (%s)\n"
             "        movq    %%r13,%%xmm0                # result = +INF\n"
             "        {disp8} jmp .LBP%" PRIu32 "_9           # goto 9\n"
             ".LBP%" PRIu32 "_2:\n"
             "        # base < 0\n"
             "        # there are special cases we have to check\n"
             "        movabsq $.LFLOATNEGONE64,%%rax     # rax = -1.0\n"
             "        movq    %%rax,%%xmm3                # xmm3 = -1.0\n"
             "        comisd  %%xmm3,%%xmm0               # base is -1.0?\n"
             "        jne     .LBP%" PRIu32 "_4               # no, goto 4\n"
             "        # yes, base is exactly -1.0\n"
             "        movabsq $.LPInf64,%%rax            # rax = +INF\n"
             "        movq    %%rax,%%xmm3                # xmm3 = +INF\n"
             "        comisd  %%xmm3,%%xmm1               # exponent is +INF\n"
             "        jne     .LBP%" PRIu32 "_3               # no, goto 3\n"
             "        # yes, exponent is +INF\n"
             "        # ok, -1^+INF is 1\n"
             "        movabsq $.LFLOATONE64,%%rax        # rax = 1.0\n"
             "        movq    %%rax,%%xmm0                # return value is 1.0\n"
             "        {disp8} jmp .LBP%" PRIu32 "_8           # goto 8\n"
             ".LBP%" PRIu32 "_3:\n"
             "        movabsq $.LNInf64,%%rax            # rax = -INF\n"
             "        movq    %%rax,%%xmm3                # xmm3 = -INF\n"
             "        comisd  %%xmm3,%%xmm1               # exponent is -INF\n"
             "        jne     .LBP%" PRIu32 "_4               # no, goto 4\n"
             "        # yes, exponent is -INF\n"
             "        # ok, -1^-INF is 1\n"
             "        movabsq $.LFLOATONE64,%%rax        # rax = 1.0\n"
             "        movq    %%rax,%%xmm0                # return value is 1.0\n"
             "        {disp8} jmp .LBP%" PRIu32 "_8           # goto 8\n"
             ".LBP%" PRIu32 "_4:\n"
             "        # is exponent an integer?\n"
             "        movq    %%xmm1, %%xmm3              # save a copy of exponent in xmm3\n"
             "                                          # xmm1 = INT(exponent)\n"
             "        subq    $4,%%rsp                   # save MXCSR\n"
             "        stmxcsr (%%rsp)\n",
          instance_number, instance_number, instance_number, instance_number, instance_number,
          instance_number, instance_number, (use_double?"absq":"l   "), (use_double?"":"d"),
          (use_double?"double":"float"), instance_number, instance_number, instance_number,
          instance_number, instance_number, instance_number, instance_number, instance_number,
          instance_number);
  if (use_SSE4_1)
    fputs("        roundsd $1,%xmm1,%xmm1\n", f);
  else
    fputs("        cvtsd2si %xmm1, %rax              # convert double to 64bit integer\n"
          "        cvtsi2sd %rax, %xmm1              # convert 64bit integer back to double\n", f);
  fprintf(f, "        ldmxcsr (%%rsp)                    # restore MXCSR\n"
             "        addq    $4,%%rsp\n"
             "        comisd  %%xmm3, %%xmm1              # if INT(exponent) != exponent then\n"
             "        jne     .LBP%" PRIu32 "_5               # goto 5\n"
             "        movq    %%xmm3, %%xmm1              # restore exponent value\n"
             "        {disp8} jmp .LBP%" PRIu32 "_6           # otherwise goto 6\n"
             ".LBP%" PRIu32 "_5:\n"
             "        # yes, base < 0 and exponent is not an integer\n"
             "        movabsq $.LOBUF,%%rdi              # output buffer variable address\n"
             "        movabsq $.Lobuf_next,%%rsi         # output bubufpos variable address\n"
             "        movabsq $.Lcurzone,%%rdx           # output zonepos variable address\n"
             "        movabsq $.Lflushoutputln,%%r13     # call flushoutputln to\n"
             "        callq   *%%r13                     # flush any normal output\n"
             "        movabsq $.Lnegraisednonint_msg, %%rcx # address of error message\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                     # DOES NOT RETURN\n"
             ".LBP%" PRIu32 "_6:\n"
             "        # (base is non-zero  _OR_ exponent >= zero) _AND_\n"
             "        # (if base is negative then exponent is integer)\n"
             "        movabsq $.Lxpow_u1,%%r13           # call pow(xmm0, xmm1)\n"
             "        callq   *%%r13\n"
             "        xorl    %%eax, %%eax                # rax=0, assume return will be false\n"
             "        movq    %%xmm0, %%rdx               # move double to rdx\n"
             "        btrq    $63, %%rdx                 # clear sign bit\n"
             "        movabsq $.LPInf64,%%rcx            # move 64bit +INF to rcx\n"
             "        cmpq    %%rcx, %%rdx                # if rdx > rcx then\n"
             "                                          # (that means all exponent bits are 1\n"
             "                                          # and at least mantissa bit is 1 so\n"
             "                                          # this is a NAN)\n"
             "        seta    %%al                       # rax=1\n"
             "        testq   %%rax,%%rax                 # if xpow did not return NaN\n"
             "        jz      .LBP%" PRIu32 "_7               # then goto 7\n"
             "        # if we got here, we got a NaN with\n"
             "        # non-zero base and non-negative exponent\n"
             "        movabsq $.LOBUF,%%rdi              # output buffer variable address\n"
             "        movabsq $.Lobuf_next,%%rsi         # output bubufpos variable address\n"
             "        movabsq $.Lcurzone,%%rdx           # output zonepos variable address\n"
             "        movabsq $.Lflushoutputln,%%r13     # call flushoutputln to\n"
             "        callq   *%%r13                     # flush any normal output\n"
             "        movabsq $.Lbadpower_msg, %%rcx     # address of badpower error message\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                     # DOES NOT RETURN\n"
             ".LBP%" PRIu32 "_7:\n"
             "        xorl    %%eax, %%eax                # rax=0, assume return will be false\n"
             "        movq    %%xmm0, %%rdx               # move result to rdx\n"
             "        btrq    $63, %%rdx                 # clear sign bit\n"
             "        movabsq $.LPInf64,%%rcx            # move 64 bit +INF to rcx\n"
             "        cmpq    %%rcx, %%rdx                # if result was +INF then\n"
             "        sete    %%al                       # rax=1, else rax=0\n"
             "        testq   %%rax,%%rax                 # if xpow did not return +INF\n"
             "        jz      .LBP%" PRIu32 "_8               # then goto 8\n"
             "        # xpow returned +/-Infinity (overflow)\n"
             "        movabsq $.Loverflow_msg,%%rsi        # exception message address\n"
             "        movabsq $.Lexception_non_fatal,%%r13 # call exception_non_fatal\n"
             "        callq   *%%r13\n"
             "        # fall through intentionally\n"
             ".LBP%" PRIu32 "_8:\n",
          instance_number, instance_number, instance_number, instance_number, instance_number,
          instance_number, instance_number, instance_number);
  if (!use_double)
    fputs("        cvtsd2ss %xmm0,%xmm0              # xmm0 = (float)xmm0\n", f);
  fprintf(f, "        # fall through intentionally\n"
             ".LBP%" PRIu32 "_9:\n"
             "        movq    %%xmm0,%%rax                # store answer in rax temporarily\n"
             "        fxrstor64 (%%rsp)                  # restore saved FPU state\n"
             "        addq    $520,%%rsp                 # deallocate 512 FPU save area & 8 bytes padding\n"
             "        movq    %%rax,%s    # move xpow result into %s\n"
             "        popq    %%r13                      # restore original value of r13\n"
             "        popq    %%rsi                      # restore original value of rsi\n"
             "        popq    %%rax                      # restore original value of rax\n"
             "        movq    %%rbp, %%rsp                # destroy stack frame\n"
             "        popq    %%rbp\n",
          instance_number, lhs_fpregname, lhs_fpregname);

  instance_number++;
  return;
}

static void binary_divide(
    FILE *f,                // File handle for assembly language output file
    const char *lhs_fpregname,
    const char *rhs_fpregname) {
  static uint32_t instance_number = 0;
  if (!f)
    ICE(__FILE__, __func__, __LINE__, emsg[87], __func__, "file");
  if (!lhs_fpregname || !lhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "lhs_fpregname");
  if (!rhs_fpregname || !rhs_fpregname[0])
    ICE(__FILE__, __func__, __LINE__, emsg[88], __func__, "rhs_fpregname");
  fprintf(f, "        # %s /= %s\n"
             "        movq    %s,%%r12     # backup copy of numerator in r12\n"
             "                                      # since a failed divide will destroy %s\n"
             "        movq    %s,%%r11     # backup copy of denominator in r11\n"
             "                                      # since a failed divide will destroy %s\n"
             "                                      # %s /= %s\n"
             "        divs%c   %s,%s   #  %s /= %s (%s)\n"
             "        subq    $16,%%rsp               # allocate storage for temp copy of MXCSR + 12 bytes padding\n"
             "        stmxcsr (%%rsp)                 # temp = mxcsr\n"
             "        testl   $.LFE_DIVBYZERO,(%%rsp) # if temp.FE_DIVBYZERO\n"
             "        jnz     .LBD%" PRIu32 "_1            # then goto 1\n"
             "        testl   $.LFE_INVALID,(%%rsp)   # if temp.FE_INVALID\n"
             "        jnz     .LBD%" PRIu32 "_2            # then goto 2\n"
             "        testl   $.LFE_UNDERFLOW,(%%rsp) # if temp.FE_UNDERFLOW\n"
             "        jnz     .LBD%" PRIu32 "_4            # then goto 4\n"
             "        testl   $.LFE_OVERFLOW,(%%rsp)  # if temp.FE_OVERFLOW\n"
             "        jz      .LBD%" PRIu32 "_0            # then goto 5\n"
             "        {disp8} jmp .LBD%" PRIu32 "_5\n"
             ".LBD%" PRIu32 "_0:\n"
             "        {disp8} jmp .LBD%" PRIu32 "_8        # else goto 8 (all OK)\n"
             ".LBD%" PRIu32 "_1:\n"
             "        # divide by zero, result depends on sign of numerator\n"
             "        andl    $0xFFC0,(%%rsp)         # clear exception in memory copy of MXCSR\n"
             "        ldmxcsr (%%rsp)                 # and reload that into real MXCSR\n"
             "        xorl    %%r11d,%%r11d            # ensure r11 is +0, not -0 (IEEE is wierd)\n"
             "        movabsq $.Ldividebyzero_msg,%%rsi # rsi = address of \"DIVIDE BY ZERO\" message\n"
             "        {disp8} jmp .LBD%" PRIu32 "_6        # goto 6\n"
             ".LBD%" PRIu32 "_2:\n"
             "        # invalid, no result, no return\n"
             "        andl    $0xFFC0,(%%rsp)         # clear exception in memory copy of MXCSR\n"
             "        ldmxcsr (%%rsp)                 # and reload that into real MXCSR\n"
             "        # either 0/0 or INF/INF\n"
             "        test%c   %%r12%s,%%r12%s            # if r12%s == 0 (%s)\n"
             "        jz      .LBD%" PRIu32 "_3            # then goto 3\n"
             "        # +-INF/+-INF\n"
             "        addq    $16,%%rsp               # deallocate storage for temp copy of MXCSR + 12 bytes padding\n"
             "        movabsq $.LNaN_msg, %%rcx       # rcx = address of NaN_msg\n"
             "        movabsq $.Lbadxit_msg, %%rax\n"
             "        jmpq    *%%rax                  # DOES NOT RETURN\n"
             ".LBD%" PRIu32 "_3:\n"
             "        # 0/0\n"
             "        mov%s $.LPInf,%%r15%s          # r15%s = +INF (%s)\n"
             "        mov%c    %%r15%s,%s     # %s = r15 (%s)\n"
             "        movabsq $.Ldividebyzero_msg,%%rsi # rsi = addres of dividebyzero_msg\n"
             "        {disp8} jmp .LBD%" PRIu32 "_7        # goto 7\n"
             ".LBD%" PRIu32 "_4:\n"
             "        # undeflow, return 0\n"
             "        andl    $0xFFC0,(%%rsp)         # clear exception in memory copy of MXCSR\n"
             "        ldmxcsr (%%rsp)                 # and reload that into real MXCSR\n"
             "        # substitute a zero value\n"
             "        xorp%c   %s,%s # %s = 0 (%s)\n"
             "        movabsq $.Lunderflow_msg,%%rsi  # rsi = address of underflow_msg\n"
             "        {disp8} jmp .LBD%" PRIu32 "_7        # goto 7\n"
             ".LBD%" PRIu32 "_5:\n"
             "        # overflow, returns +/- INF and throws OVERFLOW exception\n"
             "        andl    $0xFFC0,(%%rsp)         # clear exception in memory copy of MXCSR\n"
             "        ldmxcsr (%%rsp)                 # and reload that into real MXCSR\n"
             "        movabsq $.Loverflow_msg,%%rsi   # rsi = address of overflow message\n"
             "        # fall through intentionally\n"
             ".LBD%" PRIu32 "_6:\n"
             "        mov%c    %%r11%s,%%r15%s            # r15%s = r11%s    (%s)\n"
             "        shr%c    $%" PRIu32 ",%%r15%s              # r15%s >>= %" PRIu32 "   (%s)\n"
             "        mov%c    %%r12%s,%%r13%s            # r13%s = r12%s    (%s)\n"
             "        shr%c    $%" PRIu32 ",%%r13%s              # r13%s >>= %" PRIu32 "   (%s)\n"
             "        add%c    %%r13%s,%%r15%s            # r15%s += r13%s   (%s)\n"
             "                                       # 0,2 (same signs) or 1 (different signs)\n"
             "                                       # if %%r15%s is one use -INF else use +INF\n"
             "        mov%s $.LPInf,%%r13%s          # r13%s=+INF    (%s)\n"
             "        mov%s $.LNInf,%%r14%s          # r14%s=-INF    (%s)\n"
             "        and%c    $1,%%r15%s               # mask out all but the last bit\n"
             "        test%c   %%r15%s,%%r15%s            # if all zeros (same sign)\n"
             "        cmovz%c  %%r13%s,%%r14%s            # then r14%s = +INF, else r14%s = -INF  (%s)\n"
             "        mov%c    %%r14%s,%s     # %s = r14%s  (%s)\n",
          lhs_fpregname, rhs_fpregname, lhs_fpregname, lhs_fpregname, rhs_fpregname, rhs_fpregname,
          lhs_fpregname, rhs_fpregname, (use_double?'d':'s'), rhs_fpregname, lhs_fpregname, lhs_fpregname,
          rhs_fpregname, (use_double?"double":"float"), instance_number, instance_number, instance_number,
          instance_number, instance_number, instance_number, instance_number, instance_number,
          instance_number, instance_number, (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"double":"float"), instance_number, instance_number,
          (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'d'), (use_double?"":"d"), lhs_fpregname, lhs_fpregname, (use_double?"double":"float"),
          instance_number, instance_number, (use_double?'d':'s'), lhs_fpregname, lhs_fpregname, lhs_fpregname,
          (use_double?"double":"float"), instance_number, instance_number, instance_number,
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?63U:31U), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?63U:31U), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?63U:31U), (use_double?"double":"float"),
          (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"),
          (use_double?"":"d"), (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?"absq":"l   "), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"double":"float"), (use_double?'q':'l'), (use_double?"":"d"), (use_double?'q':'l'),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?'q':'l'), (use_double?"":"d"), (use_double?"":"d"),
          (use_double?"":"d"), (use_double?"":"d"), (use_double?"double":"float"), (use_double?'q':'d'),
          (use_double?"":"d"), lhs_fpregname, lhs_fpregname, (use_double?"":"d"), (use_double?"double":"float"));
  // cannot merge this with previous printf since that makes the format string exceed the 4095 byte C standard limit
  fprintf(f, "        # fall through intentionally\n"
             ".LBD%" PRIu32 "_7:\n"
             "        # emit some kind of exception\n"
             "        movabsq $.Lexception_non_fatal,%%r15 # call exception_non_fatal\n"
             "        callq   *%%r15\n"
             "        # fall through intentionally\n"
             ".LBD%" PRIu32 "_8:\n"
             "        addq    $16,%%rsp               # deallocate storage for temp copy of MXCSR + 12 bytes padding\n",
          instance_number, instance_number);
  instance_number++;
  return;
}
