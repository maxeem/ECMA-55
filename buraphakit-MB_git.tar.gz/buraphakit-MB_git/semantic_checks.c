//
// semantic_checks.c - This file contains functions for processing the AST.
//
// Copyright (C) 2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "globals.h"
#include "error_messages.h"
#include "tree.h"
#include "symbol_table.h"
#include "semantic_checks.h"
#define MAX_FOR_LABEL_BYTES 20
#define MAX_FOR_VAR_BYTES 20

const uint32_t
  // maximum number of bytes for FOR loop scope system (used in semantic_checks)
  MAX_SCOPE_BYTES = 256U;
                                         // UDF is short for User-Defined Function, the one-line functions created with the DEF statement.
static bool in_udf_definition = false;   // set to true during user-defined function definition (from just after DEF to the next newline)
static char curfunc_name[4] = { 0 };     // current UDF name,pattern is "FN?" with ? is a letter 'A'..'Z' and one zero-byte terminator
static char curfunc_argname[10] = { 0 }; // current UDF argument name, pattern is ".LFN?_?" with first ? is letter 'A'..'Z', 2nd ? is arg name
                                         // an empty string indicates a function takes no parameter
static bool can_option_base = true;      // set to false when you see an array reference or a DIM statement
                                         // OPTION BASE is only permitted if this is true
static bool have_DATA = false;           // if true, program contains a DATA statement
static uint32_t READ_lineno = 0U;        // if need_READSTMT is true, then this will be updated during
                                         // the parse to contain the line number of the first READ statement in
                                         // the program for use in the case when there is a READ but no DATA
                                         // statement and an error message must be issued.

// dedicated compile-time FOR loop stack to ensure every NEXT matches
// the preceeding FOR, and every FOR has a corrsponding NEXT.
// Allocated/deallocated in semantic_checks() function.
static struct forstack_entry {
  uint32_t lineno;     // line number of FOR statement
  char *body_label;    // label for start of loop body in assembly output
  char *test_label;    // label for testing loop exit condition in assembly output
  char *bol_label;     // label for exiting the loop in assembly output
  char *ndex_var;      // the ASCIIZ name of the loop index variable
  char *inc_var;       // the ASCIIZ name of the hidden variable that holds the loop increment
  char *limit_var;     // the ASCIIZ name of the hidden variable that holds the limit used in the loop test
  char *scope;         // REXX-like (stem) scope indicator.  The scope indicator for a loop (.X.Y.Z would be FOR Z
                       // inside FOR Y inside FOR X which is at global scope level.  The '.' is used as a delimiter.
                       // The global scope is just an empty string.
} *forstack = NULL;
static unsigned int forstack_ptr = 0U;   // stack pointer in forstack
// FOR loop scope indicator; empty string is GLOBAL scope
// This begins with a . and has the index variable name.  For example, .A0.B.Z9 would mean
// FOR Z9 inside of FOR B inside of FOR A0 which is at global level
// The '.' is used as a delimiter.  The global scope is just an empty string.
static char *current_scope = NULL;
static unsigned int next_label_number = 0U; // number used to generate next label name
static unsigned int next_var_number = 0U;   // number used to generate next FOR loop variable name

static void tree_setall_parent_count2s(treenode **root);
static void subtree_setall_parent_count2s_to_one(treenode **node);
static bool sc_nvar(treenode *node);
static bool sc_navar(treenode *node);
static bool sc_target_variable(treenode *node);
static bool sc_dimstmt(treenode *node);
static bool sc_optionbasestmt(treenode *node);
static bool sc_forstmt(treenode *node);
static bool sc_exitforstmt(treenode *node);
static bool sc_nextstmt(treenode *node);
static bool sc_expression(treenode *node);
static bool sc_addlines(treenode *node);
static bool sc_check_loopindex_scope(treenode *node);
static bool sc_verify_jump_targets(treenode *root);
static void sc_DAGify_jump_targets(treenode *root);
static bool sc_print(treenode *node);
static bool sc_read(treenode *node, unsigned int lineno);
static bool sc_input(treenode *node, unsigned int lineno);
static bool sc_def(treenode *node);

//
// This will process the EXIT FOR statement AST.  This is an early exit of a FOR loop, and it will
// verify that the the compile-time FOR stack is not empty
// It will use the information for the loop exit label.
// If all semantic checks pass, then true is returned.  Otherwise, false is returned.
//
static bool sc_exitforstmt(
    treenode *node) { // pointer to AST node
  if (!forstack_ptr) {
    fprintf(stderr,
            emsg[101],
            node->leaftoken->lno,
            token_names[T_EXIT] + 2,
            token_names[T_FOR] + 2,
            token_names[T_FOR] + 2);
    return false;
  }
  node->children[0]->children[0] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr - 1].bol_label, node->leaftoken->lno, 0U);

  return true;
}

//
// This will process the NEXT statement AST.  This is the end of a FOR loop, and it will
// verify that the entry on top of the the compile-time FOR stack called forstack contains
// the correct loop index variable and scope indicator.  It will use the information for the loop
// test label, the loop exit label, and the hidden variable contataining the increment value.
// If the scope is wrong or the index variable is wrong, an error is reported.
// If all semantic checks pass, then true is returned.  Otherwise, false is returned.
//
static bool sc_nextstmt(
    treenode *node) { // pointer to AST node
  char *dotspot = NULL;       // pointer to scope delimiter in current scope string

  if (!forstack_ptr) {        // empty forstack, NEXT without any preceeding FOR
    fprintf(stderr,
            emsg[101],
            node->leaftoken->lno,
            token_names[T_NEXT] + 2,
            node->children[0]->leaftoken->toketext,
            token_names[T_FOR] + 2);
    return false;
  }
  // check index variable name to ensure it's correct
  if (strcmp(node->children[0]->leaftoken->toketext, forstack[forstack_ptr - 1].ndex_var) != 0) {
    fprintf(stderr,                                  // NEXT with wrong index variable
            emsg[102],
            node->children[0]->leaftoken->lno,
            token_names[T_NEXT] + 2,
            node->children[0]->leaftoken->toketext,  // we got this index variable
            token_names[T_NEXT] + 2,
            forstack[forstack_ptr - 1].ndex_var);    // but expected this index variable
    return false;
  }
  // check scope (right index variable, but wrong scope...)
  if (strcmp(forstack[forstack_ptr - 1].scope, current_scope) != 0) {
    fprintf(stderr,
            emsg[103],
            node->children[0]->leaftoken->lno,
            token_names[T_NEXT] + 2,
            node->children[0]->leaftoken->toketext,
            current_scope,
            forstack[forstack_ptr - 1].scope);
    return false;
  }
  // remove the innermost scope level (the rightmost component of current_scope)
  dotspot = strrchr(current_scope, '.');
  if (!dotspot) {     // no dot found, NEXT is invalid at global scope
    fprintf(stderr,
            emsg[104],
            node->children[0]->leaftoken->lno,
            token_names[T_NEXT] + 2,
            node->children[0]->leaftoken->toketext);
    return false;
  }
  *dotspot = (char)0; // the actual scope string chop which removes scope of this NEXT
  debug_printf("After %s %s current scope is now '%s' on line %" PRIu32 "\n",
               token_names[T_NEXT] + 2,
               node->children[0]->leaftoken->toketext,
               (current_scope[0] ? current_scope : "global"),
               node->children[0]->leaftoken->lno);
  // node->children[0] is the forstack[forstack_ptr - 1].ndex_var
  node->children[1] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr - 1].body_label, node->leaftoken->lno, 0U);
  node->children[2] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr - 1].bol_label, node->leaftoken->lno, 0U);
  node->children[3] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr - 1].test_label, node->leaftoken->lno, 0U);
  node->children[4] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr - 1].inc_var, node->leaftoken->lno, 0U);
  node->children[5] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr - 1].limit_var, node->leaftoken->lno, 0U);
  forstack_ptr--;
  return true;
}

//
// This will process the FOR statement AST.   It will
// add an entry to the compile-time FOR stack called forstack containing
// the loop index variable, the scope indicator, and the information for the loop
// test label, the loop exit label, the hidden variable contataining the increment value,
// and the hidden variable containing the loop termination value.  It will also record
// the line where the FOR loop occurred for use in error messages.
// Returns true on success, false otherwise.
//
static bool sc_forstmt(
    treenode *node) {        // pointer to AST node
  uint32_t i;                // index into forstack, intialized to the top of stack

  debug_printf("T_NVAR <<<value is '%s'>>>\n", node->children[0]->leaftoken->toketext);
  // create new numeric scalar if possible, or verify existing variable is a scalar and not an array
  if (!assign_nvar(node->children[0]->leaftoken->toketext, node->leaftoken->lno)) {
    fprintf(stderr, emsg[105], node->leaftoken->lno, node->children[0]->leaftoken->toketext);
    return false;
  }
  // ensure the same index variable is not in use in an outer scope
  i = forstack_ptr;
  while (i > 0U) {
    i--;
    if (strcmp(node->children[0]->leaftoken->toketext, forstack[i].ndex_var) == 0) {
      fprintf(stderr, emsg[106], node->leaftoken->lno, node->children[0]->leaftoken->toketext, forstack[i].lineno);
      return false;
    }
  }
  // logically push forstack entry onto forstack (must be after code emission since we need data
  // from the emitter for the forstack entry).  Actually just ensure we have room.
  // The actual increment happens after the slot is populated, since forstack_ptr points
  // to the next available slot, not the last used slot...
  if (forstack_ptr + 1 >= FORSTACK_DEPTH) {
    fprintf(stderr, emsg[107], FORSTACK_DEPTH);
    return false;
  }

  // save index variable name
  strncpy(forstack[forstack_ptr].ndex_var, node->children[0]->leaftoken->toketext, MAX_FOR_VAR_BYTES);
  forstack[forstack_ptr].ndex_var[MAX_FOR_VAR_BYTES] = 0;
  snprintf(forstack[forstack_ptr].limit_var, MAX_FOR_VAR_BYTES, ".LFORLIMIT%04u", next_var_number);
  forstack[forstack_ptr].limit_var[MAX_FOR_VAR_BYTES] = 0;
  snprintf(forstack[forstack_ptr].inc_var, MAX_FOR_VAR_BYTES, ".LFORINCREMENT%04u", next_var_number++);
  forstack[forstack_ptr].inc_var[MAX_FOR_VAR_BYTES] = 0;
  snprintf((char *)forstack[forstack_ptr].body_label, MAX_FOR_LABEL_BYTES, ".LFORBODY%04u", next_label_number);
  forstack[forstack_ptr].body_label[MAX_FOR_LABEL_BYTES] = 0;
  snprintf((char *)forstack[forstack_ptr].test_label, MAX_FOR_LABEL_BYTES, ".LFORTEST%04u", next_label_number);
  forstack[forstack_ptr].test_label[MAX_FOR_LABEL_BYTES] = 0;
  snprintf((char *)forstack[forstack_ptr].bol_label, MAX_FOR_LABEL_BYTES, ".LFORDONE%04u", next_label_number++);
  forstack[forstack_ptr].bol_label[MAX_FOR_LABEL_BYTES] = 0;
  // update scope (append this scope level information)
  strcat(current_scope, ".");
  strcat(current_scope, forstack[forstack_ptr].ndex_var);
  debug_printf("After FOR %s current scope is now 'global%s' on line %" PRIu32 "\n",
               forstack[forstack_ptr].ndex_var, current_scope, node->leaftoken->lno);
  strcpy(forstack[forstack_ptr].scope, current_scope);
  forstack[forstack_ptr].lineno = node->leaftoken->lno;
  // inform symbol table about this loop's increment hidden variable
  if (!assign_magicvar(forstack[forstack_ptr].inc_var)) {
    fprintf(stderr, emsg[108], forstack[forstack_ptr].inc_var);
    return false;
  }
  // inform symbol table about this loop's increment loop limit variable
  if (!assign_magicvar(forstack[forstack_ptr].limit_var)) {
    fprintf(stderr, emsg[109], forstack[forstack_ptr].limit_var);
    return false;
  }
  // node->children[0] is the ndex_var
  // node->children[1] is start expression
  // node->children[2] is stop expression
  // node->children[3] is increment expression
  // node->children[4] is test of loop exit condition label
  // node->children[5] is body of loop label
  // node->children[6] is bottom of loop label
  // node->children[7] is hidden increment variable name
  // node->children[8] is hidden limit variable name
  node->children[4] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr].test_label, node->leaftoken->lno, 0U);
  node->children[5] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr].body_label, node->leaftoken->lno, 0U);
  node->children[6] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr].bol_label, node->leaftoken->lno, 0U);
  node->children[7] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr].inc_var, node->leaftoken->lno, 0U);
  node->children[8] = create_tree_node(0U, T_QSTRING, forstack[forstack_ptr].limit_var, node->leaftoken->lno, 0U);
  // This is the actual increment of the forstack_ptr now that we've populated
  // the next entry....
  forstack_ptr++;
  return true;
}

static bool sc_expression(
    treenode *node) { // pointer to AST node
  static char argname[2];     // buffer to hold one-byte UDF parameter variable (argument) name + terminator

  switch (node->numchildren) {
    case 0:
      switch(node->leaftoken->tid) {
        // Semantic checks include verifying the function is defined and the correct number
        // of arguments are passed, using information from the symbol table module.
        case T_FNID:
          debug_printf("call UDF named '%s' when curfunc_name = '%s'\n", node->leaftoken->toketext, curfunc_name);
          if (strcmp(curfunc_name, node->leaftoken->toketext) == 0) {
            fprintf(stderr, emsg[98], node->leaftoken->lno, node->leaftoken->toketext);
            return false;
          }
          if (!udf_exists(node->leaftoken->toketext, argname)) {
            fprintf(stderr, emsg[99], node->leaftoken->lno, node->leaftoken->toketext);
            return false;
          }
          if (argname[0]) {
            fprintf(stderr, emsg[100], node->leaftoken->lno, node->leaftoken->toketext);
            return false;
          }
          break;
        case T_NVAR:
          need_LOADREAL = need_PRINT = need_PRINT_NUMERIC = true;
          return sc_nvar(node);
        case T_DATES:
          need_DATES = true;
          need_STRINGS = true;
          break;
        case T_TIMES:
          need_TIMES = true;
          need_STRINGS = true;
          break;
        case T_QSTRING:
          {
            char *s = NULL;                // pointer to generated name of string literal
            if (!add_string_literal(node->leaftoken->toketext, &s)) {
              fprintf(stderr, "sc_expression():add_string_literal() failure on line %" PRIu32 "\n", node->leaftoken->lno);
              return false;
            } else {
              debug_printf("sc_expression():add_string_literal() succeeded on line %" PRIu32 ", yielding '%s'\n",
                           node->leaftoken->lno, s);
            }
            node->labelname = strdup(s);
            debug_printf("sc_expression() string literal '%s' has symbol '%s'\n", node->leaftoken->toketext, node->labelname);
          }
          // FALLS THROUGH
        case T_SVAR:
          need_strcmp = true;
          need_STRINGS = true;
          break;
        case T_INTEGER:
        case T_REAL:
          need_LOADREAL = true;
          break;
        case T_RND:
          need_RND = true;
          break;
          break;
        case T_DATE:
          need_DATE = true;
          break;
        case T_TIME:
          need_TIME = true;
          break;
        case T_MAXNUM:
        case T_PI:
        default:
          break;
      }
      break;
    case 1:
      if (!sc_expression(node->children[0]))
        return false;
      switch(node->leaftoken->tid) {
        case T_FNID:
          debug_printf("call UDF named '%s' when curfunc_name = '%s'\n", node->leaftoken->toketext, curfunc_name);
          if (strcmp(curfunc_name, node->leaftoken->toketext) == 0) {
            fprintf(stderr, emsg[98], node->leaftoken->lno, node->leaftoken->toketext);
            return false;
          }
          if (!udf_exists(node->leaftoken->toketext, argname)) {
            fprintf(stderr, emsg[99], node->leaftoken->lno, node->leaftoken->toketext);
            return false;
          }
          if (!argname[0]) {
            fprintf(stderr, emsg[113], node->leaftoken->lno, node->leaftoken->toketext);
            return false;
          }
          break;
        case T_NAVAR:
          debug_printf("1-D Numeric array variable named '%s'\n", node->leaftoken->toketext);
          need_READ_1D = need_LOADREAL = need_PRINT = need_PRINT_NUMERIC = true;
          return sc_navar(node);
        case T_ACOS: need_ACOS = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_ASIN: need_ASIN = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_ATN: need_ATN = true; break;
        case T_CEIL: need_CEIL = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_COS: need_COS = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_COSH: need_COSH = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_COT: need_COT = need_TAN = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_CSC: need_CSC = need_SIN = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_DEG: need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_EXP: need_EXP = need_PRINT = true; break;
        case T_FP: need_FP = need_MULTIPLY = need_SUBTRACT = need_INT = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_INT: need_INT = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_IP: need_IP = need_MULTIPLY = need_INT = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_LOG10: need_LOG10 = true; need_LOG = true; break;
        case T_LOG2: need_LOG2 = true; need_LOG = true; break;
        case T_LOG: need_LOG = true; break;
        case T_RAD: need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_SEC: need_SEC = need_COS = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_SIN: need_SIN = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_SINH: need_SINH = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_SQR: need_SQR = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_TAB: need_TAB = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_TAN: need_TAN = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_TANH: need_TANH = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_SUBTRACT:
          // intentionally do nothing and fall through
        case T_ABS:
          // intentionally do nothing and fall through
        case T_SGN:
          // intentionally do nothing and fall through
        case T_LEN:
          // intentionally do nothing and fall through
        default:
          break;
      }
      break;
    case 2:
      if (!(sc_expression(node->children[0]) &&
            sc_expression(node->children[1])))
        return false;
      switch(node->leaftoken->tid) {
        case T_ANGLE: need_ANGLE = true; break;
        case T_MOD: need_MOD = need_DIVIDE = need_MULTIPLY = need_SUBTRACT =
                    need_INT = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_REMAINDER: need_REMAINDER = need_DIVIDE = need_MULTIPLY = need_SUBTRACT =
                          need_INT = need_IP = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_ROUND: need_ROUND = need_DIVIDE = need_MULTIPLY = need_POWER = need_ADD =
                      need_INT = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_TRUNCATE: need_DIVIDE = need_MULTIPLY = need_POWER =
                         need_IP = need_INT = need_PRINT = need_PRINT_NUMERIC = true; break;
        case T_NAVAR:
          debug_printf("2-D Numeric array variable named '%s'\n", node->children[0]->leaftoken->toketext);
          need_READ_2D = need_LOADREAL = need_PRINT = need_PRINT_NUMERIC = true;
          return sc_navar(node);
        case T_ADD: need_ADD = need_PRINT = true; break;
        case T_SUBTRACT: need_SUBTRACT = need_PRINT = true; break;
        case T_MUL: need_MULTIPLY = need_PRINT = true; break;
        case T_DIV: need_DIVIDE = need_PRINT = true; break;
        case T_POW: need_POWER = need_PRINT = true; break;
        case T_MIN:
        case T_MAX:
          // intentionally do nothing and fall through
        default:
          // do nothing and fall through
          break;
      }
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, "%s", emsg[35]);
  }
  return true;
}

//
// The scalar numeric variable lookup in the symbol table has two paths:
// 1) normal, just look up a scalar numeric variable in the symbol table.
//         This path is taken if the flag in_udf_definition is false.
//         If the variable exists, emit code to push its value.
// 2) UDF, if we are in an arithmetic expression as part of a DEF statement,
//         first check if the variable is the UDF parameter variable name (if there is one).
//         If the parameter exists, emit code to push its value.
//         If that fails look up the scalar numeric variable in the symbol table.
//         If the variable exists, emit code to push its value.
//         This UDF path is only taken if the flag in_udf_definition is true.
//
static bool sc_nvar(
    treenode *node) { // pointer to AST node
  char varname[10];                                       // buffer to hold UDF parameter (argument) or variable name

  if (in_udf_definition) {                                // if we are in a UDF body
    if (curfunc_argname[0] &&
        (strcmp(node->leaftoken->toketext, curfunc_argname + 6) == 0)) {      // and this NVAR is the UDF parameter
      // don't copy 10th byte since we force terminate anyway
      size_t tlen = strlen(curfunc_argname);
      memset(varname, 0, 9);
      memcpy(varname, curfunc_argname, tlen>9U?9U:tlen);  // redirect for function parameter scalar numeric variable
      varname[9] = 0;
      debug_printf("using '%s' instead of '%s' because '%s' is UDF parameter\n",
        varname, node->leaftoken->toketext, node->leaftoken->toketext);
      free(node->leaftoken->toketext);
      node->leaftoken->toketext = strdup(varname);
    } else {                                              // otherwise it is a normal global scalar
      debug_printf("using unchanged '%s' in UDF since it is not a parameter\n", node->leaftoken->toketext);
      // don't copy 10th byte since we force terminate anyway
      strncpy(varname, node->leaftoken->toketext, 9U);    // so use the variable name unchanged
      varname[9] = 0;                                     // ensure termination
    }
  } else {                                                // otherwise (not in a UDF body)
    debug_printf("using unchanged '%s' since we are not in a UDF\n", node->leaftoken->toketext);
    // don't copy 10th byte since we force terminate anyway
    strncpy(varname, node->leaftoken->toketext, 9U);      // use the variable name unchanged
    varname[9] = 0;                                       // ensure termination
  }
  if ((!in_udf_definition) && (!nvar_exists(varname))) {  // if we are NOT in a UDF _and_ the global scalar is undefined
    if (!assign_nvar(varname, node->leaftoken->lno)) {    // define it, but if we cannot then
      return false;
    }
  }
  return true;
}

//
// As part of semantic checking, the number of indexes is checked to ensure it
// is valid.  Actual bounds checking for the expression used as indexes is
// performed at run time, not at compile time.
//
static bool sc_navar(
    treenode *node) { // pointer to AST node

  if (!navar_exists(node->leaftoken->toketext)) {
    if (!assign_navar(node->leaftoken->toketext, node->leaftoken->lno)) {
      debug_printf("assign_navar(%s) failed on line %" PRIu32 "\n", node->leaftoken->toketext, node->leaftoken->lno);
      return false;
    }
    node->ad = get_array_data(node->leaftoken->toketext);
    if (!(node->ad)) {
      debug_printf("No array data for '%s' found\n", node->leaftoken->toketext);
      if (!put_array_data(node->leaftoken->toketext, node->numchildren, 10U,
                          (1U == node->numchildren ? 0U : 10U))) {
        debug_printf("put_array_data(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") failed\n",
                     node->leaftoken->toketext, node->numchildren, 10U,
                     (1U == node->numchildren ? 0U : 10U));
        return false;
      } else {
        debug_printf("put_array_data(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") succeeded\n",
                     node->leaftoken->toketext, node->numchildren, 10U,
                     (1U == node->numchildren ? 0U : 10U));
      }
      node->ad = get_array_data(node->leaftoken->toketext);
    } else {
      debug_printf("array data for '%s' found\n", node->leaftoken->toketext);
      debug_printf("dims = %" PRIu32 ",dim1 = %" PRIu32 ",dim2 = %" PRIu32 "\n", node->ad->dims, node->ad->dim1, node->ad->dim2);
      if (0U == node->ad->dims) {
        debug_printf("%s", "update necessary\n");
        if (!put_array_data(node->leaftoken->toketext, node->numchildren, 10U,
                            (1U == node->numchildren ? 0U : 10U))) {
          debug_printf("put_array_data(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") failed\n",
                       node->leaftoken->toketext, node->numchildren, 10U,
                       (1U == node->numchildren ? 0U : 10U));
          return false;
        } else {
          debug_printf("put_array_data(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") succeeded\n",
                       node->leaftoken->toketext, node->numchildren, 10U,
                       (1U == node->numchildren ? 0U : 10U));
        }
      } else {
        if (node->ad->dims != node->numchildren) {
          fprintf(stderr, emsg[36], node->leaftoken->lno, node->leaftoken->toketext, node->numchildren, node->ad->dims);
          return false;
        }
        debug_printf("%s", "no update necessary\n");
      }
    }
  } else {
    node->ad = get_array_data(node->leaftoken->toketext);
    if (!(node->ad)) {
      debug_printf("No array data for '%s' found\n", node->leaftoken->toketext);
      return false;
    }
    debug_printf("array data for '%s' found\n", node->leaftoken->toketext);
    debug_printf("dims = %" PRIu32 ",dim1 = %" PRIu32 ",dim2 = %" PRIu32 "\n", node->ad->dims, node->ad->dim1, node->ad->dim2);
    if (node->ad->dims != node->numchildren) {
      ICE(__FILE__, __func__, __LINE__, emsg[36],
          node->leaftoken->lno, node->leaftoken->toketext, node->numchildren, node->ad->dims);
    }
  }
  switch (node->numchildren) {
    case 1U:
    case 2U:
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[37], node->leaftoken->lno, node->leaftoken->toketext, node->numchildren);
  }
  can_option_base = false;
  return true;
}

static bool sc_target_variable(
    treenode *node) { // pointer to AST node

  switch (node->leaftoken->tid) {
    case T_NAVAR:
      node->ad = get_array_data(node->leaftoken->toketext);
      if (!assign_navar(node->leaftoken->toketext, node->leaftoken->lno)) {
        return false;
      }
      if (!(node->ad)) {
        debug_printf("No array data for '%s' found\n", node->leaftoken->toketext);
        if (!put_array_data(node->leaftoken->toketext, node->numchildren, 10U,
                            ((1U == node->numchildren) ? 0U : 10U))) {
          debug_printf("put_array_data(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") failed\n",
                       node->leaftoken->toketext, node->numchildren, 10U,
                       (1U == node->numchildren ? 0U : 10U));
          return false;
        } else {
          debug_printf("put_array_data(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") succeeded\n",
                       node->leaftoken->toketext, node->numchildren, 10U,
                       (1U == node->numchildren ? 0U : 10U));
        }
        node->ad = get_array_data(node->leaftoken->toketext);
      } else {
        debug_printf("array data for '%s' found\n", node->leaftoken->toketext);
        debug_printf("dims = %" PRIu32 ",dim1 = %" PRIu32 ",dim2 = %" PRIu32 "\n", node->ad->dims, node->ad->dim1, node->ad->dim2);
        if (0U == node->ad->dims) {
          debug_printf("%s", "update necessary\n");
          if (!put_array_data(node->leaftoken->toketext,
                              node->numchildren, 10U,
                              (1U == node->numchildren ? 0U : 10U))) {
            debug_printf("put_array_data(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") failed\n",
                         node->leaftoken->toketext, node->numchildren, 10U,
                         (1U == node->numchildren ? 0U : 10U));
            return false;
          } else {
            debug_printf("put_array_data(%s,%" PRIu32 ",%" PRIu32 ",%" PRIu32 ") succeeded\n",
                         node->leaftoken->toketext, node->numchildren, 10U,
                         (1U == node->numchildren ? 0U : 10U));
          }
          node->ad = get_array_data(node->leaftoken->toketext);
        } else {
          if (node->ad->dims != node->numchildren) {
            fprintf(stderr, emsg[110], node->leaftoken->lno, node->leaftoken->toketext, node->numchildren, node->ad->dims);
            return false;
          }
          debug_printf("%s", "no update necessary\n");
        }
      }
      switch(node->ad->dims) {
        case 1U:
          if (!sc_expression(node->children[0]))
            return false;
          need_WRITE_1D = true;
          break;
        case 2U:
          if (!sc_expression(node->children[0]))
            return false;
          if (!sc_expression(node->children[1]))
            return false;
          need_WRITE_2D = true;
          break;
        default:
          // do nothing and fall through
          break;
      }
      can_option_base = false;
      break;
    case T_NVAR:
      return assign_nvar(node->leaftoken->toketext, node->leaftoken->lno);
    case T_SVAR:
      need_STRINGS = true;
      need_strcpy = true;
      need_strcmp = true;
      return assign_svar(node->leaftoken->toketext);
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[38], token_names[T_LET] + 2);
  }
  return true;
}

//
// This will process the DIM statement.  This is used to update the symbol
// table with information about the number of dimensions and the maximum
// value for indices for each dimension for numeric arrays.
// Returns true on success, false otherwise.
//
static bool sc_dimstmt(
    treenode *node) { // pointer to AST node

  // for each child
  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    treenode *temp = node->children[i]; // temporary pointer to a child

    if (!assign_navar(temp->leaftoken->toketext, temp->leaftoken->lno)) {
      fprintf(stderr, emsg[111], temp->leaftoken->lno, temp->leaftoken->toketext);
      return false;
    }
    switch(temp->numchildren) {
      case 1U:
        if ((base_is_one) && (0U == temp->children[0]->numeric_value.uivalue)) {
          fprintf(stderr, emsg[112], temp->children[0]->leaftoken->lno, token_names[T_DIM] + 2,
                  token_names[T_OPTION] + 2, token_names[T_BASE] + 2);
          return false;
        }
        break;
      case 2U:
        if ((base_is_one) && (0U == temp->children[0]->numeric_value.uivalue)) {
          fprintf(stderr, emsg[112], temp->children[0]->leaftoken->lno, token_names[T_DIM] + 2,
                  token_names[T_OPTION] + 2, token_names[T_BASE] + 2);
          return false;
        }
        if ((base_is_one) && (0U == temp->children[1]->numeric_value.uivalue)) {
          fprintf(stderr, emsg[112], temp->children[1]->leaftoken->lno, token_names[T_DIM] + 2,
                  token_names[T_OPTION] + 2, token_names[T_BASE] + 2);
          return false;
        }
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[39], __func__);
    }
    if (!put_array_data(temp->leaftoken->toketext, temp->numchildren, temp->children[0]->numeric_value.uivalue,
                        (1U == temp->numchildren) ? 0U : temp->children[1]->numeric_value.uivalue)) {
      arraydata *ad = NULL;

      ad = get_array_data(temp->leaftoken->toketext);
      if (!ad)
        ICE(__FILE__, __func__, __LINE__, emsg[40], token_names[T_DIM] + 2, temp->leaftoken->toketext,
            temp->leaftoken->lno);
      if (ad->dims) {
        switch (ad->dims) {
          case 1U:
            fprintf(stderr, emsg[114], temp->leaftoken->lno, token_names[T_DIM] + 2, temp->leaftoken->toketext,
                    ad->dims, ad->dim1);
            break;
          case 2U:
            fprintf(stderr, emsg[115], temp->leaftoken->lno, token_names[T_DIM] + 2, temp->leaftoken->toketext,
                    ad->dims, ad->dim1, ad->dim2);
            break;
          default:
            ICE(__FILE__, __func__, __LINE__, emsg[117], ad->dims);
        }
      } else {
        fprintf(stderr, emsg[116], temp->leaftoken->lno, token_names[T_DIM] + 2, temp->leaftoken->toketext);
      }
      return false;
    }
  }
  can_option_base = false;
  return true;
}

//
// This processes the OPTION BASE statement tree node and does not
// emit code, but does set two flags.  If successful, before returning true
// this function will set the global variable can_option_base to false, to
// prohibit multiple OPTION BASE statements. It also will update the global
// variable base_is_one depending to the value of T_INTEGER, which must
// be 0 or 1.
//
// If can_option_base is false, then the program has already
// had an OPTION BASE, a DIM, or an array reference.  In that
// case it is not permitted to change the array base setting
// and an error message will be displayed.
// On succes, true is returned, otherwise false is returned.
//
static bool sc_optionbasestmt(
    treenode *node) {          // pointer to AST node
  unsigned int value;                  // argument of OPTION BASE (should be 0 or 1)

  if ((strcmp(node->children[0]->children[0]->leaftoken->toketext, "0") != 0) &&
      (strcmp(node->children[0]->children[0]->leaftoken->toketext, "1") != 0)) {
    fprintf(stderr, emsg[118], node->children[0]->children[0]->leaftoken->lno);
    return false;
  }
  // convert the digit from ASCIIZ to unsigned integer
  value = (unsigned int)(node->children[0]->children[0]->leaftoken->toketext[0] - 48);
  if (value && (value != 1U)) { // verify it is either 0 or 1
    fprintf(stderr, emsg[118], node->children[0]->children[0]->leaftoken->lno);
    return false;
  }
  if (!can_option_base) { // ensure we are still permitted to set the base
    fprintf(stderr, emsg[119], node->children[0]->children[0]->leaftoken->lno);
    return false;
  }
  // finally, set the array minimum subscript (base) value and
  // the flag prohibiting changing it
  can_option_base = false;
  base_is_one = ((1U == value) ? true : false);
  return true;
}

//
// Returns true if it is permitted for program to jump from the line specified by
// from_slotno to the line specified by to_slotno, false otherwise.
//
static bool new_jump_permitted(
    treenode *root,            // pointer to root of AST
    uint32_t from_slotno,              // index in root->children[] of line to jump from
    uint32_t to_slotno) {              // index in root->children[] of jump target line
  size_t fromscopelen;                 // length of scope of caller
  size_t toscopelen;                   // length of scope of target

  fromscopelen = strlen(root->children[from_slotno]->labelname);  // get length of scope of caller
  toscopelen = strlen(root->children[to_slotno]->labelname);      // get length of scope of destination
  if (fromscopelen < toscopelen) {                                // if the jump is to an outer scope it
                                                                  // is not OK, note the error
    fprintf(stderr, emsg[94],
            root->children[from_slotno]->children[0]->numeric_value.uivalue,
            root->children[to_slotno]->children[0]->numeric_value.uivalue);
    return false;
  }
  // if the jump is to a scope of the same level but still a different scope, that is not OK, note the error
  if ((fromscopelen == toscopelen) &&
      (strcmp(root->children[from_slotno]->labelname, root->children[to_slotno]->labelname) != 0)) {
    fprintf(stderr, emsg[94],
            root->children[from_slotno]->children[0]->numeric_value.uivalue,
            root->children[to_slotno]->children[0]->numeric_value.uivalue);
    return false;
  }
  return true;
}

//
// Compare two unsigned integer numbers, left and right.  A pointer to this function is passed
// to mybsearch() to help find line numbers in the root AST node children[] array which has one
// entry for each source line of the input ECMA-55 Minimal BASIC program.
//
// Returns an integer < 0 if left <  right,
//                      0 if left == right,
//      or an integer > 0 if left > right
//
static int compare_line_numbers(
    const void *left,                  // pointer to first integer value
    const void *right) {               // pointer to second integer value
  return ((int)(*(treenode **)left)->children[0]->numeric_value.uivalue) - (int)(*((uint32_t *)right));
}

//
// Add declared line numbers to symbol table
//
static bool sc_addlines(
    treenode *node) {          // pointer to root of AST

  debug_printf("%s", "Add declared line numbers to symbol table.\n");
  // for each statement node
  for (unsigned int lineno = 0U; lineno < node->numchildren; ++lineno) {
    uint32_t tlineno;                  // line number variable to hold returned value from convert_line_number()
    char msg[ERROR_BUFFER_LEN];        // pointer to error message buffer

    debug_printf("Add line %s\n", node->children[lineno]->children[0]->leaftoken->toketext);
    if (!convert_line_number(node->children[lineno]->children[0]->leaftoken->toketext, &tlineno, msg)) {
      fputs(msg, stderr);
      return false;
    }
    if (lineno > 0U) {
      unsigned int slotno;

      slotno = mybsearch(&tlineno, &node->children[0], lineno, sizeof(treenode *), compare_line_numbers);
      if (slotno < lineno) {
        fprintf(stderr, emsg[95], tlineno);
        return false;
      }
      if (tlineno < node->children[lineno - 1]->numeric_value.uivalue) {
        fprintf(stderr, emsg[96], tlineno, node->children[lineno - 1]->numeric_value.uivalue);
        return false;
      }
    }
    node->children[lineno]->numeric_value.uivalue = tlineno;
  }
  return true;
}

//
// check scopes of loop index variables
//
static bool sc_check_loopindex_scope(
    treenode *node) {          // pointer to root of AST
  char *curscope = NULL;       // buffer to hold current scope prefix string
  bool retval = true;

  curscope = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_SCOPE_BYTES+1));
  curscope[0] = 0;
  forstack_ptr = 0U;
  // for all statement nodes
  for (unsigned int lineno = 0U; lineno < node->numchildren; ++lineno) {
    static char *dotspot;                     // pointer to scope delimiter in current scope string

    node->children[lineno]->labelname = strdup(curscope);
    switch (node->children[lineno]->children[1]->leaftoken->tid) {
      case T_FOR:
        strcat(curscope, ".");
        strcat(curscope, node->children[lineno]->children[1]->children[0]->leaftoken->toketext);
        debug_printf("After FOR %s current scope is now 'global%s' on line %s\n",
                     node->children[lineno]->children[1]->children[0]->leaftoken->toketext,
                     (curscope[0] ? curscope : "global"), node->children[lineno]->children[0]->leaftoken->toketext);
        if (!sc_forstmt(node->children[lineno]->children[1])) {
          retval = false;
          goto xit;
        }
        break;
      case T_EXIT:
        dotspot = strrchr(curscope, '.');
        if (dotspot)
          *dotspot = (char)0; // the actual scope string chop
        debug_printf("At %s %s current scope is now 'global%s' on line %s\n",
                     token_names[T_EXIT] + 2, token_names[T_FOR] + 2,
                     (curscope[0] ? curscope : "global"), node->children[lineno]->children[0]->leaftoken->toketext);
        if (!sc_exitforstmt(node->children[lineno]->children[1])) {
          retval = false;
          goto xit;
        }
        break;
      case T_NEXT:
        dotspot = strrchr(curscope, '.');
        if (dotspot)
          *dotspot = (char)0; // the actual scope string chop
        debug_printf("After %s %s current scope is now 'global%s' on line %s\n",
                     token_names[T_NEXT] + 2,
                     node->children[lineno]->children[1]->children[0]->leaftoken->toketext,
                     (curscope[0] ? curscope : "global"), node->children[lineno]->children[0]->leaftoken->toketext);
        if (!sc_nextstmt(node->children[lineno]->children[1])) {
          retval = false;
          goto xit;
        }
        break;
      default:
        break;
    }
  }
xit:
  free(curscope); curscope = NULL;
  return retval;
}

//
// Ensure all referenced jump target line numbers exist
//
static bool sc_verify_jump_targets(
    treenode *root) {          // pointer to root of AST
  bool retval = false;         // function return value

  debug_printf("can_option_base = %s\n", (can_option_base ? "true" : "false"));
  debug_printf("%s", "Ensure all referenced jump target line numbers exist.\n");
  // for each statement root
  for (unsigned int lineno = 0U; lineno < root->numchildren; ++lineno) {
    switch (root->children[lineno]->children[1]->leaftoken->tid) {
      case T_GOSUB:
      case T_GOTO:
        {
          unsigned int to_lineno_slotno;

          to_lineno_slotno = mybsearch(&(root->children[lineno]->children[1]->numeric_value.uivalue),
                                       &root->children[0], root->numchildren, sizeof(treenode *), compare_line_numbers);
          if (to_lineno_slotno >= root->numchildren) {
            fprintf(stderr,
                    "On line number %" PRIu32 ", %s referenced line number %" PRIu32
                    " which does not exist in the source program.\n",
                    root->children[lineno]->children[0]->numeric_value.uivalue,
                    token_names[root->children[lineno]->children[1]->leaftoken->tid] + 2,
                    root->children[lineno]->children[1]->numeric_value.uivalue);
            goto xit;
          }
          if (!new_jump_permitted(root, lineno, to_lineno_slotno))
            goto xit;
          root->children[lineno]->children[1]->numeric_value.uivalue = to_lineno_slotno;
        }
        break;
      case T_ON:
        // for each child root
        for (unsigned int i = 1U; i < root->children[lineno]->children[1]->numchildren; ++i) {
          unsigned int to_lineno_slotno;

          to_lineno_slotno = mybsearch(&(root->children[lineno]->children[1]->children[i]->numeric_value.uivalue),
                                       &root->children[0], root->numchildren, sizeof(treenode *), compare_line_numbers);
          if (to_lineno_slotno >= root->numchildren) {
            fprintf(stderr,
                    "On line number %" PRIu32 ", %s referenced line number %" PRIu32
                    " which does not exist in the source program.\n",
                    root->children[lineno]->children[0]->numeric_value.uivalue,
                    token_names[root->children[lineno]->children[1]->leaftoken->tid] + 2,
                    root->children[lineno]->children[1]->children[i]->numeric_value.uivalue);
            goto xit;
          }
          if (!new_jump_permitted(root, lineno, to_lineno_slotno))
            goto xit;
          root->children[lineno]->children[1]->children[i]->numeric_value.uivalue = to_lineno_slotno;
        }
        break;
      case T_IF:
        {
          unsigned int to_lineno_slotno;

          to_lineno_slotno = mybsearch(&(root->children[lineno]->children[1]->children[1]->numeric_value.uivalue),
                                       &root->children[0], root->numchildren, sizeof(treenode *), compare_line_numbers);
          if (to_lineno_slotno >= root->numchildren) {
            fprintf(stderr,
                    "On line number %" PRIu32 ", %s referenced line number %" PRIu32
                    " which does not exist in the source program.\n",
                    root->children[lineno]->children[0]->numeric_value.uivalue,
                    token_names[root->children[lineno]->children[1]->leaftoken->tid] + 2,
                    root->children[lineno]->children[1]->children[1]->numeric_value.uivalue);
            goto xit;
          }
          if (!new_jump_permitted(root, lineno, to_lineno_slotno))
            goto xit;
          root->children[lineno]->children[1]->numeric_value.uivalue = to_lineno_slotno;
        }
        break;
      case T_RESTORE:
      case T_FOR:
      case T_EXIT:
      case T_NEXT:
      case T_DATA:
      case T_DEF:
      case T_DIM:
      case T_END:
      case T_INPUT:
      case T_LET:
      case T_OPTION:
      case T_PRINT:
      case T_RANDOMIZE:
      case T_READ:
      case T_REM:
      case T_RETURN:
      case T_STOP:
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, "%s", emsg[35]);
    }
  }
  retval = true;
xit:
  return retval;
}

//
// visit real root of an AST and set its parent_count2 to 0
// after setting all of its children node's parent_count2's to 1 (recursively)
// WARNING: Do not run this on an ASD...
//
static void tree_setall_parent_count2s(
    treenode **root) {   // pointer to genuine root of the subtree of the AST being processed

  for (unsigned int i = 0U; i < (*root)->numchildren; ++i)
    subtree_setall_parent_count2s_to_one(&((*root)->children[i]));
  (*root)->parent_count2 = 0; // root node has no parent
  return;
}

//
// visit a node in an AST and set its parent_count2 to 1 (recursively)
// WARNING: Do not run this on an ASD...
//
static void subtree_setall_parent_count2s_to_one(
    treenode **node) {   // pointer to the node of the subtree of the AST being processed

  if (*node) {
    for (unsigned int i = 0U; i < (*node)->numchildren; ++i)
      subtree_setall_parent_count2s_to_one(&((*node)->children[i]));
    (*node)->parent_count2 = 1; // in a tree every node _but_ root has one parent
  }
  return;
}

//
// Ensure all referenced jump target line numbers link to
// actual line numbers, converting the AST into an ASD
// WARNING: This is done in-place, modifying the original
//          AST, so you need to use dag_delete_all(), not
//          tree_delete_all(), to recycle the ASD's memory.
// WARNING: You need to have already have used the
//          sc_verify_jump_targets() to process the AST
//          since this needs the changes that makes _and_
//          this assumes the AST jump targets are valid
//          and does not do error checking.
//
static void sc_DAGify_jump_targets(
    treenode *root) {          // pointer to genuine root of AST

  debug_printf("%s", "Ensure all referenced jump target line numbers link to\n"
                     "actual line numbers, converting the AST into an ASD.\n");
  // first mark all the nodes with proper parent counts for a tree
  tree_setall_parent_count2s(&root);
  // for each statement root
  for (unsigned int lineno = 0U; lineno < root->numchildren; ++lineno) {
    unsigned int lineno_slotno;

    switch (root->children[lineno]->children[1]->leaftoken->tid) {
      case T_GOSUB:
      case T_GOTO:
        {
          lineno_slotno = root->children[lineno]->children[1]->numeric_value.uivalue;
          // for the target line number
          free(root->children[lineno]->children[1]->children[0]->leaftoken->toketext);
          root->children[lineno]->children[1]->children[0]->leaftoken->toketext = NULL;
          free(root->children[lineno]->children[1]->children[0]->leaftoken);
          root->children[lineno]->children[1]->children[0]->leaftoken = NULL;
          free(root->children[lineno]->children[1]->children[0]);
          root->children[lineno]->children[1]->children[0] = root->children[lineno_slotno]->children[0];
          root->children[lineno_slotno]->children[0]->parent_count2++;
        }
        break;
      case T_ON:
        // for each target line number
        for (unsigned int i = 1U; i < root->children[lineno]->children[1]->numchildren; ++i) {
          lineno_slotno = root->children[lineno]->children[1]->children[i]->numeric_value.uivalue;
          free(root->children[lineno]->children[1]->children[i]->leaftoken->toketext);
          root->children[lineno]->children[1]->children[i]->leaftoken->toketext = NULL;
          free(root->children[lineno]->children[1]->children[i]->leaftoken);
          root->children[lineno]->children[1]->children[i]->leaftoken = NULL;
          free(root->children[lineno]->children[1]->children[i]);
          root->children[lineno]->children[1]->children[i]=root->children[lineno_slotno]->children[0];
          root->children[lineno_slotno]->children[0]->parent_count2++;
        }
        break;
      case T_IF:
        {
          // for the target line number
          lineno_slotno = root->children[lineno]->children[1]->numeric_value.uivalue;
          free(root->children[lineno]->children[1]->children[1]->leaftoken->toketext);
          root->children[lineno]->children[1]->children[1]->leaftoken->toketext = NULL;
          free(root->children[lineno]->children[1]->children[1]->leaftoken);
          root->children[lineno]->children[1]->children[1]->leaftoken = NULL;
          free(root->children[lineno]->children[1]->children[1]);
          root->children[lineno]->children[1]->children[1] = root->children[lineno_slotno]->children[0];
          root->children[lineno_slotno]->children[0]->parent_count2++;
        }
        break;
      default: // ignore anything that isn't flow-control
        break;
    }
  }
  return;
}

static bool sc_print(
    treenode *node) {          // pointer to root of AST

  need_PRINT = true;
  // for all children nodes
  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    switch (node->children[i]->leaftoken->tid) {
      case T_SVAR:
        if (!svar_exists(node->children[i]->leaftoken->toketext)) {
          if (!assign_svar(node->children[i]->leaftoken->toketext))
            return false;
          debug_printf("sc_print():string variable '%s' added\n",
                       node->children[i]->leaftoken->toketext);
          need_STRINGS = true;
        } else {
          debug_printf("sc_print():string variable '%s' already exists\n",
                       node->children[i]->leaftoken->toketext);
        }
        break;
      case T_DATES:   // -X
        need_DATES = true;
        need_STRINGS = true;
        break;
      case T_TIMES:   // -X
        need_TIMES = true;
        need_STRINGS = true;
        break;
      case T_QSTRING:
      case T_UQSTRING:
        {
          char *s = NULL;                // pointer to generated name of string literal
          if (!add_string_literal(node->children[i]->leaftoken->toketext, &s)) {
            fprintf(stderr, "sc_print():add_string_literal() failure on line %" PRIu32 "\n",
                    node->children[i]->leaftoken->lno);
            return false;
          } else {
            debug_printf("sc_print():add_string_literal() succeeded on line %" PRIu32 ", yielding '%s'\n",
                         node->children[i]->leaftoken->lno, s);
          }
          node->children[i]->labelname = strdup(s);
          debug_printf("sc_print() string literal '%s' has symbol '%s'\n",
                       node->children[i]->leaftoken->toketext,
                       node->children[i]->labelname);
        }
        // special case for newline
        if (strcmp(node->children[i]->leaftoken->toketext, "\\n") != 0)
          need_STRINGS = true;
        break;
      case T_COMMA:
      case T_SEMI:
        break;
      case T_ABS:
      case T_ACOS:       // -X
      case T_ADD:
      case T_ANGLE:      // -X
      case T_ASIN:       // -X
      case T_ATN:
      case T_CEIL:       // -X
      case T_COS:
      case T_COSH:       // -X
      case T_COT:        // -X
      case T_CSC:        // -X
      case T_DATE:       // -X
      case T_DEG:        // -X
      case T_DIV:
      case T_EXP:
      case T_FNID:
      case T_FP:         // -X
      case T_INT:
      case T_INTEGER:
      case T_IP:         // -X
      case T_LEN:        // -X
      case T_LOG10:      // -X
      case T_LOG2:       // -X
      case T_LOG:
      case T_MAX:        // -X
      case T_MAXNUM:     // -X
      case T_MIN:        // -X
      case T_MOD:        // -X
      case T_MUL:
      case T_NAVAR:
      case T_NVAR:
      case T_PI:         // -X
      case T_POW:
      case T_RAD:        // -X
      case T_REAL:
      case T_REMAINDER:  // -X
      case T_RND:
      case T_ROUND:      // -X
      case T_SEC:        // -X
      case T_SGN:
      case T_SIN:
      case T_SINH:       // -X
      case T_SQR:
      case T_SUBTRACT:
      case T_TAB:
      case T_TAN:
      case T_TANH:       // -X
      case T_TIME:       // -X
      case T_TRUNCATE:   // -X
        need_PRINT_NUMERIC = true;
        if (!sc_expression(node->children[i]))
          return false;
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[42],
            token_names[node->children[i]->leaftoken->tid] + 2);
    }
  }
  return true;
}

static bool sc_read(
    treenode *node,            // pointer to root of AST
    unsigned int lineno) {     // line number for this READ statement

  if (0 == READ_lineno)        // if this is the very first READ statement in the program
                               // save line number of this READ for error messages
    READ_lineno = node->children[lineno]->children[1]->leaftoken->lno;
  need_READSTMT = true;
  for (unsigned int i = 0U; i < node->children[lineno]->children[1]->numchildren; ++i) {
    if (!sc_target_variable(node->children[lineno]->children[1]->children[i]))
      return false;
    switch (node->children[lineno]->children[1]->children[i]->leaftoken->tid) {
      case T_SVAR:
        need_READSTMT_SVAR = true;
        break;
      case T_NVAR:
        need_READSTMT_NVAR = true;
        break;
      case T_NAVAR:
        if (1U == node->children[lineno]->children[1]->children[i]->ad->dims)
          need_READSTMT_NAVAR_1D = true;
        else
          need_READSTMT_NAVAR_2D = true;
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, "%s", emsg[206]);
    }
  }
  return true;
}

static bool sc_input(
    treenode *node,            // pointer to root of AST
    unsigned int lineno) {             // line number for this READ statement

  need_INPUT = need_strcmp = need_strcpy = true;
  for (unsigned int i = 0U; i < node->children[lineno]->children[1]->numchildren; ++i) {
    if (!sc_target_variable(node->children[lineno]->children[1]->children[i]))
      return false;
    switch (node->children[lineno]->children[1]->children[i]->leaftoken->tid) {
      case T_SVAR:
        break;
      case T_NVAR:
        need_INPUT_NVAR = true;
        break;
      case T_NAVAR:
        if (1U == node->children[lineno]->children[1]->children[i]->ad->dims)
          need_INPUT_NAVAR_1D = true;
        else
          need_INPUT_NAVAR_2D = true;
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, "%s", emsg[207]);
    }
  }
  return true;
}

static bool sc_def(
    treenode *node) {          // pointer to AST
  // Minimal BASIC explicitely disallows recursive UDFs, and a semantic check is
  // made to enforce that rule.  The in_udf_definition flag will be true if this
  // production is called as part of the arithmetic expression in a DEF
  // statement, and false otherwise.
  if (3U == node->numchildren) {
    if (!add_udf(node->children[0]->leaftoken->toketext,
                 node->children[1]->leaftoken->toketext,
                 node->children[0]->leaftoken->lno))
      return false;
    sprintf(curfunc_argname, ".LFN%c_%s",           // set current function argument name
            node->children[0]->leaftoken->toketext[2],
            node->children[1]->leaftoken->toketext);
  } else {
    if (!add_udf(node->children[0]->leaftoken->toketext,
                 NULL, node->children[0]->leaftoken->lno))
      return false;
    curfunc_argname[0] = 0; // erase current function argument name
  }
  strcpy(curfunc_name, node->children[0]->leaftoken->toketext);
  in_udf_definition = true;
  if (!sc_expression(node->children[node->numchildren - 1U]))
    return false;
  in_udf_definition = false;
  curfunc_name[0] = curfunc_argname[0] = 0;
  need_UDF = need_PRINT = need_PRINT_NUMERIC = true;
  return true;
}

bool semantic_checks(
    treenode *root) {          // pointer to genuine root of AST
  bool retval = false;         // function return value
  unsigned int ndex;           // loop index variable

  // forstack allocated here
  forstack = (struct forstack_entry *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct forstack_entry) * FORSTACK_DEPTH);
  for (ndex=0;ndex<FORSTACK_DEPTH;++ndex) {
    forstack[ndex].body_label = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_FOR_LABEL_BYTES+1));
    forstack[ndex].body_label[0] = 0;
    forstack[ndex].test_label = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_FOR_LABEL_BYTES+1));
    forstack[ndex].test_label[0] = 0;
    forstack[ndex].bol_label = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_FOR_LABEL_BYTES+1));
    forstack[ndex].bol_label[0] = 0;
    forstack[ndex].ndex_var = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_FOR_VAR_BYTES+1));
    forstack[ndex].ndex_var[0] = 0;
    forstack[ndex].inc_var = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_FOR_VAR_BYTES+1));
    forstack[ndex].inc_var[0] = 0;
    forstack[ndex].limit_var = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_FOR_VAR_BYTES+1));
    forstack[ndex].limit_var[0] = 0;
    forstack[ndex].scope = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_SCOPE_BYTES+1));
    forstack[ndex].scope[0] = 0;
  }
  forstack_ptr = 0U;
  // current_scope allocated here
  current_scope = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*(MAX_SCOPE_BYTES+1));
  current_scope[0] = 0;
  if (!(sc_addlines(root) &&
        sc_check_loopindex_scope(root) &&
        sc_verify_jump_targets(root)))
     goto xit;
  debug_printf("Populating symbol table\n"
               "can_option_base = %s\n", (can_option_base ? "true" : "false"));
  // for each statement node
  for (unsigned int lineno = 0U; lineno < root->numchildren; ++lineno) {
    debug_printf("Processing %4u%s line of input program with BASIC line number %4" PRIu32 ", a '%s' statement\n",
                 lineno + 1U, suffix((uint32_t)(lineno + 1U)),
                 root->children[lineno]->children[0]->numeric_value.uivalue,
                 token_names[root->children[lineno]->children[1]->leaftoken->tid] + 2);
    switch (root->children[lineno]->children[1]->leaftoken->tid) {
      case T_PRINT:
        if (!sc_print(root->children[lineno]->children[1]))
          goto xit;
        break;
      case T_ON:
        if (!sc_expression(root->children[lineno]->children[1]->children[0]))
          goto xit;
        need_PRINT = need_ONGOTO = true;
        break;
      case T_OPTION:
        if (!sc_optionbasestmt(root->children[lineno]->children[1]))
          goto xit;
        break;
      case T_GOSUB:
      case T_RETURN:
        need_SUBROUTINE = true; // need to set this BEFORE code generation
        break;
      case T_RANDOMIZE: need_RND = true; break;
      case T_END:
        if (lineno != root->numchildren - 1) {
          fprintf(stderr, emsg[123], root->children[lineno]->children[0]->leaftoken->toketext);
          retval = false;
          goto xit;
        }
        break;
      case T_GOTO:
      case T_RESTORE:
      case T_STOP:
      case T_REM:
        break;
      case T_DATA:
        debug_printf("have_DATA is now being set to true on line %s\n",
                     root->children[lineno]->children[0]->leaftoken->toketext);
        debug_printf("but for %s????\n", token_names[root->children[lineno]->children[1]->leaftoken->tid] + 2);
        need_strcpy = have_DATA = true;
        break;
      case T_LET:
        if (!(sc_target_variable(root->children[lineno]->children[1]->children[0]) &&
              sc_expression(root->children[lineno]->children[1]->children[1])))
          goto xit;
        break;
      case T_IF:
        if (!sc_expression(root->children[lineno]->children[1]->children[0]))
          goto xit;
        break;
      case T_READ:
        if (!sc_read(root, lineno))
          goto xit;
        break;
      case T_INPUT:
        if (!sc_input(root, lineno))
          goto xit;
        break;
      case T_EXIT:
        need_FORNEXT = need_ADD = need_SUBTRACT = need_MULTIPLY = true;
        break;
      case T_NEXT:
        if (!sc_expression(root->children[lineno]->children[1]->children[0]))
          goto xit;
        need_FORNEXT = need_ADD = need_SUBTRACT = need_MULTIPLY = true;
        break;
      case T_FOR:
        if (!(sc_expression(root->children[lineno]->children[1]->children[0]) &&
              sc_expression(root->children[lineno]->children[1]->children[1]) &&
              sc_expression(root->children[lineno]->children[1]->children[2]) &&
              sc_expression(root->children[lineno]->children[1]->children[3])))
          goto xit;
        need_FORNEXT = need_ADD = need_SUBTRACT = need_MULTIPLY = true;
        break;
      case T_DEF:
        if (!sc_def(root->children[lineno]->children[1]))
          goto xit;
        break;
      case T_DIM:
        if (!sc_dimstmt(root->children[lineno]->children[1]))
          goto xit;
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[43], token_names[root->children[lineno]->children[1]->leaftoken->tid] + 2);
    }
  }
  retval = true;                     // hope for the best
xit:
  // end statement check
  if (T_END != root->children[root->numchildren - 1]->children[1]->leaftoken->tid) {
    fputs(emsg[120], stderr);
    retval = false;
  }
  if (retval && forstack_ptr) {      // if there were unclosed FOR loops during compilation
    uint32_t i = forstack_ptr;

    while (i > 0U) {        // for each unclosed FOR loop, report the error
      i--;
      fprintf(stderr, emsg[121], forstack[i].lineno, token_names[T_FOR] + 2, forstack[i].ndex_var, token_names[T_NEXT] + 2);
    }
    retval = false;                  // and ensure we return an error
  }
  if (retval && need_READSTMT && (!have_DATA)) {   // if there was a READ statement but no DATA statement
    fprintf(stderr, emsg[122], READ_lineno);
    retval = false;                    // and ensure we return an error
  }
  // current_scope deallocated here
  free(current_scope); current_scope = NULL;
  // forstack deallocated here
  for (ndex=FORSTACK_DEPTH;ndex>0;--ndex) {
    free(forstack[ndex-1].scope); forstack[ndex-1].scope = NULL;
    free(forstack[ndex-1].limit_var); forstack[ndex-1].limit_var = NULL;
    free(forstack[ndex-1].inc_var); forstack[ndex-1].inc_var = NULL;
    free(forstack[ndex-1].ndex_var); forstack[ndex-1].ndex_var = NULL;
    free(forstack[ndex-1].bol_label); forstack[ndex-1].bol_label = NULL;
    free(forstack[ndex-1].test_label); forstack[ndex-1].test_label = NULL;
    free(forstack[ndex-1].body_label); forstack[ndex-1].body_label = NULL;
  }
  free(forstack); forstack = NULL;
  if ((!retval) && verbose) {
    fputs("\n********* SYMBOL TABLE ********\n\n", stderr);
    dump_symbol_table(false);
    fflush(stdout);
  }
  if (!retval)
    clear_symbol_table(); // deallocate symbol table dynamic memory if we cannot generate assembly
  else {
    sc_DAGify_jump_targets(root); // convert AST to ASG with jump targets linked to actual line number nodes
  }
  return retval;
}

#ifdef UNIT_TEST
#include <errno.h>
#include <getopt.h>
#include "dag.h"
#include "ast.h"

static int test1(void);

static int test1(void) {
  treenode *root = NULL,
           *curnode = NULL,
           *leftchild = NULL,
           *rightchild = NULL;
  struct token *curtoken = NULL;
  bool retval;

  //
  // A silly program which would crash when run, but large enough for testing and it is a special
  // case requiring need_PRINT_NUMERIC and need_PRINT even though there are no PRINT statements.
  // Those flags must be set becaues the error handling for things like uninitialized variables
  // (which this program has), divide by zero, NaN, underflow, or overflow might occur, and those
  // need to print the error messages, perhaps with a value.
  //
  // 10 LET X=A/B
  // 20 END
  //
  puts("TREE:\n"
       "                          T_PROGRAM\n"
       "                        /           \\\n"
       "                     /                \\\n"
       "                  /                     \\\n"
       "          T_LINE                        T_LINE\n"
       "        /        \\                   /         \\\n"
       "      10          LET              20            END\n"
       "                /     \\\n"
       "              X         DIV\n"
       "                      /     \\\n"
       "                    A         B\n");
  fflush(stdout);



  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 10U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  leftchild = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 10U;
  curtoken->cno = 12U;
  curtoken->pos = 12U;
  rightchild = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("/");
  curtoken->tid = T_DIV;
  curtoken->lno = 10U;
  curtoken->cno = 11U;
  curtoken->pos = 11U;
  curnode = create_tree_node2(2U, curtoken);
  curnode->children[0] = leftchild;
  curnode->children[1] = rightchild;

  rightchild = curnode;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("X");
  curtoken->tid = T_NVAR;
  curtoken->lno = 10U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  leftchild = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("LET");
  curtoken->tid = T_LET;
  curtoken->lno = 10U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  curnode = create_tree_node2(2U, curtoken);
  curnode->children[0] = leftchild;
  curnode->children[1] = rightchild;

  rightchild = curnode;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("10");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 10U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  leftchild = create_tree_node2(0U, curtoken);

  curnode = create_tree_node(2U, T_LINE, "One line of program", (uint32_t)0, 0U);
  curnode->children[0] = leftchild;
  curnode->children[1] = rightchild;

  root = create_tree_node(2, T_PROGRAM, "TEST1.BAS", 0U, 0U);
  root->children[0] = curnode;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("20");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 20U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  leftchild = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("END");
  curtoken->tid = T_END;
  curtoken->lno = 20U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  rightchild = create_tree_node2(0U, curtoken);

  curnode = create_tree_node(2U, T_LINE, "One line of program", (uint32_t)0, 0U);
  curnode->children[0] = leftchild;
  curnode->children[1] = rightchild;
  root->children[1] = curnode;

  printf("Height of tree should print   :5\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  puts("\nYou should see:\n"
       "\n"
       "10 LET X=A/B\n"
       "20 END\n"
       "\n"
       "You actually see:\n");
  regenerate_source(root, NULL);
  puts("");
  fflush(stdout);
  retval = semantic_checks(root);
  if (!retval) {
    fputs("ERROR: semantic checking failed!\n", stderr);
    retval = false;
  }

  dump_symbol_table(true);
  clear_symbol_table();
  printf("\nFlags\n");
  fflush(stdout);
  dumpflags();

  dag_delete_all(&root);
  if (root) {
    fputs("ERROR: root is not NULL after tree_delete_all()!\n", stderr);
    retval = false;
  }
  fflush(stdout);

  if (!need_BSS_numeric) {
    fputs("ERROR: need_BSS_numeric was not set but must be!\n", stderr);
    retval = false;
  }
  if (!need_LOADREAL) {
    fputs("ERROR: need_LOADREAL was not set but must be!\n", stderr);
    retval = false;
  }
  if (!need_DIVIDE) {
    fputs("ERROR: need_DIVIDE was not set but must be!\n", stderr);
    retval = false;
  }
  if (!need_PRINT) {
    fputs("ERROR: need_PRINT was not set but must be!\n", stderr);
    retval = false;
  }
  if (!need_PRINT_NUMERIC) {
    fputs("ERROR: need_PRINT_NUMERIC was not set but must be!\n", stderr);
    retval = false;
  }
  return retval?EXIT_SUCCESS:EXIT_FAILURE;
}

int main(int argc, char **argv) {
  int retval=EXIT_SUCCESS;
  int32_t opt; // variable used by getopt() function

  optimization_level=0U;
  extensions=use_SSE4_1=verbose=false;
  use_double=true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:X")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0], false);
        retval = EXIT_SUCCESS;
        goto xit;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        retval = EXIT_FAILURE;
        goto xit;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  init_debug_printf(stderr);
  retval=test1();
  puts("\n***********************");
  if (EXIT_SUCCESS!=retval)
    puts("*  Test result: FAIL  *");
  else
    puts("*  Test result: PASS  *");
  puts("***********************");
  fflush(stdout);
xit:
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return retval;
}
#endif
