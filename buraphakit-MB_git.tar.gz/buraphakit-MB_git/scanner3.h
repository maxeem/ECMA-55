#ifndef SCANNER3_H
#define SCANNER3_H
//
// scanner3.h - This file contains the header file for scanner3.c
//              for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <inttypes.h>
#include <stdbool.h>

// token numeric identifier constants
enum token_ids {
  T_ABS = 0,      // ABS() function
  T_ACOS,         // ACOS() function -X
  T_ADD,          // binary add operator
  T_AND,          // logical AND
  T_ANGLE,        // ANGLE() function -X
  T_ASIN,         // ASIN() function -X
  T_ATN,          // ATN() function
  T_BASE,         // part of OPTION BASE statement
  T_COMMA,        // comma used in INPUT, PRINT, DATA
  T_CEIL,         // CEIL() function -X
  T_COS,          // COS() function
  T_COSH,         // COSH() function -X
  T_COT,          // COT() function -X
  T_CSC,          // CSC() function -X
  T_DATA,         // DATA statement
  T_DATE,         // ECMA-116 DATE numeric function
  T_DATES,        // ECMA-116 DATE$ string function
  T_DEF,          // DEF statement
  T_DEG,          // DEG() function -X
  T_DIM,          // DIM statement
  T_DIV,          // binary divide operator
  T_END,          // END statement
  T_EOF,          // synthetic end-of-file token
  T_EOL,          // end-of-line token
  T_EQ,           // equals relational operator
  T_EXIT,         // used for EXIT FOR -X
  T_EXP,          // EXP() function
  T_FNID,         // numeric user-defined function
  T_FOR,          // part of FOR statement
  T_FP,           // PF() function -X
  T_GE,           // greater than or equals relational operator
  T_GO,           // part of GO TO or GO SUB
  T_GOSUB,        // GOSUB statement
  T_GOTO,         // GOTO statement
  T_GT,           // greater than relational operator
  T_IF,           // part of IF statement
  T_IP,           // IP() function -X
  T_INPUT,        // INPUT statement
  T_INT,          // INT() function
  T_INTEGER,      // integer literal
  T_LE,           // less than or equal to relational operator
  T_LEN,          // LEN() function -X
  T_LET,          // LET statement
  T_LINE,         // synthetic token representing one line of the program
  T_LOG,          // LOG() function
  T_LOG10,        // LOG10() function
  T_LOG2,         // LOG2() function
  T_LPAREN,       // left parenthesis
  T_LT,           // less than relational operator
  T_MAX,          // MAX() function -X
  T_MAXNUM,       // MAXNUM function -X
  T_MIN,          // MIN() function -X
  T_MOD,          // MOD() function -X
  T_MUL,          // binary multiply operator
  T_NAVAR,        // numeric array variable
  T_NE,           // not equals relational operator
  T_NEXT,         // part of FOR statement
  T_NOT,          // logical NOT
  T_NVAR,         // numeric scalar variable
  T_ON,           // part of ON .. GOTO statement
  T_OPTION,       // part of OPTION BASE statement
  T_OR,           // logical OR
  T_PI,           // PI function (no arguments) -X
  T_POW,          // binary power operator
  T_PRINT,        // PRINT statement
  T_PROGRAM,      // synthetic token representing the entire program
  T_QSTRING,      // quoted string used in PRINT, DATA
  T_RAD,          // RAD() function -X
  T_RANDOMIZE,    // RANDOMIZE statement
  T_READ,         // READ statement
  T_REAL,         // floating point literal value
  T_REM,          // REM statement
  T_REMAINDER,    // REMAINDER() function -X
  T_RESTORE,      // RESTORE statement
  T_RETURN,       // RETURN statement
  T_RND,          // RND function
  T_ROUND,        // ROUND() function -X
  T_RPAREN,       // right parenthesis
  T_SEC,          // SEC() function -X
  T_SEMI,         // semicolon
  T_SGN,          // SGN() function
  T_SIN,          // SIN() function
  T_SINH,         // SINH() function -X
  T_SQR,          // SQR() function
  T_STEP,         // part of FOR statement
  T_STOP,         // STOP statement
  T_SUB,          // part of GOSUB statement
  T_SUBTRACT,     // binary subtraction operator
  T_SVAR,         // string scalar variable
  T_TAB,          // TAB() function
  T_TAN,          // TAN() function
  T_TANH,         // TANH() function -X
  T_THEN,         // part of IF statement
  T_TIME,         // ECMA-116 TIME numeric function
  T_TIMES,         // ECMA-116 TIME$ string function
  T_TO,           // part of GOTO and ON .. GOTO
  T_TRUNCATE,     // TRUNCATE() function -X
  T_UQSTRING,     // unquoted string used in DATA and INPUT
  T_UNKNOWN,      // unknown token (should never occur)
};

// token definition
typedef struct token {
  enum token_ids tid; // token numeric identifier
  char *toketext;     // pointer to string of token text
  uint32_t lno;       // line number in input program
  uint32_t cno;       // column number in input program
  uint64_t pos;       // absolute byte position in input program
} token;

// scanner state
typedef struct scanner_states {
  const char * const buffer;             // buffer containing input program to scan
  const uint64_t buflen;                 // number of bytes in buffer[] including terminator
  uint64_t pos;                          // position of the next byte of the input buffer to be processed
  uint32_t current_nbs_line_number,      // current line number of the input Minimal BASIC program
           current_source_line_number,   // current input source line number (1-based)
           current_column_number;        // current column number of the input Minimal BASIC program (1-based)
  enum token_ids last_tid;               // previous token id (initialize to T_EOL)
  bool (*valid_char)[128];               // pointer to valid character table
  bool indatastatement;                  // are we within a DATA statement value list?
  const bool extensions;                 // was -X specified to enable extensions to the language?
} scanner_state;

// map of token numbers to token names for display in error messages
extern const char * const token_names[];
extern unsigned int const numtokens;

token *peek_next_token(scanner_state *ss);
enum token_ids peek_next_tid(scanner_state *ss);
token *get_next_token(scanner_state *ss);

#endif
