//
// load_textdata.h - static text loading module to access data
//                   which was linked into the executable, such
//                   as the assembly routines used in code generation,
//                   license text, etc.
//
// Copyright (C) 2017,2018,2019,2020,2021,2023  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <sys/stat.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <search.h>
#include <stdbool.h>
#include <ctype.h>
#include <assert.h>
#include "load_textdata.h"
#include "textdata.h"
#include "error_messages.h"
#include "globals.h"
#include "hexdump2.h"

extern volatile struct ilist textchunk_ndex[];  // item_list array
extern volatile uint64_t textchunk_count;       // number of elements in item_list

void WRITEWITHNEWLINE(FILE *f, int k) {
  assert(f!=NULL);
  fwrite(textchunk_ndex[k].data, textchunk_ndex[k].datalength, 1U, f);
  fputc('\n',f);
}

#ifdef UNIT_TEST
static char errbuffer[4096] = { 0 };    // error message buffer

static int compare(const void *left, const void *right);
static void listall(void);
static bool lookup(const char *key, struct ilist **ptr);
static bool test_direct(unsigned int key, const char *realname, const char *fullpath);

static void listall(void) {
  printf("textchunk_ndex=%p\n", (void *)textchunk_ndex);
  fflush(stdout);
  printf("entries=%" PRIu64 "\n", textchunk_count);
  fflush(stdout);
  for (unsigned int i = 0U; i < textchunk_count; ++i) {
    char *outgoing_data = (char *)textchunk_ndex[i].data;
    ssize_t howmanyleft = (ssize_t)textchunk_ndex[i].datalength,
            write_count = 0;

    fprintf(stdout, "chunk #%u:\n-----< begin '%s' >-----\n",
            i, textchunk_ndex[i].fname);
    fflush(stdout);
    do {
      write_count = write(STDOUT_FILENO, (void *)(outgoing_data),
                          (size_t)howmanyleft);
      if (write_count<0) {
        switch (errno) {
          case EPIPE:
            fputs("Program terminated due to pipe closure.\n", stderr);
            return;
          default:
            ;// FALLTHRU
        }
        perror("Bad write");
        exit(EXIT_FAILURE);
      }
      howmanyleft -= write_count;
      outgoing_data += write_count;
    } while (howmanyleft > 0);
    fflush(stdout);
    if (howmanyleft < 0) {
      perror("Bad write\n");
      exit(EXIT_FAILURE);
    }
    fprintf(stdout, "------< end '%s' >------\n", textchunk_ndex[i].fname);
    fflush(stdout);
  }
  return;
}

static int compare(const void *left, const void *right) {
  char **x = (char **)right;
  return strcmp((const char *)left, (const char *)(*x));
}

static bool lookup(const char *key, struct ilist **ptr) {
  *ptr=(struct ilist *)lsearch(key,
                               (void * )textchunk_ndex,
                               (size_t *)&textchunk_count,
                               sizeof(struct ilist),
                               compare);
  return (*ptr?true:false);
}

static bool test_lookups(void) {
  for (unsigned int i = 0U; i < textchunk_count; ++i) {
    struct ilist *ptr;

    if (!lookup(textchunk_ndex[i].fname, &ptr)) {
      fprintf(stderr, "Unable to find '%s'\n", textchunk_ndex[i].fname);
      exit(EXIT_FAILURE);
    }
    if (textchunk_ndex[i].datalength != ptr->datalength) {
      fprintf(stderr, "Expected %" PRIu64 " bytes, got %" PRIu64 " bytes\n",
              textchunk_ndex[i].datalength, ptr->datalength);
      return false;
    }
    if (memcmp(ptr->data, textchunk_ndex[i].data, ptr->datalength)) {
      fprintf(stderr, "For '%s' with %" PRIu64 " bytes\n",
              textchunk_ndex[i].fname, textchunk_ndex[i].datalength);
      fprintf(stderr, "Wanted:\n");
      hexdump(textchunk_ndex[i].data, 0, textchunk_ndex[i].datalength, 1, 8, stderr);
      fputs("Got:\n", stderr);
      hexdump(ptr->data, 0, ptr->datalength, 1, 8, stderr);
      return false;
    }
  }
  return true;
}

static bool test_direct(unsigned int key,
                        const char *realname,
                        const char *fullpath) {
  FILE *f = NULL;               // file handle
  size_t reallen,               // length of file in bytes
         totalsofar;            // current total number of bytes read
  unsigned char *realdata;      // buffer to contains the file contents
  struct stat sb;               // stat buffer

  if (stat(fullpath, &sb) < 0) {
    fprintf(stderr,"Cannot stat '%s'\n",fullpath);
    return false;
  }
  if (!((S_ISREG(sb.st_mode) || S_ISLNK(sb.st_mode)))) {
    fprintf(stderr, "File '%s' is not a regular file\n", fullpath);
    return false;
  }
  if ((f = fopen(fullpath, "rb")) == NULL) {
    sprintf(errbuffer, "Unable to open file '%s' for input", fullpath);
    perror(errbuffer);
    return false;
  }
  reallen = (size_t)sb.st_size;
  realdata = (unsigned char *)xmalloc(sizeof(char) * (reallen + 1U)));
  realdata[0] = 0;
  totalsofar = 0;
  do {
    size_t howmany = fread(realdata, 1, reallen - totalsofar, f);
    if (feof(f)) {
      free(realdata);
      realdata = NULL;
      sprintf(errbuffer, "fread() EOF for input file '%s'", fullpath);
      perror(errbuffer);
      fclose(f);
      return NULL;
    }
    if (ferror(f)) {
      free(realdata);
      realdata = NULL;
      sprintf(errbuffer, "fread() Error for input file '%s'", fullpath);
      perror(errbuffer);
      fclose(f);
      return NULL;
    }
    totalsofar += howmany;
  } while (totalsofar < reallen);
  fclose(f);
  f = NULL;
  realdata[reallen] = 0;     // guarantee termination
  if (strcmp(textchunk_ndex[key].fname,realname)) {
    free(realdata);
    realdata = NULL;
    fprintf(stderr,"expected '%s', got '%s'\n",realname,textchunk_ndex[key].fname);
    return false;
  }
  if (textchunk_ndex[key].datalength!=reallen) {
    free(realdata);
    realdata = NULL;
    fprintf(stderr,"expected %" PRIu64 ", got %" PRIu64 "\n",reallen,textchunk_ndex[key].datalength);
    return false;
  }
  if (memcmp(textchunk_ndex[key].data,realdata,reallen)) {
    fprintf(stderr,"data mismatch!\n"
                   "For '%s' with %" PRIu64 " bytes\n",
            textchunk_ndex[key].fname, textchunk_ndex[key].datalength);
    fputs("Wanted:\n", stderr);
    hexdump(textchunk_ndex[key].data, 0, textchunk_ndex[key].datalength, 1, 8, stderr);
    fputs("Got:\n", stderr);
    hexdump(realdata, 0, reallen, 1, 8, stderr);
    free(realdata);
    realdata = NULL;
    return false;
  }
  free(realdata);
  realdata = NULL;
  return true;
}

int main(void) {
  int retval=EXIT_SUCCESS;

  if (!test_lookups()) {
    puts("Lookup tests failed.");
    retval=EXIT_FAILURE;
  } else {
    puts("Lookup tests passed.");
    if (!test_direct(floor_asmcode,"floor.s","AMD64/floor.s")) {
      puts("test_direct failed.");
      retval=EXIT_FAILURE;
    } else {
      puts("test_direct passed.");
    }
  }
  if (retval!=EXIT_SUCCESS)
    listall();
  return retval;
}
#endif
