//
// tree.c - This is the file containing n-ary tree code.
//
// Copyright (C) 2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <errno.h>
#include <stdbool.h>
#include "globals.h"
#include "scanner3.h"
#include "dtoa5_normal.h"
#include "error_messages.h"
#include "tree.h"

char const * const opid_names[] = {
[OP_NOOP]     = "OP_NOOP",
[OP_UMINUS]   = "OP_UMINUS",
[OP_SUBTRACT] = "OP_SUBTRACT",
[OP_ADD]      = "OP_ADD",
[OP_DIVIDE]   = "OP_DIVIDE",
[OP_MULTIPLY] = "OP_MULTIPLY",
[OP_POWER]    = "OP_POWER",
[OP_BIF]      = "OP_BIF",
[OP_UDF]      = "OP_UDF",
[OP_VARR]     = "OP_VARR",
[OP_MARR]     = "OP_MARR",
[OP_DELETED]  = "OP_DELETED",
};
unsigned int const opid_count=(unsigned int)(sizeof(opid_names)/sizeof(char *));

static bool str2uint32(char const * const s, uint32_t *val);

//
// Convert a string to a 32 bit integer if possible.
// input parameter s is an ASCIIZ integer value
// output parameter val is a pointer to a uint32_t variable to hold the binary
// 32 bit unsigned integer value
// returns true if the conversion is OK, false otherwise
//
static bool str2uint32(char const * const s, uint32_t *val) {
  uint64_t tul;

  errno = 0;
  tul = strtoul(s, NULL, 10);
  if (errno) {
    if (errno==ERANGE) // out of range
       return false;
    ICE(__FILE__, __func__, __LINE__,
        "strtoul failed for input \"%s\"", s);
  }
  if (tul > UINT32_MAX) { // it's an integer, but it needs more than 32bits ....
    return false;
  }
  *val = (uint32_t)tul;
  return true;
}

//
// Create a new node for the AST from a token id, an ASCIIZ string, a specified number of children,
// a line number, and a column number
//
treenode *create_tree_node(                // Create a new node in the AST
    unsigned int const maxchildren,        // Number of children this node can have
    enum token_ids const tid,              // Token ID number
    char const * const toketext,           // Token text
    uint32_t const lno,                    // Source line number
    uint32_t const cno) {                  // Source column number
  token *thetoken = NULL;                  // token generated from tid + toketext

  thetoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  thetoken->tid = tid;
  thetoken->toketext = strdup(toketext);
  thetoken->lno = lno;
  thetoken->cno = cno;

  return create_tree_node2(maxchildren, thetoken);
}

//
// Create a new node for the AST from a token and a specified number of children
//
treenode *create_tree_node2(               // Create a new node in the AST
    unsigned int const maxchildren,        // Number of children this node can have
    token const * const thetoken) {        // Pointer to token to use to initialize this
                                           // AST node
  treenode *newnode = NULL;                // pointer to new node that gets returned

  newnode = (treenode *)xmalloc(__FILE__,__func__,__LINE__,sizeof(treenode));
  newnode->numchildren = maxchildren;
  if (maxchildren > 0U) {
    unsigned int i;                        // loop index for iterating over children of node
    newnode->children = (treenode **)xmalloc(__FILE__,__func__,__LINE__,sizeof(treenode *) * maxchildren);
    for (i = 0U; i < maxchildren; ++i)
      newnode->children[i] = NULL;
  } else {
    newnode->children = NULL;
  }
  newnode->leaftoken = (token *)thetoken;
  switch (newnode->leaftoken->tid) {
    case T_NAVAR:
      if (maxchildren==1)
        newnode->oid = OP_VARR;
      else
        newnode->oid = OP_MARR;
      break;
    case T_FNID:
      newnode->oid = OP_UDF;
      break;
    case T_ADD:
      newnode->oid = OP_ADD;
      break;
    case T_SUBTRACT:
      if (maxchildren==1)
        newnode->oid = OP_UMINUS;
      else
        newnode->oid = OP_SUBTRACT;
      break;
    case T_DIV:
      newnode->oid = OP_DIVIDE;
      break;
    case T_MUL:
      newnode->oid = OP_MULTIPLY;
      break;
    case T_POW:
      newnode->oid = OP_POWER;
      break;
    // built-in functions without parameters
    case T_MAXNUM:     // -X
    case T_PI:         // -X
    case T_RND:
    // built-in functions with one parameter
    case T_ABS:
    case T_ACOS:       // -X
    case T_ASIN:       // -X
    case T_ATN:
    case T_CEIL:       // -X
    case T_COS:
    case T_COSH:       // -X
    case T_COT:        // -X
    case T_CSC:        // -X
    case T_DEG:        // -X
    case T_EXP:
    case T_FP:         // -X
    case T_INT:
    case T_IP:         // -X
    case T_LEN:        // -X
    case T_LOG:
    case T_LOG10:      // -X
    case T_LOG2:       // -X
    case T_RAD:        // -X
    case T_SEC:        // -X
    case T_SGN:
    case T_SIN:
    case T_SINH:       // -X
    case T_SQR:
    case T_TAB:
    case T_TAN:
    case T_TANH:       // -X
    // built-in functions with two parameters
    case T_ANGLE:      // -X
    case T_MAX:        // -X
    case T_MIN:        // -X
    case T_MOD:        // -X
    case T_REMAINDER:  // -X
    case T_ROUND:      // -X
    case T_TRUNCATE:   // -X
      newnode->oid = OP_BIF;
      break;
    default:
      newnode->oid = OP_NOOP;
  }
  newnode->d_regname = NULL;
  newnode->labelname = NULL;
  if (newnode->leaftoken->tid == T_REAL) {
    if (use_double) {
      newnode->numeric_value.dvalue = dgstrtod(newnode->leaftoken->toketext, NULL);
    } else {
      newnode->numeric_value.fvalue = (float)dgstrtod(newnode->leaftoken->toketext, NULL);
    }
  } else if (newnode->leaftoken->tid == T_INTEGER) {
    // if attempt to convert token string to uint32_t fails
    if (!str2uint32(newnode->leaftoken->toketext, &(newnode->numeric_value.uivalue))) {
      // convert the node to a T_REAL of appropriate size
      newnode->leaftoken->tid = T_REAL;
      if (use_double) {
        newnode->numeric_value.dvalue = dgstrtod(newnode->leaftoken->toketext, NULL);
      } else {
        newnode->numeric_value.fvalue = (float)dgstrtod(newnode->leaftoken->toketext, NULL);
      }
    }
    // otherwise use T_INTEGER as planned
  } else {
    if (use_double)
      newnode->numeric_value.dvalue = 0.0;
    else
      newnode->numeric_value.fvalue = 0.0f;
  }
  newnode->ad = NULL;
  newnode->parent_count = newnode->parent_count2 = 0U;
  newnode->leftchild_height = newnode->rightchild_height = 0U;
  return newnode;
}

void tree_delete_all(                      // Delete the AST tree rooted at proot
    treenode **proot) {                    // Pointer to the root of the tree
  while (*proot) {
    unsigned int i;                        // loop index for iterating over children of node

    for (i = 0U; i < (*proot)->numchildren; ++i)
      tree_delete_all(&((*proot)->children[i]));
    (*proot)->numchildren = 0U;
    free((*proot)->children);
    (*proot)->children = NULL;
    free((*proot)->d_regname);
    (*proot)->d_regname = NULL;
    free((*proot)->labelname);
    (*proot)->labelname = NULL;
    if (!(*proot)->leaftoken) {            // Paranoia, it would never be NULL in a valid tree
      fprintf(stderr, "%s", emsg[210]);
      abort();                             // force a coredump so memory can be examined
    }
    free((*proot)->leaftoken->toketext);
    (*proot)->leaftoken->toketext = NULL;
    free((*proot)->leaftoken);
    (*proot)->leaftoken = NULL;
    (*proot)->ad = NULL;                   // must NOT free
    (*proot)->oid = OP_DELETED;
    if (use_double)
      (*proot)->numeric_value.dvalue = 0.0;
    else
      (*proot)->numeric_value.fvalue = 0.0f;
    free(*proot);
    *proot = NULL;
  }
  return;
}

void tree_postorder(                        // Perform a post-order traversal of the tree
                                            // rooted at proot, executing function v on
                                            // each node
    treenode const * const proot,           // Pointer to the root of the tree
    void (*v)(const treenode *n)) {         // Pointer to function to execute at each node

  if (proot) {
    unsigned int i;              // loop index for iterating over children of node

    for (i = 0U; i < proot->numchildren; ++i)
      tree_postorder(proot->children[i], v);
    (*v)(proot);
  }
  return;
}

void tree_postorder_rw(                     // Perform a post-order traversal of the tree
                                            // rooted at proot, executing function v on
                                            // each node
    treenode const * const proot,           // Pointer to the root of the tree
    void (*v)(treenode *n)) {               // Pointer to function to execute at each node

  if (proot) {
    unsigned int i;              // loop index for iterating over children of node

    for (i = 0U; i < proot->numchildren; ++i)
      tree_postorder_rw(proot->children[i], v);
    (*v)((treenode *)proot);
  }
  return;
}

// return height of tree rooted at proot
unsigned int tree_height(treenode const * const proot) {
  unsigned int i;              // loop index for iterating over children of node
  unsigned int theight = 0U;   // tree height return value

  if (!proot)
    return 0U;
  for (i = 0U; i < proot->numchildren; ++i) {
    unsigned int h = tree_height(proot->children[i]);
    if (h > theight)
      theight = h;
  }
  return (1U + theight);
}

void dump_tree_node_string(                // Display the value of a node label or token text
    treenode const * const node) {         // Pointer to the node to dump
  if (node->labelname)
    debug_printf("%s ", node->labelname);
  else
    if (OP_UMINUS==node->oid)
      debug_printf("%s ", "_");
    else
      debug_printf("%s ", node->leaftoken->toketext);
  return;
}

void dump_tree_node(                       // Display all the values of a node
    treenode const * const node) {         // Pointer to the node to dump
  fprintf(stderr, "pointer to node is %p\npointer to leaftoken is %p\n",
          (void *)node, (void *)node->leaftoken);
  if (node->leaftoken) {
    fprintf(stderr, "data->leaftoken->tid = %d (%s)\n"
                    "pointer to leaftoken->toketext is %p\n"
                    "data->leaftoken->toketext = '%s'\n",
            node->leaftoken->tid, token_names[node->leaftoken->tid],
            (void *)node->leaftoken->toketext,
            !(node->leaftoken->toketext) ? "null" : node->leaftoken->toketext);
    if (node->leaftoken->tid == T_REAL) {
      if (use_double)
        fprintf(stderr, "data->dvalue = %lf\n", node->numeric_value.dvalue);
      else
        fprintf(stderr, "data->dvalue = %f\n", node->numeric_value.fvalue);
    } else {
      fprintf(stderr, "data->uivalue = %" PRIu32 "\n", node->numeric_value.uivalue);
    }
    fprintf(stderr, "data->leaftoken->lno = %" PRIu32 "\ndata->leaftoken->cno = %" PRIu32 "\n",
            node->leaftoken->lno, node->leaftoken->cno);
  }
  fprintf(stderr, "data->oid = %d\ndata->d_regname = '%s'\ndata->labelname = '%s'\n"
                  "data->ad = %s\ndata->numchildren = %" PRIu32 "\n",
          node->oid, !(node->d_regname) ? "(null)" : node->d_regname,
          !(node->labelname) ? "(null)" : node->labelname,
          !(node->ad) ? "(null)" : "allocated", node->numchildren);
  if (!node->children)
    fputs("pointer to data->children is (null)\n", stderr);
  else {
    fprintf(stderr, "pointer to data->children is %p\n", (void *)node->children);
    if (node->numchildren > 0U) {
      fprintf(stderr, "pointer to left is %p\nleft = %s\n",
              (void *)node->children[0], !(node->children[0]) ? "(null)" : "allocated");
    }
    if (node->numchildren > 1U) {
      fprintf(stderr, "pointer to right is %p\nright = %s\n",
              (void *)node->children[1],
              !(node->children[1]) ? "(null)" : "allocated");
    }
  }
  fprintf(stderr, "data->parent_count = %u\ndata->parent_count2 = %u\n"
                  "data->leftchild_height = %u\ndata->rightchild_height = %u\n",
          node->parent_count, node->parent_count2,
          node->leftchild_height, node->rightchild_height);
  return;
}

#ifdef UNIT_TEST
#include <errno.h>
#include <getopt.h>

static void dump_tree_node_string2(treenode const * const node);
static int test1(void);

static void dump_tree_node_string2(
    treenode const * const node) {
  printf("%s ", node->leaftoken->toketext);
}

static int test1(void) {
  treenode *root = NULL;
  token *curtoken = NULL;

  root = create_tree_node(2, T_INTEGER, "1", 0U, 0U);
  dump_tree_node(root);
  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }

  puts("TREE:\n"
       "          5\n"
       "        /   \\\n"
       "       3     7\n"
       "      / \\\n"
       "     2   4\n"
       "    /\n"
       "   1");
  fflush(stdout);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("5");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 0U;
  curtoken->cno = 0U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("3");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 0U;
  curtoken->cno = 0U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("7");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 0U;
  curtoken->cno = 0U;
  root->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("2");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 0U;
  curtoken->cno = 0U;
  root->children[0]->children[0] = create_tree_node2(1U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("4");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 0U;
  curtoken->cno = 0U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_INTEGER;
  curtoken->lno = 0U;
  curtoken->cno = 0U;
  root->children[0]->children[0]->children[0] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :4\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder traversal should print   : 1 2 4 3 7 5\n"
        "Postorder traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }

  puts("\n(A+(A+B))+((A+B)/(A+B))+B\n"
       "0000000001111111111222222\n"
       "1234567890123456789012345\n\n"
       "TREE:\n"
       "              '+'\n"
       "             /   \\\n"
       "          '+'     B \n"
       "         /  \\\n"
       "       /      ----\\\n"
       "    '+'           '/'\n"
       "   /  \\          /    \\\n"
       "  A   '+'     '+'     '+'\n"
       "     /   \\    /  \\    /  \\\n"
       "    A     B  A    B  A    B");
  fflush(stdout);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 24U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  root->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("/");
  curtoken->tid = T_DIV;
  curtoken->lno = 1U;
  curtoken->cno = 17U;
  root->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  root->children[0]->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  root->children[0]->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  root->children[0]->children[0]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  root->children[0]->children[0]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 14U;
  root->children[0]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 20U;
  root->children[0]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 13U;
  root->children[0]->children[1]->children[0]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 15U;
  root->children[0]->children[1]->children[0]->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 19U;
  root->children[0]->children[1]->children[1]->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 21U;
  root->children[0]->children[1]->children[1]->children[1] = create_tree_node2(2U, curtoken);

  printf("Height of tree should print   :5\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder traversal should print   : A A B + + A B + A B + / + B +\n"
        "Postorder traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }

  return EXIT_SUCCESS;
}

int main(int argc, char **argv) {
  int retval;
  int32_t opt; // variable used by getopt() function

  optimization_level=0U;
  extensions=use_SSE4_1=verbose=false;
  use_double=true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:X")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0], false);
        retval = EXIT_SUCCESS;
        goto xit;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        retval = EXIT_FAILURE;
        goto xit;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  retval = test1();
  if (EXIT_SUCCESS!=retval)
    goto xit;
xit:
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return retval;
}
#endif
