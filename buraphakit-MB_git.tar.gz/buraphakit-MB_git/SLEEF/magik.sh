grep \.LC xtan_u1.s | cut -d$ -f2- | cut -d, -f1 | sort -k1.4 -n | uniq
