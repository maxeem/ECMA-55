#ifndef SYMBOL_TABLE_H
#define SYMBOL_TABLE_H
//
// symbol_table.h - This is the header file for symbol_table.c
//                  for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2013,2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdio.h>
#include <stdbool.h>
#include <inttypes.h>

typedef struct arraydata {
  const char * const namestring; // ASCIIZ name of array
  unsigned int dims; // number of dimensions (1 or 2, but if 0 this means no array by this name
                     // has been used in the program)
  unsigned int dim1; // maximum permitted index for first dimension
  unsigned int dim2; // maximum permitted index for second dimension (not used if dims is 1)
} arraydata;

// Type numbers
enum data_item_type {
  QSTR=0,     // quoted string
  NUM,        // floating point value
  UQSTR,      // unquoted string (used in READ and INPUT)
  PIVAL,      // PI numeric constant
  MAXNUMVAL,  // MAXNUM numeric constant
};

// lookup information in symbol table module
bool nvar_exists(const char *nvarname);
bool navar_exists(const char *navarname);
bool svar_exists(const char *svarname);
bool udf_exists(const char *udfname, char *argname);
arraydata *get_array_data(const char *navarname);
void dump_symbol_table(bool onlyused);
// add/update information in symbol table module
bool assign_nvar(const char *nvarname, const uint32_t lno);
bool assign_navar(const char *navarname, const uint32_t lno);
bool assign_svar(const char *svarname);
bool assign_magicvar(const char *magic_varname);
bool add_udf(const char *udfname,const char *argname, uint32_t lno);
bool add_string_literal(const char *s, char **symbol);
bool add_input_format(const char *fmt, char **symbol, uint32_t lno);
bool add_float_literal(const char *s, char **symbol);
bool put_array_data(const char *s, unsigned int dims, unsigned int dim1, unsigned int dim2);
bool add_data_literal(const char *s, enum data_item_type t);
// other functions
bool generate_symbol_table(FILE *f);
void clear_symbol_table(void);
#endif
