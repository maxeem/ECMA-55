//
// asmgen.c - This is the file containing the high-level routines
//            for generating assembly output for Mr. Ham's
//            ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "globals.h"
#include "error_messages.h"
#include "codegen.h"
#include "symbol_table.h"
#include "optimizer.h"
#include "asmgen.h"
#include "raw_registers.h"
#include "dag.h"
#define LEFT_CHILD 0U
#define RIGHT_CHILD 1U

// shared code
static void load_realval(treenode *node);
static void load_realvariable(treenode *node);

// bottom-up tree code
static void tree_bif1arg_bottomup(treenode *node);
static void tree_bif2arg_bottomup(treenode *node);
static void tree_unaryop_bottomup(treenode *node);
static void tree_binop_bottomup(treenode *node);
static void tree_process_node_bottomup(treenode *node);
static void tree_emit_numeric_expression_bottomup(treenode *node);

// bottom-up dag code
static void dag_bif1arg(treenode *node);
static void dag_bif2arg(treenode *node);
static void dag_unaryop(treenode *node);
static void dag_binop(treenode *node);
static void dag_process_node(treenode *node);
static void dag_emit_numeric_expression(treenode *node);

// top-down tree code
static void load_realarrayvariable(treenode *node);
static void process_numeric_node(treenode *node);
static void emit_tree_numeric_expression_topdown(treenode *node);

static void emit_string_expression(const treenode *node);
static void emit_logical_expression(treenode *node, const uint32_t target_lineno);
static void emit_numeric_expression(treenode *node);
static void run_defstmt(const treenode *node);
static void run_let_svar(const treenode *node);
static void run_let_nvar(const treenode *node);
static void run_let_navar(const treenode *node);
static void run_printstmt(const treenode *node);
static void run_forstmt(const treenode *node);
static bool run_inputstmt(const treenode *node);
static void run_readstmt(const treenode *node);
static bool run_datastmt(const treenode *node);
static void run_on_gotostmt(const treenode *node);
static void run_ifstmt(const treenode *node);
static void run_gotostmt(const treenode *node);
static void run_gosubstmt(const treenode *node);
static bool run_statement(const treenode *root, uint32_t lineno);

static FILE *outfile = NULL;               // pointer to actual output file for assembly code

// ----- Start of Bottom-up tree code -----

//
// This procedure will emit code for a built-in Function (bif)
// in a TREE.  This is part of the bottom-up tree code generation.
// ABS, SGN, SQR, ATN, CEIL, COS, EXP, INT, LOG, SIN, TAN, DEG, RAD,
// ACOS, ASIN, COSH, SINH, TANH, SEC, CSC, COT
//
static void tree_bif1arg_bottomup(
    treenode *node) {              // pointer to TREE node

  // reassign lhs register to node
  node->d_regname = node->children[LEFT_CHILD]->d_regname;
  node->children[LEFT_CHILD]->d_regname = NULL;
  switch(node->leaftoken->tid) {
    // these modify the specified register in-place
    case T_ABS: do_abs(outfile, node->d_regname); break;
    case T_SGN: do_sgn(outfile, node->d_regname); break;
    case T_SQR: do_sqr(outfile, node->d_regname); break;
    case T_DEG: do_deg(outfile, node->d_regname); break;
    case T_RAD: do_rad(outfile, node->d_regname); break;
    case T_IP: do_ip(outfile, node->d_regname); break;
    case T_FP: do_fp(outfile, node->d_regname); break;
    // these save/restore FPU state
    case T_ATN: do_atan(outfile, node->d_regname); break;
    case T_CEIL: do_ceil(outfile, node->d_regname); break;
    case T_COS: do_cos(outfile, node->d_regname); break;
    case T_COSH: do_cosh(outfile, node->d_regname); break;
    case T_COT: do_cot(outfile, node->d_regname); break;
    case T_CSC: do_csc(outfile, node->d_regname); break;
    case T_ACOS: do_acos(outfile, node->d_regname); break;
    case T_EXP: do_exp(outfile, node->d_regname); break;
    case T_INT: do_int(outfile, node->d_regname); break;
    case T_LOG: do_log(outfile, node->d_regname); break;
    case T_LOG10: do_log10(outfile, node->d_regname); break;
    case T_LOG2: do_log2(outfile, node->d_regname); break;
    case T_SEC: do_sec(outfile, node->d_regname); break;
    case T_SIN: do_sin(outfile, node->d_regname); break;
    case T_SINH: do_sinh(outfile, node->d_regname); break;
    case T_ASIN: do_asin(outfile, node->d_regname); break;
    case T_TAN: do_tan(outfile, node->d_regname); break;
    case T_TANH: do_tanh(outfile, node->d_regname); break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[202], token_names[node->leaftoken->tid]);
  }
  return;
}

//
// This procedure will emit code for a built-in Function (bif)
// in a TREE.  This is part of the bottom-up tree code generation.
// ANGLE, MAX, MIN, MOD, REMAINDER, ROUND, TRUNCATE
//
static void tree_bif2arg_bottomup(
    treenode *node) {              // pointer to TREE node

  // reassign lhs register to node
  node->d_regname = node->children[LEFT_CHILD]->d_regname;
  node->children[LEFT_CHILD]->d_regname = NULL;
  switch(node->leaftoken->tid) {
    // these modify the specified register in-place
    case T_ANGLE: do_angle(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_MAX: do_max(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_MIN: do_min(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_MOD: do_mod(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_REMAINDER: do_remainder(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_ROUND: do_round(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_TRUNCATE: do_truncate(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[202], token_names[node->leaftoken->tid]);
  }
  // deallocate the rhs register
  deallocate_register(node->children[RIGHT_CHILD]->d_regname);
  free(node->children[RIGHT_CHILD]->d_regname);
  node->children[RIGHT_CHILD]->d_regname = NULL;
  return;
}

//
// This procedure will emit code for a unary operator
// in a TREE.  This is part of the bottom-up tree code generation.
// -
//
static void tree_unaryop_bottomup(
    treenode *node) {              // pointer to TREE node

  // reassign lhs register to node
  node->d_regname = node->children[LEFT_CHILD]->d_regname;
  node->children[LEFT_CHILD]->d_regname = NULL;
  switch(node->oid) {
    case OP_UMINUS:
      // node->d_regname = -node->d_reganme
      dofpneg(outfile, node->d_regname);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, "%s", emsg[199]);
  }
  return;
}

//
// This procedure will emit code for a binary operator
// in a TREE.  This is part of the bottom-up tree code generation.
// +  -   *   /   ^
//
static void tree_binop_bottomup(
    treenode *node) {              // pointer to AST node

  // reassign lhs register to node
  node->d_regname = node->children[LEFT_CHILD]->d_regname;
  node->children[LEFT_CHILD]->d_regname = NULL;
  switch(node->oid) {
    case OP_ADD:
      // node->dregname += node->children[RIGHT_CHILD]->d_reganme
      dofpadd(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname);
      break;
    case OP_SUBTRACT:
      // node->dregname -= node->children[RIGHT_CHILD]->d_reganme
      dofpsub(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname);
      break;
    case OP_DIVIDE:
      // node->dregname /= node->children[RIGHT_CHILD]->d_reganme
      dofpdiv(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname);
      break;
    case OP_MULTIPLY:
      // node->dregname *= node->children[RIGHT_CHILD]->d_reganme
      dofpmul(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname);
      break;
    case OP_POWER:
      // node->dregname ^= node->children[RIGHT_CHILD]->d_reganme
      dofppow(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, "%s", emsg[200]);
  }

  // deallocate the rhs register
  deallocate_register(node->children[RIGHT_CHILD]->d_regname);
  free(node->children[RIGHT_CHILD]->d_regname);
  node->children[RIGHT_CHILD]->d_regname = NULL;
  return;
}

//
// This procedure will process a node in the TREE.
// This is part of bottom-up TREE code generation.
//
static void tree_process_node_bottomup(
    treenode *node) {              // pointer to TREE node

  if (node->numchildren > 1U) {
    // do tallest subtree first
    if (tree_height(node->children[RIGHT_CHILD]) > tree_height(node->children[LEFT_CHILD])) {
      tree_process_node_bottomup(node->children[RIGHT_CHILD]);
      tree_process_node_bottomup(node->children[LEFT_CHILD]);
    } else {
      tree_process_node_bottomup(node->children[LEFT_CHILD]);
      tree_process_node_bottomup(node->children[RIGHT_CHILD]);
    }
  } else if (node->numchildren > 0U) {
    tree_process_node_bottomup(node->children[LEFT_CHILD]);
  }
  switch(node->leaftoken->tid) {
    case T_INTEGER:
    case T_REAL:
      load_realval(node);
      break;
    case T_NVAR:
      load_realvariable(node);
      break;
    case T_NAVAR:
      // node->numchildren   1 is 1-d array, 2 is 2-d array
      // node->children[LEFT_CHILD] is 1st subscript
      // node->children[RIGHT_CHILD] is 2nd subscript
      // node->ad->dims better be the same as node->numchildren
      //
      // reassign lhs register to node
      node->d_regname = node->children[LEFT_CHILD]->d_regname;
      node->children[LEFT_CHILD]->d_regname = NULL;
      switch(node->ad->dims) {
        case 1U:
          load_1D_navar(outfile, node->leaftoken->toketext, node->ad->dim1, node->d_regname);
          break;
        case 2U:
          load_2D_navar(outfile, node->leaftoken->toketext, node->ad->dim1, node->ad->dim2,
                        node->d_regname, node->children[RIGHT_CHILD]->d_regname);
          // deallocate the rhs register
          deallocate_register(node->children[RIGHT_CHILD]->d_regname);
          free(node->children[RIGHT_CHILD]->d_regname);
          node->children[RIGHT_CHILD]->d_regname = NULL;
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[25],
              __func__, node->leaftoken->lno, node->leaftoken->toketext, node->ad->dims);
      }
      break;
    case T_LEN:     // -X
      if (!extensions)  // LEN is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      node->d_regname = strdup(allocate_register());
      do_len(outfile, node->d_regname);
      break;
    case T_FNID:
      switch(node->numchildren) {
        case 0U: // no arguments
          node->d_regname = strdup(allocate_register());
          break;
        case 1U: // one argument
          // reassign lhs register to node
          node->d_regname = node->children[LEFT_CHILD]->d_regname;
          node->children[LEFT_CHILD]->d_regname = NULL;
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[69], __func__,
              token_names[node->leaftoken->tid]);
      }
      do_call_udf(outfile, node->leaftoken->toketext, node->d_regname);
      break;
    case T_RND:
      node->d_regname = strdup(allocate_register());
      do_rnd(outfile, node->d_regname);
      break;
    case T_PI:        // -X
      node->d_regname = strdup(allocate_register());
      do_pi(outfile, node->d_regname);
      break;
    case T_MAXNUM:    // -X
      node->d_regname = strdup(allocate_register());
      do_maxnum(outfile, node->d_regname);
      break;
    case T_DATE:      // -X
      node->d_regname = strdup(allocate_register());
      do_date(outfile, node->d_regname);
      break;
    case T_TIME:      // -X
      node->d_regname = strdup(allocate_register());
      do_time(outfile, node->d_regname);
      break;
    case T_ABS:
    case T_ACOS:      // -X
    case T_ASIN:      // -X
    case T_ATN:
    case T_CEIL:      // -X
    case T_COS:
    case T_COT:       // -X
    case T_CSC:       // -X
    case T_COSH:      // -X
    case T_DEG:       // -X
    case T_EXP:
    case T_FP:        // -X
    case T_INT:
    case T_IP:        // -X
    case T_LOG:
    case T_LOG10:     // -X
    case T_LOG2:      // -X
    case T_RAD:       // -X
    case T_SEC:       // -X
    case T_SGN:
    case T_SIN:
    case T_SINH:      // -X
    case T_SQR:
    case T_TAN:
    case T_TANH:      // -X
      tree_bif1arg_bottomup(node);
      break;
    case T_ANGLE:     // -X
    case T_MAX:       // -X
    case T_MIN:       // -X
    case T_MOD:       // -X
    case T_REMAINDER: // -X
    case T_ROUND:     // -X
    case T_TRUNCATE:  // -X
      tree_bif2arg_bottomup(node);
      break;
    case T_ADD:
    case T_DIV:
    case T_MUL:
    case T_POW:
      tree_binop_bottomup(node);
      break;
    case T_SUBTRACT:
      switch(node->oid) {
        case OP_SUBTRACT:
          tree_binop_bottomup(node);
          break;
        case OP_UMINUS:
          tree_unaryop_bottomup(node);
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, "%s", emsg[203]);
          break;
      }
      break;
    case T_DATES:
    case T_TIMES:
    case T_QSTRING: // These seem impossible, but can occur as arguments to
    case T_SVAR:    // string functions that return a number like LEN()
      if (!extensions)  // LEN is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              node->leaftoken->toketext);
      emit_string_expression(node);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[69], __func__,
          token_names[node->leaftoken->tid]);
  }
  return;
}

//
// This procedure will use a bottom-up TREE traversal to emit
// code for an arithmetic expression.  The root node of the TREE
// for that expression is passed in the node parameter.
//
static void tree_emit_numeric_expression_bottomup(
    treenode *node) {              // pointer to TREE node

  tree_process_node_bottomup(node);
  return;
}

// ----- End of Bottom-up tree code -----

// ----- Start of Bottom-up dag code -----

//
// This procedure will process a node in the AST.
// This is part of the bottom-up DAG code generation.
// Binary operator
// +  -   *   /   ^
//
static void dag_binop(
    treenode *node) {              // pointer to DAG node
  unsigned int other;

  if (!node->children[LEFT_CHILD]->numchildren) {
    debug_printf("left child is leaf\n");
    if (!node->children[RIGHT_CHILD]->numchildren) {
      debug_printf("right child is leaf\n");
      if (1U == node->children[LEFT_CHILD]->parent_count) {
      debug_printf("we are only parent of left child\n");
        node->d_regname = node->children[LEFT_CHILD]->d_regname;
        node->children[LEFT_CHILD]->d_regname = NULL;
      } else {
        debug_printf("we are not only parent of left child\n");
        node->d_regname = strdup(allocate_register());
        freg_to_freg(outfile, node->children[LEFT_CHILD]->d_regname, node->d_regname);
      }
      other=RIGHT_CHILD;
    } else {
      debug_printf("right child is not leaf\n");
      if ((OP_ADD == node->oid) || (OP_MULTIPLY == node->oid)) {
        debug_printf("operation is add or multiply\n");
        if (!(node->children[RIGHT_CHILD]->parent_count-1U)) {
          debug_printf("we are only parent of right child\n");
          node->d_regname = node->children[RIGHT_CHILD]->d_regname;
          node->children[RIGHT_CHILD]->d_regname = NULL;
        } else {
          debug_printf("we are not only parent of right child\n");
          node->d_regname = strdup(allocate_register());
          freg_to_freg(outfile, node->children[RIGHT_CHILD]->d_regname, node->d_regname);
        }
        other=LEFT_CHILD;
      } else {
        debug_printf("operation is neither add nor multiply\n");
        if (1U == node->children[LEFT_CHILD]->parent_count) {
          debug_printf("we are only parent of right child\n");
          node->d_regname = node->children[LEFT_CHILD]->d_regname;
          node->children[LEFT_CHILD]->d_regname = NULL;
        } else {
          debug_printf("we are not only parent of right child\n");
          node->d_regname = strdup(allocate_register());
          freg_to_freg(outfile, node->children[LEFT_CHILD]->d_regname, node->d_regname);
        }
        other=RIGHT_CHILD;
      }
    }
  } else {
    debug_printf("left child is not leaf\n");
    if (1U == node->children[LEFT_CHILD]->parent_count) {
      debug_printf("we are only parent of left child\n");
      node->d_regname = node->children[LEFT_CHILD]->d_regname;
      node->children[LEFT_CHILD]->d_regname = NULL;
    } else {
      debug_printf("we are not only parent of left child\n");
      node->d_regname = strdup(allocate_register());
      freg_to_freg(outfile, node->children[LEFT_CHILD]->d_regname, node->d_regname);
    }
    other=RIGHT_CHILD;
  }
  debug_printf("other=%u\n",other);
  debug_printf("node->d_regname=%s\n",node->d_regname?node->d_regname:"Unknown");
  debug_printf("node->children[other]->d_regname=%s\n",
               node->children[other]->d_regname?node->children[other]->d_regname:"Unknown");
  node->children[LEFT_CHILD]->parent_count--;
  node->children[RIGHT_CHILD]->parent_count--;
  switch(node->oid) {
    case OP_ADD:
      // node->d_regname += node->children[other]->d_reganme
      dofpadd(outfile, node->d_regname, node->children[other]->d_regname);
      break;
    case OP_SUBTRACT:
      // node->d_regname -= node->children[other]->d_reganme
      dofpsub(outfile, node->d_regname, node->children[other]->d_regname);
      break;
    case OP_DIVIDE:
      // node->d_regname /= node->children[other]->d_reganme
      dofpdiv(outfile, node->d_regname, node->children[other]->d_regname);
      break;
    case OP_MULTIPLY:
      // node->d_regname *= node->children[other]->d_reganme
      dofpmul(outfile, node->d_regname, node->children[other]->d_regname);
      break;
    case OP_POWER:
      // node->d_regname ^= node->children[other]->d_reganme
      dofppow(outfile, node->d_regname, node->children[other]->d_regname);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, "%s", emsg[200]);
  }
  // and if other parent count is zero, deallocate the rhs register
  if (!node->children[other]->parent_count) {
    deallocate_register(node->children[other]->d_regname);
    free(node->children[other]->d_regname);
    node->children[other]->d_regname = NULL;
  }
  return;
}

//
// Built-in Function (bif) taking 1 numeric argument as input
// ABS, SGN, SQR, ATN, CEIL, COS, EXP, INT, LOG, SIN, TAN,
// ACOS, ASIN
// This is part of bottom-up DAG code generation.
//
static void dag_bif1arg(
    treenode *node) {              // pointer to DAG node

  // decrement left parent count
  node->children[LEFT_CHILD]->parent_count--;
  if (node->children[LEFT_CHILD]->parent_count > 0U) {        // we must not modify the lhs register
    // allocate new register for node
    node->d_regname = strdup(allocate_register());
    // copy lhs value to new register
    freg_to_freg(outfile, node->children[LEFT_CHILD]->d_regname, node->d_regname);
  } else {                                 // recycle lhs register for result
    // reassign lhs register to node
    node->d_regname = node->children[LEFT_CHILD]->d_regname;
    node->children[LEFT_CHILD]->d_regname = NULL;
  }
  // node->d_regname = bif(node->d_regname)
  switch(node->leaftoken->tid) {
    // these modify the specified register in-place
    case T_ABS: do_abs(outfile, node->d_regname); break;
    case T_DEG: do_deg(outfile, node->d_regname); break;
    case T_FP: do_fp(outfile, node->d_regname); break;
    case T_IP: do_ip(outfile, node->d_regname); break;
    case T_RAD: do_rad(outfile, node->d_regname); break;
    case T_SGN: do_sgn(outfile, node->d_regname); break;
    case T_SQR: do_sqr(outfile, node->d_regname); break;
    // these save/restore FPU state
    case T_ACOS: do_acos(outfile, node->d_regname); break;
    case T_ASIN: do_asin(outfile, node->d_regname); break;
    case T_ATN: do_atan(outfile, node->d_regname); break;
    case T_CEIL: do_ceil(outfile, node->d_regname); break;
    case T_COS: do_cos(outfile, node->d_regname); break;
    case T_COSH: do_cosh(outfile, node->d_regname); break;
    case T_COT: do_cot(outfile, node->d_regname); break;
    case T_CSC: do_csc(outfile, node->d_regname); break;
    case T_EXP: do_exp(outfile, node->d_regname); break;
    case T_INT: do_int(outfile, node->d_regname); break;
    case T_LOG10: do_log10(outfile, node->d_regname); break;
    case T_LOG2: do_log2(outfile, node->d_regname); break;
    case T_LOG: do_log(outfile, node->d_regname); break;
    case T_SEC: do_sec(outfile, node->d_regname); break;
    case T_SIN: do_sin(outfile, node->d_regname); break;
    case T_SINH: do_sinh(outfile, node->d_regname); break;
    case T_TAN: do_tan(outfile, node->d_regname); break;
    case T_TANH: do_tanh(outfile, node->d_regname); break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[202], token_names[node->leaftoken->tid]);
  }
  return;
}

//
// Built-in Function (bif) taking 2 numeric arguments as input
// ANGLE< MIN, MAX, MOD, REMAINDER, ROUND, TRUNCATE
// This is part of bottom-up DAG code generation.
//
static void dag_bif2arg(
    treenode *node) {              // pointer to DAG node

  // decrement left parent count
  node->children[LEFT_CHILD]->parent_count--;
  if (node->children[LEFT_CHILD]->parent_count > 0U) {        // we must not modify the lhs register
    // allocate new register for node
    node->d_regname = strdup(allocate_register());
    // copy lhs value to new register
    freg_to_freg(outfile, node->children[LEFT_CHILD]->d_regname, node->d_regname);
  } else {                                 // recycle lhs register for result
    // reassign lhs register to node
    node->d_regname = node->children[LEFT_CHILD]->d_regname;
    node->children[LEFT_CHILD]->d_regname = NULL;
  }
  // node->d_regname = bif(node->d_regname)
  switch(node->leaftoken->tid) {
    // these modify the specified register in-place
    case T_ANGLE: do_angle(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_MAX: do_max(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_MIN: do_min(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_MOD: do_mod(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_REMAINDER: do_remainder(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_ROUND: do_round(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    case T_TRUNCATE: do_truncate(outfile, node->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[202], token_names[node->leaftoken->tid]);
  }
  // decrement right parent count
  node->children[RIGHT_CHILD]->parent_count--;
  // and if rhs parent count is zero, deallocate the rhs register
  if (!node->children[RIGHT_CHILD]->parent_count) {
    deallocate_register(node->children[RIGHT_CHILD]->d_regname);
    free(node->children[RIGHT_CHILD]->d_regname);
    node->children[RIGHT_CHILD]->d_regname = NULL;
  }
  return;
}

//
// Unary operator
// This is part of bottom-up DAG code generation.
// -
//
static void dag_unaryop(
    treenode *node) {              // pointer to DAG node

  // decrement left parent count
  node->children[LEFT_CHILD]->parent_count--;
  if (node->children[LEFT_CHILD]->parent_count > 0U) {        // we must not modify the lhs register
    // allocate new register for node
    node->d_regname = strdup(allocate_register());
    // copy lhs value to new register
    freg_to_freg(outfile, node->children[LEFT_CHILD]->d_regname, node->d_regname);
  } else {                                 // recycle lhs register for result
    // reassign lhs register to node
    node->d_regname = node->children[LEFT_CHILD]->d_regname;
    node->children[LEFT_CHILD]->d_regname = NULL;
  }
  switch(node->oid) {
    case OP_UMINUS:
      // node->d_regname = -node->d_reganme
      dofpneg(outfile, node->d_regname);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, "%s", emsg[199]);
  }
  return;
}

//
// This procedure will process a node in the DAG.
// This is part of bottom-up DAG code generation.
//
static void dag_process_node(
    treenode *node) {              // pointer to DAG node

  if (node->d_regname)                     // if already processed
     return;                               // just return
  // do tallest child first
  if (node->rightchild_height > node->leftchild_height) {
    dag_process_node(node->children[RIGHT_CHILD]);
    if (node->leftchild_height > 1U)
      dag_process_node(node->children[LEFT_CHILD]);
  } else {
    if (node->leftchild_height > 1U)
      dag_process_node(node->children[LEFT_CHILD]);
    if (node->rightchild_height > 1U)
      dag_process_node(node->children[RIGHT_CHILD]);
  }
  switch(node->leaftoken->tid) {
    case T_DATES:
    case T_TIMES:
    case T_QSTRING: // These seem impossible, but can occur as arguments to
    case T_SVAR:    // string functions that return a number like LEN()
      if (!extensions) // LEN is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97],
              node->leaftoken->lno, node->leaftoken->toketext);
      emit_string_expression(node);
      break;
    case T_INTEGER:
    case T_REAL:
      load_realval(node);
      break;
    case T_NVAR:
      load_realvariable(node);
      break;
    case T_NAVAR:
      // node->numchildren   1 is 1-d array, 2 is 2-d array
      // node->children[LEFT_CHILD] is 1st subscript
      // node->children[RIGHT_CHILD] is 2nd subscript
      // node->ad->dims better be the same as node->numchildren
      //
      // decrement left parent count
      node->children[LEFT_CHILD]->parent_count--;
      if (node->children[LEFT_CHILD]->parent_count > 0U) {    // we must not modify the lhs register
        // allocate new register for node
        node->d_regname = strdup(allocate_register());
        // copy lhs value to new register
        freg_to_freg(outfile, node->children[LEFT_CHILD]->d_regname, node->d_regname);
      } else {                                       // recycle lhs register for result
        // reassign lhs register to node
        node->d_regname = node->children[LEFT_CHILD]->d_regname;
        node->children[LEFT_CHILD]->d_regname = NULL;
      }
      switch(node->ad->dims) {
        case 1U:
          load_1D_navar(outfile, node->leaftoken->toketext, node->ad->dim1, node->d_regname);
          break;
        case 2U:
          // decrement right parent count
          node->children[RIGHT_CHILD]->parent_count--;
          load_2D_navar(outfile, node->leaftoken->toketext, node->ad->dim1, node->ad->dim2,
                        node->d_regname, node->children[RIGHT_CHILD]->d_regname);
          // and if rhs parent count is zero, deallocate the rhs register
          if (!node->children[RIGHT_CHILD]->parent_count) {
            deallocate_register(node->children[RIGHT_CHILD]->d_regname);
            free(node->children[RIGHT_CHILD]->d_regname);
            node->children[RIGHT_CHILD]->d_regname = NULL;
          }
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[25],
              __func__, node->leaftoken->lno, node->leaftoken->toketext, node->ad->dims);
      }
      break;
    case T_FNID:
      switch(node->numchildren) {
        case 0U: // function has no arguments
          node->d_regname = strdup(allocate_register());
          break;
        case 1U: // function has one argument
          // decrement left parent count
          node->children[LEFT_CHILD]->parent_count--;
          if (node->children[LEFT_CHILD]->parent_count > 0U) { // we must not modify the lhs register
            // allocate new register for node
            node->d_regname = strdup(allocate_register());
            // copy lhs value to new register
            freg_to_freg(outfile, node->children[LEFT_CHILD]->d_regname, node->d_regname);
          } else {                                    // recycle lhs register for result
            // reassign lhs register to node
            node->d_regname = node->children[LEFT_CHILD]->d_regname;
            node->children[LEFT_CHILD]->d_regname = NULL;
          }
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[69], __func__,
              token_names[node->leaftoken->tid]);
      }
      do_call_udf(outfile, node->leaftoken->toketext, node->d_regname);
      break;
    case T_LEN:
      if (!extensions) // LEN is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      node->d_regname = strdup(allocate_register());
      do_len(outfile, node->d_regname);
      break;
    case T_RND:
      node->d_regname = strdup(allocate_register());
      do_rnd(outfile, node->d_regname);
      break;
    case T_PI:
      node->d_regname = strdup(allocate_register());
      do_pi(outfile, node->d_regname);
      break;
    case T_MAXNUM:
      node->d_regname = strdup(allocate_register());
      do_maxnum(outfile, node->d_regname);
      break;
    case T_DATE:      // -X
      node->d_regname = strdup(allocate_register());
      do_date(outfile, node->d_regname);
      break;
    case T_TIME:      // -X
      node->d_regname = strdup(allocate_register());
      do_time(outfile, node->d_regname);
      break;
    case T_ABS:
    case T_ACOS:     // -X
    case T_ASIN:     // -X
    case T_ATN:
    case T_CEIL:     // -X
    case T_COS:
    case T_COSH:     // -X
    case T_COT:      // -X
    case T_CSC:      // -X
    case T_DEG:      // -X
    case T_EXP:
    case T_FP:       // -X
    case T_INT:
    case T_IP:       // -X
    case T_LOG10:    // -X
    case T_LOG2:     // -X
    case T_LOG:
    case T_RAD:      // -X
    case T_SEC:      // -X
    case T_SGN:
    case T_SIN:
    case T_SINH:     // -X
    case T_SQR:
    case T_TAN:
    case T_TANH:     // -X
      dag_bif1arg(node);
      break;
    case T_ANGLE:    // -X
    case T_MAX:      // -X
    case T_MIN:      // -X
    case T_MOD:      // -X
    case T_REMAINDER: // -X
    case T_ROUND:    // -X
    case T_TRUNCATE: // -X
      if (!extensions) // These functions are not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      dag_bif2arg(node);
      break;
    case T_ADD:
    case T_DIV:
    case T_MUL:
    case T_POW:
      dag_binop(node);
      break;
    case T_SUBTRACT:
      switch(node->oid) {
        case OP_SUBTRACT:
          dag_binop(node);
          break;
        case OP_UMINUS:
          dag_unaryop(node);
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, "%s", emsg[203]);
          break;
      }
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[69], __func__,
          token_names[node->leaftoken->tid]);
  }
  return;
}

//
// This procedure will use a bottom-up DAG traversal to emit
// code for an arithmetic expression.  The root node of the DAG
// for that expression is passed in the node parameter.
//
static void dag_emit_numeric_expression(
    treenode *node) {              // pointer to DAG node
  treenode *dagroot;
  unsigned int changecount;

  dagroot = dag_numeric_expression(node);
  if (optimization_level > 2U) {
    do {     // do it once and keep doing it until there are no changes
      treenode *dagroot2;

      changecount = 0U;
      // go through an optimize dag, but may generate multiple new zeros
      dagroot = improve_dag(dagroot, &changecount);
      // rebuild new dag that will merge any duplicate zeros
      dagroot2 = dag_numeric_expression(dagroot);
      // delete dag with potential multiple zeros
      dag_delete_all(&dagroot);
      dagroot = dagroot2;
      dagroot2 = NULL;
    } while (changecount > 0U);
  }
  if (verbose) {
    debug_printf("%s():DAG Postfix evaluation plan:\n", __func__);
    tree_postorder(dagroot, dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  dag_process_node(dagroot);
  node->d_regname = strdup(dagroot->d_regname);
  dag_delete_all(&dagroot);
  dagroot = NULL;
  return;
}

// ----- End of Bottom-up dag code -----

// ----- Start of Top-down tree code -----

//
// Procedure to load an array numeric variable value into an xmm register
// This is part of the top-down tree code generation.
//
static void load_realarrayvariable(
    treenode *node) {              // pointer to AST node that needs an xmm register reloaded

  debug_printf("%s() target_varname is '%s'\n", __func__, node->leaftoken->toketext);
  if (!node->ad)
    ICE(__FILE__, __func__, __LINE__, emsg[24], node->leaftoken->toketext);
  switch(node->ad->dims) {
    case 1U:
      // if children[LEFT_CHILD] child is a scalar numeric value, allocate a register for it and load it
      if ((T_INTEGER == node->children[LEFT_CHILD]->leaftoken->tid) ||
          (T_REAL == node->children[LEFT_CHILD]->leaftoken->tid))
        load_realval(node->children[LEFT_CHILD]);
      // if children[LEFT_CHILD] child is a scalar numeric variable, allocate a register for it and load it
      if (T_NVAR == node->children[LEFT_CHILD]->leaftoken->tid)
        load_realvariable(node->children[LEFT_CHILD]);
      // if children[LEFT_CHILD] child is an array numeric variable, allocate a register for it and load it
      if (T_NAVAR == node->children[LEFT_CHILD]->leaftoken->tid)
        load_realarrayvariable(node->children[LEFT_CHILD]);
      node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
      debug_printf("%s(): destination one-dimensional array variable '%s' has column index expression value loaded in %s\n",
                   __func__, node->leaftoken->toketext, node->d_regname);
      load_1D_navar(outfile, node->leaftoken->toketext, node->ad->dim1, node->d_regname);
      break;
    case 2U:
      // if children[LEFT_CHILD] child is a scalar numeric value, allocate a register for it and load it
      if ((T_INTEGER == node->children[LEFT_CHILD]->leaftoken->tid) ||
          (T_REAL == node->children[LEFT_CHILD]->leaftoken->tid))
        load_realval(node->children[LEFT_CHILD]);
      // if children[LEFT_CHILD] child is a scalar numeric variable, allocate a register for it and load it
      if (T_NVAR == node->children[LEFT_CHILD]->leaftoken->tid)
        load_realvariable(node->children[LEFT_CHILD]);
      // if children[LEFT_CHILD] child is an array numeric variable, allocate a register for it and load it
      if (T_NAVAR == node->children[LEFT_CHILD]->leaftoken->tid)
        load_realarrayvariable(node->children[LEFT_CHILD]);
      // if children[RIGHT_CHILD] child is a scalar numeric value, allocate a register for it and load it
      if ((T_INTEGER == node->children[RIGHT_CHILD]->leaftoken->tid) ||
          (T_REAL == node->children[RIGHT_CHILD]->leaftoken->tid))
        load_realval(node->children[RIGHT_CHILD]);
      // if children[RIGHT_CHILD] child is a scalar numeric variable, allocate a register for it and load it
      if (T_NVAR == node->children[RIGHT_CHILD]->leaftoken->tid)
        load_realvariable(node->children[RIGHT_CHILD]);
      // if children[RIGHT_CHILD] child is an array numeric variable, allocate a register for it and load it
      if (T_NAVAR == node->children[RIGHT_CHILD]->leaftoken->tid)
        load_realarrayvariable(node->children[RIGHT_CHILD]);
      node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
      debug_printf("%s(): destination two-dimensional array variable '%s' has row index expression value loaded in %s and column index expression value loaded in %s\n",
                   __func__, node->leaftoken->toketext, node->d_regname, node->children[RIGHT_CHILD]->d_regname);
      load_2D_navar(outfile, node->leaftoken->toketext, node->ad->dim1, node->ad->dim2, node->d_regname, node->children[RIGHT_CHILD]->d_regname);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[25], __func__, node->leaftoken->lno, node->leaftoken->toketext, node->ad->dims);
  }
  return;
}

//
// Procedure to load a scalar numeric variable value into an xmm register
//
static void load_realvariable(
    treenode *node) {              // pointer to AST node that needs an xmm register loaded
  char *register_name = NULL;              // pointer to text name of target xmm register

  register_name = (char *)allocate_register();
  if (node->leaftoken->toketext[0] == '.') {
    load_nparm(outfile, node->leaftoken->toketext, register_name);
  } else {
    load_nvar(outfile, node->leaftoken->toketext, register_name);
  }
  // Update the AST to know what register was allocated to hold the value
  node->d_regname = strdup(register_name);
  return;
}

//
// Procedure to load a numeric constant value into an xmm register
//
static void load_realval(
    treenode *node) {              // pointer to AST node that needs an xmm register loaded
  char *register_name = NULL,              // pointer to text name of target xmm register
       *constant_name = NULL;              // pointer to text name of (internal) text constant variable name

  if (!add_float_literal(node->leaftoken->toketext, &constant_name))
    ICE(__FILE__, __func__, __LINE__, emsg[26], __func__, node->leaftoken->toketext);
  register_name = (char *)allocate_register();
  // remember the name of the floating point literal storage memory location
  node->labelname = strdup(constant_name);
  // actually load the data from the floating point literal storage memory location to the register
  load_float_literal(outfile, node->labelname, node->leaftoken->toketext, register_name);
  // Update the AST to know what register was allocated to hold the value
  node->d_regname = strdup(register_name);
  return;
}

#define LOADCHILD(WHICH_CHILD) {\
      /* if this child is a scalar numeric value, allocate a register for it and load it */ \
      if ((T_INTEGER == node->children[WHICH_CHILD]->leaftoken->tid) || \
          (T_REAL == node->children[WHICH_CHILD]->leaftoken->tid)) \
        load_realval(node->children[WHICH_CHILD]); \
      /* if this child is a scalar numeric variable, allocate a register for it and load it */ \
      if (T_NVAR == node->children[WHICH_CHILD]->leaftoken->tid) \
        load_realvariable(node->children[WHICH_CHILD]); \
      /* if this child is an array numeric variable, allocate a register for it and load it */ \
      if (T_NAVAR == node->children[WHICH_CHILD]->leaftoken->tid) \
        load_realarrayvariable(node->children[WHICH_CHILD]); \
}

//
// This procedure will process a node in the AST.
// This is part of the top-down tree code generation.
//
static void process_numeric_node(
    treenode *node) {              // pointer to AST node

  switch(node->leaftoken->tid) {
    case T_LEN:
      if (!extensions) // LEN is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              token_names[node->leaftoken->tid] + 2);
      node->d_regname = strdup(allocate_register());
      do_len(outfile, node->d_regname);
      break;
    case T_FNID:
      if (0U == node->numchildren) {       // function has no arguments
        node->d_regname = strdup(allocate_register());
        do_call_udf(outfile, node->leaftoken->toketext, node->d_regname);
      } else {                             // function has one argument
        LOADCHILD(LEFT_CHILD);
        node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
        do_call_udf(outfile, node->leaftoken->toketext, node->d_regname);
      }
      break;
    case T_RND:
      node->d_regname = strdup(allocate_register());
      do_rnd(outfile, node->d_regname);
      break;
    case T_PI:         // -X
      node->d_regname = strdup(allocate_register());
      do_pi(outfile, node->d_regname);
      break;
    case T_MAXNUM:     // -X
      node->d_regname = strdup(allocate_register());
      do_maxnum(outfile, node->d_regname);
      break;
    case T_DATE:      // -X
      node->d_regname = strdup(allocate_register());
      do_date(outfile, node->d_regname);
      break;
    case T_TIME:      // -X
      node->d_regname = strdup(allocate_register());
      do_time(outfile, node->d_regname);
      break;
    case T_ANGLE:      // -X
    case T_MAX:        // -X
    case T_MIN:        // -X
    case T_MOD:        // -X
    case T_REMAINDER:  // -X
    case T_ROUND:      // -X
    case T_TRUNCATE:   // -X
      LOADCHILD(LEFT_CHILD);
      LOADCHILD(RIGHT_CHILD);
      switch(node->leaftoken->tid) {
        case T_ANGLE: do_angle(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
        case T_MAX: do_max(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
        case T_MIN: do_min(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
        case T_MOD: do_mod(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
        case T_REMAINDER: do_remainder(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
        case T_ROUND: do_round(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
        case T_TRUNCATE: do_truncate(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[65], token_names[node->leaftoken->tid]);
      }
      node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
      // deallocate the rightchild register
      deallocate_register(node->children[RIGHT_CHILD]->d_regname);
      break;
    case T_ABS:        // ABS() does not trash any fp registers
    case T_ACOS:       // -X
    case T_ASIN:       // -X
    case T_ATN:
    case T_CEIL:       // -X
    case T_COS:
    case T_COSH:       // -X
    case T_COT:        // -X
    case T_CSC:        // -X
    case T_DEG:        // -X
    case T_EXP:
    case T_FP:         // -X
    case T_INT:
    case T_IP:         // -X
    case T_LOG:
    case T_LOG10:      // -X
    case T_LOG2:       // -X
    case T_RAD:        // -X
    case T_SEC:        // -X
    case T_SGN:        // SGN() does not trash any fp registers
    case T_SIN:
    case T_SINH:       // -X
    case T_SQR:
    case T_TAN:
    case T_TANH:       // -X
      LOADCHILD(LEFT_CHILD);
      switch(node->leaftoken->tid) {
        case T_ABS: do_abs(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_ACOS: do_acos(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_ASIN: do_asin(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_ATN: do_atan(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_CEIL: do_ceil(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_COS: do_cos(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_COSH: do_cosh(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_COT: do_cot(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_CSC: do_csc(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_DEG: do_deg(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_EXP: do_exp(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_FP: do_fp(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_INT: do_int(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_IP: do_ip(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_LOG: do_log(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_LOG10: do_log10(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_LOG2: do_log2(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_RAD: do_rad(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_SGN: do_sgn(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_SEC: do_sec(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_SIN: do_sin(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_SINH: do_sinh(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_SQR: do_sqr(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_TAN: do_tan(outfile, node->children[LEFT_CHILD]->d_regname); break;
        case T_TANH: do_tanh(outfile, node->children[LEFT_CHILD]->d_regname); break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[65], token_names[node->leaftoken->tid]);
      }
      node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
      break;
    case T_INTEGER:
    case T_REAL:
    case T_NVAR:
    case T_NAVAR:
      // do nothing right now - these are allocated a register when they are used, not now
      break;
    case T_POW:
      LOADCHILD(LEFT_CHILD);
      LOADCHILD(RIGHT_CHILD);
      // at this point both left and right operands are guaranteed to be in registers
      dofppow(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); // answer left in left
      node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
      // deallocate the rightchild register
      deallocate_register(node->children[RIGHT_CHILD]->d_regname);
      break;
    case T_ADD:
      LOADCHILD(LEFT_CHILD);
      LOADCHILD(RIGHT_CHILD);
      // at this point both left and right operands are guaranteed to be in registers
      dofpadd(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); // answer left in left
      node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
      // deallocate the rightchild register
      deallocate_register(node->children[RIGHT_CHILD]->d_regname);
      break;
    case T_SUBTRACT:
      LOADCHILD(LEFT_CHILD);
      switch(node->oid) {
        case OP_SUBTRACT:
          LOADCHILD(RIGHT_CHILD);
          // at this point both left and right operands are guaranteed to be in registers
          dofpsub(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname);
          node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
          // deallocate the rightchild register
          deallocate_register(node->children[RIGHT_CHILD]->d_regname);
          break;
        case OP_UMINUS:
          dofpneg(outfile, node->children[LEFT_CHILD]->d_regname);
          node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[15], __func__, token_names[T_SUBTRACT]);
      }
      break;
    case T_MUL:
      LOADCHILD(LEFT_CHILD);
      LOADCHILD(RIGHT_CHILD);
      // at this point both left and right operands are guaranteed to be in registers
      dofpmul(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); // answer left in left
      node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
      // deallocate the rightchild register
      deallocate_register(node->children[RIGHT_CHILD]->d_regname);
      break;
    case T_DIV:
      LOADCHILD(LEFT_CHILD);
      LOADCHILD(RIGHT_CHILD);
      // at this point both left and right operands are guaranteed to be in registers
      dofpdiv(outfile, node->children[LEFT_CHILD]->d_regname, node->children[RIGHT_CHILD]->d_regname); // answer left in left
      node->d_regname = strdup(node->children[LEFT_CHILD]->d_regname);
      // deallocate the rightchild register
      deallocate_register(node->children[RIGHT_CHILD]->d_regname);
      break;
    case T_DATES:
    case T_TIMES:
    case T_QSTRING: // These seems impossible, but can occur as arguments to
    case T_SVAR:    // string functions that return a number like LEN()
      if (!extensions)  // LEN is not permitted without extensions enabled
        FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
              node->leaftoken->toketext);
      emit_string_expression(node);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[69], __func__, token_names[node->leaftoken->tid]);
  }
  return;
}

// ----- End of Top-down tree code -----

//
// This will emit code for pushing the address of the string variable or quoted
// string literal to the dedicated runtime string address stack.
//
static void emit_string_expression(
    const treenode *node) {        // pointer to AST node

  switch(node->leaftoken->tid) {
    case T_DATES:
      do_dates(outfile);
      break;
    case T_TIMES:
      do_times(outfile);
      break;
    case T_SVAR:
      push_svar(outfile, node->leaftoken->toketext);
      break;
    case T_QSTRING:
      push_string_literal(outfile, node->labelname, node->leaftoken->toketext);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[62], __func__);
  }
  return;
}

//
// This function is used to generate code for logical expressions
// which can occur in IF statements when the -X option has been specified.
// AND, OR, NOT
//
static void emit_logical_expression(
    treenode *node,                // pointer to AST node
    const uint32_t target_lineno) {        // jump target line number for true case
  enum relop op;                           // operator type

  debug_printf("%s:%s(%s,%" PRIu32 ")\n", __FILE__, __func__, node->leaftoken->toketext, target_lineno);
  switch(node->leaftoken->tid) {
    case T_LE: op = LE; break;
    case T_GE: op = GE; break;
    case T_LT: op = LT; break;
    case T_GT: op = GT; break;
    case T_EQ: op = EQ; break;
    case T_NE: op = NE; break;
    case T_NOT: op = NOT; break;
    case T_AND: op = AND; break;
    case T_OR: op = OR; break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[201], token_names[node->leaftoken->tid] + 2);
  }
  switch(node->leaftoken->tid) {
    case T_NOT:
      emit_logical_expression(node->children[LEFT_CHILD], target_lineno);
      do_logical_not(outfile);
      break;
    case T_AND:
      node->labelname = strdup(generate_label());
      emit_logical_expression(node->children[LEFT_CHILD], target_lineno);
      jump_if_false(outfile, node->labelname);
      emit_logical_expression(node->children[RIGHT_CHILD], target_lineno);
      emit_label(outfile, node->labelname);
      break;
    case T_OR:
      node->labelname = strdup(generate_label());
      emit_logical_expression(node->children[LEFT_CHILD], target_lineno);
      jump_if_true(outfile, node->labelname);
      emit_logical_expression(node->children[RIGHT_CHILD], target_lineno);
      emit_label(outfile, node->labelname);
      break;
    case T_LE:
    case T_GE:
    case T_LT:
    case T_GT:
    case T_EQ:
    case T_NE:
      if ((T_DATES == node->children[LEFT_CHILD]->leaftoken->tid) ||
          (T_TIMES == node->children[LEFT_CHILD]->leaftoken->tid) ||
          (T_QSTRING == node->children[LEFT_CHILD]->leaftoken->tid) ||
          (T_SVAR == node->children[LEFT_CHILD]->leaftoken->tid)) {
        emit_string_expression(node->children[LEFT_CHILD]);
        emit_string_expression(node->children[RIGHT_CHILD]);
        do_string_comparison2(outfile, op);
      } else {
        emit_numeric_expression(node->children[LEFT_CHILD]);
        emit_numeric_expression(node->children[RIGHT_CHILD]);
        do_numeric_comparison(outfile, op,
                              node->children[LEFT_CHILD]->d_regname,
                              node->children[RIGHT_CHILD]->d_regname);
      }
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[201], token_names[node->leaftoken->tid] + 2);
  }
  return;
}

//
// This procedure will use a top-down post-order TREE traversal to emit
// code for an arithmetic expression.  The root node of the AST
// for that expression is passed in the node parameter.
//
static void emit_tree_numeric_expression_topdown(
    treenode *node) {              // pointer to AST node

  tree_postorder_rw(node, process_numeric_node);
  if (!node->d_regname) {                  // no register will be allocated if entire expression was constant folded
                                           // or expression was a single floating point literal
                                           // or expression was a single floating point variable
    char *column_index_register = NULL,    // pointer to text name of register for the column index
         *row_index_register = NULL;       // pointer to text name of register for the row index
    switch(node->leaftoken->tid) {
      case T_INTEGER:
      case T_REAL:
        load_realval(node);
        break;
      case T_NVAR:
        load_realvariable(node);
        break;
      case T_NAVAR:
        switch(node->ad->dims) {
          case 1U:
            // if left child is a scalar numeric value, allocate a register for it and load it
            if ((T_INTEGER == node->children[LEFT_CHILD]->leaftoken->tid) ||
                (T_REAL == node->children[LEFT_CHILD]->leaftoken->tid))
              load_realval(node->children[LEFT_CHILD]);
            // if left child is a scalar numeric variable, allocate a register for it and load it
            if (T_NVAR == node->children[LEFT_CHILD]->leaftoken->tid)
              load_realvariable(node->children[LEFT_CHILD]);
            // if left child is an array numeric variable, allocate a register for it and load it
            if (T_NAVAR == node->children[LEFT_CHILD]->leaftoken->tid)
              load_realarrayvariable(node->children[LEFT_CHILD]);
            column_index_register = strdup(node->children[LEFT_CHILD]->d_regname);
            load_1D_navar(outfile, node->leaftoken->toketext, node->ad->dim1, column_index_register);
            // Update the AST to know what register was allocated to hold the value
            node->d_regname = strdup(column_index_register);
            free(column_index_register);
            column_index_register = NULL;
            break;
          case 2U:
            // if left child is a scalar numeric value, allocate a register for it and load it
            if ((T_INTEGER == node->children[LEFT_CHILD]->leaftoken->tid) ||
                (T_REAL == node->children[LEFT_CHILD]->leaftoken->tid))
              load_realval(node->children[LEFT_CHILD]);
            // if left child is a scalar numeric variable, allocate a register for it and load it
            if (T_NVAR == node->children[LEFT_CHILD]->leaftoken->tid)
              load_realvariable(node->children[LEFT_CHILD]);
            // if left child is an array numeric variable, allocate a register for it and load it
            if (T_NAVAR == node->children[LEFT_CHILD]->leaftoken->tid)
              load_realarrayvariable(node->children[LEFT_CHILD]);
            // if right child is a scalar numeric value, allocate a register for it and load it
            if ((T_INTEGER == node->children[RIGHT_CHILD]->leaftoken->tid) ||
                (T_REAL == node->children[RIGHT_CHILD]->leaftoken->tid))
              load_realval(node->children[RIGHT_CHILD]);
            // if right child is a scalar numeric variable, allocate a register for it and load it
            if (T_NVAR == node->children[RIGHT_CHILD]->leaftoken->tid)
              load_realvariable(node->children[RIGHT_CHILD]);
            // if right child is an array numeric variable, allocate a register for it and load it
            if (T_NAVAR == node->children[RIGHT_CHILD]->leaftoken->tid)
              load_realarrayvariable(node->children[RIGHT_CHILD]);
            column_index_register = strdup(node->children[RIGHT_CHILD]->d_regname);
            row_index_register = strdup(node->children[LEFT_CHILD]->d_regname);
            load_2D_navar(outfile, node->leaftoken->toketext, node->ad->dim1, node->ad->dim2,
                          row_index_register, column_index_register);
            deallocate_register(column_index_register);
            // Update the AST to know what register was allocated to hold the value
            node->d_regname = strdup(row_index_register);
            free(column_index_register);
            column_index_register = NULL;
            free(row_index_register);
            row_index_register = NULL;
            break;
          default:
            ICE(__FILE__, __func__, __LINE__, emsg[73], __func__);
        }
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[74], __func__);
    }
  }
  return;
}

//
// This procedure will emit code for an arithmetic expression.
// The root node of the AST for that expression is passed in the node parameter.
// This procedure chooses between top-down tree traversal, bottom-up tree
// traversal, and bottom-up DAG traversal methods based on optimization_level.
// Also, if optimization_level is higher than zero, constant folding is done
// on the AST before code generation.
//
static void emit_numeric_expression(
    treenode *node) {              // pointer to AST node

  switch(optimization_level) {
    case 3U:
      // FALLS THROUGH
    case 2U:
      dag_emit_numeric_expression(node); break;
    case 1U:
      fold_numeric_expression(node);
      tree_emit_numeric_expression_bottomup(node); break;
    case 0U:
      emit_tree_numeric_expression_topdown(node); break;
    default:
      fprintf(stderr,"Unknown optimization level %u\n",
              optimization_level);
      break;
  }
  return;
}

//
// This is used to generate code for a user-defined function
// from a DEF statement.
//
static void run_defstmt(
    const treenode *node) {        // pointer to AST node

  if (2U == node->numchildren) {
    do_udf_header(outfile, node->children[LEFT_CHILD]->leaftoken->toketext, NULL);
  } else {
    do_udf_header(outfile,
                  node->children[LEFT_CHILD]->leaftoken->toketext,
                  node->children[RIGHT_CHILD]->leaftoken->toketext);
  }
  emit_numeric_expression(node->children[node->numchildren - 1U]);
  do_udf_footer(outfile,
                node->children[LEFT_CHILD]->leaftoken->toketext,
                node->children[node->numchildren-1U]->d_regname);
  return;
}

//
// This is for processing a LET statement that has a string scalar
// variable as the destination.
//
static void run_let_svar(
    const treenode *node) {        // pointer to AST node

  emit_string_expression(node->children[RIGHT_CHILD]);
  if (verbose) {
    debug_printf("%s():String Postfix evaluation plan:\n", __func__);
    tree_postorder(node->children[RIGHT_CHILD], dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  dostore_svar(outfile, node->children[LEFT_CHILD]->leaftoken->toketext);
  return;
}

//
// This is for processing a LET statement that has a numeric scalar
// variable as the destination.
//
static void run_let_nvar(
    const treenode *node) {        // pointer to AST node

  emit_numeric_expression(node->children[RIGHT_CHILD]);
  if (verbose) {
    debug_printf("%s():Numeric Postfix evaluation plan:\n", __func__);
    tree_postorder(node->children[RIGHT_CHILD], dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  dostore_nvar(outfile, node->children[LEFT_CHILD]->leaftoken->toketext, node->children[RIGHT_CHILD]->d_regname);
  return;
}

//
// This is for processing a LET statement that has a numeric array
// variable as the destination.
//
static void run_let_navar(
    const treenode *node) {        // pointer to AST node
  char *column_index_register = NULL,      // pointer to text name of register for the column index
       *row_index_register = NULL,         // pointer to text name of register for the row index
       *rhs_expression_register = NULL;    // pointer to text name of register with right-hand-side value
                                           // after expression is evaluated

  emit_numeric_expression(node->children[RIGHT_CHILD]);
  // cannot delete tree yet since one register is in use and it's daddy is n->children[RIGHT_CHILD]
  emit_numeric_expression(node->children[LEFT_CHILD]->children[LEFT_CHILD]);
  if (2U == node->children[LEFT_CHILD]->ad->dims)
    emit_numeric_expression(node->children[LEFT_CHILD]->children[RIGHT_CHILD]);
  if (verbose)
    dump_floatregs();
  switch(node->children[LEFT_CHILD]->ad->dims) {
    case 1U:
      column_index_register = strdup(node->children[LEFT_CHILD]->children[LEFT_CHILD]->d_regname);
      rhs_expression_register = strdup(node->children[RIGHT_CHILD]->d_regname);
      dostore_1D_navar(outfile,
                       node->children[LEFT_CHILD]->leaftoken->toketext,
                       node->children[LEFT_CHILD]->ad->dim1,
                       column_index_register,
                       rhs_expression_register);
      deallocate_register(column_index_register);
      break;
    case 2U:
      row_index_register = strdup(node->children[LEFT_CHILD]->children[LEFT_CHILD]->d_regname);
      column_index_register = strdup(node->children[LEFT_CHILD]->children[RIGHT_CHILD]->d_regname);
      rhs_expression_register = strdup(node->children[RIGHT_CHILD]->d_regname);
      dostore_2D_navar(outfile,
                       node->children[LEFT_CHILD]->leaftoken->toketext,
                       node->children[LEFT_CHILD]->ad->dim1,
                       node->children[LEFT_CHILD]->ad->dim2,
                       row_index_register,
                       column_index_register,
                       rhs_expression_register);
      deallocate_register(row_index_register);
      deallocate_register(column_index_register);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, emsg[76],
          node->children[LEFT_CHILD]->leaftoken->lno,
          node->children[LEFT_CHILD]->leaftoken->toketext,
          node->children[LEFT_CHILD]->ad->dims);
  }
  deallocate_register(rhs_expression_register);
  free(column_index_register);
  column_index_register = NULL;
  free(row_index_register);
  row_index_register = NULL;
  free(rhs_expression_register);
  rhs_expression_register = NULL;
  return;
}

//
// This routine emits code for the PRINT statement.
//
static void run_printstmt(
    const treenode *node) {        // pointer to AST node

  if (node) {
    // iterate over all the children
    for (unsigned int i = 0U; i < node->numchildren; ++i) {
      switch(node->children[i]->leaftoken->tid) {
        case T_SEMI:
          // ignore this
          break;
        case T_COMMA:
          doprint_nextfield(outfile);
          break;
        case T_TAB:
          tree_postorder(node->children[i]->children[LEFT_CHILD], dump_tree_node_string);
          emit_numeric_expression(node->children[i]->children[LEFT_CHILD]);
          do_tab(outfile, node->children[i]->children[LEFT_CHILD]->d_regname);
          init_floatregs();
          break;
        case T_DATES:
        case T_TIMES:
        case T_QSTRING:
          if (strcmp(node->children[i]->leaftoken->toketext, "\\n") == 0) { // special case for newline
            doprint_newline(outfile);
            break;
          }
          // intentionally fall through
        case T_SVAR:
          emit_string_expression(node->children[i]);
          doprint_string(outfile);
          break;
        case T_ACOS:        // -X
        case T_ANGLE:       // -X
        case T_ASIN:        // -X
        case T_CEIL:        // -X
        case T_COSH:        // -X
        case T_COT:         // -X
        case T_CSC:         // -X
        case T_DEG:         // -X
        case T_FP:          // -X
        case T_IP:          // -X
        case T_LEN:         // -X
        case T_LOG10:       // -X
        case T_LOG2:        // -X
        case T_MAX:         // -X
        case T_MAXNUM:      // -X
        case T_MIN:         // -X
        case T_MOD:         // -X
        case T_PI:          // -X
        case T_RAD:         // -X
        case T_REMAINDER:   // -X
        case T_ROUND:       // -X
        case T_SEC:         // -X
        case T_SINH:        // -X
        case T_TANH:        // -X
        case T_TRUNCATE:    // -X
        case T_DATE:        // -X
        case T_TIME:        // -X
          if (!extensions)  // These are not permitted without extensions enabled
            FATAL(__FILE__, __func__, __LINE__, emsg[97], node->leaftoken->lno,
                  token_names[node->leaftoken->tid] + 2);
          // FALLS THROUGH
        case T_ABS:
        case T_ADD:
        case T_ATN:
        case T_COS:
        case T_DIV:
        case T_EXP:
        case T_FNID:
        case T_INT:
        case T_INTEGER:
        case T_LOG:
        case T_LPAREN:
        case T_MUL:
        case T_NAVAR:
        case T_NVAR:
        case T_POW:
        case T_REAL:
        case T_RND:
        case T_SGN:
        case T_SIN:
        case T_SQR:
        case T_SUBTRACT:
        case T_TAN:
          emit_numeric_expression(node->children[i]);
          if (strcmp(node->children[i]->d_regname, "%xmm0") != 0)
            freg_to_freg(outfile, node->children[i]->d_regname, "%xmm0");
          doprint_number(outfile);
          init_floatregs();
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[78], token_names[T_PRINT] + 2);
      }
    }
  }
  return;
}

//
// This will process the FOR statement AST.  It will emit code for the start of the FOR
// loop.
//
static void run_forstmt(
    const treenode *node) {        // pointer to AST node

  // node->children[0] is the fse.ndex_var
  // node->children[1] is start expression
  // node->children[2] is stop expression
  // node->children[3] is increment expression
  // node->children[4] is test of loop exit condition label
  // node->children[5] is body of loop label
  // node->children[6] is bottom of loop label
  // node->children[7] is hidden increment variable name
  // node->children[8] is hidden limit variable name
  emit_comment(outfile,
               "compute expression and save custom FOR loop with index %s start value",
               node->children[LEFT_CHILD]->leaftoken->toketext);
  emit_numeric_expression(node->children[RIGHT_CHILD]);
  emit_comment(outfile,
               "compute expression and save custom FOR loop with index %s limit value",
               node->children[LEFT_CHILD]->leaftoken->toketext);
  emit_numeric_expression(node->children[2]);
  dostore_nvar(outfile,
               node->children[8]->leaftoken->toketext, // hidden limit variable name
               node->children[2]->d_regname);
  deallocate_register(node->children[2]->d_regname);
  emit_comment(outfile,
               "compute expression and save custom FOR loop with index %s increment value",
               node->children[LEFT_CHILD]->leaftoken->toketext);
  emit_numeric_expression(node->children[3]);
  dostore_nvar(outfile,
               node->children[7]->leaftoken->toketext, // hidden increment variable name
               node->children[3]->d_regname);
  deallocate_register(node->children[3]->d_regname);
  // must assign _AFTER_ limit and increment are set for the case when the index variable is used
  // in the expressions for them.
  dostore_nvar(outfile,
               node->children[LEFT_CHILD]->leaftoken->toketext, // index variable name
               node->children[RIGHT_CHILD]->d_regname);
  // now we can finally free this register
  deallocate_register(node->children[RIGHT_CHILD]->d_regname);
  // actually emit code for start of FOR loop
  do_forloopstart(outfile,
                 node->children[LEFT_CHILD]->leaftoken->toketext,  // index variable name
                 node->children[7]->leaftoken->toketext,  // hidden increment variable name
                 node->children[4]->leaftoken->toketext,  // test of loop exit condition loop label
                 node->children[5]->leaftoken->toketext); // body of loop label
  return;
}

//
// This function will emit code for the INPUT from STDIN into the
// target variables.
//
// The semantic rules for the INPUT are non-trivial. Essentially, at runtime the
// program must prompt the user for input and then wait for an entire line of
// input. After the line input is complete, the program must then scan it into
// tokens. The tokens that can be valid are:
//
// 1. number (integer or real)
// 2. quoted string
// 3. unquoted string
// 4. comma
// 5. end-of-line (newline)
//
// The last token must be an end-of-line.
// The comma serves as the delimiter between input items, except when it
// is within a quoted string. The number of items must match the number of
// variables specified in the INPUT statement. Then the type of each item is
// checked to ensure it can actually be stored in the corresponding variable
// specified in the INPUT statement. A number can always be stored in a scalar
// string variable or a numeric scalar or array variable. Quoted and unquoted
// strings can be stored in scalar string variables.
//
// But no input item can be stored in its corresponding variable until all type
// checking for all input items is complete and no type errors were found. Only
// after all type checking is successful can the input items be copied to the
// corresponding variables specified in the INPUT statement. If any error in the
// number of items or type of items occurs, the program must flush the input
// buffer and re-prompt the user for the input.
//
// Generating code to actually implement those semantics requires runtime
// temporary holding hidden variables for each of the items that can be input,
// since the data cannot be stored in the variables specified in the INPUT
// statement until all type checking is successful. The generation of code
// to implement an INPUT statement is done like this:
//
// 1. Initialize the format string to the empty string (informat).
//    For each variable in the INPUT statement do:
//      (a) For numeric variables, Append an 'N' to the format string.
//      (b) For string variables, append an 'S' to the format string.
//    Send the format string to the symbol table so it will be emitted after the
//    code generation is done (add_input_format()).
// 2. For each variable in the INPUT statement do:
//    Emit code to the main output file to call a function to print a prompt the
//    user for input, do the line input to a buffer, and process that buffer,
//    performing the scan into tokens left to right.  As each number or string token
//    is encountered, if the type is compatible, the data is moved to a hidden
//    temporary storage area. Any time an error occurs, the code must jump back to
//    the start of the statement. The code in this phase verifies the type of each
//    item matches the required type from the format string created earlier. The
//    assembly language routine that does all of this is called doinput, and it will
//    reset the input stack pointer itself before processing input.
//    Verify that the number of items matches the required number of variables, if
//    it does not, then the code must jump back to the start of the statement. This
//    is possible by using the length of the ASCIIZ format string, since there is one
//    byte for each variable (do_INPUT()).
// 3. For each variable in the INPUT statement do:
//    (a) For numeric variables, emit code that copies the floating point value
//        from the temporary holding area to the actual variable.
//    (b) For string variables, emit code that copies ASCIIZ string value from
//        the temporary holding area to the actual variable.
//
// The name of the structure for the temporary holding areas is .Lrt_nput_stack,
// the pointer used to access elements in this stack is called
// .Lrt_nput_stack_top, and doinput uses that area like a stack. However, the
// other code emitted will access the temporary holding areas directly by treating
// the stack like a vector instead of popping the items.
//
static bool run_inputstmt(
    const treenode *node) {   // pointer to AST node
  char informat[31] = {0};            // input format string, dynamically built while processing the
                                      // INPUT statement and used for code generation.  In each byte of
                                      // this ASCIIZ format string an 'N' or 'S' will be stored.  An 'N'
                                      // signals that a numeric (floating point) value is needed.  An 'S'
                                      // signals that a 7-bit ASCIIZ string value is needed.  Up to 30
                                      // values can be accepted in one INPUT statement.
  char *nformatname = NULL;           // this is a pointer to the generated name of the input format
                                      // created by the symbol table
  unsigned int informat_next = 0U;    // this is a pointer to the next available slot in the informat[]
                                      // format string.
  unsigned int i;                     // loop index for iterating over all the children

  for (i = 0U; i < node->numchildren; ++i) {
    if (verbose) {
      debug_printf("%s(): Postfix evaluation plan:\n", __func__);
      tree_postorder(node->children[i], dump_tree_node_string);
      debug_printf("%s", "\n");
      fflush(stdout);
    }
    switch(node->children[i]->leaftoken->tid) {
      case T_SVAR:
        informat[informat_next++] = 'U';
        break;
      case T_NVAR:
      case T_NAVAR:
        informat[informat_next++] = 'N';
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[79],
            node->children[i]->leaftoken->toketext,
            token_names[T_INPUT] + 2,
            node->children[i]->leaftoken->lno);
    }
  }
  informat[informat_next] = 0; // end of PRINT list, terminate format string
  // add format string to symbol table
  if (!add_input_format(informat, &nformatname, node->leaftoken->lno))
    return false;
  // emit code to read the raw input from STDIN to a line buffer
  do_INPUT(outfile, nformatname);
  for (i = 0U; i < node->numchildren; ++i) {
    switch(node->children[i]->leaftoken->tid) {
      case T_SVAR:
        // note that code for input of the scalar string variable is emitted so that
        // the input will go into a temporary holding vector until all input has been scanned
        // and verified to be of the correct types without any exceptions
        do_input_svar(outfile, node->children[i]->leaftoken->toketext);
        break;
      case T_NVAR:
        // note that code for input of the scalar numeric variable is emitted so that
        // the input will go into a temporary holding vector until all input has been scanned
        // and verified to be of the correct types without any exceptions
        do_input_nvar(outfile, node->children[i]->leaftoken->toketext, i, node->children[i]->leaftoken->lno);
        break;
      case T_NAVAR:
        // note that code for input of the array numeric variable is emitted so that
        // the input will go into a temporary holding vector until all input has been scanned
        // and verified to be of the correct types without any exceptions
        do_input_navar(outfile, node->children[i]->leaftoken->toketext, i, node->children[i]->leaftoken->lno);
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[79],
            node->children[i]->leaftoken->toketext,
            token_names[T_INPUT] + 2,
            node->children[i]->leaftoken->lno);
    }
  }
  for (i = 0U; i < node->numchildren; ++i) {
    char *column_index_register = NULL,      // pointer to text name of register for the column index
         *row_index_register = NULL;         // pointer to text name of register for the row index

    switch(node->children[i]->leaftoken->tid) {
      case T_SVAR:
        // emit code for copying the scalar string variable value from the temporary holding
        // vector to the real destination variable
        do_input_svar_phase2(outfile, node->children[i]->leaftoken->toketext, i);
        break;
      case T_NVAR:
        // emit code for copying the scalar numeric variable value from the temporary holding
        // vector to the real destination variable
        do_input_nvar_phase2(outfile, node->children[i]->leaftoken->toketext, i);
        break;
      case T_NAVAR:
        emit_numeric_expression(node->children[i]->children[LEFT_CHILD]);
        node->children[i]->d_regname = strdup(allocate_register());
        switch(node->children[i]->ad->dims) {
          case 1U:
            column_index_register = strdup(node->children[i]->children[LEFT_CHILD]->d_regname);
            // emit code for copying the array numeric variable value from the temporary holding
            // vector to the real destination variable
            do_input_1D_navar_phase2(outfile,
                                node->children[i]->leaftoken->toketext,
                                node->children[i]->ad->dim1,
                                i,
                                column_index_register,
                                node->children[i]->d_regname);
            deallocate_register(column_index_register);
            free(column_index_register);
            column_index_register = NULL;
            break;
          case 2U:
            emit_numeric_expression(node->children[i]->children[RIGHT_CHILD]);
            row_index_register = strdup(node->children[i]->children[LEFT_CHILD]->d_regname);
            column_index_register = strdup(node->children[i]->children[RIGHT_CHILD]->d_regname);
            // emit code for copying the array numeric variable value from the temporary holding
            // vector to the real destination variable
            do_input_2D_navar_phase2(outfile,
                               node->children[i]->leaftoken->toketext,
                               node->children[i]->ad->dim1,
                               node->children[i]->ad->dim2,
                               i,
                               row_index_register,
                               column_index_register,
                               node->children[i]->d_regname);
            deallocate_register(column_index_register);
            deallocate_register(row_index_register);
            free(column_index_register);
            column_index_register = NULL;
            free(row_index_register);
            row_index_register = NULL;
            break;
          default:
            ICE(__FILE__, __func__, __LINE__, "%s", emsg[80]);
        }
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[79],
            node->children[i]->leaftoken->toketext,
            token_names[T_INPUT] + 2,
            node->children[i]->leaftoken->lno);
    }
    init_floatregs();
  }
  return true;
}

//
// This is for processing a READ statement.
//
static void run_readstmt(
    const treenode *node) {        // pointer to AST node

  // iterate over all destination variables in the READ statement
  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    char *column_index_register = NULL,    // pointer to text name of register for the column index
         *row_index_register = NULL;       // pointer to text name of register for the row index

    switch(node->children[i]->leaftoken->tid) {
      case T_SVAR:
        do_read_svar(outfile, node->children[i]->leaftoken->toketext);
        break;
      case T_NVAR:
        do_read_nvar(outfile, node->children[i]->leaftoken->toketext);
        break;
      case T_NAVAR:
        emit_numeric_expression(node->children[i]->children[LEFT_CHILD]);
        node->children[i]->d_regname = strdup(allocate_register());
        switch(node->children[i]->ad->dims) {
          case 1U:
            column_index_register = strdup(node->children[i]->children[LEFT_CHILD]->d_regname);
            do_read_1D_navar(outfile,
                            node->children[i]->leaftoken->toketext,
                            node->children[i]->ad->dim1,
                            column_index_register,
                            node->children[i]->d_regname);
            deallocate_register(column_index_register);
            free(column_index_register);
            column_index_register = NULL;
            break;
          case 2U:
            emit_numeric_expression(node->children[i]->children[RIGHT_CHILD]);
            row_index_register = strdup(node->children[i]->children[LEFT_CHILD]->d_regname);
            column_index_register = strdup(node->children[i]->children[RIGHT_CHILD]->d_regname);
            do_read_2D_navar(outfile,
                            node->children[i]->leaftoken->toketext,
                            node->children[i]->ad->dim1,
                            node->children[i]->ad->dim2,
                            row_index_register,
                            column_index_register,
                            node->children[i]->d_regname);
            deallocate_register(column_index_register);
            deallocate_register(row_index_register);
            free(column_index_register);
            column_index_register = NULL;
            free(row_index_register);
            row_index_register = NULL;
            break;
          default:
            ICE(__FILE__, __func__, __LINE__, "%s", emsg[80]);
        }
        break;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[81],
            token_names[node->children[i]->leaftoken->tid],
            node->children[i]->leaftoken->toketext,
            token_names[T_READ] + 2,
            node->leaftoken->lno);
    }
    init_floatregs();
  }
  return;
}

//
// This will update the symbol table with information about the constants
// stored in a DATA statement.  After a successful parse, the symbol table
// module will be called to actually emit the definitions to support the
// READ/DATA statements.
// Returns true on success, false otherwise.
//
static bool run_datastmt(
    const treenode *node) {        // pointer to AST node

  for (unsigned int i = 0U; i < node->numchildren; ++i) {
    switch(node->children[i]->leaftoken->tid) {
      case T_UQSTRING:
        if (!add_data_literal(node->children[i]->leaftoken->toketext, UQSTR))
          return false;
        break;
      case T_QSTRING:
        if (!add_data_literal(node->children[i]->leaftoken->toketext, QSTR))
          return false;
        break;
      case T_INTEGER:
        if (!add_data_literal(node->children[i]->leaftoken->toketext, NUM))
          return false;
        break;
      case T_REAL:
        if (!add_data_literal(node->children[i]->leaftoken->toketext, NUM))
          return false;
        break;
      case T_PI:
        if (extensions && (add_data_literal(node->children[i]->leaftoken->toketext, PIVAL)))
          break;
        return false;
      case T_MAXNUM:
        if (extensions && (add_data_literal(node->children[i]->leaftoken->toketext, MAXNUMVAL)))
          break;
        return false;
      default:
        ICE(__FILE__, __func__, __LINE__, emsg[82], __func__,
            token_names[node->children[i]->leaftoken->tid]);
    }
  }
  return true;
}

//
// This will emit code for a jump table for an ON..GOTO statement.
//
static void run_on_gotostmt(
    const treenode *node) {    // pointer to AST node

  emit_numeric_expression(node->children[LEFT_CHILD]);
  do_ongotostart(outfile, node->numchildren - 1, node->children[LEFT_CHILD]->d_regname);
  for (unsigned int i = 1U; i < node->numchildren; ++i)
    do_ongotochoice(outfile, node->children[i]->numeric_value.uivalue);
  do_ongotoend(outfile);
  return;
}

//
// This is the start of processing for an IF statement.
// It will emit code for the conditional jumps to g_lineno based on
// logical comparisons done by g_relational_expression.
//
static void run_ifstmt(
    const treenode *node) {    // pointer to AST node
  uint32_t target_lineno;      // jump target line number

  target_lineno = node->children[RIGHT_CHILD]->numeric_value.uivalue;
  emit_logical_expression(node->children[LEFT_CHILD], target_lineno);
  do_conditional_branch(outfile, target_lineno);
  return;
}

//
// This is the start of processing for an GOTO statement.
// It will emit code for the unconditional jump to g_lineno.
//
static void run_gotostmt(
    const treenode *node) {    // pointer to AST node
  uint32_t target_lineno;      // jump target line number

  target_lineno = node->children[LEFT_CHILD]->numeric_value.uivalue;
  do_goto(outfile, target_lineno);
  return;
}

//
// This is the start of processing for an GOSUB statement.
// It will emit code to push the return address, then do
// the unconditional jump to g_lineno.
//
static void run_gosubstmt(
    const treenode *node) {    // pointer to AST node
  uint32_t target_lineno;      // jump target line number

  target_lineno = node->children[LEFT_CHILD]->numeric_value.uivalue;
  do_gosub(outfile, target_lineno);
  return;
}

//
// This function will cause assembly to be generated for the argument n
// which must be a pointer to one complete statement subtree from the AST.
// Returns true on success, false otherwise.
//
static bool run_statement(
    const treenode *root,      // pointer to AST node for root of entire program
    uint32_t lineno) {                 // logical line number, as in lineno-th statement
                                       // in the program starting from zero, NOT the
                                       // line number in the BASIC source program!
  treenode *n;                 // pointer to current statement's AST

  n = root->children[lineno];
  // emit statement label (for use when this line is a jump target)
  doloc(outfile, n->children[LEFT_CHILD]->numeric_value.uivalue);
  init_floatregs();
  switch(n->children[RIGHT_CHILD]->leaftoken->tid) {
    case T_DEF:
      // this is done in a separate pass
      break;
    case T_IF:
      run_ifstmt(n->children[RIGHT_CHILD]);
      break;
    case T_ON:
      run_on_gotostmt(n->children[RIGHT_CHILD]);
      break;
    case T_INPUT:
      return run_inputstmt(n->children[RIGHT_CHILD]);
    case T_READ:
      run_readstmt(n->children[RIGHT_CHILD]);
      break;
    case T_DATA:
      return run_datastmt(n->children[RIGHT_CHILD]);
    case T_DIM:
      // no code is emitted for this
      break;
    case T_EXIT:
      do_forloopexit(outfile,
               n->children[RIGHT_CHILD]->children[LEFT_CHILD]->children[LEFT_CHILD]->leaftoken->toketext); // bottom of loop label
      break;
    case T_NEXT:
      do_forloopend(outfile,
               n->children[RIGHT_CHILD]->children[0]->leaftoken->toketext,   // index variable name
               n->children[RIGHT_CHILD]->children[4]->leaftoken->toketext,   // hidden increment variable name
               n->children[RIGHT_CHILD]->children[5]->leaftoken->toketext,   // hidden limit variable name
               n->children[RIGHT_CHILD]->children[3]->leaftoken->toketext,   // test exit condition of loop label
               n->children[RIGHT_CHILD]->children[1]->leaftoken->toketext,   // body of loop label
               n->children[RIGHT_CHILD]->children[2]->leaftoken->toketext);  // bottom of loop label
      break;
    case T_FOR:
      run_forstmt(n->children[RIGHT_CHILD]);
      break;
    case T_PRINT:
      run_printstmt(n->children[RIGHT_CHILD]);
      break;
    case T_LET:
      switch(n->children[RIGHT_CHILD]->children[LEFT_CHILD]->leaftoken->tid) {
        case T_SVAR:                // assignment to a string scalar variable
          run_let_svar(n->children[RIGHT_CHILD]);
          break;
        case T_NVAR:                // assignment to a numeric scalar variable
          run_let_nvar(n->children[RIGHT_CHILD]);
          break;
        case T_NAVAR:               // assignment to a numeric array variable
          run_let_navar(n->children[RIGHT_CHILD]);
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[78], token_names[T_LET] + 2);
      }
      break;
    case T_RANDOMIZE:
      dorandomize(outfile);
      break;
    case T_RESTORE:
      do_restore(outfile);
      break;
    case T_OPTION:
      break;
    case T_REM:
      // no code is emitted for this
      break;
    case T_END:
    case T_STOP:
      do_stop(outfile);
      break;
    case T_RETURN:
      do_return(outfile);
      break;
    case T_GOTO:
      run_gotostmt(n->children[RIGHT_CHILD]);
      break;
    case T_GOSUB:
      run_gosubstmt(n->children[RIGHT_CHILD]);
      break;
    default:
      ICE(__FILE__, __func__, __LINE__, "%s", emsg[84]);
  }
  if (verbose)
    dump_floatregs();
  return true;
}

//
// This function is the external entry point for this module.
// The variable n contains the root of the AST for which we want to generate
// assembly code.  That tree must have already passed through all the
// semantic checks.  The outname is the name of the file in which to put
// the generated assembly code.  This function returns true on success,
// false otherwise.
//
bool generate_assembly(
    treenode *root,      // pointer to root AST node for the program
    const char *outname) {       // pointer to buffer containing assembly language output file name
  bool retval = false;           // return value for this function
  unsigned int lineno;           // logical line number, as in lineno-th statement in the program
                                 // starting from zero, NOT the line number in the BASIC source
                                 // program.

  if ((outfile = fopen(outname, "w")) == NULL)   // if the output assembly file cannot be opened
                                                 // report the error and exit with an indication of failure
    ICE(__FILE__, __func__, __LINE__, emsg[85], outname);
  fprintf(outfile, "# -O%u\n", optimization_level);
  if (use_double)
    fputs("# 64 bit\n", outfile);
  else {
    fputs("# 32 bit\n", outfile);
    fputs("# -s\n", outfile);
  }
  if (use_SSE4_1)
    fputs("# -4\n", outfile);
  if (extensions)
    fputs("# -X\n", outfile);
  write_prologue(outfile, root->leaftoken->toketext);
  fflush(outfile);
  // emit main program code here
  for (lineno = 0U; lineno < root->numchildren; ++lineno) {
    debug_printf("%s:%s() on line %" PRIu32 "\n", __FILE__, __func__, root->children[lineno]->children[LEFT_CHILD]->numeric_value.uivalue);
    fputs("#\n#   ", outfile);
    fputs(root->children[lineno]->leaftoken->toketext, outfile);
    fputs("#\n", outfile);
    if (!run_statement(root, lineno))
      goto xit;
  }
  fflush(outfile);
  write_epilogue(outfile);
  fflush(outfile);
  // emit user-defined functions now
  for (lineno = 0U; lineno < root->numchildren; ++lineno) {
    if (T_DEF == root->children[lineno]->children[RIGHT_CHILD]->leaftoken->tid) {
      init_floatregs();
      run_defstmt(root->children[lineno]->children[RIGHT_CHILD]);
    }
  }
  fflush(outfile);
  // attempt to write the constant and variable definitions to the assembly language output file outfile
  if (!generate_symbol_table(outfile))   // if there were problems, report the error and exit with an
                                         // indication of failure
    ICE(__FILE__, __func__, __LINE__, emsg[86], root->leaftoken->toketext);
  gen_stack(outfile); // emit code for the runtime stack definition
  retval = true;
xit:
  fflush(outfile);
  fclose(outfile);
  outfile = NULL;
  return retval;
}

#ifdef UNIT_TEST
#include <unistd.h>
#include <errno.h>
#include <getopt.h>
static void dump_tree_node_string2(const treenode *node);
static int test1(void);
static int test2(void);
static int test3(void);
static int LEN_test(void);
static int MAX_test(void);

static void dump_tree_node_string2(        // Display token text of a node
    const treenode *node) {        // Pointer to the node to dump
  if ((T_SUBTRACT == node->leaftoken->tid) && (OP_UMINUS == node->oid))
    printf("_ ");
  else
    printf("%s ", node->leaftoken->toketext);
}

static int test1(void) {
  treenode *root = NULL;
  struct token *curtoken = NULL;

  puts("Original expression: (A+B)+(B+A)");
  //                           00000000011
  //                           12345678901
  puts("TREE:\n"
       "        +  \n"
       "      /   \\\n"
       "     /     \\\n"
       "    /       \\\n"
       "   +         +\n"
       " /   \\     /   \\\n"
       "A     B   B     A\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 6U;
  curtoken->pos = 6U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  curtoken->pos = 3U;
  root->children[LEFT_CHILD] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root->children[LEFT_CHILD]->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[LEFT_CHILD]->children[RIGHT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  curtoken->pos = 9U;
  root->children[RIGHT_CHILD] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  curtoken->pos = 8U;
  root->children[RIGHT_CHILD]->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 10U;
  curtoken->pos = 10U;
  root->children[RIGHT_CHILD]->children[RIGHT_CHILD] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A B + B A + +\n"
        "Postorder tree traversal actually prints: ", stdout);
  fflush(stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  if (optimization_level > 1U) {
    puts("DAG:\n"
         "   +\n"
         "  ( )\n"
         "   +\n"
         " /   \\\n"
         "A     B");
    fflush(stdout);
  }

  printf("\n# %s%s%s-O%u\n",
          use_double?"":"-s ",
          extensions?"-X ":"",
          use_SSE4_1?"-4 ":"",
          optimization_level);
  init_floatregs();
  emit_numeric_expression(root);
  if (verbose)
    dump_floatregs();

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    fflush(stdout);
    return EXIT_FAILURE;
  }
  fflush(stdout);
  return EXIT_SUCCESS;
}

static int test2(void) {
  treenode *root = NULL;
  struct token *curtoken = NULL;

  puts("\nOriginal expression: A+(B+(B+A))");
  //                           00000000011
  //                           12345678901
  puts("TREE:\n"
       "          +\n"
       "        /   \\\n"
       "      A       +\n"
       "            /   \\\n"
       "          B      +\n"
       "               /   \\\n"
       "              B     A\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[RIGHT_CHILD] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[RIGHT_CHILD]->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[RIGHT_CHILD]->children[RIGHT_CHILD] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  curtoken->pos = 7U;
  root->children[RIGHT_CHILD]->children[RIGHT_CHILD]->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  curtoken->pos = 9U;
  root->children[RIGHT_CHILD]->children[RIGHT_CHILD]->children[RIGHT_CHILD] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :4\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A B B A + + +\n"
        "Postorder tree traversal actually prints: ", stdout);
  fflush(stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  if (optimization_level > 1U) {
    puts("DAG:\n"
         "          +\n"
         "        /   \\\n"
         "       |      +\n"
         "       |    /   \\\n"
         "       |   (     +\n"
         "       |    \\  /   \\\n"
         "       |      B     )\n"
         "        \\          /\n"
         "          \\      /\n"
         "            \\  /\n"
         "              A");
    fflush(stdout);
  }
  printf("\n# %s%s%s-O%u\n",
          use_double?"":"-s ",
          extensions?"-X ":"",
          use_SSE4_1?"-4 ":"",
          optimization_level);
  init_floatregs();
  emit_numeric_expression(root);
  if (verbose)
    dump_floatregs();

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    fflush(stdout);
    return EXIT_FAILURE;
  }
  fflush(stdout);
  return EXIT_SUCCESS;
}

static int test3(void) {
  treenode *root = NULL;
  struct token *curtoken = NULL;

  puts("\nOriginal expression: A+(B+(C+D))");
  //                           00000000011
  //                           12345678901
  puts("TREE:\n"
       "          +\n"
       "        /   \\\n"
       "      A       +\n"
       "            /   \\\n"
       "          B      +\n"
       "               /   \\\n"
       "              C     D\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  curtoken->pos = 2U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[RIGHT_CHILD] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 4U;
  curtoken->pos = 4U;
  root->children[RIGHT_CHILD]->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[RIGHT_CHILD]->children[RIGHT_CHILD] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("C");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  curtoken->pos = 7U;
  root->children[RIGHT_CHILD]->children[RIGHT_CHILD]->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("D");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  curtoken->pos = 9U;
  root->children[RIGHT_CHILD]->children[RIGHT_CHILD]->children[RIGHT_CHILD] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :4\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A B C D + + +\n"
        "Postorder tree traversal actually prints: ", stdout);
  fflush(stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  if (optimization_level > 1U) {
    puts("DAG:\n"
         "          +\n"
         "        /   \\\n"
         "      A       +\n"
         "            /   \\\n"
         "          B      +\n"
         "               /   \\\n"
         "              C     D");
    fflush(stdout);
  }
  printf("\n# %s%s%s-O%u\n",
          use_double?"":"-s ",
          extensions?"-X ":"",
          use_SSE4_1?"-4 ":"",
          optimization_level);
  init_floatregs();
  emit_numeric_expression(root);
  if (verbose)
    dump_floatregs();

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    fflush(stdout);
    return EXIT_FAILURE;
  }
  fflush(stdout);
  return EXIT_SUCCESS;
}

static int LEN_test(void) {
  treenode *root = NULL;
  struct token *curtoken = NULL;

  puts("\nOriginal expression: LEN(A$)");
  //                           1234567
  printf("TREE:\n"
         "          LEN\n"
         "        /\n"
         "      A$\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("LEN");
  curtoken->tid = T_LEN;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root = create_tree_node2(1U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A$");
  curtoken->tid = T_SVAR;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :2\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A$ LEN\n"
        "Postorder tree traversal actually prints: ", stdout);
  fflush(stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);
  fflush(stdout);

  if (optimization_level > 1U) {
    puts("DAG:\n"
         "          LEN\n"
         "        /\n"
         "      A$");
    fflush(stdout);
  }
  fprintf(stderr,"\n# %s%s%s-O%u\n",
          use_double?"":"-s ",
          extensions?"-X ":"",
          use_SSE4_1?"-4 ":"",
          optimization_level);
  init_floatregs();
  emit_numeric_expression(root);
  if (verbose)
    dump_floatregs();

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    fflush(stdout);
    return EXIT_FAILURE;
  }
  fflush(stdout);
  return EXIT_SUCCESS;
}

static int MAX_test(void) {
  treenode *root = NULL;
  struct token *curtoken = NULL;

  puts("\nOriginal expression: MAX(A,B)");
  //                           12345678
  printf("TREE:\n"
         "          MAX\n"
         "        /     \\\n"
         "      A         B\n");
  fflush(stdout);
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("MAX");
  curtoken->tid = T_MAX;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  curtoken->pos = 1U;
  root = create_tree_node2(2U, curtoken);
  root->oid = OP_BIF;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("A");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  curtoken->pos = 5U;
  root->children[LEFT_CHILD] = create_tree_node2(0U, curtoken);
  root->children[LEFT_CHILD]->oid = OP_NOOP;

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  curtoken->pos = 7U;
  root->children[RIGHT_CHILD] = create_tree_node2(0U, curtoken);
  root->children[RIGHT_CHILD]->oid = OP_NOOP;

  printf("Height of tree should print   :2\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : A B MAX\n"
        "Postorder tree traversal actually prints: ", stdout);
  fflush(stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);

  if (optimization_level > 1U) {
    puts("DAG:\n"
         "          MAX\n"
         "        /     \\\n"
         "      A         B\n");
    fflush(stdout);
  }
  fprintf(stderr,"\n# %s%s%s-O%u\n",
          use_double?"":"-s ",
          extensions?"-X ":"",
          use_SSE4_1?"-4 ":"",
          optimization_level);
  init_floatregs();
  emit_numeric_expression(root);
  if (verbose)
    dump_floatregs();

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    fflush(stdout);
    return EXIT_FAILURE;
  }
  fflush(stdout);
  return EXIT_SUCCESS;
}

int main(int argc, char **argv) {
  int retval=EXIT_SUCCESS;
  int32_t opt; // variable used by getopt() function

  optimization_level=0U;
  extensions=use_SSE4_1=use_double=verbose=false;
  use_double=true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:X")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          return EXIT_FAILURE;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          return EXIT_FAILURE;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          return EXIT_FAILURE;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          return EXIT_FAILURE;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0], false);
        return EXIT_SUCCESS;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        return EXIT_FAILURE;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    return EXIT_FAILURE;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    return EXIT_FAILURE;
  }
  outfile=stdout;
  init_debug_printf(stderr);

  retval=(test1() || test2() || test3());
  if (retval!=EXIT_SUCCESS)
    return retval;
  if (extensions) {
    retval=LEN_test();
    if (retval!=EXIT_SUCCESS)
      return retval;
    retval=MAX_test();
    if (retval!=EXIT_SUCCESS)
      return retval;
  }

#ifdef MJOLNIR
  myshowleakdata();
#endif
  return EXIT_SUCCESS;
}
#endif
