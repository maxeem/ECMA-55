//
// optimizer.c - This is the file containing the AST optimizer code
//               for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#define _POSIX_C_SOURCE 200809L
#include <features.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <fenv.h>
#include <float.h>
#include "globals.h"
#include "error_messages.h"
#include "g_fmt_BASIC_normal.h"
#include "parser2.h"
#include "optimizer.h"
#include "tree.h"
#include "symbol_table.h"

static void fold_add(treenode *node);
static void fold_multiply(treenode *node);
static void fold_subtract(treenode *node);
static void fold_unary_minus(treenode *node);
static void fold_divide(treenode *node);
static void fold_power(treenode *node);

//
// This procedure folds the binary addition node argument in-place.
// If the optimization level is higher than 2, then algebraic transforms
// are done for special cases with 0+? and ?+0.  These violate the language
// specification when NaNs are involved, so are only done when high optimization
// levels AND -X are both specified.
//
static void fold_add(
    treenode *node) {                // Pointer to the root AST node for this numeric expression

  if (optimization_level > 2U) {
    if ((T_REAL == node->children[0]->leaftoken->tid) &&
        (T_REAL == node->children[1]->leaftoken->tid)) {
      if ( (use_double && (0.0 == node->children[0]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[0]->numeric_value.fvalue)) ) {   // 0+? -> ?
        treenode *temp_node_ptr;

        debug_printf("Constant folder special case for 0+?, swap kids\n");
        // swap kids so it becomes ?+0 case
        temp_node_ptr = node->children[0];
        node->children[0] = node->children[1];
        node->children[1] = temp_node_ptr;
        temp_node_ptr = NULL;
      }
      if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[1]->numeric_value.fvalue)) ) {  // ?+0 -> ?
        treenode **tempchildren;           // temporary node to hold a children[] array

        debug_printf("Constant folder special case for ?+0\n");
        // delete right child that has the zero
        tree_delete_all(&node->children[1]);
        // keep a pointer to the children node had before the transformation
        tempchildren = node->children;
        // free node's current '+' token
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        // disconnect node's current children array
        node->children = NULL;
        // move LHS token to node
        node->leaftoken = tempchildren[0]->leaftoken;
        tempchildren[0]->leaftoken = NULL;
        // update numchildren
        node->numchildren = tempchildren[0]->numchildren;
        // copy in children
        node->children = tempchildren[0]->children;
        node->oid = tempchildren[0]->oid;
        tempchildren[0]->children = NULL;
        node->numeric_value = tempchildren[0]->numeric_value;
        // free memory
        free(tempchildren[0]);
        tempchildren[0] = NULL;
        free(tempchildren);
        tempchildren = NULL;
        node->rightchild_height = 0U;
        return;
      }
    }
  }
  if ((T_REAL == node->children[0]->leaftoken->tid) &&
      (T_REAL == node->children[1]->leaftoken->tid)) {
    char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                               // which is a properly formatted floating point value
    float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
    double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

    debug_printf("%s():normal constant fold add\n", __func__);
    feclearexcept(FE_ALL_EXCEPT);
    if (use_double) {
      dvalue = node->children[0]->numeric_value.dvalue + node->children[1]->numeric_value.dvalue;
    } else {
      fvalue = node->children[0]->numeric_value.fvalue + node->children[1]->numeric_value.fvalue;
    }
    if (fetestexcept(FE_OVERFLOW | FE_INVALID)) {
      feclearexcept(FE_ALL_EXCEPT);
      debug_printf("%s(): Cannot fold the constant addition since it would prevent a required exception.\n", __func__);
      return;
    }
    tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
    if (use_double) {
      node->numeric_value.dvalue = dvalue;
      g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
    } else {
      node->numeric_value.fvalue = fvalue;
      g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
    }
    node->leaftoken->tid = T_REAL;
    node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
    free(node->leaftoken->toketext);
    node->leaftoken->toketext = tbuf;
    tree_delete_all(&node->children[0]);
    tree_delete_all(&node->children[1]);
    free(node->children);
    node->children = NULL;
    node->numchildren = 0U;
    node->leftchild_height = node->rightchild_height = 0U;
    return;
  }
  debug_printf("%s(): cannot fold add: ", __func__);
  debug_printf("node->children[0]->leaftoken->tid=%s,node->children[1]->leaftoken->tid=%s\n",
               token_names[node->children[0]->leaftoken->tid],
               token_names[node->children[1]->leaftoken->tid]);
  return;
}

//
// This procedure folds the binary multiplication node argument in-place.
// If the optimization level is higher than 2, then algebraic transforms are
// done for special cases with 0*?, ?*0, 1*?, and ?*1.  These violate the
// language specification when NaNs are involved, so are only done when high
// optimization levels AND -X are both specified.
//
static void fold_multiply(
    treenode *node) {                // Pointer to the root AST node for this numeric expression

  if (optimization_level > 2U) {
    if ((T_REAL == node->children[0]->leaftoken->tid) &&
        (T_REAL == node->children[0]->leaftoken->tid)) {
      if ( (use_double && (0.0 == node->children[0]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[0]->numeric_value.fvalue)) ) {  // 0*? -> ?
        treenode *temp_node_ptr = NULL;
        debug_printf("Constant folder special case for 0*?, swap kids\n");
        // swap kids so it becomes ?*0 case
        temp_node_ptr = node->children[0];
        node->children[0] = node->children[1];
        node->children[1] = temp_node_ptr;
        temp_node_ptr = NULL;
      }
      if ( (use_double && (1.0 == node->children[0]->numeric_value.dvalue)) ||
           (!use_double && (1.0f == node->children[0]->numeric_value.fvalue)) ) { // 1*? -> ?
        treenode *temp_node_ptr = NULL;
        debug_printf("Constant folder special case for 1*?, swap kids\n");
        // swap kids so it becomes ?*1 case
        temp_node_ptr = node->children[0];
        node->children[0] = node->children[1];
        node->children[1] = temp_node_ptr;
        temp_node_ptr = NULL;
      }
      if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[1]->numeric_value.fvalue)) ) { // ?*0 -> ?
        treenode **tempchildren;           // temporary node to hold a children[] array

        debug_printf("Constant folder special case for ?*0\n");
        // delete left child with ?
        tree_delete_all(&node->children[0]);
        // keep a pointer to the children node had before the transformation
        tempchildren = node->children;
        // free node's current '*' token
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        // disconnect node's current children array
        node->children = NULL;
        // move RHS token to node
        node->leaftoken = tempchildren[1]->leaftoken;
        tempchildren[1]->leaftoken = NULL;
        // update numchildren
        node->numchildren = tempchildren[1]->numchildren;
        // copy in children
        node->children = tempchildren[1]->children;
        node->oid = tempchildren[1]->oid;
        tempchildren[1]->children = NULL;
        node->numeric_value = tempchildren[1]->numeric_value;
        // free memory
        free(tempchildren[1]);
        tempchildren[1] = NULL;
        free(tempchildren);
        tempchildren = NULL;
        node->leftchild_height = node->rightchild_height = 0U;
        return;
      }
      if ( (use_double && (1.0 == node->children[1]->numeric_value.dvalue)) ||
           (!use_double && (1.0f == node->children[1]->numeric_value.fvalue)) ) { // ?*1 -> ?
        treenode **tempchildren;           // temporary node to hold a children[] array

        debug_printf("Constant folder special case for ?*1\n");
        // delete right child that has the one
        tree_delete_all(&node->children[1]);
        // keep a pointer to the children node had before the transformation
        tempchildren = node->children;
        // free node's current '*' token
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        // disconnect node's current children array
        node->children = NULL;
        // move LHS token to node
        node->leaftoken = tempchildren[0]->leaftoken;
        tempchildren[0]->leaftoken = NULL;
        // update numchildren
        node->numchildren = tempchildren[0]->numchildren;
        // copy in children
        node->children = tempchildren[0]->children;
        node->numeric_value = tempchildren[0]->numeric_value;
        node->oid = tempchildren[0]->oid;
        tempchildren[0]->children = NULL;
        // free memory
        free(tempchildren[0]);
        tempchildren[0] = NULL;
        free(tempchildren);
        tempchildren = NULL;
        node->rightchild_height = 0U;
        return;
      }
    }
  }
  if (((T_INTEGER == node->children[0]->leaftoken->tid) || (T_REAL == node->children[0]->leaftoken->tid)) &&
      ((T_INTEGER == node->children[1]->leaftoken->tid) || (T_REAL == node->children[1]->leaftoken->tid)) ) {
    char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                               // which is a properly formatted floating point value
    float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
    double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

    debug_printf("%s():fold multiply\n", __func__);
    feclearexcept(FE_ALL_EXCEPT);
    if (use_double) {
      dvalue = node->children[0]->numeric_value.dvalue * node->children[1]->numeric_value.dvalue;
    } else {
      fvalue = node->children[0]->numeric_value.fvalue * node->children[1]->numeric_value.fvalue;
    }
    if (fetestexcept(FE_OVERFLOW | FE_UNDERFLOW | FE_INVALID)) {
      feclearexcept(FE_ALL_EXCEPT);
      debug_printf("%s(): Cannot fold multiply operator since it would prevent a required exception.\n", __func__);
      return;
    }
    tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
    if (use_double) {
      node->numeric_value.dvalue = dvalue;
      g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
    } else {
      node->numeric_value.fvalue = fvalue;
      g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
    }
    node->leaftoken->tid = T_REAL;
    node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
    free(node->leaftoken->toketext);
    node->leaftoken->toketext = tbuf;
    tree_delete_all(&node->children[0]);
    tree_delete_all(&node->children[1]);
    free(node->children);
    node->children = NULL;
    node->numchildren = 0U;
    node->leftchild_height = node->rightchild_height = 0U;
    return;
  }
  debug_printf("%s(): cannot fold multiply: ", __func__);
  debug_printf("node->children[0]->leaftoken->tid=%s,node->children[1]->leaftoken->tid=%s\n",
               token_names[node->children[0]->leaftoken->tid],
               token_names[node->children[1]->leaftoken->tid]);
  return;
}

//
// This procedure folds the binary subtraction node argument in-place.
// If the optimization level is higher than 2, then algebraic transforms are
// done for special cases with 0-? and ?-0.  These violate the language
// specification when NaNs are involved, so are only done when high
// optimization levels AND -X are both specified.
//
static void fold_subtract(
    treenode *node) {                // Pointer to the root AST node for this numeric expression

  if (optimization_level > 2U) {
    if ((T_REAL == node->children[0]->leaftoken->tid) &&
        (T_REAL == node->children[1]->leaftoken->tid)) {
      if ( (use_double && (0.0 == node->children[0]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[0]->numeric_value.fvalue)) ) { // 0-? -> -(?)
        treenode **tempchildren;           // temporary node to hold a children[] array

        debug_printf("Constant folder special case for 0-?\n");
        // delete left child that has the zero
        tree_delete_all(&node->children[0]);
        // create new children array with just 1 slot
        tempchildren = (treenode **)xmalloc(__FILE__,__func__,__LINE__,sizeof(treenode));
        // move rhs into slot 1 of new children array
        tempchildren[0] = node->children[1];
        tempchildren[1] = NULL;
        // update child count
        node->numchildren = 1U;
        // convert binary '-' to unary '-'
        node->oid = OP_UMINUS;
        node->numeric_value = tempchildren[0]->numeric_value;
        // delete node's current children array of size 2
        free(node->children);
        // connect new children array of size 1
        node->children = tempchildren;
        node->rightchild_height = 0U;
        return;
      }
      if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[1]->numeric_value.fvalue)) ) { // ?-0 -> ?
        treenode **tempchildren;           // temporary node to hold a children[] array

        debug_printf("Constant folder special case for ?+0\n");
        // delete right child that has the zero
        tree_delete_all(&node->children[1]);
        // keep a pointer to the children node had before the transformation
        tempchildren = node->children;
        // free node's current '-' token
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        // disconnect node's current children array
        node->children = NULL;
        // move LHS token to node
        node->leaftoken = tempchildren[0]->leaftoken;
        tempchildren[0]->leaftoken = NULL;
        // update numchildren
        node->numchildren = tempchildren[0]->numchildren;
        node->oid = tempchildren[0]->oid;
        node->numeric_value = tempchildren[0]->numeric_value;
        // copy in children
        node->children = tempchildren[0]->children;
        tempchildren[0]->children = NULL;
        // free memory
        free(tempchildren[0]);
        tempchildren[0] = NULL;
        free(tempchildren);
        tempchildren = NULL;
        node->rightchild_height = 0U;
        return;
      }
    }
  }
  if (((T_INTEGER == node->children[0]->leaftoken->tid) || (T_REAL == node->children[0]->leaftoken->tid)) &&
      ((T_INTEGER == node->children[1]->leaftoken->tid) || (T_REAL == node->children[1]->leaftoken->tid)) ) {
    char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                               // which is a properly formatted floating point value
    float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
    double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

    debug_printf("%s():fold subtract\n", __func__);
    feclearexcept(FE_ALL_EXCEPT);
    if (use_double) {
      dvalue = node->children[0]->numeric_value.dvalue - node->children[1]->numeric_value.dvalue;
    } else {
      fvalue = node->children[0]->numeric_value.fvalue - node->children[1]->numeric_value.fvalue;
    }
    if (fetestexcept(FE_OVERFLOW | FE_INVALID)) {
      feclearexcept(FE_ALL_EXCEPT);
      debug_printf("%s(): Cannot fold the constant subtraction since it would prevent a required exception.\n", __func__);
      return;
    }
    tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
    if (use_double) {
      node->numeric_value.dvalue = dvalue;
      g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
    } else {
      node->numeric_value.fvalue = fvalue;
      g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
    }
    node->leaftoken->tid = T_REAL;
    node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
    free(node->leaftoken->toketext);
    node->leaftoken->toketext = tbuf;
    tree_delete_all(&node->children[0]);
    tree_delete_all(&node->children[1]);
    free(node->children);
    node->children = NULL;
    node->numchildren = 0U;
    node->leftchild_height = node->rightchild_height = 0U;
    return;
  }
  debug_printf("%s(): cannot fold subtract: ", __func__);
  debug_printf("node->children[0]->leaftoken->tid=%s,node->children[1]->leaftoken->tid=%s\n",
               token_names[node->children[0]->leaftoken->tid],
               token_names[node->children[1]->leaftoken->tid]);
  return;
}

//
// This procedure folds the unary subtraction node argument in-place.
// If the optimization level is higher than 2, then algebraic transforms are
// done for special case with -(C).  This violate the language
// specification when NaNs are involved, so are only done when high
// optimization levels AND -X are both specified.
//
static void fold_unary_minus(
    treenode *node) {                // Pointer to the root AST node for this numeric expression

  if ((T_INTEGER == node->children[0]->leaftoken->tid) || (T_REAL == node->children[0]->leaftoken->tid)) {
    char *tbuf = NULL;                       // buffer used to hold the result of g_fmt() conversion
                                             // which is a properly formatted floating point value
    float fvalue = 0x7fc00000;               // generated float value, which defaults to a 32 bit NAN
    double dvalue = 0x7ff8000000000000L;     // generated double value, which defaults to a 64 bit NAN

    debug_printf("%s():fold unary minus\n", __func__);
    if (strstr(node->children[0]->leaftoken->toketext,"INF")==NULL) {
      debug_printf("Most not fold anything with INFINITY\n");
      return;
    }
    feclearexcept(FE_ALL_EXCEPT);
    if (use_double) {
      dvalue = -node->children[0]->numeric_value.dvalue;
    } else {
      fvalue = -node->children[0]->numeric_value.fvalue;
    }
    tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
    if (use_double) {
      node->numeric_value.dvalue = dvalue;
      g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
    } else {
      node->numeric_value.fvalue = fvalue;
      g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
    }
    node->leaftoken->tid = T_REAL;
    node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
    free(node->leaftoken->toketext);
    node->leaftoken->toketext = tbuf;
    tree_delete_all(&node->children[0]);
    free(node->children);
    node->children = NULL;
    node->numchildren = 0U;
    return;
  }
  debug_printf("%s(): cannot fold unary minus\n", __func__);
  debug_printf("node->children[0]->leaftoken->tid=%s\n", token_names[node->children[0]->leaftoken->tid]);
  return;
}

//
// This procedure folds the binary division node argument in-place.
//
static void fold_divide(
    treenode *node) {                // Pointer to the root AST node for this numeric expression

  if ((T_REAL == node->children[0]->leaftoken->tid) &&
      (T_REAL == node->children[1]->leaftoken->tid)) {
    if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
         (!use_double && (0.0f == node->children[1]->numeric_value.dvalue)) ) { // ?/0 -> ?
      // cannot fold this
      return;
    }
  }
  if (optimization_level > 2U) {
    if ((T_REAL == node->children[1]->leaftoken->tid) &&
        (T_REAL == node->children[1]->leaftoken->tid)) {
      if ( (use_double && (1.0 == node->children[1]->numeric_value.dvalue)) ||
           (!use_double && (1.0f == node->children[1]->numeric_value.fvalue)) ) { // ?/1 -> ?
        treenode **tempchildren;           // temporary node to hold a children[] array

        debug_printf("Constant folder special case for ?/1\n");
        // delete right child that has the one
        tree_delete_all(&node->children[1]);
        // keep a pointer to the children node had before the transformation
        tempchildren = node->children;
        // free node's current '*' token
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        // disconnect node's current children array
        node->children = NULL;
        // move LHS token to node
        node->leaftoken = tempchildren[0]->leaftoken;
        tempchildren[0]->leaftoken = NULL;
        // update numchildren
        node->numchildren = tempchildren[0]->numchildren;
        // copy in children
        node->children = tempchildren[0]->children;
        node->numeric_value = tempchildren[0]->numeric_value;
        node->oid = tempchildren[0]->oid;
        tempchildren[0]->children = NULL;
        // free memory
        free(tempchildren[0]);
        tempchildren[0] = NULL;
        free(tempchildren);
        tempchildren = NULL;
        node->rightchild_height = 0U;
        return;
      }
    }
  }
  if (((T_INTEGER == node->children[0]->leaftoken->tid) || (T_REAL == node->children[0]->leaftoken->tid)) &&
      ((T_INTEGER == node->children[1]->leaftoken->tid) || (T_REAL == node->children[1]->leaftoken->tid))) {
    char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                               // which is a properly formatted floating point value
    float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
    double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

    debug_printf("%s():fold_divide\n", __func__);
    feclearexcept(FE_ALL_EXCEPT);
    if (use_double) {
      if (node->children[1]->numeric_value.dvalue < DBL_MIN) {
        debug_printf("%s(): Cannot fold the constant division since it would prevent a required exception.\n", __func__);
        return;
      }
      dvalue = node->children[0]->numeric_value.dvalue / node->children[1]->numeric_value.dvalue;
    } else {
      if (node->children[1]->numeric_value.fvalue < FLT_MIN) {
        debug_printf("%s(): Cannot fold the constant division since it would prevent a required exception.\n", __func__);
        return;
      }
      fvalue = node->children[0]->numeric_value.fvalue / node->children[1]->numeric_value.fvalue;
    }
    if (fetestexcept(FE_DIVBYZERO | FE_INVALID | FE_UNDERFLOW | FE_OVERFLOW)) {
      feclearexcept(FE_ALL_EXCEPT);
      debug_printf("%s(): Cannot fold the constant division since it would prevent a required exception.\n", __func__);
      return;
    }
    tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
    if (use_double) {
      node->numeric_value.dvalue = dvalue;
      g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
    } else {
      node->numeric_value.fvalue = fvalue;
      g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
    }
    node->leaftoken->tid = T_REAL;
    node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
    free(node->leaftoken->toketext);
    node->leaftoken->toketext = tbuf;
    tree_delete_all(&node->children[0]);
    tree_delete_all(&node->children[1]);
    free(node->children);
    node->children = NULL;
    node->numchildren = 0U;
    node->leftchild_height = node->rightchild_height = 0U;
    return;
  }
  debug_printf("%s(): cannot fold divide: ", __func__);
  debug_printf("node->children[0]->leaftoken->tid=%s,node->children[1]->leaftoken->tid=%s\n",
               token_names[node->children[0]->leaftoken->tid],
               token_names[node->children[1]->leaftoken->tid]);
  return;
}

//
// This procedure folds the binary power node argument in-place.
//
static void fold_power(
    treenode *node) {                // Pointer to the root AST node for this numeric expression

  if (optimization_level > 2U) {
    if ((T_REAL == node->children[0]->leaftoken->tid) &&
        (T_REAL == node->children[1]->leaftoken->tid)) {
      if ( (use_double && (0.0 == node->children[1]->numeric_value.dvalue)) ||
           (!use_double && (0.0f == node->children[1]->numeric_value.fvalue)) ) { // ?^0 -> 1
        debug_printf("fold_power ?^0 -> 1\n");
        tree_delete_all(&node->children[0]);
        tree_delete_all(&node->children[1]);
        free(node->children);
        node->children = NULL;
        node->numchildren = 0U;
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
        node->leaftoken->toketext = strdup("1");
        node->leaftoken->tid = T_REAL;
        node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
        if (use_double) {
          node->numeric_value.dvalue = 1.0;
        } else {
          node->numeric_value.fvalue = 1.0f;
        }
        node->leftchild_height = node->rightchild_height = 0U;
        return;
      }
      if ( (use_double && (1.0 == node->children[0]->numeric_value.dvalue)) ||
           (!use_double && (1.0f == node->children[0]->numeric_value.fvalue)) ) { // 1^? -> 1
        debug_printf("fold_power 1^? -> 1\n");
        tree_delete_all(&node->children[0]);
        tree_delete_all(&node->children[1]);
        free(node->children);
        node->children = NULL;
        node->numchildren = 0U;
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        node->leaftoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
        node->leaftoken->toketext = strdup("1");
        node->leaftoken->tid = T_REAL;
        node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
        if (use_double) {
          node->numeric_value.dvalue = 1.0;
        } else {
          node->numeric_value.fvalue = 1.0f;
        }
        node->leftchild_height = node->rightchild_height = 0U;
        return;
      }
      if ( (use_double && (1.0 == node->children[1]->numeric_value.dvalue)) ||
           (!use_double && (1.0f == node->children[1]->numeric_value.fvalue)) ) { // ?^1 -> ?
        treenode **tempchildren;           // temporary node to hold a children[] array

        debug_printf("fold_power ?^1\n");
        // delete right child that has the one
        tree_delete_all(&node->children[1]);
        // keep a pointer to the children node had before the transformation
        tempchildren = node->children;
        // free node's current '*' token
        free(node->leaftoken->toketext);
        free(node->leaftoken);
        // disconnect node's current children array
        node->children = NULL;
        // move LHS token to node
        node->leaftoken = tempchildren[0]->leaftoken;
        tempchildren[0]->leaftoken = NULL;
        // update numchildren
        node->numchildren = tempchildren[0]->numchildren;
        // copy in children
        node->children = tempchildren[0]->children;
        node->numeric_value = tempchildren[0]->numeric_value;
        node->oid = tempchildren[0]->oid;
        tempchildren[0]->children = NULL;
        node->rightchild_height = 0U;
        // free memory
        free(tempchildren[0]);
        tempchildren[0] = NULL;
        free(tempchildren);
        tempchildren = NULL;
        return;
      }
    }
  }
  if (((T_INTEGER == node->children[0]->leaftoken->tid) || (T_REAL == node->children[0]->leaftoken->tid)) &&
      ((T_INTEGER == node->children[1]->leaftoken->tid) || (T_REAL == node->children[1]->leaftoken->tid))) {
    char *tbuf = NULL;                         // buffer used to hold the result of g_fmt() conversion
                                               // which is a properly formatted floating point value
    float fvalue = 0x7fc00000;                 // generated float value, which defaults to a 32 bit NAN
    double dvalue = 0x7ff8000000000000L;       // generated double value, which defaults to a 64 bit NAN

    debug_printf("%s():fold power\n", __func__);
    feclearexcept(FE_ALL_EXCEPT);
    if (use_double) {
      dvalue = pow(node->children[0]->numeric_value.dvalue, node->children[1]->numeric_value.dvalue);
    } else {
      fvalue = powf(node->children[0]->numeric_value.fvalue, node->children[1]->numeric_value.fvalue);
    }
    if (fetestexcept(FE_INVALID))
      ICE(__FILE__, __func__, __LINE__, emsg[16], node->leaftoken->lno);
    if (fetestexcept(FE_DIVBYZERO | FE_OVERFLOW | FE_UNDERFLOW)) {
      feclearexcept(FE_ALL_EXCEPT);
      debug_printf("%s(): Cannot fold power operator since the result gives a range error and must throw an exception.\n", __func__);
      return;
    }
    tbuf = (char *)xmalloc(__FILE__,__func__,__LINE__,sizeof(char)*FLOAT_BUFFER_LEN);
    if (use_double) {
      node->numeric_value.dvalue = dvalue;
      g_fmt(tbuf, node->numeric_value.dvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_WIDE_OUTPUT);
    } else {
      node->numeric_value.fvalue = fvalue;
      g_fmt(tbuf, node->numeric_value.fvalue, SIGNIFICANCE_WIDTH_INTERNAL, EXRAD_NARROW_OUTPUT);
    }
    node->leaftoken->tid = T_REAL;
    node->oid = OP_NOOP; // must manually set this since we are changing tid in-place
    free(node->leaftoken->toketext);
    node->leaftoken->toketext = tbuf;
    tree_delete_all(&node->children[0]);
    tree_delete_all(&node->children[1]);
    free(node->children);
    node->children = NULL;
    node->numchildren = 0U;
    node->leftchild_height = node->rightchild_height = 0U;
    return;
  }
  debug_printf("%s(): cannot fold power: ", __func__);
  debug_printf("node->children[0]->leaftoken->tid=%s,node->children[1]->leaftoken->tid=%s\n",
               token_names[node->children[0]->leaftoken->tid],
               token_names[node->children[1]->leaftoken->tid]);
  return;
}

//
// This procedure traverses the tree rooted at the node argument and performs simple
// constant folding, rewriting the AST in place as required to make that happen.
//
static void fold_numeric_node(
    treenode *node) {                // Pointer to the root AST node for this numeric expression
  char *end = NULL;                          // need by strto[df]()

  debug_printf("%s():processing %s:'%s'\n", __func__, token_names[node->leaftoken->tid], node->leaftoken->toketext);
  if (verbose) {
    // dump incoming tree
    debug_printf("%s():Postfix evaluation plan BEFORE iteration:\n", __func__);
    tree_postorder(node, dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  if (node->numchildren > 1U) {
    if (T_INTEGER == node->children[1]->leaftoken->tid) {
      if (use_double) {
        node->children[1]->numeric_value.dvalue = (double)strtod(node->children[1]->leaftoken->toketext, &end);
      } else {
        node->children[1]->numeric_value.fvalue = (float)strtof(node->children[1]->leaftoken->toketext, &end);
      }
      node->children[1]->leaftoken->tid = T_REAL;
    }
  }
  if (node->numchildren > 0U) {
    if (T_INTEGER == node->children[0]->leaftoken->tid) {
      if (use_double) {
        node->children[0]->numeric_value.dvalue = (double)strtod(node->children[0]->leaftoken->toketext, &end);
      } else {
        node->children[0]->numeric_value.fvalue = (float)strtof(node->children[0]->leaftoken->toketext, &end);
      }
      node->children[0]->leaftoken->tid = T_REAL;
    }
  }
  switch (node->leaftoken->tid) {
    case T_ADD:
      debug_printf("node->children[0]->leaftoken->tid=%s,node->children[1]->leaftoken->tid=%s\n",
                   token_names[node->children[0]->leaftoken->tid],
                   token_names[node->children[1]->leaftoken->tid]);
      fold_add(node);
      break;
    case T_SUBTRACT:
      switch (node->oid) {
        case OP_SUBTRACT:
          fold_subtract(node);
          break;
        case OP_UMINUS:
          fold_unary_minus(node);
          break;
        default:
          ICE(__FILE__, __func__, __LINE__, emsg[15], __func__, token_names[T_SUBTRACT]);
      }
      break;
    case T_MUL:
      debug_printf("node->children[0]->leaftoken->tid=%s,node->children[1]->leaftoken->tid=%s\n",
                   token_names[node->children[0]->leaftoken->tid],
                   token_names[node->children[1]->leaftoken->tid]);
      fold_multiply(node);
      break;
    case T_DIV:
      fold_divide(node);
      break;
    case T_POW:
      fold_power(node);
      break;
    default:
      debug_printf("%s():nothing to do for %s\n", __func__, token_names[node->leaftoken->tid]);
      break;
  }
  if (verbose) {
    // tree may have been modified, so dump resulting tree
    debug_printf("%s():Postfix evaluation plan AFTER iteration:\n", __func__);
    tree_postorder(node, dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  return;
}

//
// This procedure performs constant folding on the tree rooted by
// the node parameter.
//
void fold_numeric_expression(
    treenode *node) {                // Pointer to the root AST node for this numeric expression

  debug_printf("%s BEGIN\n", __func__);
  tree_postorder_rw(node, fold_numeric_node);
  debug_printf("%s END\n", __func__);
  if (verbose) {
    // tree may have been modified, so dump resulting tree
    debug_printf("%s():Postfix evaluation plan:\n", __func__);
    tree_postorder(node, dump_tree_node_string);
    debug_printf("%s", "\n");
    fflush(stdout);
  }
  return;
}

#ifdef UNIT_TEST
#include <errno.h>
#include <getopt.h>

static void dump_tree_node_string2(const treenode *node);
static int test1(void);

static void dump_tree_node_string2(        // Display token text of a node
    const treenode *node) {                // Pointer to the node to dump
  char *thecopy=NULL;
  if ((T_SUBTRACT == node->leaftoken->tid) && (OP_UMINUS == node->oid)) {
    fputs("_ ",stdout);
    return;
  }
  thecopy=trim(strdup(node->leaftoken->toketext));
  printf("%s ", thecopy);
  free(thecopy);thecopy=NULL;
  return;
}

static int test1(void) {
  treenode *root = NULL;
  struct token *curtoken = NULL;

  puts("Original expression: (1+2)+(3+B)\n"
       "        +\n"
       "     /     \\\n"
       "   +         +\n"
       " /   \\     /   \\\n"
       "1     2   3     B\n");
  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 5U;
  root = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 2U;
  root->children[0] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("1");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 1U;
  root->children[0]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("2");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 3U;
  root->children[0]->children[1] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("+");
  curtoken->tid = T_ADD;
  curtoken->lno = 1U;
  curtoken->cno = 8U;
  root->children[1] = create_tree_node2(2U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("3");
  curtoken->tid = T_REAL;
  curtoken->lno = 1U;
  curtoken->cno = 7U;
  root->children[1]->children[0] = create_tree_node2(0U, curtoken);

  curtoken = (struct token *)xmalloc(__FILE__,__func__,__LINE__,sizeof(struct token));
  curtoken->toketext = strdup("B");
  curtoken->tid = T_NVAR;
  curtoken->lno = 1U;
  curtoken->cno = 9U;
  root->children[1]->children[1] = create_tree_node2(0U, curtoken);

  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : 1 2 + 3 B + +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);

  fold_numeric_expression(root);
  puts("Folded expression: 3+(3+B)\n"
       "     +\n"
       "  /     \\\n"
       "3         +\n"
       "        /   \\\n"
       "       3     B\n\n"
       "Height of tree should print   :3");
  printf("Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : 3 3 B + +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);

  fold_numeric_expression(root);
  puts("Fold unfoldable expression: 3+(3+B)\n"
       "     +\n"
       "  /     \\\n"
       "3         +\n"
       "        /   \\\n"
       "       3     B\n");
  printf("Height of tree should print   :3\n"
         "Height of tree actually prints:%u\n", tree_height(root));
  fputs("Postorder tree traversal should print   : 3 3 B + +\n"
        "Postorder tree traversal actually prints: ", stdout);
  tree_postorder(root, dump_tree_node_string2);
  fputc('\n', stdout);

  tree_delete_all(&root);
  if (root) {
    puts("root is not NULL after tree_delete_all()!");
    return EXIT_FAILURE;
  }
  return EXIT_SUCCESS;
}

int main(int argc, char **argv) {
  int retval=EXIT_SUCCESS;
  int32_t opt; // variable used by getopt() function

  optimization_level=0U;
  extensions=use_SSE4_1=verbose=false;
  use_double=true;
  // process command-line arguments
  while ((opt = getopt(argc, argv, "hsv4O:X")) != -1) {
    char *endptr = NULL;
    switch (opt) {
      case 'X': // eXtensions
        extensions = true;
        break;
      case '4': // use SSE4.1 instructions
        use_SSE4_1 = true;
        break;
      case 's': // use 32bit floating point math
        use_double = false;
        break;
      case 'v': // show verbose diagnostic messages during compilation
        verbose = true;
        break;
      case 'O': // specify the optimization level
        errno = 0;
        optimization_level = (uint8_t)strtol(optarg, &endptr, 10);
        if ((errno != 0) && (0U == optimization_level)) {
          fputs("Bogus argument to -O; you must use an integer\n", stderr);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (endptr == optarg) {
          fprintf(stderr, "Bogus or missing argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (*endptr != '\0') {
          fprintf(stderr, "trailing garbage in argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        if (optimization_level > MAX_OPTIMIZATION_LEVEL) {
          fprintf(stderr, "Bogus argument to -O; you must use an integer between 0 and %u\n",
                  MAX_OPTIMIZATION_LEVEL);
          retval = EXIT_FAILURE;
          goto xit;
        }
        break;
      case 'h': // show help (usage) information and exit
        usage(argv[0], false);
        retval = EXIT_SUCCESS;
        goto xit;
      default: // unknown option encountered
        fputs("Unknown option\n", stderr);
        retval = EXIT_FAILURE;
        goto xit;
    }
  }
  if ((optimization_level > 2U) && (!extensions)) {
    fputs("Optimization levels higher than 2 potentially violate the ECMA-55 standard so\n"
          "you must also specify -X if you want to use those optimization levels\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  // There should be no remaining options
  if ((argc - optind) != 0) {
    fputs("Garbage after last option\n", stderr);
    retval = EXIT_FAILURE;
    goto xit;
  }
  init_debug_printf(stderr);
  retval=test1();
  if (EXIT_SUCCESS!=retval)
    goto xit;
xit:
#ifdef MJOLNIR
  myshowleakdata();
#endif
  return retval;
}
#endif
