//
// zonermore.c - This is C version of the print zone support
//               for Mr. Ham's ECMA-55 Minimal BASIC compiler.
//
// Copyright (C) 2014,2015,2016,2017,2018,2019,2020,2021  John Gatewood Ham
//
// This file is part of ecma55.
//
// ecma55 is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License version 2
// as published by the Free Software Foundation.
//
// ecma55 is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with ecma55.  If not, see <http://www.gnu.org/licenses/>.
//
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define __NR_write 1UL
#define OUTPUT_WIDTH 132                 // number of ASCII character per output line
                                         // 80 for narrow, 132 for wide
#define MAX_ZONE 5                       // maximum zone number, zones go from 1 to 5
#if OUTPUT_WIDTH == 80
#define ZONE_WIDTH 15                    // EXRAD_WIDTH = 2, SIGNIFICANCE_WIDTH = 7
                                         // Need room for leading sign/space, the E and it's sign/space,
                                         // and a decimal, and a trailing space
                                         // 7 + 2 + 1 + 2 + 1 + 1 = 14    FUDGE FACTOR is 1
#elif OUTPUT_WIDTH == 132
#define ZONE_WIDTH 26                    // EXRAD_WIDTH = 3, SIGNIFICANCE_WIDTH = 18
                                         // Need room for leading sign/space, the E and it's sign/space,
                                         // and a decimal, and a trailing space
                                         // 18 + 3 + 1 + 2 + 1 + 1 = 26
#else
#define ZONE_WIDTH (OUTPUT_WIDTH / MAX_ZONE) // width of one print zone
#endif
static char OBUF[OUTPUT_WIDTH + 1] = "OUTPUT BUFFER IS UNINITIALIZED"; // the actual one-line output buffer
static unsigned long int obuf_next = 1UL;  // next byte of output buffer to use
static unsigned long int curzone = 1UL;    // current zone to use for output

void initbuf(void);
void outputbuf(void);
void outputbuf2(void);
void appendbuf(const char *s);
void tab(unsigned long int column);
void nextzone(unsigned long int forceit);

//
// This procedure implements the Minimal BASIC TAB() function.  The unsigned
// integer argument is the column number.  If a value of zero is specified an
// error occurs and the entire program will abort after printing the error
// message.  If the column is greater than OUTPUT_WIDTH, then it will be
// brought into range by dividing column by OUTPUT_WIDTH and using the
// remainder as the value for column.  Once the columnt is in the range
// 1..OUTPUT_WIDTH inclusive, the TAB() function will set obuf_next to the
// value specifed by the column argument, unless that is less than obuf_next,
// in which case the current line will be output and then the obuf_next will be
// set to the value of column.  Note that the TAB() function in ECMA-55 Minimal
// BASIC takes a floating point value and rounds it to an integer.  This
// function is called after that conversion using the integer value which is
// the result of that conversion.  Columns and zones are 1-based.
//
void tab(
    unsigned long int column) {

  if (column < 1UL) {                          // if bad input parameter then print error message
    signed long int ret;

    __asm__ volatile (
          "syscall"
          : "=a" (ret)
          : "0"(__NR_write), "D"(STDERR_FILENO), "S"("ERROR: tab column is less than minimum output column 1\n"), "d"(55U)
          : "cc", "rcx", "r11", "memory"
    );
    abort();                                   // and abort program
  }
  if (column > OUTPUT_WIDTH)                   // if they try to use a column greater than the maximum then
    column = column % OUTPUT_WIDTH;            // wrap around to a column that can be used
  if (column < obuf_next)                      // if we had to wrap around
    outputbuf();                               // output the current contents of the output buffer
  obuf_next = column;                          // update output column
  curzone = ((column - 1U) / ZONE_WIDTH) + 1U; // update output zone
  return;
}

//
// This procedure will initialize the output system.  It will first initialize
// the output buffer to all spaces.  Then it will set the current output
// position in the buffer to 1, and set the current output zone to 1.
// Columns and zones are 1-based.
//
void initbuf(void) {
  unsigned long int i;                 // position in output buffer

  for (i = 0UL; i < OUTPUT_WIDTH; i++) // initialize output buffer contents
    OBUF[i] = ' ';                     // to all spaces
  OBUF[OUTPUT_WIDTH] = (char)0;        // terminate the output buffer
  obuf_next = curzone = 1UL;           // set output position to first column and first zone
  return;
}

//
// This procedure will first terminate the output buffer contents so that
// it is a valid ASCIIZ string.  Then it writes the output buffer contents
// to STDOUT, followed by a newline.  If either write fails, the program
// will abort.  If the writes are successful, then the output buffer is
// re-initialized by calling the initbuf() procedure.
//
void outputbuf(void) {
  signed long int ret;

  OBUF[OUTPUT_WIDTH] = (char)0;
  __asm__ volatile (
        "syscall"
        : "=a" (ret)
        : "0"(__NR_write), "D"(STDOUT_FILENO), "S"(OBUF), "d"(OUTPUT_WIDTH)
        : "cc", "rcx", "r11", "memory"
  );
  if (ret < 0L)                                 // if the write fails
    abort();                                    // abort the program (no error can be displayed)
  __asm__ volatile (
        "syscall"
        : "=a" (ret)
        : "0"(__NR_write), "D"(STDOUT_FILENO), "S"("\n"), "d"(1U)
        : "cc", "rcx", "r11", "memory"
  );
  if (ret < 0L)                                 // if the write fails
    abort();                                    // abort the program (no error can be displayed)
  initbuf();                                    // re-initialize buffer
  return;
}

//
// This procedure will first terminate the output buffer contents so that
// it is a valid ASCIIZ string.  Then it write thes output buffer contents
// to STDOUT.  If the write fails, the program will abort.  If the write is
//  successful, then the output buffer is re-initialized by calling the
// initbuf() procedure.
//
void outputbuf2(void) {
  signed long int ret;
  if (1U == obuf_next)
    return;
  OBUF[obuf_next] = (char)0;

  __asm__ volatile (
        "syscall"
        : "=a" (ret)
        : "0"(__NR_write), "D"(STDOUT_FILENO), "S"(OBUF), "d"(obuf_next-1)
        : "cc", "rcx", "r11", "memory"
  );
  if (ret < 0L)                                 // if the write fails
    abort();                                    // abort the program (no error can be displayed)
  initbuf();                                    // re-initialize buffer
  return;
}

//
// This procedure will cause the ASCIIZ string specified by the s parameter
// to be output to STDOUT through the buffered print system.
// Columns and zones are 1-based.
//
void appendbuf(
    const char *s) {
  unsigned long int slen;                          // length of ASCIIZ string s
  unsigned long int i = 0UL;                       // index of position in ASCIIZ string s, zero-based
  unsigned long int newpos;                        // column position of start of current zone

  if (!s) {                                        // if argument was bogus then
    signed long int ret;

    __asm__ volatile (
          "syscall"
          : "=a" (ret)
          : "0"(__NR_write), "D"(STDERR_FILENO), "S"("NULL pointer sent to appendbuf\n"), "d"(32U)
          : "cc", "rcx", "r11", "memory"
    );
    abort();
  }
  newpos = ((curzone - 1UL) * ZONE_WIDTH) + 1UL;   // calculate start columnt of current zone
  if (obuf_next < newpos)                          // if output position is less than current zone then
    obuf_next = newpos;                            // move to start of current zone
  slen = strlen(s);                                // calculate length of string s
  if ((obuf_next > 1UL) &&                         // if the output position is not the first column
      (obuf_next + slen - 1UL > OUTPUT_WIDTH))     // and s will not fit on this line then
    outputbuf();                                   // output buffer and a newline and move to column 1
  while (i < slen) {                               // while there are characters (bytes) in string s
    OBUF[obuf_next++ - 1] = s[i++];                // copy the character from s to the output buffer
    if ((i < slen) && (obuf_next > OUTPUT_WIDTH))  // if the output buffer is full but we are not at the end of s
      outputbuf();                                 // output buffer and a newline and move to column 1
  }
  curzone = ((obuf_next - 1UL) / ZONE_WIDTH) + 1UL;// update curzone zone number to next available zone
  return;
}

//
// This procedure will update the current zone to the next avaiable zone, wrapping
// back to zone 1 after zone 5.  If the forceit parameter is one then move to the next
// output zone even if we are on the first character of an output zone already.  If
// forceit is zero and we are on the first character of an output zone already, do
// nothing.
//
void nextzone(
    unsigned long int forceit) {
  unsigned long int next = curzone + 1UL;      // next is the next print zone

  if ((0UL == forceit) &&                      // if we do not want to force a move
      (obuf_next > 1UL) &&                     // and the buffer position is not the first position
      (((obuf_next - 1UL) % ZONE_WIDTH) == 0UL)) // and we are already at the start of a zone
    return;                                    // do nothing
  if (next > MAX_ZONE) {                       // if the next zone is past the last zone
    outputbuf();                               // output the current buffered line
    next = 1UL;                                // then use zone 1 on the next line
  }
  curzone = next;                              // update the current zone value
  obuf_next = (curzone - 1UL) * ZONE_WIDTH;    // move current output position to start of (new) current zone
  return;
}

// everything after this line is self-test code and is not part of the actual runtime library
#ifdef UNIT_TEST
#include <assert.h>
#define YES 1UL
#define NO 0UL
static char *genheaderline0(void);
static char *genheaderline1(void);
static char *genheaderline2(void);

static char *genheaderline0(void) {
  static char buffer[OUTPUT_WIDTH + 1] = { 0 };
  unsigned int i;

  for (i = 0U; i < OUTPUT_WIDTH; ++i)
    buffer[i] = "0123456789"[(i+1) / 100U];
  buffer[OUTPUT_WIDTH] = 0;
  return &buffer[0];
}

static char *genheaderline1(void) {
  static char buffer[OUTPUT_WIDTH + 1] = { 0 };
  unsigned int i;

  for (i = 0U; i < OUTPUT_WIDTH; ++i)
    buffer[i] = (char)('0' + ((i % 100U + 1U) / 10U) % 10U); // not pretty
  buffer[OUTPUT_WIDTH] = 0;
  return &buffer[0];
}

static char *genheaderline2(void) {
  static char buffer[OUTPUT_WIDTH + 1] = { 0 };
  unsigned int i;

  for (i = 0U; i < OUTPUT_WIDTH; ++i)
    buffer[i] = "1234567890"[i % 10U];
  buffer[OUTPUT_WIDTH] = 0;
  return &buffer[0];
}

int main(void) {
  char *hdr0 = NULL;                // (optional) line to show first digit (if OUTPUT_WIDTH>99) (the 1 in 123)
  char *hdr1 = genheaderline1();    // line to show column second-to-last digit (the 3 in 32)
  char *hdr2 = genheaderline2();    // line to show column last digit (the 2 in 32)

  if (OUTPUT_WIDTH > 99)
    hdr0 = genheaderline0();
  initbuf();
  appendbuf("ZONE TEST");
  outputbuf();
  appendbuf("ONE");
  nextzone(NO);
  appendbuf("TWO");
  nextzone(NO);
  appendbuf("THREE");
  nextzone(NO);
  appendbuf("FOUR");
  nextzone(NO);
  appendbuf("FIVE");
  nextzone(NO);
  appendbuf("12345678901234");
  nextzone(NO);
  appendbuf("OK?");
  outputbuf();
  nextzone(YES);
  nextzone(YES);
  appendbuf("THREE");
  outputbuf();
                               // force a blank line to be output
  outputbuf();
  appendbuf("UH... ");
  appendbuf(hdr2);
  outputbuf();
  appendbuf(hdr2);
  outputbuf();
  appendbuf(hdr2);
  appendbuf("1234567890");
  nextzone(NO);
  appendbuf("DONE");
  outputbuf();
  if (OUTPUT_WIDTH > 99) {
    appendbuf(hdr0);
    outputbuf();
  }
  appendbuf(hdr1);
  outputbuf();
  appendbuf(hdr2);
  outputbuf();
  tab(OUTPUT_WIDTH - 1);
  appendbuf("1");
  outputbuf();
  tab(10);
  appendbuf("A");
  tab(40);
  appendbuf("A");
  nextzone(NO);
  appendbuf("A");
  tab(OUTPUT_WIDTH);
  appendbuf("1");
  outputbuf();
  appendbuf("<FIFTEEN BYTES>");
  nextzone(NO);
  appendbuf("*FIFTEEN BYTES*");
  outputbuf();
  appendbuf("<FIFTEEN BYTES>");
  nextzone(YES);
  appendbuf("*FIFTEEN BYTES*");
  outputbuf();
  tab(10);
  appendbuf("<FIFTEEN BYTES>");
  nextzone(NO);
  appendbuf("*FIFTEEN BYTES*");
  nextzone(YES);
  appendbuf("[FIFTEEN BYTES]");
  outputbuf();
  if (OUTPUT_WIDTH > 99) {
    appendbuf(hdr0);
    outputbuf();
  }
  appendbuf(hdr1);
  outputbuf();
  appendbuf(hdr2);
  outputbuf();
  tab(70);
  appendbuf("seventy");
  tab(10);                     // equivalent to newline, then tab(10)
  appendbuf("ten");
  tab(14);
  appendbuf("tins");
                               // should see '          ten tins'
  outputbuf();
  if (OUTPUT_WIDTH > 99) {
    appendbuf(hdr0);
    outputbuf();
  }
  appendbuf(hdr1);
  outputbuf();
  appendbuf(hdr2);
  outputbuf();
  tab(3 * OUTPUT_WIDTH + 10);  // equivalent to newline, then tab(10)
  appendbuf("ten");
                               // should see '          ten'
  outputbuf();
  if (OUTPUT_WIDTH > 99) {
    appendbuf(hdr0);
    outputbuf();
  }
  appendbuf(hdr1);
  outputbuf();
  appendbuf(hdr2);
  outputbuf();
  nextzone(YES);
  nextzone(YES);
  nextzone(YES);
  nextzone(YES);
  tab(5);
  appendbuf("HI");
                               // should see newline (a blank line), then '     HI'
  outputbuf();
  if (OUTPUT_WIDTH > 99) {
    appendbuf(hdr0);
    outputbuf();
  }
  appendbuf(hdr1);
  outputbuf();
  appendbuf(hdr2);
  outputbuf();
  nextzone(YES);
  nextzone(YES);
  nextzone(YES);
  appendbuf("-2.225073858507201E-308 ");
  appendbuf(" MOVE INTO LAST ZONE");
  nextzone(YES);
  nextzone(YES);
  appendbuf("HI");
  outputbuf();

                               // now to simulate a partial flush
  appendbuf("INPUT X");
  appendbuf("? ");
  outputbuf2();
  sleep(5);
  appendbuf("123");
  outputbuf();
  return EXIT_SUCCESS;
}
#endif
